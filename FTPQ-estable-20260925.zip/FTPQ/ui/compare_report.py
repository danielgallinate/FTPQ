"""Formateo y exportación de resultados compare."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from core.compare_export_paths import suggest_compare_export_path
from core.compare_types import CompareExample, CompareResult
from ui.i18n import tr


def format_compare_result(result: CompareResult) -> str:
    if result.status == "abort":
        return tr(
            "compare.result.abort",
            reason=result.abort_reason,
            name_a=result.file_a.label,
            name_b=result.file_b.label,
        )

    keys_line = tr("compare.result.no_keys")
    if result.keys_used:
        keys_line = tr("compare.result.keys", keys=", ".join(result.keys_used))

    status_key = "compare.result.match" if result.status == "match" else "compare.result.diff"
    lines = [
        tr(status_key),
        "",
        tr(
            "compare.result.files",
            name_a=result.file_a.label,
            size_a=f"{result.file_a.file_size:,}",
            rows_a=f"{result.file_a.row_count:,}",
            name_b=result.file_b.label,
            size_b=f"{result.file_b.file_size:,}",
            rows_b=f"{result.file_b.row_count:,}",
        ),
        keys_line,
        "",
        tr("compare.result.summary_heading"),
        tr(
            "compare.result.delta_rows",
            delta=_signed_int(result.row_delta),
        ),
        tr(
            "compare.result.delta_bytes",
            delta=_signed_int(result.size_delta),
        ),
        tr(
            "compare.result.matched_rows",
            matched=f"{result.matched_rows:,}",
            pct=f"{result.match_pct:.2f}",
        ),
        tr(
            "compare.result.signatures",
            shared=f"{result.shared_signatures:,}",
            only_a=f"{result.only_in_a:,}",
            only_b=f"{result.only_in_b:,}",
        ),
        tr("compare.result.columns", count=f"{result.column_count:,}"),
        "",
        tr(
            "compare.result.counts",
            only_a=f"{result.only_in_a:,}",
            only_b=f"{result.only_in_b:,}",
        ),
    ]
    if result.duplicate_excess:
        lines.append(tr("compare.result.duplicate_excess"))

    grouped = _group_examples(result.examples)
    for kind, heading_key in (
        ("only_a", "compare.examples.only_a"),
        ("only_b", "compare.examples.only_b"),
        ("key_only_a", "compare.examples.key_only_a"),
        ("key_only_b", "compare.examples.key_only_b"),
        ("duplicate_excess", "compare.examples.duplicate_excess"),
    ):
        items = grouped.get(kind, [])
        if not items:
            continue
        lines.append("")
        lines.append(tr(heading_key))
        for item in items:
            lines.append(f"  · {_format_example_line(item)}")

    lines.extend(["", tr("compare.result.export_footer", generated=_export_timestamp())])
    return "\n".join(lines)


def export_compare_result(result: CompareResult, path: Path) -> None:
    path.write_text(format_compare_result(result) + "\n", encoding="utf-8")


def default_export_path(result: CompareResult, folder: Path) -> Path:
    return suggest_compare_export_path(folder, result.status)


def _format_example_line(example: CompareExample) -> str:
    if example.kind in ("only_a", "key_only_a") and example.line_a > 0:
        return tr("compare.example.row_a", line=example.line_a, text=example.text)
    if example.kind in ("only_b", "key_only_b") and example.line_b > 0:
        return tr("compare.example.row_b", line=example.line_b, text=example.text)
    return example.text


def _signed_int(value: int) -> str:
    if value > 0:
        return f"+{value:,}"
    return f"{value:,}"


def _export_timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _group_examples(examples: tuple[CompareExample, ...]) -> dict[str, list[CompareExample]]:
    grouped: dict[str, list[CompareExample]] = {}
    for example in examples:
        grouped.setdefault(example.kind, []).append(example)
    return grouped
