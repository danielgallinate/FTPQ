"""Worker compare tabular — hilo aparte."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from PySide6.QtCore import QObject, Signal

from adapters.pandas_compare import compare_tabular_files
from core.app_log import log_event, log_exception
from core.app_profile import AppProfile
from core.compare_types import CompareFileSide, CompareResult
from core.result import Ok


@dataclass(frozen=True, slots=True)
class CompareJob:
    path_a: Path
    path_b: Path
    label_a: str
    label_b: str
    profile: AppProfile
    keys: tuple[str, ...] = ()


class CompareWorker(QObject):
    finished = Signal(object)
    progress = Signal(str)
    compare_requested = Signal(object)

    def __init__(self) -> None:
        super().__init__()
        self.compare_requested.connect(self._do_compare)

    def _do_compare(self, job: object) -> None:
        if not isinstance(job, CompareJob):
            return
        try:
            log_event(f"compare start {job.label_a} vs {job.label_b}")
            self.progress.emit("read")
            result = compare_tabular_files(
                job.path_a,
                job.path_b,
                label_a=job.label_a,
                label_b=job.label_b,
                profile=job.profile,
                keys=job.keys,
            )
            self.progress.emit("done")
            log_event("compare done")
            self.finished.emit(result)
        except Exception as exc:  # noqa: BLE001
            log_exception("compare", exc)
            self.finished.emit(
                Ok(
                    CompareResult(
                        status="abort",
                        file_a=CompareFileSide(
                            label=job.label_a, path=job.path_a, file_size=0
                        ),
                        file_b=CompareFileSide(
                            label=job.label_b, path=job.path_b, file_size=0
                        ),
                        abort_reason=str(exc),
                    )
                )
            )
