"""Worker de análisis tabular — hilo aparte del SFTP."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QObject, Signal, Slot

from adapters.pandas_analyzer import analyze_tabular_file
from core.analysis_limits import DEFAULT_MAX_DISPLAY_ROWS, UI_SAMPLE_MAX_ROWS
from core.analysis_errors import AnalysisError, AnalysisTooLargeError
from core.app_log import log_event, log_exception
from core.result import Err


class AnalysisWorker(QObject):
    finished = Signal(object)

    analyze_requested = Signal(str, int)

    def __init__(self) -> None:
        super().__init__()

    @Slot(str, int)
    def _do_analyze(self, path_str: str, max_display_rows: int) -> None:
        path = Path(path_str)
        limit = max_display_rows if max_display_rows > 0 else DEFAULT_MAX_DISPLAY_ROWS
        try:
            size = path.stat().st_size if path.is_file() else 0
            log_event(f"analyze start {path.name} ({size:,} bytes, max_rows={limit:,})")
            result = analyze_tabular_file(
                path,
                max_display_rows=limit,
                sample_rows=min(limit, UI_SAMPLE_MAX_ROWS),
            )
            log_event(f"analyze done {path.name}")
        except MemoryError as exc:
            log_exception("analyze MemoryError", exc)
            result = Err(
                AnalysisTooLargeError(
                    "Memoria insuficiente para analizar este archivo. "
                    "Pruebe un CSV más pequeño o cierre otras apps.",
                    path=str(path),
                    file_size=size if path.is_file() else 0,
                    limit_bytes=0,
                )
            )
        except Exception as exc:  # noqa: BLE001
            log_exception("analyze", exc)
            result = Err(AnalysisError(str(exc)))
        self.finished.emit(result)
