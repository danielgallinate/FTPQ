"""Operaciones SFTP de sesión persistente — un solo hilo (Paramiko no es thread-safe)."""
from __future__ import annotations

from PySide6.QtCore import QObject, Signal, Slot

from core.app_profile import AppProfile
from core.app_log import log_event, log_exception
from core.result import Err
from core.sftp_errors import SftpError, TransferCancelledError
from ui.app_controller import AppController


class SftpSessionWorker(QObject):
    """Worker que vive en un único QThread; serializa connect/list/download/visualize."""

    finished = Signal(object)
    progress = Signal(str)

    connect_requested = Signal(object)
    list_requested = Signal(str)
    download_requested = Signal(str, str, bool)
    visualize_requested = Signal(str)
    cancel_transfer_requested = Signal()

    def __init__(self, controller: AppController) -> None:
        super().__init__()
        self._controller = controller
        self.connect_requested.connect(self._do_connect)
        self.list_requested.connect(self._do_list)
        self.download_requested.connect(self._do_download)
        self.visualize_requested.connect(self._do_visualize)
        self.cancel_transfer_requested.connect(self._do_cancel_transfer)

    def _do_connect(self, profile: AppProfile) -> None:
        self._safe_emit(lambda: self._controller.connect_and_list(profile), "connect")

    def _do_list(self, remote_path: str) -> None:
        self._safe_emit(
            lambda: self._controller.list_remote_dir(remote_path),
            f"list {remote_path}",
        )

    def _do_download(self, filename: str, local_path: str, force: bool) -> None:
        from pathlib import Path

        destination = Path(local_path)
        self._run_with_progress(
            lambda fn: self._controller.download_remote_file(
                fn, destination, force=force
            ),
            filename,
            context=f"download {filename}",
        )

    def _do_visualize(self, filename: str) -> None:
        self._run_with_progress(
            self._controller.visualize_remote_file,
            filename,
            context=f"visualize {filename}",
        )

    @Slot()
    def _do_cancel_transfer(self) -> None:
        log_event("cancel transfer requested")
        try:
            self._controller.cancel_transfer()
        except Exception as exc:  # noqa: BLE001
            log_exception("cancel transfer", exc)

    def _safe_emit(self, operation, context: str) -> None:
        try:
            self._emit(operation())
        except Exception as exc:  # noqa: BLE001
            log_exception(context, exc)
            self._emit(Err(SftpError(str(exc))))

    def _run_with_progress(self, operation, filename: str, *, context: str) -> None:
        def on_progress(transferred: int, total: int) -> None:
            self.progress.emit(_format_download_progress(transferred, total))

        log_event(f"{context} start")
        self._controller.set_download_progress_handler(on_progress)
        try:
            result = operation(filename)
        except TransferCancelledError as exc:
            log_event(f"{context} cancelled")
            result = Err(exc)
        except Exception as exc:  # noqa: BLE001
            log_exception(context, exc)
            result = Err(SftpError(str(exc)))
        finally:
            self._controller.set_download_progress_handler(None)
        log_event(f"{context} finished")
        self._emit(result)

    @Slot()
    def disconnect_browser(self) -> None:
        try:
            self._controller.browser.disconnect()
        except Exception as exc:  # noqa: BLE001
            log_exception("shutdown disconnect", exc)

    def _emit(self, result: object) -> None:
        try:
            self.finished.emit(result)
        except Exception as exc:  # noqa: BLE001
            self.finished.emit(Err(SftpError(str(exc))))


def _format_download_progress(transferred: int, total: int) -> str:
    if total > 0:
        pct = min(100, transferred * 100 // total)
        return f"{pct}% · {_human_bytes(transferred)} / {_human_bytes(total)}"
    return f"{_human_bytes(transferred)} transferidos"


def _human_bytes(size: int) -> str:
    if size >= 1_048_576:
        return f"{size / 1_048_576:.1f} MB"
    if size >= 1024:
        return f"{size / 1024:.1f} KB"
    return f"{size} B"
