"""Shell T invertida — layout 2:1:1 vertical, 2:1 horizontal arriba."""
from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import QObject, Qt, QThread, Signal, Slot, QMetaObject
from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QMessageBox,
    QFileDialog,
    QSplitter,
    QStackedWidget,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

from core.app_profile import AppProfile
from core.app_log import log_file_display, log_exception, log_event
from core.analysis_types import is_tabular_extension
from core.compare_policy import preflight_compare_paths
from core.compare_types import ComparePick
from core.file_view import read_text_head_preview, read_visualize_file
from core.visualization_policy import tabular_uses_pandas
from core.sftp_paths import join_remote_path
from core.local_browser import (
    LocalListing,
    default_start_path,
    list_directory,
    resolve_folder_open,
)
from core.result import Err, Ok
from core.sftp_errors import SftpError, TransferCancelledError
from core.sftp_types import RemoteEntry, SftpListing, VisualizeResult
from core.download_paths import next_versioned_path
from ui.app_controller import AppController
from ui.dialogs.download_collision import DownloadCollisionChoice, ask_download_collision
from ui.chrome.file_actions_menu import show_file_actions_menu, show_local_file_actions_menu
from ui.chrome.header_bar import build_header_bar
from ui.chrome.menu_bar import apply_menu_translations
from ui.i18n import language_changed, tr
from ui.compare_report import (
    default_export_path,
    export_compare_result,
    format_compare_result,
)
from ui.dialogs.compare_keys import ask_compare_keys
from ui.shell.analysis_worker import AnalysisWorker
from ui.shell.compare_worker import CompareJob, CompareWorker
from ui.widgets.browser_mode_bar import BrowserLayoutMode, BrowserModeBar
from ui.panels.local_file_panel import LocalFilePanel
from ui.panels.local_file_sort import local_entry_to_row
from ui.shell.sftp_session_worker import SftpSessionWorker
from ui.panels.assistant_panel import AssistantPanel
from ui.panels.detail_panel import DetailPanel
from ui.panels.navigator_panel import NavigatorPanel
from ui.panels.query_panel import QueryPanel
from ui.theme.theme_engine import ChromeMode, ThemeEngine, WallpaperHost
from ui.theme.app_icon import apply_app_icon
from ui.theme.icon_store import install_icon, pick_icon_source
from ui.theme.wallpaper_store import (
    install_wallpaper,
    pick_wallpaper_source,
    resolve_wallpaper_path,
)
from ui.version import display_version


class _SftpTestWorker(QObject):
    finished = Signal(object)

    def __init__(self, controller: AppController, draft: AppProfile) -> None:
        super().__init__()
        self._controller = controller
        self._draft = draft

    def run(self) -> None:
        try:
            result = self._controller.test_sftp(self._draft)
        except Exception as exc:  # noqa: BLE001 — hilo UI; nunca colgar botones
            result = Err(SftpError(str(exc)))
        self.finished.emit(result)


class MainWindow(QMainWindow):
    def __init__(
        self,
        *,
        theme: ThemeEngine,
        controller: AppController | None = None,
    ) -> None:
        super().__init__()
        language_changed().connect(self._retranslate_ui)
        self._theme = theme
        self._controller = controller or AppController()
        self._test_thread: QThread | None = None
        self._test_worker: _SftpTestWorker | None = None
        self._sftp_thread = QThread(self)
        self._sftp_worker = SftpSessionWorker(self._controller)
        self._sftp_worker.moveToThread(self._sftp_thread)
        self._sftp_worker.finished.connect(
            self._on_sftp_session_finished,
            Qt.ConnectionType.QueuedConnection,
        )
        self._sftp_worker.progress.connect(
            self._on_sftp_download_progress,
            Qt.ConnectionType.QueuedConnection,
        )
        self._sftp_thread.start()
        self._analysis_thread = QThread(self)
        self._analysis_worker = AnalysisWorker()
        self._analysis_worker.moveToThread(self._analysis_thread)
        self._analysis_worker.analyze_requested.connect(
            self._analysis_worker._do_analyze,
            Qt.ConnectionType.QueuedConnection,
        )
        self._analysis_worker.finished.connect(
            self._on_analysis_finished,
            Qt.ConnectionType.QueuedConnection,
        )
        self._analysis_thread.start()
        self._compare_thread = QThread(self)
        self._compare_worker = CompareWorker()
        self._compare_worker.moveToThread(self._compare_thread)
        self._compare_worker.finished.connect(
            self._on_compare_finished,
            Qt.ConnectionType.QueuedConnection,
        )
        self._compare_worker.progress.connect(
            self._on_compare_progress,
            Qt.ConnectionType.QueuedConnection,
        )
        self._compare_thread.start()
        self._analysis_busy = False
        self._analysis_cancel_requested = False
        self._compare_cancel_requested = False
        self._last_compare_result = None
        self._compare_root_split_sizes: list[int] | None = None
        self._visualize_top_split_sizes: list[int] | None = None
        self._visualize_root_split_sizes: list[int] | None = None
        self._pending_visualize_meta: dict | None = None
        self._last_progress_text = ""
        self._last_progress_at = 0.0
        self._sftp_busy = False
        self._sftp_op = ""
        self._current_sftp_path = "."
        self._pending_file: dict | None = None
        self._visualize_mode_active = False
        self._file_manager_active = False
        self._browser_mode = BrowserLayoutMode.SFTP_LOCAL
        self._local_browser_path: Path | None = None
        self._local1_browser_path: Path | None = None
        self._pending_local_file: dict | None = None
        self._pending_local1_file: dict | None = None
        self._compare_pick_a: ComparePick | None = None
        self._compare_pick_b: ComparePick | None = None
        self._compare_busy = False
        self._pending_compare_after_download: str | None = None
        self._shutdown_done = False
        self.setWindowTitle(tr("app.window_title", version=display_version()))
        self.resize(1100, 720)

        self._navigator = NavigatorPanel()
        self._local1 = LocalFilePanel(title_key="panel.local_side_a")
        self._browser_mode_bar = BrowserModeBar()
        self._browser_mode_bar.hide()
        self._left_stack = QStackedWidget()
        self._left_stack.addWidget(self._navigator)
        self._left_stack.addWidget(self._local1)
        self._browser_left = QWidget()
        browser_left_layout = QVBoxLayout(self._browser_left)
        browser_left_layout.setContentsMargins(0, 0, 0, 0)
        browser_left_layout.setSpacing(0)
        browser_left_layout.addWidget(self._left_stack, stretch=1)

        self._detail = DetailPanel()
        self._assistant = AssistantPanel()

        self._top_split = QSplitter(Qt.Orientation.Horizontal)
        self._top_split.addWidget(self._browser_left)
        self._top_split.addWidget(self._detail)
        self._top_split.setStretchFactor(0, 2)
        self._top_split.setStretchFactor(1, 1)
        self._top_split.setHandleWidth(ThemeEngine.SECTION_GAP)
        self._top_split.setChildrenCollapsible(False)

        self._top_area = QWidget()
        top_area_layout = QVBoxLayout(self._top_area)
        top_area_layout.setContentsMargins(0, 0, 0, 0)
        top_area_layout.setSpacing(4)
        top_area_layout.addWidget(self._browser_mode_bar)
        top_area_layout.addWidget(self._top_split, stretch=1)

        self._root_split = QSplitter(Qt.Orientation.Vertical)
        self._root_split.addWidget(self._top_area)
        self._root_split.addWidget(self._assistant)
        self._root_split.setStretchFactor(0, 2)
        self._root_split.setStretchFactor(1, 1)
        self._root_split.setHandleWidth(ThemeEngine.SECTION_GAP)
        self._root_split.setChildrenCollapsible(False)

        self._host = WallpaperHost(theme, wallpaper_path=resolve_wallpaper_path())
        host_layout = QVBoxLayout(self._host)
        host_layout.setContentsMargins(
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
        )
        host_layout.setSpacing(ThemeEngine.SECTION_GAP)

        self._query = QueryPanel(self._host)
        self._query.hide()

        self._header, self._color_button, self._menu_bar, self._menu_state = build_header_bar(
            self._host,
            parent_window=self,
            on_connect=self._connect_sftp,
            on_file_manager=self._toggle_file_manager,
            on_toggle_chrome=self._toggle_chrome,
            on_open_paths=self._open_paths,
            on_open_keys=self._open_keys,
            on_pick_wallpaper=self._pick_wallpaper,
            on_pick_icon=self._pick_icon,
            on_language_picked=self._on_language_picked,
        )
        host_layout.addWidget(self._header)
        host_layout.addWidget(self._root_split, stretch=1)
        self.setCentralWidget(self._host)
        self.menuBar().hide()

        self.setStatusBar(QStatusBar())
        self._set_status_disconnected()

        self._navigator.selection_changed.connect(self._on_navigator_selection)
        self._navigator.folder_open_requested.connect(self._open_remote_folder)
        self._navigator.file_actions_requested.connect(self._show_file_actions)

        local = self._detail.local_files
        local.folder_open_requested.connect(self._open_local_folder)
        local.file_actions_requested.connect(self._show_local_file_actions)
        local.selection_changed.connect(self._on_local_b_selection)

        self._local1.folder_open_requested.connect(self._open_local1_folder)
        self._local1.file_actions_requested.connect(self._show_local1_file_actions)
        self._local1.selection_changed.connect(self._on_local1_selection)

        self._browser_mode_bar.mode_changed.connect(self._on_browser_mode_changed)
        self._browser_mode_bar.compare_requested.connect(self._start_compare)

        keys = self._assistant.keys_panel
        keys.back_requested.connect(self._leave_keys_mode)
        keys.test_requested.connect(self._test_sftp_keys)
        keys.save_requested.connect(self._save_sftp_keys)

        paths = self._assistant.paths_panel
        paths.message.connect(self._detail.show_message)
        paths.back_requested.connect(self._leave_paths_mode)
        paths.save_requested.connect(self._save_paths_config)
        paths.import_env_requested.connect(self._import_env_config)

        compare_report = self._assistant.compare_panel
        compare_report.export_requested.connect(self._export_last_compare_result)
        compare_report.close_requested.connect(self._leave_compare_report)

        self._detail.close_tabular_requested.connect(self._leave_visualize_mode)
        self._detail.cancel_operation_requested.connect(self._cancel_active_operation)

        if self._controller.last_env_import is not None:
            self._detail.show_message(
                tr(
                    "msg.profile_env",
                    origin=self._controller.last_env_import,
                    host=self._controller.profile.host or tr("detail.dash"),
                    user=self._controller.profile.user or tr("detail.dash"),
                )
            )

    def _on_language_picked(self, code: str) -> None:
        self._controller.set_ui_language(code)
        self._retranslate_ui()

    def _text_view_trunc_note(self, view: VisualizeResult) -> str:
        parts: list[str] = []
        if view.text_fallback:
            parts.append(tr("msg.text_fallback_pandas"))
        if view.display_truncated:
            parts.append(tr("msg.trunc_screen"))
        return "".join(parts)

    def _text_view_content_suffix(self, view: VisualizeResult) -> str:
        if not view.display_truncated:
            return ""
        shown = len(view.content.splitlines())
        if view.line_count > shown:
            return tr("msg.lines_omitted", n=view.line_count - shown)
        return ""

    def _present_text_view(
        self,
        *,
        name: str,
        view: VisualizeResult,
        remote: str | Path,
        leave_file_manager: bool = False,
    ) -> None:
        if leave_file_manager:
            self._leave_file_manager()
        text = tr(
            "msg.visualized",
            name=name,
            trunc=self._text_view_trunc_note(view),
            remote=str(remote),
            local=view.local_path,
            bytes=view.file_size,
            lines=view.line_count,
            content=view.content + self._text_view_content_suffix(view),
        )
        self._detail.show_text_view(text, filename=name)
        self._enter_visualize_mode()
        self.statusBar().showMessage(
            tr("status.viewed", name=name, version=display_version())
        )

    def _retranslate_ui(self) -> None:
        apply_menu_translations(self._menu_state)
        self.setWindowTitle(tr("app.window_title", version=display_version()))
        self._color_button.retranslate_ui()
        self._navigator.retranslate_ui()
        self._local1.retranslate_ui()
        self._browser_mode_bar.retranslate_ui()
        self._detail.retranslate_ui()
        self._assistant.retranslate_ui()
        if self._file_manager_active:
            self._menu_state.act_file_manager.setChecked(True)
        if not self._sftp_busy and not self._navigator._path:
            self._set_status_disconnected()

    def _theme_mode_label(self) -> str:
        return self._theme.mode_label()

    def _error_log_footer(self) -> str:
        return tr("err.log_footer", path=log_file_display())

    def _show_operation_error(self, title: str, error: object) -> None:
        if isinstance(error, BaseException):
            log_exception(title, error)
        else:
            log_event(f"{title}: {error}")
        self._detail.show_message(f"{title}\n\n{error}{self._error_log_footer()}")

    def _merged_keys_draft(self) -> AppProfile:
        """Llaves + host/carpetas ya guardados."""
        draft = self._assistant.keys_panel.build_draft_profile()
        saved = self._controller.profile
        if not draft.host.strip():
            draft.host = saved.host
        if draft.port == 22 and saved.port != 22:
            draft.port = saved.port
        if not str(draft.ssh_keys_dir).strip():
            draft.ssh_keys_dir = saved.ssh_keys_dir
        return draft

    def _set_settings_focus_layout(self, focused: bool) -> None:
        """Oculta navegador + detalle; el asistente (config) usa todo el alto."""
        self._top_area.setVisible(not focused)

    def _open_paths(self) -> None:
        if self._file_manager_active:
            self._leave_file_manager()
        if self._assistant.is_keys_mode():
            self._leave_keys_mode()
        if self._assistant.is_paths_mode():
            self._assistant.paths_panel.refresh()
        else:
            self._assistant.enter_paths_mode(self._controller.profile)
        self._set_settings_focus_layout(True)
        self.statusBar().showMessage(tr("status.paths", version=display_version()))

    def _leave_paths_mode(self) -> None:
        self._assistant.leave_paths_mode()
        self._set_settings_focus_layout(False)
        self._detail.show_message(tr("panel.detail_empty"))
        self._set_status_disconnected()

    def _save_paths_config(self) -> None:
        try:
            draft = self._assistant.paths_panel.build_draft_profile()
            self._controller.save_profile(draft)
            self._assistant.paths_panel.apply_saved_profile(self._controller.profile)
            if self._assistant.keys_panel.is_bound():
                self._assistant.keys_panel.apply_saved_profile(self._controller.profile)
            self._leave_paths_mode()
            self._detail.show_message(
                tr(
                    "msg.paths_saved",
                    host=draft.host or tr("detail.dash"),
                    name=draft.profile_id,
                )
            )
            self.statusBar().showMessage(tr("status.profile_saved", version=display_version()))
        except OSError as exc:
            self._detail.show_message(tr("msg.paths_save_fail", error=exc))

    def _import_env_config(self) -> None:
        path = self._controller.pick_and_import_env(self)
        if path is None:
            return
        profile = self._controller.profile
        self._assistant.paths_panel.apply_imported_profile(profile)
        if self._assistant.keys_panel.is_bound():
            self._assistant.keys_panel.apply_saved_profile(profile)
        self._detail.show_message(
            tr(
                "msg.imported_env",
                path=path,
                host=profile.host or tr("detail.dash"),
                name=profile.profile_id,
            )
        )
        self.statusBar().showMessage(tr("status.imported", version=display_version()))

    def _save_visualize_layout_snapshot(self) -> None:
        if self._visualize_top_split_sizes is not None:
            return
        top_sizes = self._top_split.sizes()
        if sum(top_sizes) > 0:
            self._visualize_top_split_sizes = list(top_sizes)
        root_sizes = self._root_split.sizes()
        if sum(root_sizes) > 0:
            self._visualize_root_split_sizes = list(root_sizes)

    def _restore_visualize_layout_snapshot(self) -> None:
        self._browser_left.setVisible(True)
        self._assistant.setVisible(True)
        if self._visualize_top_split_sizes is not None:
            self._top_split.setSizes(self._visualize_top_split_sizes)
            self._visualize_top_split_sizes = None
        if self._visualize_root_split_sizes is not None:
            self._root_split.setSizes(self._visualize_root_split_sizes)
            self._visualize_root_split_sizes = None
        if self._file_manager_active:
            self._browser_mode_bar.show()
        else:
            self._browser_mode_bar.hide()

    def _set_visualize_focus_layout(self, focused: bool) -> None:
        """Oculta paneles de trabajo; el visualizador usa casi toda la ventana."""
        if focused:
            self._save_visualize_layout_snapshot()
            self._browser_mode_bar.hide()
            self._browser_left.hide()
            self._assistant.hide()
            top_total = (
                sum(self._visualize_top_split_sizes or self._top_split.sizes())
                or max(self._top_split.width(), 800)
            )
            self._top_split.setSizes([0, max(top_total, 1)])
            root_total = (
                sum(self._visualize_root_split_sizes or self._root_split.sizes())
                or max(self._root_split.height(), 600)
            )
            self._root_split.setSizes([max(root_total, 1), 0])
            return
        self._restore_visualize_layout_snapshot()

    def _enter_visualize_mode(self) -> None:
        self._visualize_mode_active = True
        self._set_visualize_focus_layout(True)

    def _leave_visualize_mode(self) -> None:
        self._visualize_mode_active = False
        self._detail.exit_view_mode()
        self._set_visualize_focus_layout(False)
        self._pending_visualize_meta = None
        if self._file_manager_active:
            self._detail.show_local_browser()
            self._refresh_local_listing()
            listing_path = self._detail.local_files._path or tr("local.roots")
            self.statusBar().showMessage(
                tr(
                    "status.file_manager",
                    path=listing_path,
                    version=display_version(),
                )
            )
        else:
            self._detail.show_message(tr("panel.detail_empty"))
            self.statusBar().showMessage(tr("status.browser", version=display_version()))

    def _set_keys_focus_layout(self, focused: bool) -> None:
        self._set_settings_focus_layout(focused)

    def _open_keys(self) -> None:
        if self._file_manager_active:
            self._leave_file_manager()
        if self._assistant.is_paths_mode():
            self._leave_paths_mode()
        if self._assistant.is_keys_mode():
            self._assistant.keys_panel.refresh()
        else:
            self._assistant.enter_keys_mode(
                self._controller.profile,
                self._controller.key_store,
            )
        self._set_keys_focus_layout(True)
        self._assistant.keys_panel.show_feedback(tr("keys.feedback_hint"))
        self.statusBar().showMessage(tr("status.keys", version=display_version()))

    def _leave_keys_mode(self) -> None:
        self._assistant.leave_keys_mode()
        self._set_keys_focus_layout(False)
        self._detail.show_message(tr("panel.detail_empty"))
        self._set_status_disconnected()

    def _save_sftp_keys(self) -> None:
        try:
            draft = self._merged_keys_draft()
            self._controller.save_profile(draft)
            self._assistant.keys_panel.apply_saved_profile(self._controller.profile)
            if self._assistant.paths_panel._profile is not None:
                self._assistant.paths_panel.apply_saved_profile(
                    self._controller.profile
                )
            self._leave_keys_mode()
            self._connect_sftp(profile=self._controller.profile)
        except OSError as exc:
            self._assistant.keys_panel.show_feedback(tr("msg.keys_save_fail", error=exc))

    def _test_sftp_keys(self) -> None:
        if self._test_thread is not None and self._test_thread.isRunning():
            return
        draft = self._merged_keys_draft()
        self._assistant.keys_panel.show_feedback(
            tr(
                "msg.test_progress",
                host=draft.host or tr("detail.dash"),
                user=draft.user or tr("detail.dash"),
            )
        )
        self._assistant.keys_panel.set_actions_enabled(False)

        self._test_thread = QThread(self)
        self._test_worker = _SftpTestWorker(self._controller, draft)
        self._test_worker.moveToThread(self._test_thread)
        self._test_thread.started.connect(self._test_worker.run)
        self._test_worker.finished.connect(
            self._on_sftp_test_finished,
            Qt.ConnectionType.QueuedConnection,
        )
        self._test_worker.finished.connect(self._test_thread.quit)
        self._test_thread.finished.connect(self._clear_sftp_test_worker)
        self._test_thread.start()

    def _on_sftp_test_finished(self, result: object) -> None:
        self._assistant.keys_panel.set_actions_enabled(True)
        if isinstance(result, Ok):
            self._assistant.keys_panel.show_feedback(tr("msg.test_ok"))
            self.statusBar().showMessage(tr("status.test_ok", version=display_version()))
            return
        if isinstance(result, Err):
            err = result.error
            self._assistant.keys_panel.show_feedback(tr("msg.test_fail", error=err))
            self.statusBar().showMessage(tr("status.test_fail", version=display_version()))
            return
        self._assistant.keys_panel.show_feedback(
            tr("msg.test_unexpected", result=repr(result))
        )

    def _set_operation_cancel_visible(self, visible: bool) -> None:
        self._detail.set_operation_cancel_visible(visible)

    def _cancel_active_operation(self) -> None:
        if self._compare_busy:
            self._compare_cancel_requested = True
            self._set_operation_cancel_visible(False)
            if (
                self._sftp_busy
                and self._sftp_op == "visualize"
                and self._pending_compare_after_download
            ):
                self._controller.request_cancel_transfer()
                self._sftp_worker.cancel_transfer_requested.emit()
            self.statusBar().showMessage(tr("status.stopping", version=display_version()))
            return
        if self._analysis_busy:
            self._analysis_cancel_requested = True
            self._set_operation_cancel_visible(False)
            self._detail.show_message(tr("msg.cancel_analysis"))
            self.statusBar().showMessage(tr("status.cancel_analysis", version=display_version()))
            return
        if not self._sftp_busy or self._sftp_op not in ("download", "visualize"):
            self._set_operation_cancel_visible(False)
            return
        name = self._pending_file["name"] if self._pending_file else tr("detail.dash")
        label = (
            tr("msg.cancel_download_label")
            if self._sftp_op == "download"
            else tr("msg.cancel_visualize_label")
        )
        self._detail.show_message(tr("msg.cancel_download", label=label, name=name))
        self.statusBar().showMessage(tr("status.stopping", version=display_version()))
        self._controller.request_cancel_transfer()
        self._sftp_worker.cancel_transfer_requested.emit()

    def _connect_sftp(self, *, profile: AppProfile | None = None) -> None:
        if self._sftp_busy:
            return
        if self._assistant.is_keys_mode():
            self._leave_keys_mode()
        draft = profile or self._controller.profile
        self._detail.show_message(
            tr(
                "msg.connecting",
                host=draft.host or tr("detail.dash"),
                user=draft.user or tr("detail.dash"),
            )
        )
        self.statusBar().showMessage(tr("status.connecting", version=display_version()))
        self._sftp_op = "connect"
        self._set_sftp_ui_busy(True)
        self._sftp_worker.connect_requested.emit(draft)

    def _set_sftp_ui_busy(self, busy: bool) -> None:
        self._sftp_busy = busy
        if self._assistant.is_keys_mode():
            self._assistant.keys_panel.set_actions_enabled(not busy)
        self._menu_state.act_connect.setEnabled(not busy)

    def _on_sftp_session_finished(self, result: object) -> None:
        op = self._sftp_op
        self._set_sftp_ui_busy(False)
        if op in ("download", "visualize"):
            self._set_operation_cancel_visible(False)
        if op == "connect":
            self._on_sftp_connect_finished(result)
        elif op == "list":
            self._on_sftp_list_finished(result)
        elif op in ("download", "visualize"):
            self._on_sftp_file_finished(result, op)

    def _on_sftp_download_progress(self, message: str) -> None:
        if self._sftp_op not in ("download", "visualize") or self._pending_file is None:
            return
        now = time.monotonic()
        if message == self._last_progress_text:
            return
        # Evitar redibujar Detalle en cada chunk SFTP (~miles de veces en 60+ MB)
        if now - self._last_progress_at < 0.4 and not message.startswith("100%"):
            self.statusBar().showMessage(
                tr("status.progress", message=message, version=display_version())
            )
            return
        self._last_progress_text = message
        self._last_progress_at = now
        name = self._pending_file["name"]
        label = (
            tr("msg.download_progress")
            if self._sftp_op == "download"
            else tr("msg.download_full")
        )
        self._detail.show_message(f"{label}…\n{name}\n\n{message}")
        self.statusBar().showMessage(
            tr("status.progress", message=message, version=display_version())
        )

    def _on_sftp_connect_finished(self, result: object) -> None:
        if isinstance(result, Ok):
            listing: SftpListing = result.value
            self._apply_listing(listing)
            self.statusBar().showMessage(
                tr(
                    "status.connected",
                    path=listing.display_path or listing.remote_path,
                    version=display_version(),
                )
            )
            return
        if isinstance(result, Err):
            err = result.error
            log_event(f"connect failed: {err}")
            self._navigator.set_disconnected()
            self._show_operation_error(tr("msg.connect_fail"), err)
            self._set_status_disconnected()
            return
        self._detail.show_message(tr("msg.connect_unexpected", result=repr(result)))
        self._set_status_disconnected()

    def _apply_listing(self, listing: SftpListing) -> None:
        self._current_sftp_path = listing.remote_path
        label = listing.display_path or listing.remote_path
        self._navigator.set_path(label)
        self._navigator.set_entries(_entries_for_ui(listing.entries))
        names = [entry.name for entry in listing.entries if entry.name != ".."]
        preview = ", ".join(names[:8])
        if len(names) > 8:
            preview += f" … (+{len(names) - 8})"
        folders = sum(1 for entry in listing.entries if entry.entry_type == "dir")
        files = len(names) - sum(
            1 for entry in listing.entries if entry.name != ".." and entry.entry_type == "dir"
        )
        summary = (
            tr("msg.connected_summary", folders=folders, files=files)
            if names
            else tr("msg.connected_empty")
        )
        self._detail.show_message(
            tr(
                "msg.connected",
                summary=summary,
                path=label,
                preview=preview or tr("msg.no_entries"),
            )
        )

    def _open_remote_folder(self, name: str) -> None:
        if self._sftp_busy:
            return
        target = name.rstrip("/") or name
        self._sftp_op = "list"
        self._set_sftp_ui_busy(True)
        self._sftp_worker.list_requested.emit(target)

    def _on_sftp_list_finished(self, result: object) -> None:
        if isinstance(result, Ok):
            self._apply_listing(result.value)
            return
        if isinstance(result, Err):
            self._show_operation_error(tr("msg.folder_fail"), result.error)

    def _toggle_file_manager(self) -> None:
        if self._menu_state.act_file_manager.isChecked():
            self._enter_file_manager()
        else:
            self._leave_file_manager()

    def _enter_file_manager(self) -> None:
        if self._file_manager_active:
            return
        if self._assistant.is_keys_mode():
            self._leave_keys_mode()
        if self._assistant.is_paths_mode():
            self._leave_paths_mode()
        if self._visualize_mode_active:
            self._leave_visualize_mode()
        self._file_manager_active = True
        self._menu_state.act_file_manager.setChecked(True)
        self._browser_mode_bar.show()
        start = default_start_path(self._controller.profile.download_dir)
        self._local_browser_path = start
        self._local1_browser_path = start
        self._compare_pick_a = None
        self._compare_pick_b = None
        self._apply_browser_mode(self._browser_mode)
        self._update_compare_button()

    def _leave_file_manager(self) -> None:
        if not self._file_manager_active:
            self._menu_state.act_file_manager.setChecked(False)
            return
        self._file_manager_active = False
        self._pending_local_file = None
        self._pending_local1_file = None
        self._compare_pick_a = None
        self._compare_pick_b = None
        self._browser_mode_bar.hide()
        self._menu_state.act_file_manager.setChecked(False)
        self._left_stack.setCurrentWidget(self._navigator)
        self._detail.hide_local_browser()
        self._update_compare_button()
        if not self._visualize_mode_active:
            if self._navigator._path:
                self.statusBar().showMessage(
                    tr(
                        "status.connected",
                        path=self._navigator._path,
                        version=display_version(),
                    )
                )
            else:
                self._set_status_disconnected()

    def _on_browser_mode_changed(self, mode: object) -> None:
        if isinstance(mode, BrowserLayoutMode):
            self._browser_mode = mode
            self._apply_browser_mode(mode)

    def _restore_file_manager_detail_view(self) -> None:
        """Tras compare/error, recuperar Local B según modo activo."""
        if not self._file_manager_active:
            return
        self._apply_browser_mode(self._browser_mode)

    def _apply_browser_mode(self, mode: BrowserLayoutMode) -> None:
        if not self._file_manager_active:
            return
        if mode is BrowserLayoutMode.SFTP_ONLY:
            self._left_stack.setCurrentWidget(self._navigator)
            self._detail.hide_local_browser()
        elif mode is BrowserLayoutMode.SFTP_LOCAL:
            self._left_stack.setCurrentWidget(self._navigator)
            self._detail.show_local_browser()
            self._refresh_local_listing()
        else:
            self._left_stack.setCurrentWidget(self._local1)
            self._detail.show_local_browser()
            self._refresh_local_listing()
            self._refresh_local1_listing()

    def _refresh_local1_listing(self) -> None:
        listing = list_directory(self._local1_browser_path)
        self._apply_local1_listing(listing)

    def _apply_local1_listing(self, listing: LocalListing) -> None:
        self._local1_browser_path = listing.current_path
        self._local1.set_path(listing.display_path)
        self._local1.set_entries(_local_entries_for_ui(listing))

    def _open_local1_folder(self, name: str) -> None:
        target = resolve_folder_open(self._local1_browser_path, name)
        if target is None and name.rstrip("/") != "..":
            return
        self._local1_browser_path = target
        self._refresh_local1_listing()

    def _show_local1_file_actions(self, payload: dict) -> None:
        self._pending_local1_file = payload
        show_local_file_actions_menu(
            self,
            payload["global_pos"],
            on_preview=lambda: self._visualize_local_path(payload.get("absolute_path", "")),
            on_compare_a=lambda: self._assign_compare_pick("a", payload, local=True),
            on_compare_b=lambda: self._assign_compare_pick("b", payload, local=True),
        )

    def _on_navigator_selection(self, payload: dict) -> None:
        self._detail.show_detail(payload)
        if not self._file_manager_active:
            return
        if self._browser_mode is BrowserLayoutMode.LOCAL_LOCAL:
            return
        self._auto_assign_compare_pick("a", payload, local=False)

    def _on_local_b_selection(self, payload: dict) -> None:
        if not self._file_manager_active:
            return
        if self._browser_mode is BrowserLayoutMode.SFTP_ONLY:
            return
        self._auto_assign_compare_pick("b", payload, local=True)

    def _on_local1_selection(self, payload: dict) -> None:
        if not self._file_manager_active:
            return
        if self._browser_mode is not BrowserLayoutMode.LOCAL_LOCAL:
            return
        self._auto_assign_compare_pick("a", payload, local=True)

    @staticmethod
    def _payload_is_compare_file(payload: dict) -> bool:
        name = payload.get("name", "").rstrip("/")
        size = payload.get("size", "")
        if not name or name == "..":
            return False
        return size != tr("nav.dir_marker")

    def _auto_assign_compare_pick(self, side: str, payload: dict, *, local: bool) -> None:
        if not self._payload_is_compare_file(payload):
            return
        name = payload.get("name", "").rstrip("/")
        if not is_tabular_extension(name):
            return
        self._assign_compare_pick(side, payload, local=local)

    def _assign_compare_pick(self, side: str, payload: dict, *, local: bool) -> None:
        name = payload.get("name", "")
        if local:
            raw = payload.get("absolute_path", "")
            if not raw:
                return
            pick = ComparePick(label=name, local_path=Path(raw), is_remote=False)
        else:
            pick = ComparePick(
                label=name,
                remote_name=name,
                is_remote=True,
            )
        if side == "a":
            self._compare_pick_a = pick
        else:
            self._compare_pick_b = pick
        self._update_compare_button()
        self.statusBar().showMessage(
            tr("compare.pick_status", side=side.upper(), name=name, version=display_version())
        )

    def _pick_compare_a_sftp(self) -> None:
        if self._pending_file is None:
            return
        self._assign_compare_pick("a", self._pending_file, local=False)

    def _pick_compare_b_sftp(self) -> None:
        if self._pending_file is None:
            return
        self._assign_compare_pick("b", self._pending_file, local=False)

    def _pick_compare_a_local(self) -> None:
        if self._pending_local_file is None:
            return
        self._assign_compare_pick("a", self._pending_local_file, local=True)

    def _pick_compare_b_local(self) -> None:
        if self._pending_local_file is None:
            return
        self._assign_compare_pick("b", self._pending_local_file, local=True)

    def _update_compare_button(self) -> None:
        ready = (
            self._file_manager_active
            and self._compare_pick_a is not None
            and self._compare_pick_b is not None
            and self._compare_pick_a.is_tabular_candidate()
            and self._compare_pick_b.is_tabular_candidate()
        )
        self._browser_mode_bar.set_compare_enabled(ready)

    def _start_compare(self) -> None:
        if self._compare_busy:
            return
        pick_a = self._compare_pick_a
        pick_b = self._compare_pick_b
        if pick_a is None or pick_b is None:
            return
        if pick_a.is_remote and pick_b.is_remote:
            self._show_operation_error(tr("compare.title"), tr("compare.err_both_remote"))
            return
        self._compare_busy = True
        self._compare_cancel_requested = False
        self._set_operation_cancel_visible(True)
        self.statusBar().showMessage(
            tr("compare.status.progress", msg=tr("compare.stage.start"), version=display_version())
        )
        if pick_a.is_remote:
            self._pending_compare_after_download = "a"
            self._download_for_compare(pick_a.remote_name or pick_a.label)
            return
        if pick_b.is_remote:
            self._pending_compare_after_download = "b"
            self._download_for_compare(pick_b.remote_name or pick_b.label)
            return
        self._continue_compare_with_local_paths()

    def _download_for_compare(self, filename: str) -> None:
        self._pending_file = {"name": filename}
        self._sftp_op = "visualize"
        self._set_sftp_ui_busy(True)
        self._set_operation_cancel_visible(True)
        self.statusBar().showMessage(
            tr("compare.status.progress", msg=tr("compare.stage.download"), version=display_version())
        )
        self._sftp_worker.visualize_requested.emit(filename)

    def _on_compare_progress(self, stage: str) -> None:
        if not self._compare_busy or self._compare_cancel_requested:
            return
        key = "compare.stage.read" if stage == "read" else "compare.stage.analyze"
        self.statusBar().showMessage(
            tr("compare.status.progress", msg=tr(key), version=display_version())
        )

    def _continue_compare_with_local_paths(self) -> None:
        pick_a = self._compare_pick_a
        pick_b = self._compare_pick_b
        if pick_a is None or pick_b is None:
            self._compare_busy = False
            return
        path_a = self._resolve_pick_path(pick_a)
        path_b = self._resolve_pick_path(pick_b)
        if path_a is None or path_b is None:
            self._compare_busy = False
            self._show_operation_error(tr("compare.title"), tr("compare.err_missing_file"))
            return

        pre = preflight_compare_paths(
            path_a,
            path_b,
            label_a=pick_a.label,
            label_b=pick_b.label,
            profile=self._controller.profile,
        )
        if isinstance(pre, Err):
            self._compare_busy = False
            self._set_operation_cancel_visible(False)
            self._present_compare_abort(pre.error.message)
            return

        columns, _, _ = pre.value
        accepted, keys = ask_compare_keys(self, columns)
        if not accepted:
            self._compare_busy = False
            self._set_operation_cancel_visible(False)
            if self._file_manager_active:
                self._restore_file_manager_detail_view()
                self.statusBar().showMessage(tr("compare.cancelled"))
            else:
                self._detail.show_message(tr("compare.cancelled"), force=True)
            return

        job = CompareJob(
            path_a=path_a,
            path_b=path_b,
            label_a=pick_a.label,
            label_b=pick_b.label,
            profile=self._controller.profile,
            keys=keys,
        )
        self._compare_worker.compare_requested.emit(job)

    def _resolve_pick_path(self, pick: ComparePick) -> Path | None:
        if pick.local_path is not None and pick.local_path.is_file():
            return pick.local_path
        return None

    def _on_compare_finished(self, result: object) -> None:
        self._compare_busy = False
        self._set_operation_cancel_visible(False)
        if self._compare_cancel_requested:
            self._compare_cancel_requested = False
            self._restore_file_manager_detail_view()
            self.statusBar().showMessage(tr("status.cancelled", version=display_version()))
            return
        if not isinstance(result, Ok):
            self._show_operation_error(tr("compare.title"), repr(result))
            self._restore_file_manager_detail_view()
            return
        self._present_compare_result(result.value)

    def _expand_assistant_for_compare(self) -> None:
        sizes = self._root_split.sizes()
        if sum(sizes) > 0:
            self._compare_root_split_sizes = sizes
        total = sum(sizes) if sum(sizes) > 0 else max(self.height(), 720)
        self._root_split.setSizes([max(180, total // 3), max(260, total * 2 // 3)])

    def _restore_assistant_split(self) -> None:
        if self._compare_root_split_sizes is not None:
            self._root_split.setSizes(self._compare_root_split_sizes)
            self._compare_root_split_sizes = None

    def _leave_compare_report(self) -> None:
        self._assistant.leave_compare_report()
        self._restore_assistant_split()
        if self._file_manager_active:
            self._restore_file_manager_detail_view()
            listing_path = self._detail.local_files._path or tr("local.roots")
            self.statusBar().showMessage(
                tr(
                    "status.file_manager",
                    path=listing_path,
                    version=display_version(),
                )
            )
        else:
            self.statusBar().showMessage(tr("status.browser", version=display_version()))

    def _present_compare_abort(self, reason: str) -> None:
        from core.compare_types import CompareFileSide, CompareResult

        self._present_compare_result(
            CompareResult(
                status="abort",
                file_a=CompareFileSide(label="A", path=Path("."), file_size=0),
                file_b=CompareFileSide(label="B", path=Path("."), file_size=0),
                abort_reason=reason,
            )
        )

    def _present_compare_result(self, result: object) -> None:
        from core.compare_types import CompareResult

        if not isinstance(result, CompareResult):
            return
        self._last_compare_result = result
        text = format_compare_result(result)
        self._expand_assistant_for_compare()
        self._assistant.show_compare_report(text)
        self._restore_file_manager_detail_view()
        if result.status == "abort":
            self.statusBar().showMessage(tr("compare.status.abort", version=display_version()))
            return
        key = "compare.status.match" if result.status == "match" else "compare.status.diff"
        self.statusBar().showMessage(tr(key, version=display_version()))

    def _export_last_compare_result(self) -> None:
        if self._last_compare_result is None:
            return
        self._export_compare_result(self._last_compare_result)

    def _export_compare_result(self, result: object) -> None:
        from core.compare_types import CompareResult

        if not isinstance(result, CompareResult):
            return
        folder = self._controller.profile.download_dir
        suggested = default_export_path(result, folder)
        path, _ = QFileDialog.getSaveFileName(
            self,
            tr("compare.export"),
            str(suggested),
            tr("filter.text"),
        )
        if not path:
            return
        export_compare_result(result, Path(path))
        self.statusBar().showMessage(
            tr("compare.status.exported", path=path, version=display_version())
        )

    def _visualize_local_path(self, raw: str) -> None:
        if not raw:
            return
        self._pending_local_file = {"absolute_path": raw, "name": Path(raw).name}
        self._visualize_local_file()

    def _refresh_local_listing(self) -> None:
        listing = list_directory(self._local_browser_path)
        self._apply_local_listing(listing)

    def _refresh_local_if_watching(self, local: Path) -> None:
        """Actualiza el panel local si la descarga cayó en la carpeta visible."""
        if not self._file_manager_active or self._local_browser_path is None:
            return
        try:
            if local.resolve().parent == self._local_browser_path.resolve():
                self._refresh_local_listing()
        except OSError:
            return

    def _apply_local_listing(self, listing: LocalListing) -> None:
        self._local_browser_path = listing.current_path
        self._detail.local_files.set_path(listing.display_path)
        self._detail.local_files.set_entries(_local_entries_for_ui(listing))
        self.statusBar().showMessage(
            tr(
                "status.file_manager",
                path=listing.display_path,
                version=display_version(),
            )
        )

    def _open_local_folder(self, name: str) -> None:
        token = name.rstrip("/") or ".."
        if self._local_browser_path is None and token == "..":
            self._refresh_local_listing()
            return
        target = resolve_folder_open(self._local_browser_path, token)
        if target is None and token != "..":
            return
        self._local_browser_path = target
        self._refresh_local_listing()

    def _show_local_file_actions(self, payload: dict) -> None:
        self._pending_local_file = payload
        compare = self._file_manager_active
        show_local_file_actions_menu(
            self,
            payload["global_pos"],
            on_preview=self._visualize_local_file,
            on_compare_a=self._pick_compare_a_local if compare else None,
            on_compare_b=self._pick_compare_b_local if compare else None,
        )

    def _visualize_local_file(self) -> None:
        if self._pending_local_file is None or self._analysis_busy:
            return
        raw = self._pending_local_file.get("absolute_path", "")
        if not raw:
            return
        path = Path(raw)
        if not path.is_file():
            return
        name = path.name
        file_size = path.stat().st_size
        if is_tabular_extension(name):
            if tabular_uses_pandas(self._controller.profile, file_size):
                self._pending_visualize_meta = {
                    "name": name,
                    "remote": str(path),
                    "local": path,
                    "file_size": file_size,
                    "from_file_manager": True,
                }
                self._set_operation_cancel_visible(True)
                self._start_tabular_analysis(path)
                return
            result = read_text_head_preview(path, text_fallback=True)
            if isinstance(result, Ok):
                self._present_text_view(
                    name=name,
                    view=result.value,
                    remote=path,
                )
                return
            if isinstance(result, Err):
                self._show_operation_error(tr("msg.op.visualize"), result.error)
            return
        result = read_visualize_file(path)
        if isinstance(result, Ok):
            self._present_text_view(
                name=name,
                view=result.value,
                remote=path,
            )
            return
        if isinstance(result, Err):
            self._show_operation_error(tr("msg.op.visualize"), result.error)

    def _show_file_actions(self, payload: dict) -> None:
        self._pending_file = payload
        global_pos = payload["global_pos"]
        compare = self._file_manager_active
        show_file_actions_menu(
            self,
            global_pos,
            on_download=self._download_selected_file,
            on_preview=self._visualize_selected_file,
            on_compare_a=self._pick_compare_a_sftp if compare else None,
            on_compare_b=self._pick_compare_b_sftp if compare else None,
        )

    def _download_selected_file(self) -> None:
        if self._pending_file is None or self._sftp_busy or self._analysis_busy:
            return
        filename = self._pending_file["name"]
        local = self._controller.pick_download_path(self, filename)
        if local is None:
            return
        force = False
        if local.is_file():
            choice = ask_download_collision(self, local)
            if choice is DownloadCollisionChoice.CANCEL:
                return
            if choice is DownloadCollisionChoice.VERSION:
                local = next_versioned_path(local)
            else:
                force = True
        if self._file_manager_active:
            self.statusBar().showMessage(
                tr("msg.downloading", filename=filename, dest=local)
            )
        else:
            self._detail.show_message(
                tr("msg.downloading", filename=filename, dest=local)
            )
        self._last_progress_text = ""
        self._last_progress_at = 0.0
        self._sftp_op = "download"
        self._set_sftp_ui_busy(True)
        self._set_operation_cancel_visible(True)
        self._sftp_worker.download_requested.emit(filename, str(local), force)

    def _visualize_selected_file(self) -> None:
        self._run_file_action("visualize")

    def _run_file_action(self, op: str) -> None:
        if self._pending_file is None or self._sftp_busy or self._analysis_busy:
            return
        filename = self._pending_file["name"]
        if op == "download":
            status = f"{tr('msg.download_progress')}…\n{filename}"
        else:
            status = f"{tr('msg.download_full')}…\n{filename}"
        self._detail.show_message(status)
        self._last_progress_text = ""
        self._last_progress_at = 0.0
        self._sftp_op = op
        self._set_sftp_ui_busy(True)
        self._set_operation_cancel_visible(True)
        signal = (
            self._sftp_worker.download_requested
            if op == "download"
            else self._sftp_worker.visualize_requested
        )
        signal.emit(filename)

    def _on_sftp_file_finished(self, result: object, op: str) -> None:
        if self._pending_file is None:
            return
        name = self._pending_file["name"]
        from core.sftp_paths import join_remote_path

        remote = join_remote_path(self._current_sftp_path, name)
        if isinstance(result, Ok):
            if op == "download":
                local: Path = result.value
                self._refresh_local_if_watching(local)
                if self._file_manager_active:
                    self.statusBar().showMessage(
                        tr("status.downloaded", name=local.name, version=display_version())
                    )
                else:
                    self._detail.show_message(
                        tr("msg.download_done", remote=remote, local=local)
                    )
                    self.statusBar().showMessage(
                        tr("status.downloaded", name=local.name, version=display_version())
                    )
                return
            view: VisualizeResult = result.value
            if self._pending_compare_after_download and self._compare_busy:
                side = self._pending_compare_after_download
                self._pending_compare_after_download = None
                if self._compare_cancel_requested:
                    self._compare_busy = False
                    self._set_operation_cancel_visible(False)
                    self._compare_cancel_requested = False
                    self._restore_file_manager_detail_view()
                    self.statusBar().showMessage(tr("status.cancelled", version=display_version()))
                    return
                if side == "a" and self._compare_pick_a is not None:
                    self._compare_pick_a.local_path = view.local_path
                    self._compare_pick_a.is_remote = False
                elif side == "b" and self._compare_pick_b is not None:
                    self._compare_pick_b.local_path = view.local_path
                    self._compare_pick_b.is_remote = False
                else:
                    self._compare_busy = False
                    self._show_operation_error(tr("compare.title"), tr("compare.err_missing_file"))
                    return
                self._continue_compare_with_local_paths()
                return
            if view.tabular:
                self._pending_visualize_meta = {
                    "name": name,
                    "remote": remote,
                    "local": view.local_path,
                    "file_size": view.file_size,
                }
                self._detail.show_message(
                    tr("msg.analyzing", filename=name)
                    + f"\n\nRemoto: {remote}\nLocal: {view.local_path}"
                )
                self._set_operation_cancel_visible(True)
                self._start_tabular_analysis(view.local_path)
                return
            self._present_text_view(
                name=name,
                view=view,
                remote=remote,
            )
            return
        if isinstance(result, Err):
            if self._pending_compare_after_download:
                self._pending_compare_after_download = None
                self._compare_busy = False
                self._set_operation_cancel_visible(False)
                if self._compare_cancel_requested:
                    self._compare_cancel_requested = False
                    self._restore_file_manager_detail_view()
            if isinstance(result.error, TransferCancelledError):
                self._pending_visualize_meta = None
                self._detail.show_message(
                    tr("msg.cancelled", name=name, error=result.error)
                )
                self.statusBar().showMessage(tr("status.cancelled", version=display_version()))
                return
            action = (
                tr("msg.op.download") if op == "download" else tr("msg.op.visualize")
            )
            self._show_operation_error(tr("msg.file_error", op=action), result.error)

    def _start_tabular_analysis(self, local_path: Path) -> None:
        if self._analysis_busy:
            return
        self._analysis_busy = True
        limit = self._controller.profile.max_display_rows
        self._analysis_worker.analyze_requested.emit(str(local_path), limit)

    def _on_analysis_finished(self, result: object) -> None:
        self._analysis_busy = False
        self._set_operation_cancel_visible(False)
        if self._analysis_cancel_requested:
            self._analysis_cancel_requested = False
            self._pending_visualize_meta = None
            if self._file_manager_active:
                self._detail.show_local_browser()
                self._refresh_local_listing()
            else:
                self._detail.show_message(tr("msg.visualize_cancelled"))
            self.statusBar().showMessage(tr("status.cancelled", version=display_version()))
            return
        meta = self._pending_visualize_meta
        if meta is None:
            return
        name = meta["name"]
        if isinstance(result, Ok):
            dataset = result.value
            try:
                self._detail.show_tabular(
                    dataset,
                    filename=name,
                    file_size_bytes=meta.get("file_size"),
                )
                self._enter_visualize_mode()
                if dataset.display_truncated:
                    shown = len(dataset.rows)
                    QMessageBox.information(
                        self,
                        tr("msg.tabular_truncated.title"),
                        tr(
                            "msg.tabular_truncated.body",
                            shown=f"{shown:,}",
                            total=f"{dataset.total_rows:,}",
                        ),
                    )
                self.statusBar().showMessage(
                    tr("status.tabular", name=name, version=display_version())
                )
            except Exception as exc:  # noqa: BLE001
                self._show_operation_error(tr("msg.show_fail", name=name), exc)
            return
        if isinstance(result, Err):
            self._show_operation_error(
                tr("msg.analysis_fail", name=name),
                tr("msg.analysis_saved", error=result.error),
            )
            return
        self._show_operation_error(tr("msg.analysis_unexpected"), repr(result))

    def shutdown_workers(self) -> None:
        if self._shutdown_done:
            return
        self._shutdown_done = True
        log_event("shutdown start")

        if self._test_thread is not None and self._test_thread.isRunning():
            self._test_thread.quit()
            self._test_thread.wait(3000)

        if self._sftp_thread.isRunning():
            QMetaObject.invokeMethod(
                self._sftp_worker,
                "disconnect_browser",
                Qt.ConnectionType.BlockingQueuedConnection,
            )

        if self._analysis_thread.isRunning():
            self._analysis_thread.quit()
            if not self._analysis_thread.wait(5000):
                log_event("analysis thread timeout on shutdown")

        if self._compare_thread.isRunning():
            self._compare_thread.quit()
            if not self._compare_thread.wait(5000):
                log_event("compare thread timeout on shutdown")

        if self._sftp_thread.isRunning():
            self._sftp_thread.quit()
            if not self._sftp_thread.wait(5000):
                log_event("sftp thread timeout on shutdown")

        log_event("shutdown done")

    def closeEvent(self, event) -> None:  # noqa: N802 — Qt API
        self.shutdown_workers()
        super().closeEvent(event)

    def _clear_sftp_test_worker(self) -> None:
        self._assistant.keys_panel.set_actions_enabled(True)
        self._test_worker = None
        self._test_thread = None

    def _toggle_chrome(self) -> None:
        self._theme.toggle_chrome()
        self._host.refresh_scrim()
        self.statusBar().showMessage(
            f"{self._theme_mode_label()} · {display_version()}"
        )
        if self._visualize_mode_active:
            self._detail.restore_active_view()
            self._set_visualize_focus_layout(True)

    def _pick_wallpaper(self) -> None:
        source = pick_wallpaper_source(self)
        if source is None:
            return
        try:
            installed = install_wallpaper(source)
        except ValueError as exc:
            self._detail.show_message(tr("msg.wallpaper_fail", error=exc))
            return
        except OSError as exc:
            self._detail.show_message(tr("msg.wallpaper_copy_fail", error=exc))
            return
        self._host.set_wallpaper(installed)
        self.statusBar().showMessage(
            tr("status.wallpaper", name=installed.name, version=display_version())
        )

    def _pick_icon(self) -> None:
        source = pick_icon_source(self)
        if source is None:
            return
        try:
            installed = install_icon(source)
        except ValueError as exc:
            self._detail.show_message(tr("msg.icon_fail", error=exc))
            return
        except OSError as exc:
            self._detail.show_message(tr("msg.icon_copy_fail", error=exc))
            return
        app = QApplication.instance()
        if app is not None:
            apply_app_icon(app)
        self.statusBar().showMessage(
            tr("status.icon", name=installed.name, version=display_version())
        )

    def _set_status_disconnected(self) -> None:
        self.statusBar().showMessage(
            tr(
                "status.disconnected",
                mode=self._theme_mode_label(),
                version=display_version(),
            )
        )


def _format_size(size_bytes: int) -> str:
    if size_bytes >= 1_000_000:
        return f"{size_bytes / 1_000_000:7.1f}M"
    if size_bytes >= 1_000:
        return f"{size_bytes / 1_000:7.1f}K"
    return f"{size_bytes:7d}"


def _local_entries_for_ui(listing: LocalListing) -> list[dict]:
    return [local_entry_to_row(entry) for entry in listing.entries]


def _entries_for_ui(entries: list[RemoteEntry]) -> list[dict]:
    rows: list[dict] = []
    for entry in entries:
        is_dir = entry.entry_type == "dir" or entry.name == ".."
        display_name = entry.name
        if is_dir and entry.name not in (".", "..") and not display_name.endswith("/"):
            display_name = f"{display_name}/"
        ext = "" if is_dir else (Path(entry.name).suffix or "")
        size = tr("nav.dir_marker") if is_dir else _format_size(entry.size)
        modified = ""
        if entry.modified is not None:
            modified = entry.modified.strftime("%Y-%m-%d %H:%M")
        rows.append(
            {
                "name": display_name,
                "ext": ext,
                "size": size,
                "modified": modified,
            }
        )
    return rows
