# Assets UI

| Archivo | Uso |
|---------|-----|
| `pexels-pixabay-33109.jpg` | **Fondo por defecto** (capa 0, cover) |
| `wallpapers/` | Fondos elegidos desde **Ver → Fondo…** (copia local) |
| `wallpaper.json` | Preferencia del fondo activo (ruta relativa a `assets/`) |
| `icon/app.ico` | Icono por defecto (opcional). Ver [`icon/README.md`](icon/README.md) |
| `icon/icons/` | Iconos elegidos desde **Ver → Icono…** |
| `icon/icon.json` | Preferencia del icono activo |

Reemplazar el JPG por defecto o usar **Ver → Fondo…** en la app.
