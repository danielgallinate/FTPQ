# Icono de la aplicación

Coloca aquí el icono del proyecto o elígelo desde **Ver → Icono…** en la app.

## Por defecto (opcional)

| Archivo | Uso |
|---------|-----|
| `app.ico` | Icono principal (Windows / WSL / fallback) |
| `app.icns` | macOS nativo (prioridad en Mac si existe) |
| `app.png` | Fallback (p. ej. 256×256) |

## Elegido desde la UI

| Ruta | Uso |
|------|-----|
| `icons/` | Copias locales del archivo que elijas |
| `icon.json` | Preferencia del icono activo (ruta relativa a esta carpeta) |

Formatos admitidos al elegir archivo: **`.ico`**, **`.icns`**, **`.png`**.

Misma lógica que el fondo (`wallpaper_store.py`): copia al proyecto y persiste en JSON.

**Persistencia:** lo elegido en **Ver → Icono…** queda en `icon.json` y se usa en cada arranque hasta que borres el archivo copiado (entonces vuelve a `app.ico` / `app.png` si existen, o icono del sistema).

Resolución en código: `ui/theme/icon_store.py` · aplicación: `ui/theme/app_icon.py`
