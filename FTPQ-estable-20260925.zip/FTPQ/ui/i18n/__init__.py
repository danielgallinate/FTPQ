"""Internacionalización UI — es (latino) / en."""
from ui.i18n.locale import (
    current_language,
    init_locale,
    language_changed,
    set_language,
    tr,
)

__all__ = [
    "current_language",
    "init_locale",
    "language_changed",
    "set_language",
    "tr",
]
