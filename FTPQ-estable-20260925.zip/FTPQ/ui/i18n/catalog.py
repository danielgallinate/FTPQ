"""Catálogo de cadenas UI — es (latinoamérica) / en."""
from __future__ import annotations

# Claves técnicas (.env) se repiten igual en ambos idiomas donde aplica.

CATALOG: dict[str, dict[str, str]] = {
    # — App —
    "app.name": {"es": "PDE Desktop", "en": "PDE Desktop"},
    "app.window_title": {
        "es": "PDE Desktop {version}",
        "en": "PDE Desktop {version}",
    },
    "app.prototype": {"es": "Beta {version}", "en": "Beta {version}"},
    # — Menú —
    "menu.file": {"es": "Archivo", "en": "File"},
    "menu.view": {"es": "Ver", "en": "View"},
    "menu.settings": {"es": "Configuración", "en": "Settings"},
    "menu.help": {"es": "Ayuda", "en": "Help"},
    "menu.language": {"es": "Idioma", "en": "Language"},
    "action.connect": {"es": "Conectar", "en": "Connect"},
    "action.file_manager": {"es": "Administrador de archivos", "en": "File manager"},
    "action.wallpaper": {"es": "Fondo…", "en": "Wallpaper…"},
    "action.icon": {"es": "Icono…", "en": "Icon…"},
    "action.keys": {"es": "Llaves…", "en": "Keys…"},
    "action.paths": {"es": "Rutas…", "en": "Paths…"},
    "action.version": {"es": "Versión…", "en": "Version…"},
    "action.about": {"es": "Quiénes somos…", "en": "About…"},
    "language.spanish": {"es": "Español (latino)", "en": "Spanish (Latin America)"},
    "language.english": {"es": "Inglés", "en": "English"},
    "dialog.version_title": {
        "es": "PDE Desktop — Versión",
        "en": "PDE Desktop — Version",
    },
    "dialog.download_collision.title": {
        "es": "Archivo ya existe",
        "en": "File already exists",
    },
    "dialog.download_collision.text": {
        "es": "«{name}» ya está en la carpeta de destino.",
        "en": "«{name}» already exists in the destination folder.",
    },
    "dialog.download_collision.info": {
        "es": "Ruta:\n{path}\n\n¿Sobrescribir o guardar una nueva versión?",
        "en": "Path:\n{path}\n\nOverwrite or save a new version?",
    },
    "dialog.download_collision.overwrite": {
        "es": "Sobrescribir",
        "en": "Overwrite",
    },
    "dialog.download_collision.version": {
        "es": "Versionar",
        "en": "Save new version",
    },
    # — Placeholders / stubs —
    "stub.open.title": {"es": "Archivo → Conectar", "en": "File → Connect"},
    "stub.open.body": {
        "es": (
            "Prototipo visual.\n\n"
            "Flujo futuro: elegir llave → user → test → conectar.\n"
            "Use Archivo → Conectar con el perfil configurado."
        ),
        "en": (
            "Visual prototype.\n\n"
            "Future flow: pick key → user → test → connect.\n"
            "Use File → Connect with your saved profile."
        ),
    },
    "stub.config.title": {
        "es": "Configuración → {section}",
        "en": "Settings → {section}",
    },
    "stub.config.body": {
        "es": "Prototipo visual.\n\nSección «{section}» — pendiente de implementación.",
        "en": "Visual prototype.\n\nSection «{section}» — not implemented yet.",
    },
    "stub.about.title": {"es": "Ayuda → Quiénes somos", "en": "Help → About"},
    "stub.about.body": {
        "es": (
            "PDE Desktop\n"
            "Prototipo UI — PySide6\n\n"
            "Asistencia sobre archivos provistos por PDE.\n"
            "Local · sin nube"
        ),
        "en": (
            "PDE Desktop\n"
            "UI prototype — PySide6\n\n"
            "Assistance on files provided by PDE.\n"
            "Local · no cloud"
        ),
    },
    # — Archivo contextual —
    "file.download": {"es": "Descargar", "en": "Download"},
    "file.visualize": {"es": "Visualizar", "en": "View"},
    "file.forbidden_menu": {
        "es": "Borrar / mover / editar…",
        "en": "Delete / move / edit…",
    },
    "file.forbidden.title": {
        "es": "Operación no permitida",
        "en": "Operation not allowed",
    },
    "file.forbidden.body": {
        "es": (
            "En esta versión no están permitidas:\n\n"
            "• Borrar\n• Mover\n• Editar\n\n"
            "Solo lectura: descargar y visualizar."
        ),
        "en": (
            "Not allowed in this version:\n\n"
            "• Delete\n• Move\n• Edit\n\n"
            "Read-only: download and view."
        ),
    },
    # — Chrome —
    "chrome.toggle_tooltip": {
        "es": "Color — oscuro · claro · neutro · sólido",
        "en": "Color — dark · light · neutral · solid",
    },
    "theme.dark": {"es": "Chrome oscuro (texto blanco)", "en": "Dark chrome (white text)"},
    "theme.light": {"es": "Chrome claro (texto negro)", "en": "Light chrome (black text)"},
    "theme.neutral": {"es": "Chrome neutro (gris)", "en": "Neutral chrome (gray)"},
    "theme.solid": {"es": "Chrome sólido (sin fondo)", "en": "Solid chrome (no wallpaper)"},
    # — Paneles —
    "panel.navigator": {"es": "Navegador", "en": "Browser"},
    "panel.detail": {"es": "Detalle / mensajes", "en": "Detail / messages"},
    "panel.local_files": {
        "es": "Archivos locales",
        "en": "Local files",
    },
    "panel.local_side_a": {"es": "Local A", "en": "Local A"},
    "panel.local_side_b": {"es": "Local B", "en": "Local B"},
    "panel.assistant": {"es": "Asistente PDE", "en": "PDE Assistant"},
    "panel.settings_keys": {
        "es": "Configuración — Llaves",
        "en": "Settings — Keys",
    },
    "panel.settings_paths": {
        "es": "Configuración — Rutas",
        "en": "Settings — Paths",
    },
    "panel.assistant_body": {
        "es": (
            "Asistente metadata — próximamente.\n"
            "Podrá buscar archivos por fecha y carpeta sin leer el contenido.\n"
            "(Prototipo visual — sin lógica)"
        ),
        "en": (
            "Metadata assistant — coming soon.\n"
            "Search files by date and folder without reading content.\n"
            "(Visual prototype — no logic)"
        ),
    },
    "panel.detail_empty": {
        "es": (
            "Seleccione un archivo o carpeta en el navegador.\n\n"
            "Los mensajes de conexión y errores aparecerán aquí."
        ),
        "en": (
            "Select a file or folder in the browser.\n\n"
            "Connection messages and errors will appear here."
        ),
    },
    "action.stop": {"es": "Detener", "en": "Stop"},
    "action.send": {"es": "Enviar", "en": "Send"},
    "action.close": {"es": "Cerrar", "en": "Close"},
    "action.save": {"es": "Guardar", "en": "Save"},
    "action.back": {"es": "Volver", "en": "Back"},
    "action.all": {"es": "Todas", "en": "All"},
    "action.none": {"es": "Ninguna", "en": "None"},
    # — Navegador —
    "nav.disconnected": {"es": "Sin conexión", "en": "Not connected"},
    "nav.disconnected_hint": {
        "es": "Sin conexión — Archivo → Conectar",
        "en": "Not connected — File → Connect",
    },
    "nav.col.name": {"es": "Nombre", "en": "Name"},
    "nav.col.ext": {"es": "Ext", "en": "Ext"},
    "nav.col.size": {"es": "Tamaño", "en": "Size"},
    "nav.col.modified": {"es": "Modificado", "en": "Modified"},
    "nav.dir_marker": {"es": "<DIR>", "en": "<DIR>"},
    "local.roots": {"es": "Unidades", "en": "Drives"},
    "detail.field.name": {"es": "Nombre:", "en": "Name:"},
    "detail.field.ext": {"es": "Ext:", "en": "Ext:"},
    "detail.field.size": {"es": "Tamaño:", "en": "Size:"},
    "detail.field.date": {"es": "Fecha:", "en": "Date:"},
    "detail.field.path": {"es": "Ruta:", "en": "Path:"},
    "detail.dash": {"es": "—", "en": "—"},
    # — Config llaves —
    "keys.header": {"es": "CONFIG — llaves SFTP", "en": "CONFIG — SFTP keys"},
    "keys.hint": {
        "es": "Test SFTP = verificar · Guardar = guardar y conectar",
        "en": "Test SFTP = verify · Save = save and connect",
    },
    "keys.user_hint": {
        "es": "Login Transfer Family (= CONFIG_NAME en nonprod)",
        "en": "Transfer Family login (= CONFIG_NAME in nonprod)",
    },
    "keys.label.key": {"es": "Llave", "en": "Key"},
    "keys.label.path": {"es": "Ruta", "en": "Path"},
    "keys.label.type": {"es": "Tipo", "en": "Type"},
    "keys.fingerprint": {"es": "Huella:", "en": "Fingerprint:"},
    "keys.fingerprint_loading": {"es": "Huella: …", "en": "Fingerprint: …"},
    "keys.fingerprint_empty": {"es": "Huella: —", "en": "Fingerprint: —"},
    "keys.fingerprint_value": {"es": "Huella: {fp}", "en": "Fingerprint: {fp}"},
    "keys.new_name_ph": {"es": "Nombre nueva llave…", "en": "New key name…"},
    "keys.create": {"es": "Crear nueva llave…", "en": "Create new key…"},
    "keys.test": {"es": "Test SFTP", "en": "Test SFTP"},
    "keys.dir_missing": {"es": "Carpeta no encontrada: {path}", "en": "Folder not found: {path}"},
    "keys.count": {
        "es": "{count} llave(s) en {path}",
        "en": "{count} key(s) in {path}",
    },
    "keys.configure_dir": {
        "es": "Configure carpeta de llaves en Rutas.",
        "en": "Set keys folder in Paths.",
    },
    "keys.exists": {"es": "Ya existe: {path}", "en": "Already exists: {path}"},
    "keys.create_fail": {"es": "No se pudo crear la llave:\n{error}", "en": "Could not create key:\n{error}"},
    "keys.created": {
        "es": "Llave creada — use Guardar para persistir.\n{path}\nHuella: {fp}",
        "en": "Key created — use Save to persist.\n{path}\nFingerprint: {fp}",
    },
    "keys.feedback_hint": {
        "es": "Edite SFTP_USER y llave. Test SFTP no guarda; Guardar conecta al SFTP.",
        "en": "Edit SFTP_USER and key. Test SFTP does not save; Save connects to SFTP.",
    },
    # — Config rutas —
    "paths.header": {"es": "CONFIG — rutas y sources", "en": "CONFIG — paths and sources"},
    "paths.hint": {
        "es": "SFTP_HOST · carpetas locales · Guardar = persistir (sin auto-conectar)",
        "en": "SFTP_HOST · local folders · Save = persist (no auto-connect)",
    },
    "paths.keys_folder": {"es": "Carpeta llaves", "en": "Keys folder"},
    "paths.port": {"es": "Puerto", "en": "Port"},
    "paths.display_rows": {
        "es": "Filas máx. en tabla",
        "en": "Max table rows",
    },
    "paths.display_rows_hint": {
        "es": "Si el archivo tiene más filas, la tabla muestra solo este límite. "
        "Las estadísticas de columnas siguen calculándose sobre el archivo completo.",
        "en": "If the file has more rows, the table shows only up to this limit. "
        "Column statistics are still computed on the full file.",
    },
    "paths.tabular_mode": {"es": "Modo CSV/TSV/PSV", "en": "CSV/TSV/PSV mode"},
    "paths.tabular_mode.auto": {"es": "Automático", "en": "Automatic"},
    "paths.tabular_mode.full": {"es": "Siempre tabla (pandas)", "en": "Always table (pandas)"},
    "paths.tabular_mode.text_only": {
        "es": "Solo texto (sin pandas)",
        "en": "Text only (no pandas)",
    },
    "paths.tabular_mode_hint": {
        "es": "Automático: si el archivo supera el umbral pandas, abre vista previa textual "
        "sin estadísticas ni columnas. La descarga sigue siendo completa.",
        "en": "Automatic: if the file exceeds the pandas threshold, open a text preview "
        "without stats or columns. Download remains full.",
    },
    "paths.pandas_threshold": {"es": "Umbral pandas", "en": "Pandas threshold"},
    "paths.pandas_threshold_hint": {
        "es": "Solo en modo Automático. Hasta este tamaño: tabla y stats. "
        "Por encima: primeros 2 MiB como texto. Tope absoluto pandas: 200 MB.",
        "en": "Automatic mode only. Up to this size: table and stats. "
        "Above: first 2 MiB as text. Absolute pandas cap: 200 MB.",
    },
    "paths.import_env": {"es": "Importar .env…", "en": "Import .env…"},
    # — Visualizador —
    "viewer.columns_visible": {"es": "Columnas visibles", "en": "Visible columns"},
    "viewer.filter_ph": {"es": "Filtrar columnas…", "en": "Filter columns…"},
    "viewer.columns_hint": {
        "es": "Ninguna deja 1 columna visible: la tabla no puede mostrarse vacía.",
        "en": "None leaves exactly 1 visible column: the table cannot be empty.",
    },
    "viewer.column_stats": {"es": "Análisis de columna", "en": "Column analysis"},
    "viewer.rows_view": {"es": "Vista de filas", "en": "Row view"},
    "viewer.unique_rows": {"es": "Solo filas únicas", "en": "Unique rows only"},
    "viewer.unique_hint": {
        "es": (
            "Deduplica por las columnas visibles marcadas arriba. "
            "«Únicos» en análisis es por columna en todo el archivo."
        ),
        "en": (
            "Deduplicates by visible columns checked above. "
            "«Unique» in analysis is per column across the whole file."
        ),
    },
    "viewer.tab.columns": {"es": "Columnas", "en": "Columns"},
    "viewer.tab.timezone": {"es": "Zona horaria", "en": "Timezone"},
    "viewer.timezone.hint": {
        "es": "Convierte columnas datetime de una zona a otra. Origen por defecto UTC.",
        "en": "Convert datetime columns from one zone to another. Default source is UTC.",
    },
    "viewer.timezone.source": {"es": "Zona origen", "en": "Source zone"},
    "viewer.timezone.target": {"es": "Zona destino", "en": "Target zone"},
    "viewer.timezone.columns": {"es": "Columnas a convertir", "en": "Columns to convert"},
    "viewer.timezone.select_detected": {"es": "Marcar detectadas", "en": "Select detected"},
    "viewer.timezone.select_none": {"es": "Ninguna", "en": "None"},
    "viewer.timezone.apply": {"es": "Aplicar conversión", "en": "Apply conversion"},
    "viewer.timezone.clear": {"es": "Quitar conversión", "en": "Clear conversion"},
    "viewer.timezone.toggle_column": {
        "es": "Incluir en conversión timezone",
        "en": "Include in timezone conversion",
    },
    "viewer.timezone.detected_hint": {
        "es": "Detectada como datetime (nombre UTC o muestra parseable).",
        "en": "Detected as datetime (UTC name or parseable sample).",
    },
    "viewer.timezone.status_idle": {
        "es": "Seleccione columnas y pulse Aplicar conversión.",
        "en": "Select columns and click Apply conversion.",
    },
    "viewer.timezone.status_ready": {
        "es": "{source} → {target} · {count} columnas listas.",
        "en": "{source} → {target} · {count} columns ready.",
    },
    "viewer.timezone.applied": {
        "es": "Timezone aplicado: {source} → {target} en {count} columnas.",
        "en": "Timezone applied: {source} → {target} on {count} columns.",
    },
    "viewer.timezone.cleared": {
        "es": "Conversión timezone quitada — valores originales.",
        "en": "Timezone conversion cleared — original values restored.",
    },
    "viewer.header": {
        "es": "Visualización — {filename} — {rows} filas — {cols} columnas — {size}{trunc}",
        "en": "View — {filename} — {rows} rows — {cols} columns — {size}{trunc}",
    },
    "viewer.truncated": {"es": " · truncada", "en": " · truncated"},
    "viewer.sampled": {"es": " · muestra", "en": " · sample"},
    "viewer.truncated_banner": {
        "es": "Solo se muestran {shown} de {total} filas. "
        "Para ver o procesar el archivo completo, use Excel, Power Query u otra herramienta.",
        "en": "Only {shown} of {total} rows are shown. "
        "To view or process the full file, use Excel, Power Query, or another tool.",
    },
    "viewer.load.title": {"es": "Carga de filas", "en": "Row load"},
    "viewer.load.sample_title": {"es": "Muestra de filas", "en": "Row sample"},
    "viewer.load.status": {
        "es": "Mostrando {shown} de {total} filas · {cols} columnas · "
        "volumen estimado {volume} celdas (referencia {ref_cols} columnas)",
        "en": "Showing {shown} of {total} rows · {cols} columns · "
        "estimated volume {volume} cells ({ref_cols}-column reference)",
    },
    "viewer.load.sample_status": {
        "es": "Archivo {total} filas · mostrando {shown} · {cols} columnas",
        "en": "File {total} rows · showing {shown} · {cols} columns",
    },
    "viewer.load.sample_hint": {
        "es": "Elige una opción o escribe filas (mín. {min}, máx. total). Ej.: 250 o 25%",
        "en": "Pick an option or type rows (min {min}, max total). E.g. 250 or 25%",
    },
    "viewer.load.option_total": {
        "es": "Total ({rows})",
        "en": "Total ({rows})",
    },
    "viewer.load.option_pct50": {
        "es": "50% ({rows})",
        "en": "50% ({rows})",
    },
    "viewer.load.option_pct10": {
        "es": "10% ({rows})",
        "en": "10% ({rows})",
    },
    "viewer.load.option_preset": {
        "es": "{rows} filas",
        "en": "{rows} rows",
    },
    "viewer.load.hint_ok": {
        "es": "Umbral manejable: hasta {budget} celdas estimadas. "
        "Las columnas del archivo no se limitan.",
        "en": "Manageable threshold: up to {budget} estimated cells. "
        "File columns are not capped.",
    },
    "viewer.load.hint_warn": {
        "es": "La opción seleccionada supera el umbral manejable ({budget} celdas estimadas). "
        "Pulse autorizar para cargar.",
        "en": "The selected option exceeds the manageable threshold ({budget} estimated cells). "
        "Click authorize to load.",
    },
    "viewer.load.rows_label": {"es": "Filas a cargar", "en": "Rows to load"},
    "viewer.load.sample_rows_label": {"es": "Tamaño de muestra", "en": "Sample size"},
    "viewer.load.button": {"es": "Cargar", "en": "Load"},
    "viewer.load.sample_button": {"es": "Recargar muestra", "en": "Reload sample"},
    "viewer.load.authorize": {"es": "Autorizar carga", "en": "Authorize load"},
    "viewer.build.mark_rows": {
        "es": "Marcar filas seleccionadas",
        "en": "Mark selected rows",
    },
    "viewer.build.clear_marks": {"es": "Quitar marcas", "en": "Clear marks"},
    "viewer.build.add_all": {"es": "Añadir todos", "en": "Add all"},
    "viewer.build.remove_duplicates": {
        "es": "Quitar duplicados del grid",
        "en": "Remove duplicates from grid",
    },
    "viewer.build.marked_count": {
        "es": "{count} fila(s) marcada(s)",
        "en": "{count} row(s) marked",
    },
    "viewer.build.select_rows": {
        "es": "Seleccione una o más filas en el grid.",
        "en": "Select one or more rows in the grid.",
    },
    "viewer.build.no_key": {
        "es": "Defina la llave primaria del template.",
        "en": "Set the template primary key.",
    },
    "viewer.build.no_duplicates": {
        "es": "No hay duplicados según la llave.",
        "en": "No duplicates for the current key.",
    },
    "viewer.build.duplicates_removed": {
        "es": "Se ocultaron {count} fila(s) duplicada(s).",
        "en": "Hid {count} duplicate row(s).",
    },
    "viewer.cell_copied": {"es": "Copiado", "en": "Copied"},
    "viewer.copy_cell": {"es": "Copiar celda", "en": "Copy cell"},
    "viewer.color_menu": {"es": "Color de referencia", "en": "Reference color"},
    "viewer.color_clear": {"es": "Quitar color", "en": "Clear color"},
    "viewer.color_label": {"es": "Color {n}", "en": "Color {n}"},
    "viewer.row_section": {"es": "Fila {n}", "en": "Row {n}"},
    "viewer.col_section": {"es": "Columna {n}", "en": "Column {n}"},
    "viewer.stat.column": {"es": "Columna:", "en": "Column:"},
    "viewer.stat.type": {"es": "Tipo:", "en": "Type:"},
    "viewer.stat.nulls": {"es": "Nulos:", "en": "Nulls:"},
    "viewer.stat.uniques": {"es": "Únicos:", "en": "Unique:"},
    "viewer.stat.sum": {"es": "Suma:", "en": "Sum:"},
    "viewer.stat.mean": {"es": "Media:", "en": "Mean:"},
    "viewer.stat.min": {"es": "Mín:", "en": "Min:"},
    "viewer.stat.max": {"es": "Máx:", "en": "Max:"},
    "viewer.stat.non_numeric": {
        "es": "Suma/Media: no numérica",
        "en": "Sum/Mean: non-numeric",
    },
    "viewer.stat.row_count": {
        "es": "Filas en tabla: {count} (combinaciones únicas de columnas visibles)",
        "en": "Rows in table: {count} (unique combinations of visible columns)",
    },
    "query.ph": {
        "es": "Escriba una consulta… (deshabilitado en prototipo)",
        "en": "Type a query… (disabled in prototype)",
    },
    # — Diálogos / QFileDialog —
    "dialog.pick_folder": {"es": "Seleccionar carpeta", "en": "Select folder"},
    "dialog.pick_file": {"es": "Seleccionar archivo", "en": "Select file"},
    "dialog.import_env": {"es": "Importar .env del validator", "en": "Import validator .env"},
    "dialog.download": {"es": "Descargar archivo", "en": "Download file"},
    "dialog.wallpaper": {"es": "Elegir fondo", "en": "Choose wallpaper"},
    "dialog.icon": {"es": "Elegir icono", "en": "Choose icon"},
    "dialog.icon_filter": {
        "es": "Iconos (*.ico *.icns *.png);;Todos (*.*)",
        "en": "Icons (*.ico *.icns *.png);;All (*.*)",
    },
    "filter.env": {"es": "Env (*.env);;All (*)", "en": "Env (*.env);;All (*)"},
    "filter.download": {
        "es": "Todos (*.*);;CSV (*.csv);;Texto (*.txt)",
        "en": "All (*.*);;CSV (*.csv);;Text (*.txt)",
    },
    "filter.images": {
        "es": "Imágenes (*.jpg *.jpeg *.png *.webp *.bmp);;Todos (*.*)",
        "en": "Images (*.jpg *.jpeg *.png *.webp *.bmp);;All (*.*)",
    },
    "filter.text": {"es": "Texto (*.txt);;All (*)", "en": "Text (*.txt);;All (*)"},
    "browser.mode.sftp": {"es": "SFTP", "en": "SFTP"},
    "browser.mode.sftp_local": {"es": "SFTP + local", "en": "SFTP + local"},
    "browser.mode.local_local": {"es": "Local ×2", "en": "Local ×2"},
    "compare.action": {"es": "Comparar", "en": "Compare"},
    "compare.pick_a": {"es": "Usar como lado A", "en": "Use as side A"},
    "compare.pick_b": {"es": "Usar como lado B", "en": "Use as side B"},
    "compare.pick_status": {
        "es": "Compare — lado {side}: {name} · {version}",
        "en": "Compare — side {side}: {name} · {version}",
    },
    "compare.title": {"es": "Comparar archivos", "en": "Compare files"},
    "panel.compare_report": {
        "es": "Compare — informe",
        "en": "Compare — report",
    },
    "compare.status.progress": {
        "es": "Compare: {msg} · {version}",
        "en": "Compare: {msg} · {version}",
    },
    "compare.stage.start": {"es": "Iniciando…", "en": "Starting…"},
    "compare.stage.download": {"es": "Descargando remoto…", "en": "Downloading remote…"},
    "compare.stage.read": {"es": "Leyendo archivos…", "en": "Reading files…"},
    "compare.stage.analyze": {"es": "Analizando diferencias…", "en": "Analyzing differences…"},
    "compare.cancelled": {"es": "Compare cancelado.", "en": "Compare cancelled."},
    "compare.export": {"es": "Exportar informe…", "en": "Export report…"},
    "compare.err_both_remote": {
        "es": "Compare admite remoto + local o local + local, no remoto + remoto.",
        "en": "Compare supports remote + local or local + local, not remote + remote.",
    },
    "compare.err_missing_file": {
        "es": "No se encontró uno de los archivos elegidos.",
        "en": "One of the selected files was not found.",
    },
    "compare.keys.title": {"es": "Columnas llave", "en": "Key columns"},
    "compare.keys.hint": {
        "es": "Cabeceras idénticas. Elija columnas llave o omita para comparar fila completa.",
        "en": "Identical headers. Pick key columns or skip to compare full rows.",
    },
    "compare.keys.skip": {"es": "Omitir llaves", "en": "Skip keys"},
    "compare.result.match": {"es": "MATCH — contenido equivalente", "en": "MATCH — equivalent content"},
    "compare.result.diff": {"es": "DIFF — hay diferencias", "en": "DIFF — differences found"},
    "compare.result.abort": {
        "es": "ABORT — {name_a} vs {name_b}\n{reason}",
        "en": "ABORT — {name_a} vs {name_b}\n{reason}",
    },
    "compare.result.no_keys": {"es": "Llaves: (ninguna — fila completa)", "en": "Keys: (none — full row)"},
    "compare.result.keys": {"es": "Llaves: {keys}", "en": "Keys: {keys}"},
    "compare.result.files": {
        "es": "A: {name_a} · {size_a} B · {rows_a} filas\nB: {name_b} · {size_b} B · {rows_b} filas",
        "en": "A: {name_a} · {size_a} B · {rows_a} rows\nB: {name_b} · {size_b} B · {rows_b} rows",
    },
    "compare.result.counts": {
        "es": "Solo en A: {only_a} · Solo en B: {only_b}",
        "en": "Only in A: {only_a} · Only in B: {only_b}",
    },
    "compare.result.duplicate_excess": {
        "es": "Nota: mismas filas únicas pero conteos de duplicados distintos.",
        "en": "Note: same unique rows but different duplicate counts.",
    },
    "compare.examples.only_a": {"es": "Ejemplos solo en A:", "en": "Examples only in A:"},
    "compare.examples.only_b": {"es": "Ejemplos solo en B:", "en": "Examples only in B:"},
    "compare.examples.key_only_a": {"es": "Llaves solo en A:", "en": "Keys only in A:"},
    "compare.examples.key_only_b": {"es": "Llaves solo en B:", "en": "Keys only in B:"},
    "compare.examples.duplicate_excess": {
        "es": "Duplicados / exceso de filas:",
        "en": "Duplicates / row excess:",
    },
    "compare.status.match": {"es": "Compare: MATCH · {version}", "en": "Compare: MATCH · {version}"},
    "compare.status.diff": {"es": "Compare: DIFF · {version}", "en": "Compare: DIFF · {version}"},
    "compare.status.abort": {"es": "Compare: ABORT · {version}", "en": "Compare: ABORT · {version}"},
    "compare.status.exported": {
        "es": "Informe exportado: {path} · {version}",
        "en": "Report exported: {path} · {version}",
    },
    "compare.result.summary_heading": {
        "es": "Resumen",
        "en": "Summary",
    },
    "compare.result.delta_rows": {
        "es": "Δ filas (B−A): {delta}",
        "en": "Δ rows (B−A): {delta}",
    },
    "compare.result.delta_bytes": {
        "es": "Δ bytes (B−A): {delta}",
        "en": "Δ bytes (B−A): {delta}",
    },
    "compare.result.matched_rows": {
        "es": "Filas emparejadas (multiset): {matched} ({pct}%)",
        "en": "Matched rows (multiset): {matched} ({pct}%)",
    },
    "compare.result.signatures": {
        "es": "Firmas compartidas: {shared} · Exceso solo A: {only_a} · Exceso solo B: {only_b}",
        "en": "Shared signatures: {shared} · Excess only A: {only_a} · Excess only B: {only_b}",
    },
    "compare.result.columns": {
        "es": "Columnas comparadas: {count}",
        "en": "Columns compared: {count}",
    },
    "compare.example.row_a": {
        "es": "A L{line}: {text}",
        "en": "A L{line}: {text}",
    },
    "compare.example.row_b": {
        "es": "B L{line}: {text}",
        "en": "B L{line}: {text}",
    },
    "compare.result.export_footer": {
        "es": "Generado: {generated}",
        "en": "Generated: {generated}",
    },
    # — Startup —
    "startup.unclean": {
        "es": (
            "La sesión anterior no cerró correctamente "
            "(cierre forzado o cierre inesperado).\n\n"
            "Log: {log_path}\n\n"
            "¿Iniciar de todos modos?"
        ),
        "en": (
            "The previous session did not shut down cleanly "
            "(forced or unexpected exit).\n\n"
            "Log: {log_path}\n\n"
            "Start anyway?"
        ),
    },
    # — Changelog dialog —
    "changelog.build": {"es": "Build actual: {version}", "en": "Current build: {version}"},
    "changelog.title": {"es": "Registro de cambios:", "en": "Change log:"},
    "changelog.empty": {
        "es": "(sin entradas — editar ui/version_changelog.txt)",
        "en": "(no entries — edit ui/version_changelog.txt)",
    },
    # — Errores controller —
    "err.no_session": {
        "es": "Sin sesión SFTP — use Archivo → Conectar.",
        "en": "No SFTP session — use File → Connect.",
    },
    "err.download_dir": {
        "es": "No se pudo crear carpeta de descargas:\n{error}",
        "en": "Could not create download folder:\n{error}",
    },
    "err.local_dest": {
        "es": "No se pudo preparar destino local:\n{error}",
        "en": "Could not prepare local destination:\n{error}",
    },
    "err.download_cancelled": {
        "es": "Descarga cancelada por el usuario.",
        "en": "Download cancelled by user.",
    },
    "err.save_local": {
        "es": "No se pudo guardar localmente:\n{error}",
        "en": "Could not save locally:\n{error}",
    },
    "err.visualize_unsupported": {
        "es": "Visualización no soportada para este tipo de archivo.",
        "en": "View not supported for this file type.",
    },
    "err.visualize_cancelled": {
        "es": "Visualización cancelada por el usuario.",
        "en": "View cancelled by user.",
    },
    "err.local_folder": {
        "es": "No se pudo preparar carpeta local:\n{error}",
        "en": "Could not prepare local folder:\n{error}",
    },
    "err.host_missing": {
        "es": "Host SFTP no configurado.\nUse Configuración → Rutas (SFTP_HOST del .env §3).",
        "en": "SFTP host not configured.\nUse Settings → Paths (SFTP_HOST from .env §3).",
    },
    "err.user_empty": {"es": "SFTP_USER vacío.", "en": "SFTP_USER is empty."},
    "err.key_missing": {
        "es": "Llave privada no encontrada:\n{path}",
        "en": "Private key not found:\n{path}",
    },
    "err.analysis_memory": {
        "es": "Memoria insuficiente para analizar este archivo. Pruebe un CSV más pequeño o cierre otras apps.",
        "en": "Not enough memory to analyze this file. Try a smaller CSV or close other apps.",
    },
    "err.log_footer": {"es": "\n\nLog: {path}", "en": "\n\nLog: {path}"},
    # — Mensajes shell (main_window) —
    "msg.profile_env": {
        "es": (
            "Perfil completado desde .env del validator.\n\n"
            "Origen: {origin}\nSFTP_HOST: {host}\nSFTP_USER: {user}"
        ),
        "en": (
            "Profile completed from validator .env.\n\n"
            "Source: {origin}\nSFTP_HOST: {host}\nSFTP_USER: {user}"
        ),
    },
    "msg.paths_intro": {
        "es": (
            "Configuración — Rutas\n\n"
            "SFTP_HOST (§3) y carpetas locales.\n"
            "Importar .env trae host/user/llave.\n"
            "Archivo → Conectar abre la raíz SFTP."
        ),
        "en": (
            "Settings — Paths\n\n"
            "SFTP_HOST (§3) and local folders.\n"
            "Import .env brings host/user/key.\n"
            "File → Connect opens SFTP root."
        ),
    },
    "msg.paths_saved": {
        "es": "Rutas guardadas.\n\nSFTP_HOST: {host}\nCONFIG_NAME: {name}",
        "en": "Paths saved.\n\nSFTP_HOST: {host}\nCONFIG_NAME: {name}",
    },
    "msg.paths_save_fail": {
        "es": "No se pudo guardar rutas:\n{error}",
        "en": "Could not save paths:\n{error}",
    },
    "msg.imported_env": {
        "es": (
            "Importado desde .env\n\n"
            "Archivo: {path}\nSFTP_HOST: {host}\nCONFIG_NAME: {name}\n\n"
            "Revise Llaves (SFTP_USER/llave) y pulse Guardar o Archivo → Conectar."
        ),
        "en": (
            "Imported from .env\n\n"
            "File: {path}\nSFTP_HOST: {host}\nCONFIG_NAME: {name}\n\n"
            "Review Keys (SFTP_USER/key) then Save or File → Connect."
        ),
    },
    "msg.keys_save_fail": {
        "es": "No se pudo guardar:\n{error}",
        "en": "Could not save:\n{error}",
    },
    "msg.test_progress": {
        "es": "Test SFTP en curso… Host: {host} · User: {user}",
        "en": "SFTP test in progress… Host: {host} · User: {user}",
    },
    "msg.test_ok": {
        "es": "Test SFTP — OK. User + llave verificados (no guardado).",
        "en": "SFTP test — OK. User + key verified (not saved).",
    },
    "msg.test_fail": {"es": "Test SFTP — falló: {error}", "en": "SFTP test — failed: {error}"},
    "msg.test_unexpected": {
        "es": "Test SFTP — respuesta inesperada: {result}",
        "en": "SFTP test — unexpected response: {result}",
    },
    "msg.cancel_analysis": {
        "es": (
            "Deteniendo visualización…\n\n"
            "El análisis en curso se descartará al terminar."
        ),
        "en": (
            "Stopping view…\n\n"
            "The current analysis will be discarded when it finishes."
        ),
    },
    "msg.cancel_download": {
        "es": "Deteniendo {label}…\n{name}",
        "en": "Stopping {label}…\n{name}",
    },
    "msg.cancel_download_label": {"es": "descarga", "en": "download"},
    "msg.cancel_visualize_label": {
        "es": "descarga para visualización",
        "en": "download for view",
    },
    "msg.connecting": {
        "es": "Conectando SFTP…\n\nHost: {host}\nUser: {user}",
        "en": "Connecting SFTP…\n\nHost: {host}\nUser: {user}",
    },
    "msg.connected": {
        "es": "Conectado — {summary}\n{path}\n\n{preview}",
        "en": "Connected — {summary}\n{path}\n\n{preview}",
    },
    "msg.connected_summary": {
        "es": "{folders} carpeta(s), {files} archivo(s)",
        "en": "{folders} folder(s), {files} file(s)",
    },
    "msg.connected_empty": {"es": "vacío", "en": "empty"},
    "msg.no_entries": {"es": "(sin entradas)", "en": "(no entries)"},
    "msg.connect_fail": {"es": "Conexión SFTP — falló", "en": "SFTP connection — failed"},
    "msg.connect_unexpected": {
        "es": "Conexión SFTP — respuesta inesperada:\n{result}",
        "en": "SFTP connection — unexpected response:\n{result}",
    },
    "msg.folder_fail": {"es": "No se pudo abrir carpeta", "en": "Could not open folder"},
    "msg.downloading": {
        "es": "Descargando…\n{filename}\n\nDestino: {dest}",
        "en": "Downloading…\n{filename}\n\nDestination: {dest}",
    },
    "msg.download_done": {
        "es": "Descarga completa\n\nRemoto: {remote}\nLocal: {local}",
        "en": "Download complete\n\nRemote: {remote}\nLocal: {local}",
    },
    "msg.download_progress": {"es": "Descargando", "en": "Downloading"},
    "msg.download_full": {
        "es": "Descargando archivo completo",
        "en": "Downloading full file",
    },
    "msg.analyzing": {"es": "Analizando datos…\n{filename}", "en": "Analyzing data…\n{filename}"},
    "msg.visualized": {
        "es": (
            "Visualización — {name}{trunc}\n"
            "Remoto: {remote}\nLocal: {local}\n{bytes} bytes · {lines} líneas\n\n{content}"
        ),
        "en": (
            "View — {name}{trunc}\n"
            "Remote: {remote}\nLocal: {local}\n{bytes} bytes · {lines} lines\n\n{content}"
        ),
    },
    "msg.trunc_screen": {"es": " (pantalla truncada)", "en": " (screen truncated)"},
    "msg.text_fallback_pandas": {
        "es": " (sin pandas — archivo grande; vista previa textual)",
        "en": " (no pandas — large file; text preview)",
    },
    "msg.lines_omitted": {"es": " ({n} líneas omitidas en pantalla)", "en": " ({n} lines omitted on screen)"},
    "msg.cancelled": {"es": "Operación cancelada\n\n{name}\n\n{error}", "en": "Operation cancelled\n\n{name}\n\n{error}"},
    "msg.visualize_cancelled": {
        "es": "Visualización cancelada.",
        "en": "View cancelled.",
    },
    "msg.file_error": {
        "es": "Error en {op}",
        "en": "Error during {op}",
    },
    "msg.op.download": {"es": "descarga", "en": "download"},
    "msg.op.visualize": {"es": "visualización", "en": "view"},
    "msg.show_fail": {"es": "Error mostrando {name}", "en": "Error showing {name}"},
    "msg.analysis_fail": {
        "es": "Error en análisis de {name}",
        "en": "Error analyzing {name}",
    },
    "msg.tabular_truncated.title": {
        "es": "Tabla truncada",
        "en": "Table truncated",
    },
    "msg.tabular_truncated.body": {
        "es": "El archivo tiene {total} filas. Solo se cargaron {shown} en la tabla.\n\n"
        "Para el archivo completo, use Excel, Power Query u otra herramienta.",
        "en": "The file has {total} rows. Only {shown} were loaded into the table.\n\n"
        "For the full file, use Excel, Power Query, or another tool.",
    },
    "msg.analysis_saved": {
        "es": "{error}\n\nEl archivo ya está descargado en la ruta local indicada.",
        "en": "{error}\n\nThe file is already downloaded to the local path shown.",
    },
    "msg.analysis_unexpected": {
        "es": "Análisis — respuesta inesperada",
        "en": "Analysis — unexpected response",
    },
    "msg.wallpaper_fail": {
        "es": "No se pudo usar el fondo\n\n{error}",
        "en": "Could not use wallpaper\n\n{error}",
    },
    "msg.wallpaper_copy_fail": {
        "es": "No se pudo copiar el fondo\n\n{error}",
        "en": "Could not copy wallpaper\n\n{error}",
    },
    "msg.icon_fail": {
        "es": "No se pudo usar el icono\n\n{error}",
        "en": "Could not use icon\n\n{error}",
    },
    "msg.icon_copy_fail": {
        "es": "No se pudo copiar el icono\n\n{error}",
        "en": "Could not copy icon\n\n{error}",
    },
    # — Status bar —
    "status.paths": {"es": "Configuración — Rutas · {version}", "en": "Settings — Paths · {version}"},
    "status.profile_saved": {"es": "Perfil guardado · {version}", "en": "Profile saved · {version}"},
    "status.imported": {"es": "Importado .env · {version}", "en": "Imported .env · {version}"},
    "status.browser": {"es": "Navegador · {version}", "en": "Browser · {version}"},
    "status.file_manager": {
        "es": "Archivos locales · {path} · {version}",
        "en": "Local files · {path} · {version}",
    },
    "status.keys": {"es": "Configuración — Llaves · {version}", "en": "Settings — Keys · {version}"},
    "status.test_ok": {"es": "Test SFTP OK · {version}", "en": "SFTP test OK · {version}"},
    "status.test_fail": {"es": "Test SFTP falló · {version}", "en": "SFTP test failed · {version}"},
    "status.cancel_analysis": {"es": "Cancelando análisis… · {version}", "en": "Cancelling analysis… · {version}"},
    "status.stopping": {"es": "Deteniendo… · {version}", "en": "Stopping… · {version}"},
    "status.connecting": {"es": "Conectando SFTP… · {version}", "en": "Connecting SFTP… · {version}"},
    "status.connected": {"es": "Conectado · {path} · {version}", "en": "Connected · {path} · {version}"},
    "status.progress": {"es": "{message} · {version}", "en": "{message} · {version}"},
    "status.downloaded": {"es": "Descargado · {name} · {version}", "en": "Downloaded · {name} · {version}"},
    "status.viewed": {"es": "Visualizado · {name} · {version}", "en": "Viewed · {name} · {version}"},
    "status.cancelled": {"es": "Cancelado · {version}", "en": "Cancelled · {version}"},
    "status.tabular": {"es": "Análisis tabular · {name} · {version}", "en": "Tabular analysis · {name} · {version}"},
    "status.wallpaper": {"es": "Fondo · {name} · {version}", "en": "Wallpaper · {name} · {version}"},
    "status.icon": {"es": "Icono · {name} · {version}", "en": "Icon · {name} · {version}"},
    "status.disconnected": {"es": "Desconectado · {mode} · {version}", "en": "Disconnected · {mode} · {version}"},
    "progress.bytes": {
        "es": "{pct}% · {done} / {total}",
        "en": "{pct}% · {done} / {total}",
    },
    "progress.done": {"es": "{done} transferidos", "en": "{done} transferred"},
    "unit.mb": {"es": " MB", "en": " MB"},
    "unit.kb": {"es": " KB", "en": " KB"},
    "unit.b": {"es": " B", "en": " B"},
    "size.mb": {"es": "{value:.1f} MB", "en": "{value:.1f} MB"},
    "size.kb": {"es": "{value:.1f} KB", "en": "{value:.1f} KB"},
    "size.b": {"es": "{value} B", "en": "{value} B"},
    # — EMR QA —
    "emr.app.title": {"es": "EMR QA", "en": "EMR QA"},
    "emr.action.close_file": {"es": "Cerrar archivo", "en": "Close file"},
    "emr.action.quit": {"es": "Salir", "en": "Quit"},
    "emr.action.open": {"es": "Abrir", "en": "Open"},
    "emr.action.probe": {"es": "Probar", "en": "Validate"},
    "emr.action.about": {"es": "Acerca de EMR QA", "en": "About EMR QA"},
    "emr.about.body": {
        "es": "Iteración 2 — archivos locales, Abrir/Probar, templates v2.0",
        "en": "Iteration 2 — local files, Open/Validate, v2.0 templates",
    },
    "emr.about.description": {
        "es": (
            "EMR QA (iteración 2) valida archivos tabulares locales contra templates "
            "con minibase propia. Abra CSV/TSV/PSV desde el navegador, use Probar para "
            "definir llaves, guardar registros golden y QA cruzado. Opcionalmente cifre "
            "la minibase (Ver → Llave). Uso individual; datos solo en su equipo."
        ),
        "en": (
            "EMR QA (iteration 2) validates local tabular files against templates with "
            "their own minibase. Open CSV/TSV/PSV from the browser, use Validate to define "
            "keys, save golden records, and cross-QA. Optionally encrypt the minibase "
            "(View → Key). Individual use; data stays on your machine."
        ),
    },
    "emr.about.open_manual": {
        "es": "Abrir manual de uso…",
        "en": "Open user manual…",
    },
    "emr.about.manual_missing": {
        "es": "No se encontró el manual:\n{path}",
        "en": "Manual not found:\n{path}",
    },
    "emr.about.manual_open_failed": {
        "es": "No se pudo abrir el manual con la aplicación predeterminada:\n{path}",
        "en": "Could not open the manual with the default application:\n{path}",
    },
    "emr.filter.valid_only": {
        "es": "Solo archivos válidos (.csv, .tsv, .psv, .xlsx, .xls)",
        "en": "Valid files only (.csv, .tsv, .psv, .xlsx, .xls)",
    },
    "emr.browser.nav_hint": {
        "es": "Doble clic en carpeta para entrar · doble clic en .. para subir · "
        "usa Inicio o Descargas si te pierdes.",
        "en": "Double-click a folder to enter · double-click .. to go up · "
        "use Home or Downloads if you get lost.",
    },
    "emr.browser.go_home": {"es": "Inicio", "en": "Home"},
    "emr.browser.go_downloads": {"es": "Descargas", "en": "Downloads"},
    "emr.panel.messages": {"es": "Mensajes", "en": "Messages"},
    "emr.tab.view": {"es": "Vista", "en": "View"},
    "emr.tab.view.hint": {
        "es": "Exploración del grid: columnas visibles, colores en encabezado (clic derecho), "
        "solo filas únicas por columnas marcadas, stats por columna y zona horaria. "
        "No ejecuta validación. Al exportar un job se guardan las columnas visibles y "
        "el timezone activo; colores y unique rows son solo de exploración en pantalla.",
        "en": "Grid exploration: visible columns, header colors (right-click), "
        "unique rows by checked columns, per-column stats, and timezone. "
        "Does not run validation. Exporting a job saves visible columns and active timezone; "
        "colors and unique rows are on-screen exploration only.",
    },
    "emr.tab.validation": {"es": "Validation", "en": "Validation"},
    "emr.tab.reference": {"es": "Referencia", "en": "Reference"},
    "emr.tab.qa": {"es": "QA", "en": "QA"},
    "emr.tab.template_edit": {"es": "Template Edit", "en": "Template Edit"},
    "emr.tab.template": {"es": "Template", "en": "Template"},
    "emr.tab.catalog": {"es": "Catálogos", "en": "Catalogs"},
    "emr.tab.schema_edit": {"es": "Esquema", "en": "Schema"},
    "emr.tab.schema": {"es": "Estructura", "en": "Structure"},
    "emr.tab.automation": {"es": "Automatización", "en": "Automation"},
    "emr.action.export_job": {
        "es": "Exportar job de automatización…",
        "en": "Export automation job…",
    },
    "emr.action.open_job": {
        "es": "Abrir job…",
        "en": "Open job…",
    },
    "emr.action.run_job": {
        "es": "Ejecutar job…",
        "en": "Run job…",
    },
    "emr.action.edit_job": {
        "es": "Editar job…",
        "en": "Edit job…",
    },
    "emr.automation.hint": {
        "es": "Pruebas guardadas en emr-qa/knowledge_bases/default/jobs/ "
        "(*.job.json, *.schema.json). Seleccione un job para ver el comando CLI. "
        "Ejecutar: Archivo → Ejecutar job…. Crear esquema: tab Esquema → Guardar.",
        "en": "Tests live under emr-qa/knowledge_bases/default/jobs/ "
        "(*.job.json, *.schema.json). Select a job for the CLI command. "
        "Run via File → Run job…. Create schema: Schema tab → Save.",
    },
    "emr.job_run.dialog_hint": {
        "es": "Ajuste rutas y templates de sesión (no se guardan en el job salvo Editar job). "
        "Tras ejecutar se abrirá Probar con el resultado.",
        "en": "Adjust session paths and templates (not saved to the job except via Edit job). "
        "After run, Probar opens with the result.",
    },
    "emr.job_run.job_label": {
        "es": "Archivo job",
        "en": "Job file",
    },
    "emr.job_run.templates_session_hint": {
        "es": "Una ruta por fila (relativa a knowledge_bases/…/templates/). "
        "Use + para añadir o − para quitar. Solo afecta esta ejecución.",
        "en": "One path per row (relative to knowledge_bases/…/templates/). "
        "Use + to add or − to remove. Applies to this run only.",
    },
    "emr.job_run.add_template": {"es": "+ Añadir template", "en": "+ Add template"},
    "emr.job_run.template_ph": {
        "es": "ej. case_patient.json",
        "en": "e.g. case_patient.json",
    },
    "emr.job_run.template_filter": {
        "es": "Templates (*.json)",
        "en": "Templates (*.json)",
    },
    "emr.job_run.validation_template": {
        "es": "Template validation (sesión)",
        "en": "Validation template (session)",
    },
    "emr.job_run.schema_id": {
        "es": "Catálogo de esquema (schema_id)",
        "en": "Schema catalog (schema_id)",
    },
    "emr.job.metadata.title": {
        "es": "Documentación del job",
        "en": "Job documentation",
    },
    "emr.job.metadata.intro": {
        "es": "Describa qué valida este job, qué archivos usar y cómo interpretar PASS/FAIL. "
        "El texto se guarda en el JSON (campo description).",
        "en": "Describe what this job validates, which files to use, and how to read PASS/FAIL. "
        "Text is stored in the JSON (description field).",
    },
    "emr.job.metadata.name_label": {"es": "Nombre", "en": "Name"},
    "emr.job.metadata.description_label": {
        "es": "Documentación",
        "en": "Documentation",
    },
    "emr.job.metadata.description_ph": {
        "es": "Qué hace este job, archivos esperados, notas para QA…",
        "en": "What this job does, expected files, QA notes…",
    },
    "emr.job.metadata.include_file": {
        "es": "Guardar ruta del archivo abierto en el job (file)",
        "en": "Save open file path in job (file)",
    },
    "emr.job.metadata.include_reference": {
        "es": "Guardar ruta de referencia en el job (reference_file)",
        "en": "Save reference path in job (reference_file)",
    },
    "emr.job.metadata.saved": {
        "es": "Job actualizado: {path}",
        "en": "Job updated: {path}",
    },
    "emr.job.row_limit_label": {
        "es": "Límite de filas (extract)",
        "en": "Row limit (extract)",
    },
    "emr.job.row_limit_ph": {
        "es": "100 · 10% · vacío = todo el archivo",
        "en": "100 · 10% · empty = full file",
    },
    "emr.job.row_limit_hint": {
        "es": "Solo afecta el archivo a validar. Referencia y catálogos siempre se cargan completos.",
        "en": "Applies to the file under validation only. Reference and catalogs always load in full.",
    },
    "emr.job.default_description.qa": {
        "es": "Job QA: valida el extract contra los templates listados en qa.template_paths "
        "(y catálogos si aplica). Use row_limit (ej. 5000 o 10%) para muestrear filas del extract; "
        "referencia y catálogos van completos. En Ejecutar job indique el CSV/TXT a validar.",
        "en": "QA job: validates the extract against templates in qa.template_paths "
        "(and catalogs if any). Use row_limit (e.g. 5000 or 10%) to sample extract rows; "
        "reference and catalogs load in full. In Run job, pick the CSV/TXT to validate.",
    },
    "emr.job.default_description.reference": {
        "es": "Job referencia: compara el extract con un segundo archivo por llaves configuradas "
        "en reference.pairs. Indique file y reference_file al ejecutar.",
        "en": "Reference job: compares the extract to a second file using keys in reference.pairs. "
        "Provide file and reference_file when running.",
    },
    "emr.job.default_description.validation": {
        "es": "Job validation: overlay de minibase/reglas del template en validation.template_path.",
        "en": "Validation job: minibase/rules overlay from validation.template_path.",
    },
    "emr.job.default_description.schema": {
        "es": "Job estructura: valida tipos, null y columnas según schema.schema_id.",
        "en": "Structure job: validates types, nulls, and columns from schema.schema_id.",
    },
    "emr.automation.export_reference": {
        "es": "Exportar job (referencia)…",
        "en": "Export job (reference)…",
    },
    "emr.automation.export_qa": {
        "es": "Exportar job (QA)…",
        "en": "Export job (QA)…",
    },
    "emr.automation.export_schema": {
        "es": "Exportar job (estructura)…",
        "en": "Export job (structure)…",
    },
    "emr.automation.need_schema_catalog": {
        "es": "Elija un catálogo de esquema en el tab Estructura.",
        "en": "Pick a schema catalog on the Structure tab.",
    },
    "emr.automation.refresh_jobs": {"es": "Actualizar lista", "en": "Refresh list"},
    "emr.automation.open_job": {"es": "Abrir job…", "en": "Open job…"},
    "emr.automation.run_section": {"es": "Ejecutar (sesión)", "en": "Run (session)"},
    "emr.automation.file_label": {"es": "Archivo a validar", "en": "File to validate"},
    "emr.automation.reference_label": {
        "es": "Archivo de referencia",
        "en": "Reference file",
    },
    "emr.automation.browse": {"es": "Examinar…", "en": "Browse…"},
    "emr.automation.templates_label": {"es": "Templates del job", "en": "Job templates"},
    "emr.automation.catalogs_session": {
        "es": "Catálogos (sesión, editables)",
        "en": "Catalogs (session, editable)",
    },
    "emr.automation.run_job": {"es": "Ejecutar job", "en": "Run job"},
    "emr.automation.link_column_ph": {
        "es": "columna enlace (opcional)",
        "en": "link column (optional)",
    },
    "emr.automation.catalogs_from_job": {
        "es": "Catálogos: {names}",
        "en": "Catalogs: {names}",
    },
    "emr.automation.run_need_file": {
        "es": "Indique el archivo a validar.",
        "en": "Specify the file to validate.",
    },
    "emr.automation.run_need_reference": {
        "es": "Indique el archivo de referencia.",
        "en": "Specify the reference file.",
    },
    "emr.automation.run_need_templates": {
        "es": "Indique al menos un template QA en la sesión.",
        "en": "Specify at least one QA template for this session.",
    },
    "emr.automation.run_busy": {
        "es": "Espere a que termine la carga o validación en curso.",
        "en": "Wait for the current load or validation to finish.",
    },
    "emr.automation.pick_job": {
        "es": "Seleccione un job de la lista.",
        "en": "Select a job from the list.",
    },
    "emr.automation.job_meta": {
        "es": "{name} · modo {mode} · {columns} columnas evaluadas\n{path}",
        "en": "{name} · mode {mode} · {columns} evaluated columns\n{path}",
    },
    "emr.automation.editor_title": {
        "es": "Job JSON (solo lectura)",
        "en": "Job JSON (read-only)",
    },
    "emr.automation.save_job": {"es": "Guardar job", "en": "Save job"},
    "emr.automation.job_load_fail": {
        "es": "No se pudo leer el job: {error}",
        "en": "Could not read job: {error}",
    },
    "emr.automation.job_invalid": {
        "es": "JSON de job inválido: {error}",
        "en": "Invalid job JSON: {error}",
    },
    "emr.tab.qa.hint": {
        "es": "Valida el archivo contra templates (minibase/reglas) por llaves de negocio. "
        "Colorea solo mientras está en este tab. Export job genera un script QA separado.",
        "en": "Validates the file against templates (minibase/rules) using business keys. "
        "Grid colors apply only while this tab is active. Export job writes a separate QA script.",
    },
    "emr.tab.reference.hint": {
        "es": "Compara dos archivos planos por llaves y columnas mapeadas. "
        "Colorea solo mientras está en este tab. Export job genera un script reference separado.",
        "en": "Compares two flat files by keys and mapped columns. "
        "Grid colors apply only while this tab is active. Export job writes a separate reference script.",
    },
    "emr.automation.export": {
        "es": "Exportar job…",
        "en": "Export job…",
    },
    "emr.automation.command_title": {
        "es": "Comando CLI",
        "en": "CLI command",
    },
    "emr.automation.command_ph": {
        "es": "Exporte un job para ver el comando de ejecución.",
        "en": "Export a job to see the run command.",
    },
    "emr.automation.export_ok": {
        "es": "Job exportado: {path}",
        "en": "Job exported: {path}",
    },
    "emr.automation.export_saved_hint": {
        "es": "Carpeta del job: {path}",
        "en": "Job folder: {path}",
    },
    "emr.automation.export_cancelled": {
        "es": "Exportación cancelada; no se creó ningún archivo.",
        "en": "Export cancelled; no file was created.",
    },
    "emr.automation.export_fail": {
        "es": "No se pudo exportar el job: {error}",
        "en": "Could not export job: {error}",
    },
    "emr.automation.need_probar": {
        "es": "Abra un archivo en Probar antes de exportar el job.",
        "en": "Open a file in Validate before exporting the job.",
    },
    "emr.automation.need_mode": {
        "es": "Configure Referencia, QA o Validation antes de exportar "
        "(llave + columnas, templates QA, o template de validation).",
        "en": "Configure Reference, QA, or Validation before exporting "
        "(key + columns, QA templates, or validation template).",
    },
    "emr.automation.need_reference_config": {
        "es": "Configure la referencia (llave + columnas) antes de exportar.",
        "en": "Configure reference (key + columns) before exporting.",
    },
    "emr.automation.need_qa_templates": {
        "es": "Seleccione al menos un template QA antes de exportar.",
        "en": "Select at least one QA template before exporting.",
    },
    "emr.automation.need_validation_template": {
        "es": "Cargue un template en Validation antes de exportar.",
        "en": "Load a template in Validation before exporting.",
    },
    "emr.automation.dialog_title": {
        "es": "Exportar job EMR QA",
        "en": "Export EMR QA job",
    },
    "emr.automation.dialog_filter": {
        "es": "Job EMR QA (*.job.json)",
        "en": "EMR QA job (*.job.json)",
    },
    "emr.catalog.tab_hint": {
        "es": "1) Cree el catálogo y revíselo en la tabla de abajo. "
        "2) Clic derecho en encabezado de columna → Usar catálogo: verá el valor "
        "traducido entre paréntesis en el grid (ej. 123 (Clínica Norte)). "
        "3) Opcional: tab Referencia para comparar contra otro archivo.",
        "en": "1) Create the catalog and review it in the table below. "
        "2) Right-click a column header → Use catalog: translated values appear "
        "in parentheses in the grid (e.g. 123 (North Clinic)). "
        "3) Optional: Reference tab to compare against another file.",
    },
    "emr.catalog.preview_empty": {
        "es": "Seleccione un catálogo en la lista para ver su contenido.",
        "en": "Select a catalog from the list to view its contents.",
    },
    "emr.catalog.preview_title": {
        "es": "Vista previa — {name} · {rows} filas · llave: {key_column}",
        "en": "Preview — {name} · {rows} rows · key: {key_column}",
    },
    "emr.catalog.existing_title": {"es": "Catálogos guardados", "en": "Saved catalogs"},
    "emr.catalog.create_title": {"es": "Nuevo catálogo", "en": "New catalog"},
    "emr.catalog.name_label": {"es": "Nombre", "en": "Name"},
    "emr.catalog.key_column_label": {
        "es": "Columna llave (obligatoria)",
        "en": "Key column (required)",
    },
    "emr.catalog.unique_keys": {
        "es": "Sin duplicados (conservar primera fila por llave)",
        "en": "No duplicates (keep first row per key)",
    },
    "emr.catalog.err_columns": {
        "es": "Marque al menos una columna.",
        "en": "Check at least one column.",
    },
    "emr.catalog.columns_label": {
        "es": "Columnas a incluir",
        "en": "Columns to include",
    },
    "emr.catalog.refresh": {"es": "Actualizar", "en": "Refresh"},
    "emr.catalog.delete": {"es": "Eliminar", "en": "Delete"},
    "emr.catalog.create_btn": {"es": "Crear catálogo", "en": "Create catalog"},
    "emr.catalog.list_item": {
        "es": "{name} · {rows} filas · llave: {key_column}",
        "en": "{name} · {rows} rows · key: {key_column}",
    },
    "emr.catalog.delete_confirm": {
        "es": "¿Eliminar el catálogo «{catalog}»?",
        "en": "Delete catalog «{catalog}»?",
    },
    "emr.catalog.err_name": {
        "es": "Indique un nombre para el catálogo.",
        "en": "Enter a catalog name.",
    },
    "emr.catalog.err_key": {
        "es": "Seleccione la columna llave.",
        "en": "Select the key column.",
    },
    "emr.catalog.err_conflict": {
        "es": "La llave «{key_value}» tiene filas distintas — revise duplicados.",
        "en": "Key «{key_value}» has conflicting rows — check duplicates.",
    },
    "emr.catalog.created": {
        "es": "Catálogo «{name}» creado ({rows} filas).",
        "en": "Catalog «{name}» created ({rows} rows).",
    },
    "emr.catalog.created_skipped": {
        "es": "Catálogo «{name}» creado ({rows} filas; {skipped} duplicadas omitidas).",
        "en": "Catalog «{name}» created ({rows} rows; {skipped} duplicates skipped).",
    },
    "emr.catalog.preview_draft": {
        "es": "Vista previa — {rows} filas · {columns} columnas · llave: {key_column}",
        "en": "Preview — {rows} rows · {columns} columns · key: {key_column}",
    },
    "emr.catalog.preview_draft_skipped": {
        "es": "Vista previa — {rows} filas · {columns} columnas · llave: {key_column} "
        "({skipped} duplicadas omitidas)",
        "en": "Preview — {rows} rows · {columns} columns · key: {key_column} "
        "({skipped} duplicates skipped)",
    },
    "emr.catalog.preview_conflict": {
        "es": "Conflicto en llave «{key_value}» — active Sin duplicados o revise datos.",
        "en": "Conflict on key «{key_value}» — enable No duplicates or fix data.",
    },
    "emr.catalog.use_menu": {"es": "Usar catálogo…", "en": "Use catalog…"},
    "emr.catalog.use_title": {
        "es": "Catálogo en columna",
        "en": "Catalog on column",
    },
    "emr.catalog.use_hint": {
        "es": "Columna «{column}». El grid mostrará valor (traducción). "
        "Match = columna del catálogo que coincide con el archivo; "
        "tooltip = columnas entre paréntesis.",
        "en": "Column «{column}». The grid will show value (translation). "
        "Match = catalog column that matches the file; "
        "tooltip columns = text shown in parentheses.",
    },
    "emr.catalog.miss_marker": {"es": "?", "en": "?"},
    "emr.catalog.none": {"es": "(ninguno)", "en": "(none)"},
    "emr.catalog.pick_catalog": {"es": "Catálogo", "en": "Catalog"},
    "emr.catalog.match_column": {
        "es": "Columna match (código en catálogo)",
        "en": "Match column (code in catalog)",
    },
    "emr.catalog.display_columns": {
        "es": "Columnas para tooltip",
        "en": "Columns for tooltip",
    },
    "emr.catalog.compare_column": {
        "es": "Columna para comparar",
        "en": "Column to compare",
    },
    "emr.catalog.multi_comma": {
        "es": "Varios códigos en la celda (separados por coma)",
        "en": "Multiple codes in cell (comma-separated)",
    },
    "emr.catalog.clear_binding": {
        "es": "Quitar catálogo",
        "en": "Remove catalog",
    },
    "emr.catalog.binding_saved": {
        "es": "Catálogo asociado a «{column}» ({catalog}).",
        "en": "Catalog linked to «{column}» ({catalog}).",
    },
    "emr.catalog.binding_cleared": {
        "es": "Catálogo quitado de «{column}».",
        "en": "Catalog removed from «{column}».",
    },
    "emr.catalog.cell_tooltip": {
        "es": "Archivo: {file}\nCatálogo: {catalog}",
        "en": "File: {file}\nCatalog: {catalog}",
    },
    "emr.catalog.cell_tooltip_diff": {
        "es": "Archivo: {file}\nCatálogo: {catalog}\nReferencia: {reference}",
        "en": "File: {file}\nCatalog: {catalog}\nReference: {reference}",
    },
    "emr.template.none": {"es": "Sin template", "en": "No template"},
    "emr.template.create": {"es": "Create template", "en": "Create template"},
    "emr.template.load": {"es": "Load template", "en": "Load template"},
    "emr.template.create_dialog_title": {
        "es": "Nuevo template",
        "en": "New template",
    },
    "emr.template.create_dialog_hint": {
        "es": "Un template es una mini base de datos local. Puede crearse vacío y crecer al guardar registros.",
        "en": "A template is a local mini database. It can start empty and grow as you save records.",
    },
    "emr.template.name_label": {"es": "Nombre", "en": "Name"},
    "emr.template.name_ph": {"es": "Nombre del template", "en": "Template name"},
    "emr.template.name_required": {"es": "Indique un nombre.", "en": "Enter a name."},
    "emr.template.key_columns": {
        "es": "Columnas de la llave primaria",
        "en": "Primary key columns",
    },
    "emr.template.key_required": {
        "es": "Seleccione al menos una columna para la llave.",
        "en": "Select at least one key column.",
    },
    "emr.template.key_leave_compare": {
        "es": "Deje al menos un campo fuera de la llave para comparar valores.",
        "en": "Leave at least one field outside the key to compare values.",
    },
    "emr.template.load_dialog_title": {
        "es": "Cargar template",
        "en": "Load template",
    },
    "emr.template.file_filter": {
        "es": "Template JSON (*.json)",
        "en": "Template JSON (*.json)",
    },
    "emr.template.empty_hint": {
        "es": "Cree o cargue un template para validar y guardar registros.",
        "en": "Create or load a template to validate and save records.",
    },
    "emr.template.meta": {
        "es": "{records} registros · {fields} campos · {locked}",
        "en": "{records} records · {fields} fields · {locked}",
    },
    "emr.template.structure_locked": {
        "es": "estructura bloqueada",
        "en": "structure locked",
    },
    "emr.template.structure_editable": {
        "es": "estructura editable",
        "en": "structure editable",
    },
    "emr.template.key_section": {
        "es": "Llave primaria (localiza la fila)",
        "en": "Primary key (locates the row)",
    },
    "emr.template.compare_fields_hint": {
        "es": "Los campos no marcados como llave se comparan contra la minibase.",
        "en": "Fields not in the key are compared against the minibase.",
    },
    "emr.schema.edit.hint": {
        "es": "Defina columnas esperadas, tipo, null y modo estricto. "
        "En «Batch — emparejamiento de archivos» indique regex (una por línea) para el batch automático. "
        "Al guardar se crean <schema_id>.schema.json y <schema_id>.job.json en knowledge_bases/default/jobs/.",
        "en": "Define expected columns, type, nullability, and strict mode. "
        "Under «Batch — file matching», set regex patterns (one per line) for automatic batch runs. "
        "On save, writes <schema_id>.schema.json and <schema_id>.job.json under knowledge_bases/default/jobs/.",
    },
    "emr.schema.edit.existing": {"es": "Catálogos de esquema", "en": "Schema catalogs"},
    "emr.schema.edit.refresh": {"es": "Actualizar", "en": "Refresh"},
    "emr.schema.edit.new": {"es": "Nuevo catálogo", "en": "New catalog"},
    "emr.schema.edit.delete": {"es": "Eliminar catálogo", "en": "Delete catalog"},
    "emr.schema.edit.name_label": {"es": "Nombre", "en": "Name"},
    "emr.schema.edit.strict": {
        "es": "Modo estricto (mismo número de columnas, conjunto exacto)",
        "en": "Strict mode (exact column count and names)",
    },
    "emr.schema.edit.import_columns": {
        "es": "Importar columnas del archivo",
        "en": "Import columns from file",
    },
    "emr.schema.edit.add_row": {"es": "Añadir columna", "en": "Add column"},
    "emr.schema.edit.remove_rows": {"es": "Eliminar fila(s)", "en": "Remove row(s)"},
    "emr.schema.edit.save": {"es": "Guardar catálogo", "en": "Save catalog"},
    "emr.schema.edit.name_prompt": {"es": "Nombre del catálogo:", "en": "Catalog name:"},
    "emr.schema.edit.delete_confirm": {
        "es": "¿Eliminar el catálogo «{schema_id}»?",
        "en": "Delete catalog «{schema_id}»?",
    },
    "emr.schema.edit.need_dataset": {
        "es": "Abra un archivo en Probar para importar columnas.",
        "en": "Open a file in Probar to import columns.",
    },
    "emr.schema.edit.need_catalog": {
        "es": "Cree o seleccione un catálogo.",
        "en": "Create or select a catalog.",
    },
    "emr.schema.edit.need_name": {"es": "Indique un nombre.", "en": "Enter a name."},
    "emr.schema.edit.need_columns": {
        "es": "Añada al menos una columna con nombre.",
        "en": "Add at least one named column.",
    },
    "emr.schema.edit.saved": {"es": "Catálogo de esquema guardado.", "en": "Schema catalog saved."},
    "emr.schema.edit.deleted": {"es": "Catálogo eliminado.", "en": "Catalog deleted."},
    "emr.batch_match.title": {
        "es": "Batch — emparejamiento de archivos",
        "en": "Batch — file matching",
    },
    "emr.batch_match.hint": {
        "es": "Una expresión regular por línea (Python). Extensiones: csv, tsv, psv, xlsx, xlsm, xls. "
        "Si está vacío, el job no entra al batch automático.",
        "en": "One regular expression per line (Python). Extensions: csv, tsv, psv, xlsx, xlsm, xls. "
        "If empty, the job is excluded from automatic batch runs.",
    },
    "emr.batch_match.patterns_label": {
        "es": "Patrones de nombre de archivo",
        "en": "Filename patterns",
    },
    "emr.batch_match.excludes_label": {
        "es": "Exclusiones (opcional)",
        "en": "Exclusions (optional)",
    },
    "emr.batch_match.example": {
        "es": "Ejemplo: {pattern}",
        "en": "Example: {pattern}",
    },
    "emr.batch_match.use_example": {
        "es": "Insertar ejemplo",
        "en": "Insert example",
    },
    "emr.batch_match.from_file": {
        "es": "Insertar desde archivo cargado",
        "en": "Insert from loaded file",
    },
    "emr.batch_match.from_file_empty": {
        "es": "Carga un archivo para generar el patrón desde su nombre.",
        "en": "Load a file to build the pattern from its name.",
    },
    "emr.batch_match.invalid_regex": {
        "es": "Regex inválida en emparejamiento batch",
        "en": "Invalid regex in batch matching",
    },
    "emr.catalog.batch_save": {
        "es": "Guardar reglas batch",
        "en": "Save batch rules",
    },
    "emr.catalog.batch_saved": {
        "es": "Reglas batch del catálogo guardadas.",
        "en": "Catalog batch rules saved.",
    },
    "emr.catalog.batch_pick": {
        "es": "Seleccione un catálogo para editar las reglas batch.",
        "en": "Select a catalog to edit batch rules.",
    },
    "emr.schema.col.enabled": {"es": "Evaluar", "en": "Evaluate"},
    "emr.schema.col.name": {"es": "Columna", "en": "Column"},
    "emr.schema.col.type": {"es": "Tipo", "en": "Type"},
    "emr.schema.col.null": {"es": "Null", "en": "Null"},
    "emr.schema.col.unique": {
        "es": "Único",
        "en": "Unique",
    },
    "emr.schema.col.date_format": {"es": "Formato fecha", "en": "Date format"},
    "emr.schema.strict.badge": {"es": "estricto", "en": "strict"},
    "emr.schema.strict.yes": {"es": "Sí", "en": "Yes"},
    "emr.schema.strict.no": {"es": "No", "en": "No"},
    "emr.schema.test.hint": {
        "es": "Validación estructural separada de QA y Referencia. "
        "Columnas no evaluadas o fuera del catálogo cuentan como coverage, no error.",
        "en": "Structural validation separate from QA and Reference. "
        "Unevaluated or out-of-catalog columns count as coverage, not errors.",
    },
    "emr.schema.test.catalog_label": {"es": "Catálogo de esquema", "en": "Schema catalog"},
    "emr.schema.test.pick_catalog": {"es": "— elegir catálogo —", "en": "— pick catalog —"},
    "emr.schema.test.execute": {"es": "Validar estructura", "en": "Validate structure"},
    "emr.schema.need_config": {
        "es": "Elija un catálogo de esquema.",
        "en": "Pick a schema catalog.",
    },
    "emr.schema.done": {"es": "Validación estructural completada.", "en": "Structure validation done."},
    "emr.schema.summary.title": {"es": "Resumen estructura", "en": "Structure summary"},
    "emr.schema.summary.idle": {
        "es": "Elija catálogo y pulse Validar estructura.",
        "en": "Pick a catalog and click Validate structure.",
    },
    "emr.schema.summary.running": {"es": "Validando…", "en": "Validating…"},
    "emr.schema.summary.error": {"es": "Error de validación", "en": "Validation error"},
    "emr.schema.summary.copy": {"es": "Copiar reporte", "en": "Copy report"},
    "emr.schema.summary.meta": {
        "es": "{schema} · estricto: {strict} · {rows} filas",
        "en": "{schema} · strict: {strict} · {rows} rows",
    },
    "emr.schema.summary.kpi_cells": {
        "es": "Celdas OK {ok} · NOK {nok}",
        "en": "Cells OK {ok} · NOK {nok}",
    },
    "emr.schema.summary.kpi_coverage": {
        "es": "Coverage {pct}%",
        "en": "Coverage {pct}%",
    },
    "emr.schema.summary.kpi_quality": {
        "es": "Calidad {pct}%",
        "en": "Quality {pct}%",
    },
    "emr.schema.summary.kpi_gaps": {
        "es": "Errores estructura {structural} · columnas sin coverage {coverage}",
        "en": "Structural errors {structural} · uncovered columns {coverage}",
    },
    "emr.schema.report.title": {
        "es": "=== Reporte estructura columnar ===",
        "en": "=== Column structure report ===",
    },
    "emr.schema.report.file": {"es": "Archivo: {name}", "en": "File: {name}"},
    "emr.schema.report.schema": {
        "es": "Esquema: {name} ({schema_id})",
        "en": "Schema: {name} ({schema_id})",
    },
    "emr.schema.report.strict": {"es": "Estricto: {value}", "en": "Strict: {value}"},
    "emr.schema.report.generated": {"es": "Generado: {at}", "en": "Generated: {at}"},
    "emr.schema.report.cells": {
        "es": "Celdas OK {ok} · NOK {nok} · sin evaluar {unevaluated}",
        "en": "Cells OK {ok} · NOK {nok} · unevaluated {unevaluated}",
    },
    "emr.schema.report.coverage_pct": {"es": "Coverage: {pct}%", "en": "Coverage: {pct}%"},
    "emr.schema.report.quality_pct": {"es": "Calidad: {pct}%", "en": "Quality: {pct}%"},
    "emr.schema.report.structural": {
        "es": "Errores estructurales:",
        "en": "Structural errors:",
    },
    "emr.schema.report.coverage_columns": {
        "es": "Columnas fuera del catálogo (coverage):",
        "en": "Columns outside catalog (coverage):",
    },
    "emr.schema.report.by_column": {"es": "Por columna:", "en": "By column:"},
    "emr.schema.report.column_unevaluated": {
        "es": "  · {column} — no evaluada (coverage)",
        "en": "  · {column} — not evaluated (coverage)",
    },
    "emr.schema.report.column_line": {
        "es": "  · {column} ({type}) OK {ok} NOK {nok} ({pct}%)",
        "en": "  · {column} ({type}) OK {ok} NOK {nok} ({pct}%)",
    },
    "emr.schema.headline.ok": {
        "es": "Estructura OK — {ok}/{judged} celdas",
        "en": "Structure OK — {ok}/{judged} cells",
    },
    "emr.schema.headline.nok": {
        "es": "Estructura NOK — {nok} celdas en {judged} evaluadas",
        "en": "Structure NOK — {nok} cells of {judged} judged",
    },
    "emr.schema.headline.structural": {
        "es": "Errores estructurales ({count})",
        "en": "Structural errors ({count})",
    },
    "emr.schema.headline.mixed": {
        "es": "Estructura NOK — {structural} errores de columnas, {nok} celdas NOK",
        "en": "Structure NOK — {structural} column errors, {nok} NOK cells",
    },
    "emr.schema.headline.no_data": {
        "es": "SIN DATOS — el archivo no trae filas; no se puede evaluar tipo ni patrón",
        "en": "NO DATA — file has no rows; type and pattern cannot be evaluated",
    },
    "emr.schema.headline.coverage_only": {
        "es": "Sin celdas evaluadas — revise coverage",
        "en": "No cells judged — check coverage",
    },
    "emr.ref.enabled": {
        "es": "Comparar",
        "en": "Compare",
    },
    "emr.ref.is_key": {
        "es": "Llave",
        "en": "Key",
    },
    "emr.ref.execute": {
        "es": "Ejecutar comparación",
        "en": "Run comparison",
    },
    "emr.ref.need_key": {
        "es": "Marca al menos una columna comparada como llave.",
        "en": "Mark at least one compared column as key.",
    },
    "emr.ref.need_pair": {
        "es": "Añade al menos una columna comparada activa.",
        "en": "Add at least one active compared column.",
    },
    "emr.ref.config_pending": {
        "es": "Configuración actualizada. Pulsa Ejecutar comparación para actualizar el grid.",
        "en": "Configuration updated. Click Run comparison to refresh the grid.",
    },
    "emr.ref.cell_tooltip_diff": {
        "es": "Archivo: {file}\nReferencia: {reference}",
        "en": "File: {file}\nReference: {reference}",
    },
    "emr.ref.cell_tooltip_no_match": {
        "es": "Archivo: {file}\nReferencia: sin fila con esa llave",
        "en": "File: {file}\nReference: no row with that key",
    },
    "emr.ref.hint": {
        "es": "Elija referencia y mapee columnas (marque Llave en la fila de join). "
        "Pulse Ejecutar comparación cuando esté listo. "
        "Regex opcional en cada fila. <NA> y vacíos cuentan igual.",
        "en": "Pick reference and map columns (check Key on the join row). "
        "Click Run comparison when ready. "
        "Optional regex per row. <NA> and empty values count the same.",
    },
    "emr.ref.pick_file": {"es": "Elegir referencia…", "en": "Pick reference…"},
    "emr.ref.pick_dialog_title": {
        "es": "Archivo de referencia tabular",
        "en": "Tabular reference file",
    },
    "emr.ref.file_filter": {
        "es": "Tabular (*.csv *.tsv *.psv)",
        "en": "Tabular (*.csv *.tsv *.psv)",
    },
    "emr.ref.not_tabular": {
        "es": "Solo archivos CSV, TSV o PSV.",
        "en": "CSV, TSV, or PSV files only.",
    },
    "emr.ref.no_file": {
        "es": "Sin archivo de referencia.",
        "en": "No reference file selected.",
    },
    "emr.ref.meta": {
        "es": "{name} · {rows} filas · {cols} columnas",
        "en": "{name} · {rows} rows · {cols} columns",
    },
    "emr.ref.truncated": {
        "es": "referencia truncada a 500.000 filas",
        "en": "reference truncated to 500,000 rows",
    },
    "emr.ref.dup_policy": {
        "es": "Llaves duplicadas en referencia",
        "en": "Duplicate keys in reference",
    },
    "emr.ref.dup_first": {
        "es": "Usar primera coincidencia",
        "en": "Use first match",
    },
    "emr.ref.dup_ambiguous": {
        "es": "Marcar como ambiguo (error de llave)",
        "en": "Mark as ambiguous (key error)",
    },
    "emr.ref.join_section": {
        "es": "Llave de cruce (mapear columnas)",
        "en": "Join key (map columns)",
    },
    "emr.ref.pairs_section": {
        "es": "Columnas comparadas (marca Llave en la fila de join)",
        "en": "Compared columns (check Key on the join row)",
    },
    "emr.ref.add_join": {"es": "+ Llave", "en": "+ Key"},
    "emr.ref.add_pair": {"es": "+ Columna", "en": "+ Column"},
    "emr.ref.auto_map": {
        "es": "Auto-mapear nombres iguales",
        "en": "Auto-map matching names",
    },
    "emr.ref.col_file": {"es": "Archivo", "en": "File"},
    "emr.ref.col_ref": {"es": "Referencia", "en": "Reference"},
    "emr.ref.regex_left_ph": {"es": "Regex archivo", "en": "File regex"},
    "emr.ref.regex_right_ph": {"es": "Regex referencia", "en": "Reference regex"},
    "emr.ref.replace_ph": {
        "es": "Reemplazo (~ = vacío)",
        "en": "Replace (~ = empty)",
    },
    "emr.ref.loaded": {
        "es": "Referencia cargada: {name}",
        "en": "Reference loaded: {name}",
    },
    "emr.ref.need_file": {
        "es": "Elija primero un archivo de referencia.",
        "en": "Pick a reference file first.",
    },
    "emr.ref.auto_mapped": {
        "es": "Columnas auto-mapeadas por nombre.",
        "en": "Columns auto-mapped by name.",
    },
    "emr.ref.need_config": {
        "es": "Configure referencia, una llave y al menos una columna comparada.",
        "en": "Configure reference, one key, and at least one compared column.",
    },
    "emr.ref.disabled": {
        "es": "Active la comparación contra referencia.",
        "en": "Enable reference comparison.",
    },
    "emr.ref.done": {
        "es": "Comparación contra referencia completada.",
        "en": "Reference comparison complete.",
    },
    "emr.ref.no_match_rows": {
        "es": "{count} filas sin coincidencia de llave",
        "en": "{count} rows with no key match",
    },
    "emr.ref.summary.title": {
        "es": "Resumen de comparación",
        "en": "Comparison summary",
    },
    "emr.ref.summary.compare_now": {
        "es": "Comparar ahora",
        "en": "Compare now",
    },
    "emr.ref.summary.copy": {
        "es": "Copiar resumen",
        "en": "Copy summary",
    },
    "emr.ref.summary.idle": {
        "es": "Sin ejecutar",
        "en": "Not run yet",
    },
    "emr.ref.summary.idle_hint": {
        "es": "Configure referencia y columnas abajo; luego Ejecutar comparación.",
        "en": "Configure reference and columns below; then Run comparison.",
    },
    "emr.ref.summary.need_config_hint": {
        "es": "Complete la llave de cruce y al menos una columna, luego Comparar ahora.",
        "en": "Complete join key and at least one column, then Compare now.",
    },
    "emr.ref.summary.running": {
        "es": "Comparando…",
        "en": "Comparing…",
    },
    "emr.ref.summary.running_hint": {
        "es": "Emparejando filas contra la referencia.",
        "en": "Matching rows against the reference file.",
    },
    "emr.ref.summary.done": {
        "es": "Completado",
        "en": "Complete",
    },
    "emr.ref.summary.error": {
        "es": "Error",
        "en": "Error",
    },
    "emr.ref.summary.kpi_rows": {
        "es": "Filas localizadas: {matched}/{total} ({pct}%)",
        "en": "Rows located: {matched}/{total} ({pct}%)",
    },
    "emr.ref.summary.kpi_cells": {
        "es": "Celdas OK: {ok}/{total} ({pct}%)",
        "en": "Cells OK: {ok}/{total} ({pct}%)",
    },
    "emr.ref.summary.kpi_no_match": {
        "es": "Sin llave: {count} · Ambiguas: {ambiguous}",
        "en": "No key match: {count} · Ambiguous: {ambiguous}",
    },
    "emr.ref.summary.kpi_deltas": {
        "es": "Deltas (NOK): {count} celdas · {pairs} columnas",
        "en": "Deltas (NOK): {count} cells · {pairs} columns",
    },
    "emr.ref.summary.columns": {
        "es": "Por columna (OK / NOK)",
        "en": "By column (OK / NOK)",
    },
    "emr.ref.summary.columns_empty": {
        "es": "Sin columnas evaluadas.",
        "en": "No evaluated columns.",
    },
    "emr.ref.summary.column_line": {
        "es": "· {left}: OK {ok} · NOK {nok} ({pct}%)",
        "en": "· {left}: OK {ok} · NOK {nok} ({pct}%)",
    },
    "emr.ref.summary.columns_more": {
        "es": "… y {count} columnas más",
        "en": "… and {count} more columns",
    },
    "emr.ref.summary.progress_line": {
        "es": "Filas {rows}/{total} localizadas · celdas OK {ok} · NOK {nok}",
        "en": "Rows {rows}/{total} located · cells OK {ok} · NOK {nok}",
    },
    "emr.ref.report.title": {
        "es": "Informe comparación referencia",
        "en": "Reference comparison report",
    },
    "emr.ref.report.file": {"es": "Archivo: {name}", "en": "File: {name}"},
    "emr.ref.report.reference": {
        "es": "Referencia: {name}",
        "en": "Reference: {name}",
    },
    "emr.ref.report.generated": {
        "es": "Generado: {at}",
        "en": "Generated: {at}",
    },
    "emr.ref.report.rows": {
        "es": "Filas: {matched} localizadas de {compared} ({pct}%)",
        "en": "Rows: {matched} located of {compared} ({pct}%)",
    },
    "emr.ref.report.cells": {
        "es": "Celdas: OK {ok} · NOK {nok} ({pct}% OK)",
        "en": "Cells: OK {ok} · NOK {nok} ({pct}% OK)",
    },
    "emr.ref.report.no_match": {
        "es": "Filas sin llave: {count}",
        "en": "Rows without key: {count}",
    },
    "emr.ref.report.ambiguous": {
        "es": "Filas ambiguas: {count}",
        "en": "Ambiguous rows: {count}",
    },
    "emr.ref.report.dup_keys": {
        "es": "Llaves duplicadas en referencia: {count}",
        "en": "Duplicate keys in reference: {count}",
    },
    "emr.ref.report.join": {
        "es": "Llave: {keys}",
        "en": "Join key: {keys}",
    },
    "emr.ref.report.columns_header": {
        "es": "Columnas:",
        "en": "Columns:",
    },
    "emr.ref.report.column_line": {
        "es": "  {left} ↔ {right}: OK {ok} NOK {nok} ({pct}%)",
        "en": "  {left} ↔ {right}: OK {ok} NOK {nok} ({pct}%)",
    },
    "emr.ref.report.headline_empty": {
        "es": "Sin filas para comparar.",
        "en": "No rows to compare.",
    },
    "emr.ref.report.headline_no_match": {
        "es": "Ninguna fila coincidió por llave — revise el mapeo de llave.",
        "en": "No rows matched on join key — check key mapping.",
    },
    "emr.ref.report.headline_ok": {
        "es": "Todo coincide con la referencia en las columnas evaluadas.",
        "en": "Everything matches the reference for evaluated columns.",
    },
    "emr.ref.report.headline_mostly_ok": {
        "es": "Casi todo coincide; revise deltas puntuales.",
        "en": "Mostly matches; review remaining deltas.",
    },
    "emr.ref.report.headline_deltas": {
        "es": "Hay deltas: {nok} celdas distintas · {rows} filas sin llave.",
        "en": "Deltas found: {nok} mismatched cells · {rows} rows without key.",
    },
    "emr.ref.fullscreen.open": {"es": "Pantalla completa", "en": "Full screen"},
    "emr.ref.fullscreen.close": {"es": "Cerrar", "en": "Close"},
    "emr.ref.fullscreen.title": {
        "es": "Referencia — {file} vs {reference}",
        "en": "Reference — {file} vs {reference}",
    },
    "emr.ref.report.summary_section": {"es": "Resumen", "en": "Summary"},
    "emr.ref.report.columns_section": {"es": "Columnas comparadas", "en": "Compared columns"},
    "emr.ref.report.meta_block": {
        "es": "{file} vs {reference}\n{headline}\n{generated}",
        "en": "{file} vs {reference}\n{headline}\n{generated}",
    },
    "emr.ref.report.rows_label": {"es": "Filas localizadas", "en": "Rows located"},
    "emr.ref.report.cells_label": {"es": "Celdas evaluadas", "en": "Cells judged"},
    "emr.ref.report.ref_rows": {"es": "Filas referencia cargadas", "en": "Reference rows loaded"},
    "emr.ref.report.ref_rows_value": {
        "es": "{loaded} de {total}",
        "en": "{loaded} of {total}",
    },
    "emr.ref.report.pairs_compared": {
        "es": "Pares de columnas",
        "en": "Column pairs",
    },
    "emr.ref.report.table.column": {"es": "Columna", "en": "Column"},
    "emr.ref.report.table.reference": {"es": "Referencia", "en": "Reference"},
    "emr.ref.report.table.ok": {"es": "OK", "en": "OK"},
    "emr.ref.report.table.nok": {"es": "NOK", "en": "NOK"},
    "emr.ref.report.table.ok_pct": {"es": "% OK", "en": "% OK"},
    "emr.ref.charts.cells_title": {"es": "Celdas OK vs NOK", "en": "Cells OK vs NOK"},
    "emr.ref.charts.columns_title": {"es": "Por columna", "en": "By column"},
    "emr.ref.charts.cells_pie_title": {
        "es": "Distribución de celdas",
        "en": "Cell distribution",
    },
    "emr.ref.charts.columns_bar_title": {
        "es": "OK vs NOK por columna",
        "en": "OK vs NOK by column",
    },
    "emr.ref.charts.ok": {"es": "OK", "en": "OK"},
    "emr.ref.charts.nok": {"es": "NOK", "en": "NOK"},
    "emr.ref.charts.no_data": {"es": "Sin datos", "en": "No data"},
    "emr.ref.metrics.nok_only_empty": {
        "es": "(Sin columnas con NOK)",
        "en": "(No columns with NOK)",
    },
    "emr.ref.metrics.csv.header": {
        "es": "section,column,reference,ok,nok,ok_pct",
        "en": "section,column,reference,ok,nok,ok_pct",
    },
    "emr.ref.metrics.csv.section_column": {
        "es": "column",
        "en": "column",
    },
    "emr.ref.metrics.csv.section_summary": {
        "es": "summary",
        "en": "summary",
    },
    "emr.ref.metrics.export_pdf_title": {
        "es": "Exportar reporte referencia PDF",
        "en": "Export reference report PDF",
    },
    "emr.ref.metrics.export_pdf_filter": {
        "es": "PDF (*.pdf)",
        "en": "PDF (*.pdf)",
    },
    "emr.ref.na_hint": {
        "es": "Los valores <NA>/vacíos se normalizan igual en ambos lados antes de comparar.",
        "en": "<NA>/empty values are normalized the same on both sides before comparing.",
    },
    "emr.template.apply_key": {"es": "Aplicar llave", "en": "Apply key"},
    "emr.template.active_fields": {
        "es": "Columnas activas — valores a guardar",
        "en": "Active columns — values to save",
    },
    "emr.template.add_record": {"es": "ADD", "en": "ADD"},
    "emr.template.save_record": {"es": "Save", "en": "Save"},
    "emr.template.value_ph": {"es": "Valor", "en": "Value"},
    "emr.template.no_active_columns": {
        "es": "Marque columnas visibles en el tab Vista.",
        "en": "Enable columns in the View tab.",
    },
    "emr.template.need_dataset": {
        "es": "Abra un archivo tabular antes de crear un template.",
        "en": "Open a tabular file before creating a template.",
    },
    "emr.template.need_visible_columns": {
        "es": "Seleccione al menos una columna visible en Vista.",
        "en": "Select at least one visible column in View.",
    },
    "emr.template.created": {
        "es": "Template creado: {name}",
        "en": "Template created: {name}",
    },
    "emr.template.loaded": {
        "es": "Template cargado: {name}",
        "en": "Template loaded: {name}",
    },
    "emr.template.need_template": {
        "es": "Cree o cargue un template primero.",
        "en": "Create or load a template first.",
    },
    "emr.template.key_locked": {
        "es": "La llave no puede cambiar: ya hay registros guardados.",
        "en": "Key cannot change: saved records exist.",
    },
    "emr.template.key_applied": {
        "es": "Llave primaria actualizada.",
        "en": "Primary key updated.",
    },
    "emr.template.record_added": {
        "es": "Registro añadido al template.",
        "en": "Record added to template.",
    },
    "emr.template.records_added": {
        "es": "{count} registro(s) añadido(s) al template.",
        "en": "{count} record(s) added to template.",
    },
    "emr.template.need_values_or_mark": {
        "es": "Marque filas en el grid o ingrese valores en el formulario.",
        "en": "Mark rows in the grid or enter values in the form.",
    },
    "emr.msg.build_mode": {
        "es": "Añada tuplas con +, ADD, Añadir todos o el formulario manual.",
        "en": "Add tuples with +, ADD, Add all, or the manual form.",
    },
    "emr.msg.minibase_overlay": {
        "es": "Grid validado contra la minibase del template activo.",
        "en": "Grid validated against the active template minibase.",
    },
    "emr.template.record_saved": {
        "es": "Registro guardado en el template.",
        "en": "Record saved to template.",
    },
    "emr.qa.hint": {
        "es": "Marque uno o más templates para validar el archivo contra sus minibases.",
        "en": "Check one or more templates to validate the file against their minibases.",
    },
    "emr.qa.discrepancy_mode": {
        "es": "Resaltar discrepancia entre templates (naranja)",
        "en": "Highlight template discrepancy (orange)",
    },
    "emr.qa.conflicts": {
        "es": "Discrepancias entre templates: {count} celdas",
        "en": "Template discrepancies: {count} cells",
    },
    "emr.qa.empty": {
        "es": "No hay templates guardados. Créelos en el tab Validation.",
        "en": "No saved templates. Create them in the Validation tab.",
    },
    "emr.qa.template_item": {
        "es": "{name} ({records} reg.)",
        "en": "{name} ({records} rec.)",
    },
    "emr.qa.templates_active": {
        "es": "Templates activos: {count}",
        "en": "Active templates: {count}",
    },
    "emr.qa.metrics.title": {
        "es": "Resumen QA",
        "en": "QA summary",
    },
    "emr.qa.metrics.empty": {
        "es": "Marque templates y ejecute validación para ver métricas.",
        "en": "Check templates and run validation to see metrics.",
    },
    "emr.qa.metrics.nok_only": {
        "es": "Solo columnas NOK",
        "en": "NOK columns only",
    },
    "emr.qa.metrics.copy_report": {
        "es": "Copiar reporte",
        "en": "Copy report",
    },
    "emr.qa.metrics.copy_csv": {
        "es": "Copiar CSV",
        "en": "Copy CSV",
    },
    "emr.qa.metrics.export_pdf": {
        "es": "Exportar PDF",
        "en": "Export PDF",
    },
    "emr.qa.metrics.export_pdf_title": {
        "es": "Guardar reporte QA como PDF",
        "en": "Save QA report as PDF",
    },
    "emr.qa.metrics.export_pdf_filter": {
        "es": "Documento PDF (*.pdf)",
        "en": "PDF document (*.pdf)",
    },
    "emr.qa.metrics.export_pdf_done": {
        "es": "PDF guardado en:\n{path}",
        "en": "PDF saved to:\n{path}",
    },
    "emr.qa.metrics.export_pdf_fail": {
        "es": "No se pudo guardar el PDF:\n{error}",
        "en": "Could not save PDF:\n{error}",
    },
    "emr.qa.metrics.tab_report": {
        "es": "Reporte",
        "en": "Report",
    },
    "emr.qa.metrics.tab_charts": {
        "es": "Gráficos",
        "en": "Charts",
    },
    "emr.qa.metrics.kpi_coverage": {
        "es": "Cobertura {pct}% ({judged}/{eligible})",
        "en": "Coverage {pct}% ({judged}/{eligible})",
    },
    "emr.qa.metrics.kpi_quality": {
        "es": "Calidad {pct}% (OK {ok}/{judged})",
        "en": "Quality {pct}% (OK {ok}/{judged})",
    },
    "emr.qa.metrics.kpi_localization": {
        "es": "Localización {pct}% ({located}/{complete})",
        "en": "Localization {pct}% ({located}/{complete})",
    },
    "emr.qa.metrics.kpi_conflict": {
        "es": "Discrepancia {pct}% ({count}/{judged})",
        "en": "Discrepancy {pct}% ({count}/{judged})",
    },
    "emr.qa.metrics.chart_columns": {
        "es": "OK vs NOK por columna",
        "en": "OK vs NOK by column",
    },
    "emr.qa.metrics.chart_templates": {
        "es": "OK vs NOK por plantilla",
        "en": "OK vs NOK by template",
    },
    "emr.qa.metrics.chart_bar_subtitle": {
        "es": "{title}\nOK {ok} · NOK {nok}",
        "en": "{title}\nOK {ok} · NOK {nok}",
    },
    "emr.qa.metrics.chart_coverage": {
        "es": "Cobertura sobre elegibles (unificado)",
        "en": "Coverage of eligible cells (merged)",
    },
    "emr.qa.metrics.chart_quality": {
        "es": "OK / NOK / no cubierto (unificado)",
        "en": "OK / NOK / uncovered (merged)",
    },
    "emr.qa.metrics.chart_quality_subtitle": {
        "es": "{title}\nElegibles {eligible} · OK {ok} · NOK {nok} · no cubierto {uncovered}",
        "en": "{title}\nEligible {eligible} · OK {ok} · NOK {nok} · uncovered {uncovered}",
    },
    "emr.qa.metrics.chart_coverage_subtitle": {
        "es": "{title}\n{pct}% · juzgadas {judged}/{eligible} celdas",
        "en": "{title}\n{pct}% · judged {judged}/{eligible} cells",
    },
    "emr.qa.metrics.chart_coverage_by_template": {
        "es": "Cobertura por plantilla",
        "en": "Coverage by template",
    },
    "emr.qa.metrics.chart_slice_label": {
        "es": "{name} {pct}% ({count})",
        "en": "{name} {pct}% ({count})",
    },
    "emr.qa.metrics.chart_slice_legend": {
        "es": "{name} {pct}% ({count})",
        "en": "{name} {pct}% ({count})",
    },
    "emr.qa.metrics.chart_ok": {
        "es": "OK",
        "en": "OK",
    },
    "emr.qa.metrics.chart_nok": {
        "es": "NOK",
        "en": "NOK",
    },
    "emr.qa.metrics.chart_judged": {
        "es": "Juzgadas",
        "en": "Judged",
    },
    "emr.qa.metrics.chart_pending": {
        "es": "No evaluadas",
        "en": "Unevaluated",
    },
    "emr.qa.metrics.chart_uncovered": {
        "es": "No cubierto",
        "en": "Uncovered",
    },
    "emr.qa.metrics.chart_board_hint": {
        "es": "Por plantilla: el pie muestra OK / NOK / no cubierto; debajo, base y evaluado en cifras",
        "en": "Per template: pie shows OK / NOK / uncovered; counts for base and evaluated below",
    },
    "emr.qa.metrics.chart_mini_stats": {
        "es": "Base {eligible} · Evaluado {judged} ({coverage_pct}%)\nOK {ok} ({ok_pct}%) · NOK {nok} ({nok_pct}%) · No cubierto {uncovered}",
        "en": "Base {eligible} · Evaluated {judged} ({coverage_pct}%)\nOK {ok} ({ok_pct}%) · NOK {nok} ({nok_pct}%) · Uncovered {uncovered}",
    },
    "emr.qa.metrics.unknown_file": {
        "es": "(sin archivo)",
        "en": "(no file)",
    },
    "emr.qa.metrics.mode.fail_any": {
        "es": "fallo cualquiera",
        "en": "fail any",
    },
    "emr.qa.metrics.mode.discrepancy": {
        "es": "discrepancia",
        "en": "discrepancy",
    },
    "emr.qa.metrics.report.title": {
        "es": "=== QA · {file} ===",
        "en": "=== QA · {file} ===",
    },
    "emr.qa.metrics.report.generated": {
        "es": "Generado: {when}",
        "en": "Generated: {when}",
    },
    "emr.qa.metrics.report.header": {
        "es": "Templates: {templates} · Modo: {mode} · Visibles: {visible} · Evaluables: {evaluable} · No aplicables: {not_applicable}",
        "en": "Templates: {templates} · Mode: {mode} · Visible: {visible} · Evaluable: {evaluable} · Not applicable: {not_applicable}",
    },
    "emr.qa.metrics.report.section_kpis": {
        "es": "--- KPIs ---",
        "en": "--- KPIs ---",
    },
    "emr.qa.metrics.report.coverage": {
        "es": "Cobertura:     {pct}%  ({judged}/{eligible} juzgadas)",
        "en": "Coverage:      {pct}%  ({judged}/{eligible} judged)",
    },
    "emr.qa.metrics.report.quality": {
        "es": "Calidad:       {pct}%  (OK {ok}/{judged})",
        "en": "Quality:       {pct}%  (OK {ok}/{judged})",
    },
    "emr.qa.metrics.report.localization": {
        "es": "Localización:  {pct}%  ({located}/{complete} filas)",
        "en": "Localization:  {pct}%  ({located}/{complete} rows)",
    },
    "emr.qa.metrics.report.conflict": {
        "es": "Discrepancia:  {pct}%  ({count}/{judged})",
        "en": "Discrepancy:   {pct}%  ({count}/{judged})",
    },
    "emr.qa.metrics.report.section_keys": {
        "es": "--- Llaves (global) ---",
        "en": "--- Keys (global) ---",
    },
    "emr.qa.metrics.report.rows_total": {
        "es": "Filas totales:        {count}",
        "en": "Total rows:           {count}",
    },
    "emr.qa.metrics.report.rows_key_complete": {
        "es": "Llave completa:       {count}",
        "en": "Complete key:         {count}",
    },
    "emr.qa.metrics.report.rows_located": {
        "es": "Localizadas:          {count}",
        "en": "Located:              {count}",
    },
    "emr.qa.metrics.report.rows_partial": {
        "es": "Ancla parcial:        {count}",
        "en": "Partial anchor:       {count}",
    },
    "emr.qa.metrics.report.rows_orphan": {
        "es": "Huérfanas:            {count}",
        "en": "Orphan:               {count}",
    },
    "emr.qa.metrics.report.rows_key_conflict": {
        "es": "Conflicto de llave:   {count}",
        "en": "Key conflict:         {count}",
    },
    "emr.qa.metrics.report.section_delta": {
        "es": "--- Delta vs corrida anterior ---",
        "en": "--- Delta vs previous run ---",
    },
    "emr.qa.metrics.report.delta_ok": {
        "es": "OK:           {value}",
        "en": "OK:           {value}",
    },
    "emr.qa.metrics.report.delta_nok": {
        "es": "NOK:          {value}",
        "en": "NOK:          {value}",
    },
    "emr.qa.metrics.report.delta_conflict": {
        "es": "Discrepancia: {value}",
        "en": "Discrepancy:  {value}",
    },
    "emr.qa.metrics.report.delta_coverage": {
        "es": "Cobertura:    {value} pp",
        "en": "Coverage:     {value} pp",
    },
    "emr.qa.metrics.report.delta_quality": {
        "es": "Calidad:      {value} pp",
        "en": "Quality:      {value} pp",
    },
    "emr.qa.metrics.report.delta_localization": {
        "es": "Localización: {value} pp",
        "en": "Localization: {value} pp",
    },
    "emr.qa.metrics.report.section_columns": {
        "es": "--- Por columna ---",
        "en": "--- By column ---",
    },
    "emr.qa.metrics.report.columns_header": {
        "es": "Columna         | Eleg. | Juzg. |    OK |   NOK |  Disc | No ev |   %OK",
        "en": "Column          | Elig. | Judg. |    OK |   NOK |  Disc | Un ev |   %OK",
    },
    "emr.qa.metrics.report.column_not_applicable": {
        "es": "{column}|  — no aplicable en templates activos",
        "en": "{column}|  — not applicable in active templates",
    },
    "emr.qa.metrics.report.not_applicable_list": {
        "es": "Columnas visibles no aplicables:",
        "en": "Visible columns not applicable:",
    },
    "emr.qa.metrics.report.section_templates": {
        "es": "--- Por template ---",
        "en": "--- By template ---",
    },
    "emr.qa.metrics.report.template_line": {
        "es": "[{name}] juzgadas={judged} OK={ok} NOK={nok} disc={conflict} loc={loc_pct}% (localizadas {located}/{complete})",
        "en": "[{name}] judged={judged} OK={ok} NOK={nok} disc={conflict} loc={loc_pct}% (located {located}/{complete})",
    },
    "emr.qa.metrics.report.section_top_nok": {
        "es": "--- Top columnas NOK ---",
        "en": "--- Top NOK columns ---",
    },
    "emr.qa.metrics.report.top_nok_line": {
        "es": "  {column}: {nok} NOK ({ok_pct}% OK)",
        "en": "  {column}: {nok} NOK ({ok_pct}% OK)",
    },
    "emr.qa.metrics.csv.header": {
        "es": "seccion,columna,elegibles,juzgadas,ok,nok,discrepancia,no_evaluadas,ok_pct",
        "en": "section,column,eligible,judged,ok,nok,conflict,unevaluated,ok_pct",
    },
    "emr.qa.metrics.csv.section_column": {
        "es": "columna",
        "en": "column",
    },
    "emr.qa.metrics.csv.section_template": {
        "es": "template",
        "en": "template",
    },
    "emr.qa.metrics.csv.section_summary": {
        "es": "resumen",
        "en": "summary",
    },
    "emr.qa.metrics.fullscreen": {
        "es": "Pantalla completa",
        "en": "Full screen",
    },
    "emr.qa.metrics.fullscreen_title": {
        "es": "Reporte QA — {file}",
        "en": "QA report — {file}",
    },
    "emr.qa.metrics.report.meta_block": {
        "es": "Archivo: {file}\nGenerado: {when}\nTemplates: {templates}\nModo: {mode}\nColumnas visibles: {visible} · Evaluables: {evaluable} · No aplicables: {not_applicable}",
        "en": "File: {file}\nGenerated: {when}\nTemplates: {templates}\nMode: {mode}\nVisible columns: {visible} · Evaluable: {evaluable} · Not applicable: {not_applicable}",
    },
    "emr.qa.metrics.report.template_profiles_title": {
        "es": "Perfil de templates:",
        "en": "Template profiles:",
    },
    "emr.qa.metrics.report.template_profile_line": {
        "es": "  • {name}: {key_summary} · columnas ({columns}) · compara ({compare}) · minibase {records} rec.",
        "en": "  • {name}: {key_summary} · columns ({columns}) · compares ({compare}) · minibase {records} rec.",
    },
    "emr.qa.metrics.report.template_profile.no_key": {
        "es": "sin llave",
        "en": "no key",
    },
    "emr.qa.metrics.report.template_profile.simple_key": {
        "es": "llave simple ({columns})",
        "en": "simple key ({columns})",
    },
    "emr.qa.metrics.report.template_profile.composite_key": {
        "es": "llave compuesta ({columns})",
        "en": "composite key ({columns})",
    },
    "emr.qa.metrics.table.section_summary": {
        "es": "Resumen",
        "en": "Summary",
    },
    "emr.qa.metrics.table.metric": {
        "es": "Métrica",
        "en": "Metric",
    },
    "emr.qa.metrics.table.value": {
        "es": "Valor",
        "en": "Value",
    },
    "emr.qa.metrics.table.coverage": {
        "es": "Cobertura",
        "en": "Coverage",
    },
    "emr.qa.metrics.table.coverage_value": {
        "es": "{pct}% ({judged}/{eligible} juzgadas)",
        "en": "{pct}% ({judged}/{eligible} judged)",
    },
    "emr.qa.metrics.table.quality": {
        "es": "Calidad",
        "en": "Quality",
    },
    "emr.qa.metrics.table.quality_value": {
        "es": "{pct}% (OK {ok}/{judged})",
        "en": "{pct}% (OK {ok}/{judged})",
    },
    "emr.qa.metrics.table.localization": {
        "es": "Localización",
        "en": "Localization",
    },
    "emr.qa.metrics.table.localization_value": {
        "es": "{pct}% ({located}/{complete} filas)",
        "en": "{pct}% ({located}/{complete} rows)",
    },
    "emr.qa.metrics.table.conflict": {
        "es": "Discrepancia",
        "en": "Discrepancy",
    },
    "emr.qa.metrics.table.conflict_value": {
        "es": "{pct}% ({count}/{judged})",
        "en": "{pct}% ({count}/{judged})",
    },
    "emr.qa.metrics.table.unevaluated": {
        "es": "Celdas no evaluadas",
        "en": "Unevaluated cells",
    },
    "emr.qa.metrics.table.delta_ok": {
        "es": "Delta OK",
        "en": "Delta OK",
    },
    "emr.qa.metrics.table.delta_nok": {
        "es": "Delta NOK",
        "en": "Delta NOK",
    },
    "emr.qa.metrics.table.delta_conflict": {
        "es": "Delta discrepancia",
        "en": "Delta discrepancy",
    },
    "emr.qa.metrics.table.delta_coverage": {
        "es": "Delta cobertura",
        "en": "Delta coverage",
    },
    "emr.qa.metrics.table.delta_quality": {
        "es": "Delta calidad",
        "en": "Delta quality",
    },
    "emr.qa.metrics.table.delta_localization": {
        "es": "Delta localización",
        "en": "Delta localization",
    },
    "emr.qa.metrics.table.col_name": {
        "es": "Columna",
        "en": "Column",
    },
    "emr.qa.metrics.table.col_eligible": {
        "es": "Elegibles",
        "en": "Eligible",
    },
    "emr.qa.metrics.table.col_judged": {
        "es": "Juzgadas",
        "en": "Judged",
    },
    "emr.qa.metrics.table.col_ok": {
        "es": "OK",
        "en": "OK",
    },
    "emr.qa.metrics.table.col_nok": {
        "es": "NOK",
        "en": "NOK",
    },
    "emr.qa.metrics.table.col_conflict": {
        "es": "Discrepancia",
        "en": "Discrepancy",
    },
    "emr.qa.metrics.table.col_unevaluated": {
        "es": "No eval.",
        "en": "Uneval.",
    },
    "emr.qa.metrics.table.col_ok_pct": {
        "es": "% OK",
        "en": "% OK",
    },
    "emr.qa.metrics.table.col_status": {
        "es": "Estado",
        "en": "Status",
    },
    "emr.qa.metrics.table.not_applicable": {
        "es": "No aplicable",
        "en": "Not applicable",
    },
    "emr.qa.metrics.table.tpl_name": {
        "es": "Template",
        "en": "Template",
    },
    "emr.qa.metrics.table.tpl_loc_pct": {
        "es": "% loc.",
        "en": "% loc.",
    },
    "emr.qa.metrics.table.tpl_located": {
        "es": "Localizadas",
        "en": "Located",
    },
    "emr.qa.metrics.table.tpl_key_complete": {
        "es": "Llave compl.",
        "en": "Key complete",
    },
    "emr.qa.metrics.table.tpl_partial": {
        "es": "Ancla parcial",
        "en": "Partial anchor",
    },
    "emr.qa.metrics.table.tpl_orphan": {
        "es": "Huérfanas",
        "en": "Orphan",
    },
    "emr.qa.metrics.table.tpl_key_conflict": {
        "es": "Conf. llave",
        "en": "Key conflict",
    },
    "emr.template_edit.hint": {
        "es": "Edite los registros del template. La estructura de columnas no cambia.",
        "en": "Edit template records. Column structure cannot change.",
    },
    "emr.template_edit.hint_named": {
        "es": "{name} · {records} registros.",
        "en": "{name} · {records} records.",
    },
    "emr.template_edit.pending_hint": {
        "es": "Borde ámbar = cambio pendiente de Guardar.",
        "en": "Amber edge = pending change until Save.",
    },
    "emr.template_edit.no_template": {
        "es": "Cargue un template en el tab Validation.",
        "en": "Load a template in the Validation tab.",
    },
    "emr.template_edit.saved": {
        "es": "Cambios del template guardados.",
        "en": "Template changes saved.",
    },
    "emr.template_edit.cancelled": {
        "es": "Edición cancelada — se restauró el template.",
        "en": "Edit cancelled — template restored.",
    },
    "emr.template_edit.cancel": {"es": "Cancelar", "en": "Cancel"},
    "emr.template_edit.add_row": {"es": "Añadir fila", "en": "Add row"},
    "emr.template_edit.remove_rows": {"es": "Quitar filas", "en": "Remove rows"},
    "emr.template_edit.encrypt": {"es": "Cifrar minibase", "en": "Encrypt minibase"},
    "emr.template_edit.encrypt_title": {
        "es": "Cifrar minibase",
        "en": "Encrypt minibase",
    },
    "emr.template_edit.encrypt_confirm": {
        "es": "La minibase quedará cifrada con la llave activa. Podrá seguir editándola; al guardar se mantendrá cifrada.",
        "en": "The minibase will be encrypted with the active key. You can keep editing; saves will stay encrypted.",
    },
    "emr.template_edit.encrypted": {
        "es": "Minibase cifrada y guardada.",
        "en": "Minibase encrypted and saved.",
    },
    "emr.template_edit.encrypted_hint": {
        "es": "Minibase cifrada (llave {key_id}).",
        "en": "Encrypted minibase (key {key_id}).",
    },
    "emr.template_edit.plaintext_hint": {
        "es": "Minibase en texto plano.",
        "en": "Plaintext minibase.",
    },
    "emr.template.encrypted_badge": {
        "es": "cifrada ({key_id})",
        "en": "encrypted ({key_id})",
    },
    "emr.menu.key": {"es": "Llave", "en": "Key"},
    "emr.key.status_active": {
        "es": "Llave activa: {key_id}",
        "en": "Active key: {key_id}",
    },
    "emr.key.status_none": {"es": "Sin llave activa", "en": "No active key"},
    "emr.key.generate": {"es": "Generar llave nueva…", "en": "Generate new key…"},
    "emr.key.load": {"es": "Cargar llave existente…", "en": "Load existing key…"},
    "emr.key.export": {"es": "Exportar llave activa…", "en": "Export active key…"},
    "emr.key.generate_title": {
        "es": "Generar llave nueva",
        "en": "Generate new key",
    },
    "emr.key.generate_warning": {
        "es": "Los templates cifrados con la llave anterior no podrán abrirse hasta que cargue esa llave de nuevo. ¿Continuar?",
        "en": "Templates encrypted with the previous key will not open until you load that key again. Continue?",
    },
    "emr.key.generate_ok": {
        "es": "Llave generada: {key_id}",
        "en": "Key generated: {key_id}",
    },
    "emr.key.load_title": {"es": "Cargar llave", "en": "Load key"},
    "emr.key.load_ok": {
        "es": "Llave cargada: {key_id}",
        "en": "Key loaded: {key_id}",
    },
    "emr.key.load_dialog_title": {
        "es": "Seleccionar archivo de llave",
        "en": "Select key file",
    },
    "emr.key.export_dialog_title": {
        "es": "Exportar llave",
        "en": "Export key",
    },
    "emr.key.export_none": {
        "es": "No hay llave activa para exportar.",
        "en": "No active key to export.",
    },
    "emr.key.export_ok": {
        "es": "Llave exportada.",
        "en": "Key exported.",
    },
    "emr.key.file_filter": {
        "es": "Llave JSON (*.key *.json);;Todos (*.*)",
        "en": "JSON key (*.key *.json);;All (*.*)",
    },
    "emr.msg.not_tabular": {"es": "No tabular: {name}", "en": "Not tabular: {name}"},
    "emr.status.loading": {"es": "Cargando {name}…", "en": "Loading {name}…"},
    "emr.msg.open_error": {"es": "Error al abrir: {error}", "en": "Error opening: {error}"},
    "emr.msg.sampled_file": {
        "es": "Archivo grande: se cargó una muestra de {rows} filas ({total}). "
        "Métricas y validaciones aplican solo a la muestra; use el CLI para el archivo completo.",
        "en": "Large file: loaded a sample of {rows} rows ({total}). "
        "Metrics and validations cover the sample only; use the CLI for the full file.",
    },
    "emr.msg.sampled_total_estimate": {
        "es": "el archivo tiene ~{total} filas",
        "en": "the file has ~{total} rows",
    },
    "emr.msg.sampled_total_unknown": {
        "es": "total del archivo desconocido",
        "en": "full file total unknown",
    },
    "emr.msg.pick_template": {
        "es": "Cree o cargue un template en el tab Validation.",
        "en": "Create or load a template in the Validation tab.",
    },
    "emr.msg.qa_pick_templates": {
        "es": "Marque uno o más templates en el tab QA.",
        "en": "Check one or more templates in the QA tab.",
    },
    "emr.msg.no_validation_tab": {
        "es": "Sin validación en este tab — use Validation o QA.",
        "en": "No validation in this tab — use Validation or QA.",
    },
    "emr.msg.probe_no_template": {
        "es": "Modo Probar: falta template activo.",
        "en": "Validate mode: no active template.",
    },
    "emr.progress.validated": {
        "es": "Validado: {percent}% ({passed}/{total} celdas)",
        "en": "Validated: {percent}% ({passed}/{total} cells)",
    },
    "emr.progress.validating_start": {
        "es": "Validando {rows} filas…",
        "en": "Validating {rows} rows…",
    },
    "emr.progress.validating_prepare": {
        "es": "Preparando filas para validación…",
        "en": "Preparing rows for validation…",
    },
    "emr.progress.validating_prepare_rows": {
        "es": "Preparando filas {current}/{total} ({pct}%)",
        "en": "Preparing rows {current}/{total} ({pct}%)",
    },
    "emr.progress.validating_load_template": {
        "es": "Cargando template {current}/{total}: {name}",
        "en": "Loading template {current}/{total}: {name}",
    },
    "emr.progress.validating_template": {
        "es": "Template {current}/{total}: {name}",
        "en": "Template {current}/{total}: {name}",
    },
    "emr.progress.validating_rows": {
        "es": "Validando filas {current}/{total} ({pct}%)",
        "en": "Validating rows {current}/{total} ({pct}%)",
    },
    "emr.progress.validating_rows_named": {
        "es": "{name} · filas {current}/{total} ({pct}%)",
        "en": "{name} · rows {current}/{total} ({pct}%)",
    },
    "emr.progress.validating_metrics": {
        "es": "Calculando métricas QA…",
        "en": "Computing QA metrics…",
    },
    "emr.status.validating": {
        "es": "Validación en curso · {rows} filas",
        "en": "Validation running · {rows} rows",
    },
    "emr.status.validation_done": {
        "es": "Validación completada",
        "en": "Validation complete",
    },
    "emr.status.validation_error": {
        "es": "Error en validación",
        "en": "Validation error",
    },
    "emr.status.job_running": {
        "es": "Ejecutando job…",
        "en": "Running job…",
    },
    "emr.msg.validation_error": {
        "es": "No se pudo completar la validación:\n{error}",
        "en": "Validation could not complete:\n{error}",
    },
    "emr.msg.key_errors": {
        "es": "Filas con error de llave: {count}",
        "en": "Rows with key errors: {count}",
    },
    "emr.msg.no_alerts": {"es": "Sin alertas.", "en": "No alerts."},
    "emr.msg.no_overlay": {
        "es": "El job no devolvió overlay.",
        "en": "Job did not return an overlay.",
    },
    "emr.msg.job_run_ok": {"es": "Job completado (PASS)", "en": "Job completed (PASS)"},
    "emr.msg.job_run_fail": {
        "es": "Job falló: {error}",
        "en": "Job failed: {error}",
    },
    "emr.dialog.tabular_filter": {
        "es": "Archivos tabulares (*.csv *.txt *.tsv *.psv)",
        "en": "Tabular files (*.csv *.txt *.tsv *.psv)",
    },
    "emr.msg.no_dataset_template": {
        "es": "No hay dataset o template activo.",
        "en": "No active dataset or template.",
    },
    "emr.msg.select_row": {
        "es": "Seleccione una fila en el grid.",
        "en": "Select a row in the grid.",
    },
    "emr.msg.duplicate": {"es": "Duplicado: llave {key_id}", "en": "Duplicate: key {key_id}"},
    "emr.msg.record_saved": {
        "es": "Registro guardado: {record_id}",
        "en": "Record saved: {record_id}",
    },
    "emr.msg.wallpaper_fail": {
        "es": "No se pudo instalar fondo: {error}",
        "en": "Could not install wallpaper: {error}",
    },
    "emr.msg.wallpaper_ok": {"es": "Fondo: {name}", "en": "Wallpaper: {name}"},
    "emr.msg.icon_fail": {
        "es": "No se pudo instalar el icono: {error}",
        "en": "Could not install icon: {error}",
    },
    "emr.msg.icon_ok": {"es": "Icono: {name}", "en": "Icon: {name}"},
}
