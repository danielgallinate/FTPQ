"""Idioma UI — español (latino) e inglés."""
from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import QObject, Signal

from core.ui_preferences import DEFAULT_UI_LANGUAGE, normalize_ui_language
from ui.i18n.catalog import CATALOG

_LEGACY_LOCALE_FILE = Path.home() / ".pde-desktop" / "locale.json"


class _I18nHub(QObject):
    language_changed = Signal()


_hub = _I18nHub()
_language = DEFAULT_UI_LANGUAGE


def language_changed() -> Signal:
    return _hub.language_changed


def current_language() -> str:
    return _language


def init_locale(saved_language: str | None = None) -> str:
    """Carga preferencia del perfil (o archivo legado) y retorna código activo."""
    global _language
    if saved_language is not None:
        _language = normalize_ui_language(saved_language)
        return _language
    legacy = load_legacy_language_file()
    _language = legacy if legacy is not None else DEFAULT_UI_LANGUAGE
    return _language


def set_language(code: str) -> bool:
    global _language
    normalized = normalize_ui_language(code)
    if normalized == _language:
        return False
    _language = normalized
    _hub.language_changed.emit()
    return True


def tr(key: str, **kwargs: object) -> str:
    entry = CATALOG.get(key)
    if entry is None:
        return key
    text = entry.get(_language) or entry.get(DEFAULT_UI_LANGUAGE) or key
    if kwargs:
        return text.format(**kwargs)
    return text


def load_legacy_language_file() -> str | None:
    """Lee ~/.pde-desktop/locale.json si existe (migración a perfil)."""
    try:
        data = json.loads(_LEGACY_LOCALE_FILE.read_text(encoding="utf-8"))
        code = normalize_ui_language(str(data.get("language", "")))
        return code
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return None
