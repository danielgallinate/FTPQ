"""Fila superior: menú + Color alineado derecha (siempre visible)."""
from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QMenuBar, QWidget

from ui.chrome.color_button import ColorButton
from ui.chrome.menu_bar import AppMenuState, populate_menu_bar


def build_header_bar(
    parent: QWidget,
    *,
    parent_window: QWidget,
    on_connect: Callable[[], None] | None = None,
    on_file_manager: Callable[[], None] | None = None,
    on_toggle_chrome: Callable[[], None] | None = None,
    on_open_paths: Callable[[], None] | None = None,
    on_open_keys: Callable[[], None] | None = None,
    on_pick_wallpaper: Callable[[], None] | None = None,
    on_pick_icon: Callable[[], None] | None = None,
    on_language_picked: Callable[[str], None] | None = None,
) -> tuple[QWidget, ColorButton, QMenuBar, AppMenuState]:
    bar = QWidget(parent)
    bar.setObjectName("headerBar")

    menu = QMenuBar(bar)
    menu_state = populate_menu_bar(
        menu,
        parent_window=parent_window,
        on_connect=on_connect,
        on_file_manager=on_file_manager,
        on_open_paths=on_open_paths,
        on_open_keys=on_open_keys,
        on_pick_wallpaper=on_pick_wallpaper,
        on_pick_icon=on_pick_icon,
        on_language_picked=on_language_picked,
    )

    color = ColorButton(on_toggle_chrome or (lambda: None), bar)

    layout = QHBoxLayout(bar)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(8)
    layout.addWidget(menu, stretch=1)
    layout.addWidget(color, stretch=0, alignment=Qt.AlignmentFlag.AlignRight)

    return bar, color, menu, menu_state
