"""Menú compacto — acciones sobre archivo remoto."""
from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import QPoint
from PySide6.QtWidgets import QMenu, QMessageBox, QWidget

from ui.i18n import tr


def show_file_actions_menu(
    parent: QWidget,
    global_pos: QPoint,
    *,
    on_download: Callable[[], None],
    on_preview: Callable[[], None],
    on_compare_a: Callable[[], None] | None = None,
    on_compare_b: Callable[[], None] | None = None,
) -> None:
    menu = QMenu(parent)
    menu.setObjectName("fileActionsMenu")
    menu.addAction(tr("file.download"), on_download)
    menu.addAction(tr("file.visualize"), on_preview)
    if on_compare_a is not None:
        menu.addSeparator()
        menu.addAction(tr("compare.pick_a"), on_compare_a)
    if on_compare_b is not None:
        menu.addAction(tr("compare.pick_b"), on_compare_b)
    menu.addSeparator()
    menu.addAction(tr("file.forbidden_menu"), lambda: _forbidden_alert(parent))
    menu.exec(global_pos)


def show_local_file_actions_menu(
    parent: QWidget,
    global_pos: QPoint,
    *,
    on_preview: Callable[[], None],
    on_compare_a: Callable[[], None] | None = None,
    on_compare_b: Callable[[], None] | None = None,
) -> None:
    menu = QMenu(parent)
    menu.setObjectName("localFileActionsMenu")
    menu.addAction(tr("file.visualize"), on_preview)
    if on_compare_a is not None:
        menu.addSeparator()
        menu.addAction(tr("compare.pick_a"), on_compare_a)
    if on_compare_b is not None:
        menu.addAction(tr("compare.pick_b"), on_compare_b)
    menu.addSeparator()
    menu.addAction(tr("file.forbidden_menu"), lambda: _forbidden_alert(parent))
    menu.exec(global_pos)


def _forbidden_alert(parent: QWidget) -> None:
    QMessageBox.information(
        parent,
        tr("file.forbidden.title"),
        tr("file.forbidden.body"),
    )
