"""Diálogos stub — prototipo sin lógica SFTP."""
from __future__ import annotations

from PySide6.QtWidgets import QMessageBox, QWidget

from ui.i18n import tr


def _dialog_parent(parent: QWidget | None) -> QWidget | None:
    if parent is None:
        return None
    return parent.window()


def stub(parent: QWidget | None, title: str, body: str) -> None:
    QMessageBox.information(_dialog_parent(parent), title, body)


def open_connection_stub(parent: QWidget | None) -> None:
    stub(parent, tr("stub.open.title"), tr("stub.open.body"))


def config_stub(parent: QWidget | None, section: str) -> None:
    stub(
        parent,
        tr("stub.config.title", section=section),
        tr("stub.config.body", section=section),
    )


def who_is_stub(parent: QWidget | None) -> None:
    stub(parent, tr("stub.about.title"), tr("stub.about.body"))
