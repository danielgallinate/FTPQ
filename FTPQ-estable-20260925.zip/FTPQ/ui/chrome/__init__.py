"""Menú y diálogos chrome — sin lógica de dominio."""
