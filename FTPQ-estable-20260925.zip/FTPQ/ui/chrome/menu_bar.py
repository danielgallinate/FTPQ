"""Menú superior — ítems File / Ver / Config / Help + idioma."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from PySide6.QtGui import QAction, QActionGroup
from PySide6.QtWidgets import QDialog, QDialogButtonBox, QMenu, QMenuBar, QTextEdit, QVBoxLayout, QWidget

from ui.chrome import placeholders
from ui.i18n import current_language, tr
from ui.version_changelog import format_changelog_dialog_text


@dataclass
class AppMenuState:
    file_menu: QMenu
    view_menu: QMenu | None
    config_menu: QMenu
    help_menu: QMenu
    language_menu: QMenu
    act_connect: QAction
    act_file_manager: QAction
    act_wallpaper: QAction | None
    act_icon: QAction | None
    act_keys: QAction
    act_paths: QAction
    act_version: QAction
    act_about: QAction
    act_lang_es: QAction
    act_lang_en: QAction


def populate_menu_bar(
    bar: QMenuBar,
    *,
    parent_window: QWidget,
    on_connect: Callable[[], None] | None = None,
    on_file_manager: Callable[[], None] | None = None,
    on_open_paths: Callable[[], None] | None = None,
    on_open_keys: Callable[[], None] | None = None,
    on_pick_wallpaper: Callable[[], None] | None = None,
    on_pick_icon: Callable[[], None] | None = None,
    on_language_picked: Callable[[str], None] | None = None,
) -> AppMenuState:
    bar.setNativeMenuBar(False)

    file_menu = bar.addMenu("")
    act_connect = QAction("", bar)
    if on_connect is not None:
        act_connect.triggered.connect(on_connect)
    else:
        act_connect.triggered.connect(
            lambda: placeholders.open_connection_stub(parent_window)
        )
    file_menu.addAction(act_connect)

    act_file_manager = QAction("", bar)
    act_file_manager.setCheckable(True)
    if on_file_manager is not None:
        act_file_manager.triggered.connect(on_file_manager)
    file_menu.addAction(act_file_manager)

    view_menu: QMenu | None = None
    act_wallpaper: QAction | None = None
    act_icon: QAction | None = None
    if on_pick_wallpaper is not None or on_pick_icon is not None:
        view_menu = bar.addMenu("")
        if on_pick_wallpaper is not None:
            act_wallpaper = QAction("", bar)
            act_wallpaper.triggered.connect(on_pick_wallpaper)
            view_menu.addAction(act_wallpaper)
        if on_pick_icon is not None:
            act_icon = QAction("", bar)
            act_icon.triggered.connect(on_pick_icon)
            view_menu.addAction(act_icon)

    config_menu = bar.addMenu("")
    act_keys = QAction("", bar)
    act_paths = QAction("", bar)
    if on_open_keys is not None:
        act_keys.triggered.connect(on_open_keys)
    else:
        act_keys.triggered.connect(
            lambda: placeholders.config_stub(parent_window, tr("action.keys").rstrip("…"))
        )
    if on_open_paths is not None:
        act_paths.triggered.connect(on_open_paths)
    else:
        act_paths.triggered.connect(
            lambda: placeholders.config_stub(parent_window, tr("action.paths").rstrip("…"))
        )
    config_menu.addAction(act_keys)
    config_menu.addAction(act_paths)

    help_menu = bar.addMenu("")
    act_version = QAction("", bar)
    act_version.triggered.connect(lambda: _show_version_dialog(parent_window))
    help_menu.addAction(act_version)
    act_about = QAction("", bar)
    act_about.triggered.connect(lambda: placeholders.who_is_stub(parent_window))
    help_menu.addAction(act_about)

    language_menu = help_menu.addMenu("")
    lang_group = QActionGroup(bar)
    lang_group.setExclusive(True)

    def _pick_language(code: str) -> None:
        if on_language_picked is not None:
            on_language_picked(code)

    act_lang_es = QAction("", bar)
    act_lang_es.setCheckable(True)
    lang_group.addAction(act_lang_es)
    act_lang_es.triggered.connect(lambda: _pick_language("es"))
    language_menu.addAction(act_lang_es)

    act_lang_en = QAction("", bar)
    act_lang_en.setCheckable(True)
    lang_group.addAction(act_lang_en)
    act_lang_en.triggered.connect(lambda: _pick_language("en"))
    language_menu.addAction(act_lang_en)

    state = AppMenuState(
        file_menu=file_menu,
        view_menu=view_menu,
        config_menu=config_menu,
        help_menu=help_menu,
        language_menu=language_menu,
        act_connect=act_connect,
        act_file_manager=act_file_manager,
        act_wallpaper=act_wallpaper,
        act_icon=act_icon,
        act_keys=act_keys,
        act_paths=act_paths,
        act_version=act_version,
        act_about=act_about,
        act_lang_es=act_lang_es,
        act_lang_en=act_lang_en,
    )
    apply_menu_translations(state)
    return state


def apply_menu_translations(state: AppMenuState) -> None:
    state.file_menu.setTitle(tr("menu.file"))
    state.act_connect.setText(tr("action.connect"))
    state.act_file_manager.setText(tr("action.file_manager"))
    if state.view_menu is not None:
        state.view_menu.setTitle(tr("menu.view"))
        if state.act_wallpaper is not None:
            state.act_wallpaper.setText(tr("action.wallpaper"))
        if state.act_icon is not None:
            state.act_icon.setText(tr("action.icon"))
    state.config_menu.setTitle(tr("menu.settings"))
    state.act_keys.setText(tr("action.keys"))
    state.act_paths.setText(tr("action.paths"))
    state.help_menu.setTitle(tr("menu.help"))
    state.act_version.setText(tr("action.version"))
    state.act_about.setText(tr("action.about"))
    state.language_menu.setTitle(tr("menu.language"))
    state.act_lang_es.setText(tr("language.spanish"))
    state.act_lang_en.setText(tr("language.english"))
    lang = current_language()
    state.act_lang_es.setChecked(lang == "es")
    state.act_lang_en.setChecked(lang == "en")


def _show_version_dialog(parent: QWidget) -> None:
    owner = parent.window() if parent is not None else None
    dialog = QDialog(owner)
    dialog.setWindowTitle(tr("dialog.version_title"))
    dialog.resize(640, 480)

    body = QTextEdit(dialog)
    body.setReadOnly(True)
    body.setPlainText(format_changelog_dialog_text())

    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
    buttons.rejected.connect(dialog.reject)
    close_btn = buttons.button(QDialogButtonBox.StandardButton.Close)
    if close_btn is not None:
        close_btn.clicked.connect(dialog.accept)

    layout = QVBoxLayout(dialog)
    layout.addWidget(body)
    layout.addWidget(buttons)
    dialog.exec()
