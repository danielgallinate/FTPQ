"""Botón Color — letras multicolor; alterna chrome claro/oscuro."""
from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QWidget

from ui.i18n import tr

_LETTER_COLORS = (
    ("C", "#FF6B6B"),
    ("o", "#FFA94D"),
    ("l", "#FFE066"),
    ("o", "#69DB7C"),
    ("r", "#4DABF7"),
)


class ColorButton(QWidget):
    def __init__(self, on_click: Callable[[], None], parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("colorButton")
        self._wrap = QPushButton()
        self._wrap.setFlat(True)
        self._wrap.setCursor(Qt.CursorShape.PointingHandCursor)
        self._wrap.setToolTip(tr("chrome.toggle_tooltip"))
        self._wrap.clicked.connect(on_click)

        row = QHBoxLayout(self._wrap)
        row.setContentsMargins(8, 2, 8, 2)
        row.setSpacing(0)
        for char, color in _LETTER_COLORS:
            label = QLabel(char)
            label.setStyleSheet(
                f"color: {color}; font-weight: 700; font-size: 14px; background: transparent;"
            )
            row.addWidget(label)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 4, 0)
        outer.addWidget(self._wrap)

    def retranslate_ui(self) -> None:
        self._wrap.setToolTip(tr("chrome.toggle_tooltip"))
