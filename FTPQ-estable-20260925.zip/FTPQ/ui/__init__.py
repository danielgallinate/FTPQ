"""PDE Desktop — capa UI (PySide6 prototipo)."""
