"""Confirmación de inicio — avisa si la sesión anterior terminó mal."""
from __future__ import annotations

from PySide6.QtWidgets import QMessageBox

from core.app_log import log_file_display, previous_session_unclean
from ui.i18n import tr
from ui.version import display_version


def confirm_app_start() -> bool:
    if not previous_session_unclean():
        return True

    version = display_version()
    box = QMessageBox()
    box.setIcon(QMessageBox.Icon.Warning)
    box.setWindowTitle(tr("app.name"))
    box.setText(tr("app.prototype", version=version))
    box.setInformativeText(
        tr("startup.unclean", log_path=log_file_display())
    )
    box.setStandardButtons(
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
    )
    box.setDefaultButton(QMessageBox.StandardButton.Yes)
    return box.exec() == QMessageBox.StandardButton.Yes
