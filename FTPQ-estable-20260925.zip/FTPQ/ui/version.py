"""Versión visible — semver release + historial dev en changelog."""
from __future__ import annotations

from datetime import date

# Release actual (instaladores, tag, Help → Versión)
MAJOR = 1
MINOR = 0
PATCH = 0
PRERELEASE = ""  # vacío = estable
PRERELEASE_NUM = 0

# Builds dev diarios (archivo changelog 0.0.YYMMDD.NNNN) — solo referencia histórica
VERSION_DAY = "260717"
BUILD_OF_DAY = 1


def display_version() -> str:
    """1.0.0 estable; 1.0.0-beta.N prerelease; 0.0.YYMMDD.NNNN solo si PRERELEASE is None."""
    if PRERELEASE == "":
        return f"{MAJOR}.{MINOR}.{PATCH}"
    if PRERELEASE:
        suffix = f"-{PRERELEASE}"
        if PRERELEASE_NUM:
            suffix += f".{PRERELEASE_NUM}"
        return f"{MAJOR}.{MINOR}.{PATCH}{suffix}"
    day = date.today().strftime("%y%m%d")
    build = BUILD_OF_DAY if day == VERSION_DAY else 1
    return f"0.0.{day}.{build:04d}"


def release_tag() -> str:
    return f"v{display_version()}"


def release_channel() -> str:
    if PRERELEASE:
        return PRERELEASE
    return "stable"


def is_beta_release() -> bool:
    return bool(PRERELEASE)
