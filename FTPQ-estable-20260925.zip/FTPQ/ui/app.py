"""Entry point — prototipo UI PySide6."""
from __future__ import annotations

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication

from core.app_log import (
    install_runtime_logging,
    log_event,
    mark_session_started,
    mark_session_stopped,
)
from ui.app_controller import bootstrap_profile
from ui.i18n import init_locale
from ui.shell.main_window import MainWindow
from ui.startup import confirm_app_start
from ui.theme.app_icon import apply_app_icon
from ui.theme.theme_engine import ThemeEngine


def _platform_font() -> QFont:
    if sys.platform == "darwin":
        return QFont(".AppleSystemUIFont", 13)
    if sys.platform == "win32":
        return QFont("Segoe UI", 13)
    font = QFont()
    font.setPointSize(13)
    return font


def main() -> int:
    install_runtime_logging()
    app = QApplication(sys.argv)
    app.setApplicationName("PDE Desktop")
    app.setStyle("Fusion")
    app.setFont(_platform_font())
    init_locale(bootstrap_profile().language)

    if not confirm_app_start():
        log_event("Inicio cancelado por el usuario")
        return 0

    mark_session_started()
    app.aboutToQuit.connect(mark_session_stopped)

    theme = ThemeEngine(app)
    theme.apply()
    apply_app_icon(app)

    window = MainWindow(theme=theme)
    app.aboutToQuit.connect(window.shutdown_workers)
    window.show()
    code = app.exec()
    log_event(f"PDE Desktop cerrado (code={code})")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
