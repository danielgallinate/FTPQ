"""Registro visual de builds — ui/version_changelog.txt."""
from __future__ import annotations

from pathlib import Path

from ui.i18n import tr
from ui.version import display_version

_CHANGELOG_FILE = Path(__file__).with_name("version_changelog.txt")


def changelog_path() -> Path:
    return _CHANGELOG_FILE


def load_changelog_entries() -> list[tuple[str, str]]:
    """Devuelve [(versión, cambio), …] más reciente primero."""
    if not _CHANGELOG_FILE.is_file():
        return []
    entries: list[tuple[str, str]] = []
    for raw in _CHANGELOG_FILE.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "|" not in line:
            continue
        version, change = line.split("|", 1)
        entries.append((version.strip(), change.strip()))
    return entries


def format_changelog_dialog_text() -> str:
    current = display_version()
    lines = [tr("changelog.build", version=current), "", tr("changelog.title"), ""]
    entries = load_changelog_entries()
    if not entries:
        lines.append(tr("changelog.empty"))
        return "\n".join(lines)
    for version, change in entries:
        lines.append(f"{version} | {change}")
    return "\n".join(lines)
