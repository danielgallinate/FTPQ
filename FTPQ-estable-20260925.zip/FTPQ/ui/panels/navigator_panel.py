"""U-P1 — Navegador remoto (prototipo visual)."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHeaderView,
    QLabel,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from ui.i18n import tr

_COL_NAME = 0
_COL_EXT = 1
_COL_SIZE = 2
_COL_MODIFIED = 3


def _size_sort_key(text: str) -> tuple[int, float]:
    if text == tr("nav.dir_marker"):
        return (0, -1.0)
    value = text.strip()
    if value.endswith("M"):
        try:
            return (1, float(value[:-1]) * 1_000_000)
        except ValueError:
            return (2, 0.0)
    if value.endswith("K"):
        try:
            return (1, float(value[:-1]) * 1_000)
        except ValueError:
            return (2, 0.0)
    try:
        return (1, float(value))
    except ValueError:
        return (2, 0.0)


class NavigatorPanel(QFrame):
    path_changed = Signal(str)
    selection_changed = Signal(dict)
    folder_open_requested = Signal(str)
    file_actions_requested = Signal(dict)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("panel")
        self.setFrameShape(QFrame.Shape.NoFrame)
        self._path = ""
        self._entries: list[dict] = []
        self._sort_column = _COL_NAME
        self._sort_order = Qt.SortOrder.AscendingOrder

        self._title = QLabel()
        self._title.setObjectName("panelTitle")

        self._path_label = QLabel()
        self._path_label.setObjectName("panelSubhead")
        self._path_label.setWordWrap(True)

        self._table = QTableWidget(0, 4)
        self._table.setObjectName("panelBody")
        self._table.setFrameShape(QFrame.Shape.NoFrame)
        self._table.setHorizontalHeaderLabels(self._column_labels())
        self._table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self._table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._table.setSortingEnabled(False)
        self._table.verticalHeader().setVisible(False)
        header = self._table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSortIndicatorShown(True)
        header.setSectionsClickable(True)
        header.sectionClicked.connect(self._on_header_clicked)
        self._table.itemSelectionChanged.connect(self._on_selection)
        self._table.cellDoubleClicked.connect(self._on_cell_activate)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self._title)
        layout.addWidget(self._path_label)
        layout.addWidget(self._table, stretch=1)

        self.retranslate_ui()
        self.set_disconnected()

    @staticmethod
    def _column_labels() -> list[str]:
        return [
            tr("nav.col.name"),
            tr("nav.col.ext"),
            tr("nav.col.size"),
            tr("nav.col.modified"),
        ]

    def retranslate_ui(self) -> None:
        self._title.setText(tr("panel.navigator"))
        self._table.setHorizontalHeaderLabels(self._column_labels())
        if self._path:
            self.set_path(self._path)
        else:
            self.set_disconnected()

    def set_disconnected(self) -> None:
        self._path = ""
        self._entries = []
        self._path_label.setText(tr("nav.disconnected_hint"))
        self._table.setRowCount(0)

    def set_path(self, path: str) -> None:
        self._path = path
        self._path_label.setText(path or "SFTP /")
        self.path_changed.emit(path)

    def current_folder_name(self) -> str | None:
        rows = self._table.selectionModel().selectedRows()
        if not rows:
            return None
        name = self._item_text(rows[0].row(), 0)
        return name or None

    def _on_header_clicked(self, column: int) -> None:
        if self._sort_column == column:
            self._sort_order = (
                Qt.SortOrder.DescendingOrder
                if self._sort_order == Qt.SortOrder.AscendingOrder
                else Qt.SortOrder.AscendingOrder
            )
        else:
            self._sort_column = column
            self._sort_order = Qt.SortOrder.AscendingOrder
        self._apply_sort()

    def _entry_sort_key(self, entry: dict, column: int):
        if column == _COL_NAME:
            return entry.get("name", "").casefold()
        if column == _COL_EXT:
            return entry.get("ext", "").casefold()
        if column == _COL_SIZE:
            return _size_sort_key(str(entry.get("size", "")))
        if column == _COL_MODIFIED:
            return entry.get("modified", "")
        return ""

    def _apply_sort(self) -> None:
        parent_rows = [
            entry
            for entry in self._entries
            if entry.get("name", "").rstrip("/") == ".."
        ]
        others = [
            entry
            for entry in self._entries
            if entry.get("name", "").rstrip("/") != ".."
        ]
        reverse = self._sort_order == Qt.SortOrder.DescendingOrder
        others.sort(
            key=lambda entry: self._entry_sort_key(entry, self._sort_column),
            reverse=reverse,
        )
        self._populate_table(parent_rows + others)
        header = self._table.horizontalHeader()
        header.setSortIndicator(self._sort_column, self._sort_order)

    def _populate_table(self, entries: list[dict]) -> None:
        self._table.setRowCount(0)
        for row, entry in enumerate(entries):
            self._table.insertRow(row)
            values = (
                entry.get("name", ""),
                entry.get("ext", ""),
                entry.get("size", ""),
                entry.get("modified", ""),
            )
            for col, text in enumerate(values):
                self._table.setItem(row, col, QTableWidgetItem(str(text)))

    def _on_cell_activate(self, row: int, _col: int) -> None:
        name = self._item_text(row, 0)
        size = self._item_text(row, 2)
        if not name:
            return
        if name == ".." or size == tr("nav.dir_marker"):
            self.folder_open_requested.emit(name.rstrip("/") or "..")
            return
        item = self._table.item(row, 0)
        if item is None:
            return
        rect = self._table.visualItemRect(item)
        global_pos = self._table.viewport().mapToGlobal(rect.center())
        self.file_actions_requested.emit(
            {
                "name": name.rstrip("/"),
                "ext": self._item_text(row, 1),
                "size": size,
                "modified": self._item_text(row, 3),
                "path": self._path,
                "global_pos": global_pos,
            }
        )

    def set_entries(self, entries: list[dict]) -> None:
        self._entries = list(entries)
        self._apply_sort()

    def _on_selection(self) -> None:
        rows = self._table.selectionModel().selectedRows()
        if not rows:
            return
        row = rows[0].row()
        payload = {
            "name": self._item_text(row, 0),
            "ext": self._item_text(row, 1),
            "size": self._item_text(row, 2),
            "modified": self._item_text(row, 3),
            "path": self._path,
        }
        self.selection_changed.emit(payload)

    def _item_text(self, row: int, col: int) -> str:
        item = self._table.item(row, col)
        return item.text() if item else ""
