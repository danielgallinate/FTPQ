"""Panel embebido — Configuración → Rutas (host, carpetas locales)."""
from __future__ import annotations

from copy import deepcopy

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from core.app_profile import AppProfile
from core.analysis_limits import DISPLAY_ROW_PRESETS, normalize_max_display_rows
from core.visualization_policy import (
    PANDAS_THRESHOLD_PRESETS,
    TABULAR_MODES,
    format_bytes_label,
    normalize_pandas_max_bytes,
    normalize_tabular_mode,
)
from ui.dialogs.path_field import PathField
from ui.i18n import tr


class PathsPanel(QFrame):
    save_requested = Signal()
    import_env_requested = Signal()
    message = Signal(str)
    back_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("pathsPanel")
        self._profile: AppProfile | None = None

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        body_host = QWidget()
        body = QVBoxLayout(body_host)
        body.setContentsMargins(8, 6, 8, 4)
        body.setSpacing(6)

        header = QLabel()
        header.setObjectName("configSectionTitle")
        body.addWidget(header)
        self._header = header

        hint = QLabel()
        hint.setObjectName("configHint")
        body.addWidget(hint)
        self._hint = hint

        s1 = QFrame()
        s1.setObjectName("configSection")
        f1 = QFormLayout(s1)
        f1.setContentsMargins(8, 6, 8, 6)
        f1.setSpacing(4)
        f1.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

        self._config_name = QLineEdit()
        self._config_name.setObjectName("configField")
        self._download = PathField(pick="dir")
        self._keys_dir = PathField(pick="dir")

        self._keys_folder_label = QLabel()
        f1.addRow("CONFIG_NAME", self._config_name)
        f1.addRow("DOWNLOAD_DIR", self._download)
        f1.addRow(self._keys_folder_label, self._keys_dir)
        body.addWidget(s1)

        s_vis = QFrame()
        s_vis.setObjectName("configSection")
        f_vis = QFormLayout(s_vis)
        f_vis.setContentsMargins(8, 6, 8, 6)
        f_vis.setSpacing(4)
        f_vis.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self._display_rows = QComboBox()
        self._display_rows.setObjectName("configField")
        for preset in DISPLAY_ROW_PRESETS:
            self._display_rows.addItem(f"{preset:,}", preset)
        self._display_rows_label = QLabel()
        self._display_rows_hint = QLabel()
        self._display_rows_hint.setObjectName("configHint")
        self._display_rows_hint.setWordWrap(True)
        f_vis.addRow(self._display_rows_label, self._display_rows)
        f_vis.addRow("", self._display_rows_hint)
        self._tabular_mode = QComboBox()
        self._tabular_mode.setObjectName("configField")
        for mode in TABULAR_MODES:
            self._tabular_mode.addItem(mode, mode)
        self._tabular_mode_label = QLabel()
        self._tabular_mode_hint = QLabel()
        self._tabular_mode_hint.setObjectName("configHint")
        self._tabular_mode_hint.setWordWrap(True)
        f_vis.addRow(self._tabular_mode_label, self._tabular_mode)
        f_vis.addRow("", self._tabular_mode_hint)
        self._pandas_threshold = QComboBox()
        self._pandas_threshold.setObjectName("configField")
        for preset in PANDAS_THRESHOLD_PRESETS:
            self._pandas_threshold.addItem(format_bytes_label(preset), preset)
        self._pandas_threshold_label = QLabel()
        self._pandas_threshold_hint = QLabel()
        self._pandas_threshold_hint.setObjectName("configHint")
        self._pandas_threshold_hint.setWordWrap(True)
        f_vis.addRow(self._pandas_threshold_label, self._pandas_threshold)
        f_vis.addRow("", self._pandas_threshold_hint)
        body.addWidget(s_vis)

        s3 = QFrame()
        s3.setObjectName("configSection")
        f3 = QFormLayout(s3)
        f3.setContentsMargins(8, 6, 8, 6)
        f3.setSpacing(4)
        self._host = QLineEdit()
        self._host.setObjectName("configField")
        self._host.setPlaceholderText("s-….server.transfer.us-west-2.amazonaws.com")
        self._port = QSpinBox()
        self._port.setObjectName("configField")
        self._port.setRange(1, 65535)
        self._port.setValue(22)
        self._port_label = QLabel()
        f3.addRow("SFTP_HOST", self._host)
        f3.addRow(self._port_label, self._port)
        body.addWidget(s3)
        body.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(body_host)
        root.addWidget(scroll, stretch=1)

        self._footer = QFrame()
        self._footer.setObjectName("configActionBar")
        actions = QHBoxLayout(self._footer)
        actions.setContentsMargins(8, 8, 8, 8)
        actions.setSpacing(8)
        self._import_env = QPushButton()
        self._import_env.clicked.connect(self.import_env_requested.emit)
        self._save = QPushButton()
        self._save.setObjectName("saveAction")
        self._save.setMinimumWidth(80)
        self._save.clicked.connect(self.save_requested.emit)
        self._back = QPushButton()
        self._back.clicked.connect(self.back_requested.emit)
        actions.addWidget(self._import_env)
        actions.addWidget(self._save)
        actions.addStretch()
        actions.addWidget(self._back)
        root.addWidget(self._footer, stretch=0)

        self.retranslate_ui()

    def retranslate_ui(self) -> None:
        self._header.setText(tr("paths.header"))
        self._hint.setText(tr("paths.hint"))
        self._keys_folder_label.setText(tr("paths.keys_folder"))
        self._port_label.setText(tr("paths.port"))
        self._display_rows_label.setText(tr("paths.display_rows"))
        self._display_rows_hint.setText(tr("paths.display_rows_hint"))
        mode_labels = {
            "auto": tr("paths.tabular_mode.auto"),
            "full": tr("paths.tabular_mode.full"),
            "text_only": tr("paths.tabular_mode.text_only"),
        }
        for index, mode in enumerate(TABULAR_MODES):
            self._tabular_mode.setItemText(index, mode_labels[mode])
        self._tabular_mode_label.setText(tr("paths.tabular_mode"))
        self._tabular_mode_hint.setText(tr("paths.tabular_mode_hint"))
        self._pandas_threshold_label.setText(tr("paths.pandas_threshold"))
        self._pandas_threshold_hint.setText(tr("paths.pandas_threshold_hint"))
        self._import_env.setText(tr("paths.import_env"))
        self._save.setText(tr("action.save"))
        self._back.setText(tr("action.back"))

    def bind(self, profile: AppProfile) -> None:
        self._profile = deepcopy(profile)
        self.refresh()

    def refresh(self) -> None:
        if self._profile is None:
            return
        p = self._profile
        self._config_name.setText(p.profile_id if p.profile_id != "default" else "")
        self._host.setText(p.host)
        self._port.setValue(p.port)
        self._keys_dir.setText(str(p.ssh_keys_dir))
        self._download.setText(str(p.download_dir))
        idx = self._display_rows.findData(
            normalize_max_display_rows(p.max_display_rows)
        )
        if idx >= 0:
            self._display_rows.setCurrentIndex(idx)
        mode_idx = self._tabular_mode.findData(normalize_tabular_mode(p.tabular_mode))
        if mode_idx >= 0:
            self._tabular_mode.setCurrentIndex(mode_idx)
        threshold_idx = self._pandas_threshold.findData(
            normalize_pandas_max_bytes(p.pandas_max_bytes)
        )
        if threshold_idx >= 0:
            self._pandas_threshold.setCurrentIndex(threshold_idx)

    def build_draft_profile(self) -> AppProfile:
        if self._profile is None:
            return AppProfile.default()
        p = deepcopy(self._profile)
        name = self._config_name.text().strip() or "default"
        p.profile_id = name
        p.host = self._host.text().strip()
        p.port = self._port.value()
        p.ssh_keys_dir = self._keys_dir.path()
        p.download_dir = self._download.path()
        rows_data = self._display_rows.currentData()
        p.max_display_rows = normalize_max_display_rows(
            int(rows_data) if rows_data is not None else p.max_display_rows
        )
        mode_data = self._tabular_mode.currentData()
        p.tabular_mode = normalize_tabular_mode(
            str(mode_data) if mode_data is not None else p.tabular_mode
        )
        threshold_data = self._pandas_threshold.currentData()
        p.pandas_max_bytes = normalize_pandas_max_bytes(
            int(threshold_data) if threshold_data is not None else p.pandas_max_bytes
        )
        return p

    def apply_saved_profile(self, profile: AppProfile) -> None:
        self._profile = deepcopy(profile)
        self.refresh()

    def apply_imported_profile(self, profile: AppProfile) -> None:
        if self._profile is None:
            self._profile = deepcopy(profile)
        else:
            from core.env_import import merge_missing

            self._profile = merge_missing(self._profile, profile)
        self.refresh()
