"""Panel embebido — SFTP_USER + llave, estilo validator F4."""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path

from PySide6.QtCore import QObject, Qt, QThread, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLayout,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from core.app_profile import AppProfile
from core.env_import import sync_config_name
from core.key_store import IKeyStore
from ui.i18n import tr


class _FingerprintWorker(QObject):
    finished = Signal(str)

    def __init__(self, key_store: IKeyStore, path: Path) -> None:
        super().__init__()
        self._key_store = key_store
        self._path = path

    def run(self) -> None:
        try:
            fp = self._key_store.fingerprint(self._path)
        except OSError:
            fp = "?"
        self.finished.emit(fp)


class KeysPanel(QFrame):
    save_requested = Signal()
    test_requested = Signal()
    message = Signal(str)
    back_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("keysPanel")

        self._profile: AppProfile | None = None
        self._key_store: IKeyStore | None = None
        self._candidates: list[Path] = []
        self._thread: QThread | None = None
        self._worker: _FingerprintWorker | None = None
        self._showing_default_status = True

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        body_host = QWidget()
        body_layout = QVBoxLayout(body_host)
        body_layout.setContentsMargins(8, 6, 8, 4)
        body_layout.setSpacing(6)

        self._header = QLabel()
        self._header.setObjectName("configSectionTitle")
        body_layout.addWidget(self._header)

        self._hint = QLabel()
        self._hint.setObjectName("configHint")
        body_layout.addWidget(self._hint)
        self.message.connect(self.show_feedback)

        self._user = QLineEdit()
        self._user.setObjectName("configField")
        self._user_hint = QLabel()
        body_layout.addWidget(
            self._section(
                "SFTP_USER",
                self._user,
                self._user_hint,
            )
        )

        self._keys_count = QLabel()
        self._keys_count.setObjectName("configHint")
        self._key_combo = QComboBox()
        self._key_combo.setObjectName("configField")
        self._key_combo.currentIndexChanged.connect(self._on_key_changed)
        self._key_path = QLineEdit()
        self._key_path.setObjectName("configField")
        self._key_path.setReadOnly(True)
        self._key_label = QLabel()
        self._path_label = QLabel()
        self._fingerprint = QLabel()
        self._fingerprint.setObjectName("configHint")

        key_grid = QGridLayout()
        key_grid.setHorizontalSpacing(6)
        key_grid.setVerticalSpacing(4)
        key_grid.addWidget(self._key_label, 0, 0)
        key_grid.addWidget(self._key_combo, 0, 1)
        key_grid.addWidget(self._path_label, 1, 0)
        key_grid.addWidget(self._key_path, 1, 1)
        key_grid.setColumnStretch(1, 1)

        key_inner = QVBoxLayout()
        key_inner.setSpacing(4)
        key_inner.addLayout(key_grid)
        key_inner.addWidget(self._keys_count)
        key_inner.addWidget(self._fingerprint)
        key_section = self._section("SFTP_KEY_PATH")
        key_section.layout().addLayout(key_inner)
        body_layout.addWidget(key_section)

        create_row = QHBoxLayout()
        create_row.setSpacing(6)
        self._type = QComboBox()
        self._type.setObjectName("configField")
        self._type.addItems(["RSA 4096", "ECDSA 256"])
        self._new_name = QLineEdit()
        self._new_name.setObjectName("configField")
        self._create = QPushButton()
        self._create.clicked.connect(self._create_key)
        self._type_label = QLabel()
        create_row.addWidget(self._type_label)
        create_row.addWidget(self._type)
        create_row.addWidget(self._new_name, stretch=1)
        create_row.addWidget(self._create)
        body_layout.addLayout(create_row)
        body_layout.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(body_host)
        root.addWidget(scroll, stretch=1)

        self._footer = QFrame()
        self._footer.setObjectName("configActionBar")
        footer_layout = QVBoxLayout(self._footer)
        footer_layout.setContentsMargins(8, 8, 8, 8)
        footer_layout.setSpacing(6)
        actions = QHBoxLayout()
        actions.setSpacing(8)
        self._test = QPushButton()
        self._test.setObjectName("primaryAction")
        self._test.setMinimumWidth(100)
        self._test.clicked.connect(self.test_requested.emit)
        self._save = QPushButton()
        self._save.setObjectName("saveAction")
        self._save.setMinimumWidth(80)
        self._save.clicked.connect(self.save_requested.emit)
        self._back = QPushButton()
        self._back.clicked.connect(self.back_requested.emit)
        actions.addWidget(self._test)
        actions.addWidget(self._save)
        actions.addStretch()
        actions.addWidget(self._back)
        footer_layout.addLayout(actions)

        self._status = QLabel()
        self._status.setObjectName("configHint")
        self._status.setWordWrap(True)
        footer_layout.addWidget(self._status)
        root.addWidget(self._footer, stretch=0)

        self.retranslate_ui()

    def retranslate_ui(self) -> None:
        self._header.setText(tr("keys.header"))
        self._hint.setText(tr("keys.hint"))
        self._user_hint.setText(tr("keys.user_hint"))
        self._key_label.setText(tr("keys.label.key"))
        self._path_label.setText(tr("keys.label.path"))
        self._type_label.setText(tr("keys.label.type"))
        self._new_name.setPlaceholderText(tr("keys.new_name_ph"))
        self._create.setText(tr("keys.create"))
        self._test.setText(tr("keys.test"))
        self._save.setText(tr("action.save"))
        self._back.setText(tr("action.back"))
        if self._showing_default_status:
            self._status.setText(tr("keys.feedback_hint"))
        fp_text = self._fingerprint.text()
        if fp_text.endswith("…"):
            self._fingerprint.setText(tr("keys.fingerprint_loading"))
        elif fp_text.endswith("—") or not fp_text:
            self._fingerprint.setText(tr("keys.fingerprint_empty"))
        elif ":" in fp_text:
            fp = fp_text.split(":", 1)[-1].strip()
            if fp and fp not in {"—", "…"}:
                self._fingerprint.setText(tr("keys.fingerprint_value", fp=fp))

    def is_bound(self) -> bool:
        return self._profile is not None and self._key_store is not None

    def _section(self, title: str, *widgets) -> QFrame:
        frame = QFrame()
        frame.setObjectName("configSection")
        inner = QVBoxLayout(frame)
        inner.setContentsMargins(8, 6, 8, 6)
        inner.setSpacing(4)
        label = QLabel(title)
        label.setObjectName("configFieldLabel")
        inner.addWidget(label)
        for widget in widgets:
            if isinstance(widget, QLayout):
                inner.addLayout(widget)
            else:
                inner.addWidget(widget)
        return frame

    def bind(self, profile: AppProfile, key_store: IKeyStore) -> None:
        self._profile = deepcopy(profile)
        self._key_store = key_store
        self.refresh()

    def apply_saved_profile(self, profile: AppProfile) -> None:
        if self._key_store is None:
            self._profile = deepcopy(profile)
            return
        self.bind(profile, self._key_store)

    def build_draft_profile(self) -> AppProfile:
        if self._profile is None:
            return AppProfile.default()
        profile = deepcopy(self._profile)
        profile.user = self._user.text().strip()
        path = self._selected_key_path()
        if path is not None:
            profile.private_key_path = path
        sync_config_name(profile)
        return profile

    def refresh(self) -> None:
        if self._profile is None or self._key_store is None:
            return

        self._stop_worker()
        profile = self._profile
        self._user.setText(profile.user)

        keys_dir = profile.ssh_keys_dir.expanduser()
        self._key_combo.blockSignals(True)
        self._key_combo.clear()
        self._candidates = []

        if not keys_dir.is_dir():
            self._keys_count.setText(tr("keys.dir_missing", path=keys_dir))
            self._key_path.clear()
            self._fingerprint.setText(tr("keys.fingerprint_empty"))
            self._key_combo.blockSignals(False)
            self._create.setEnabled(False)
            return

        discovered = self._key_store.discover(keys_dir)
        self._candidates = [c.path for c in discovered]
        self._keys_count.setText(
            tr("keys.count", count=len(self._candidates), path=keys_dir)
        )
        for path in self._candidates:
            self._key_combo.addItem(path.name, str(path))

        active = profile.private_key_path.expanduser().resolve()
        index = 0
        for i, path in enumerate(self._candidates):
            if path.resolve() == active:
                index = i
                break
        if self._candidates:
            self._key_combo.setCurrentIndex(index)
        self._key_combo.blockSignals(False)
        self._create.setEnabled(True)
        self._on_key_changed()

    def stop_background_work(self) -> None:
        self._stop_worker()

    def _on_key_changed(self) -> None:
        path = self._selected_key_path()
        if path is None:
            self._key_path.clear()
            self._fingerprint.setText(tr("keys.fingerprint_empty"))
            return
        self._key_path.setText(str(path))
        self._fingerprint.setText(tr("keys.fingerprint_loading"))
        if self._key_store is not None:
            self._start_fingerprint_worker(path)

    def _selected_key_path(self) -> Path | None:
        raw = self._key_combo.currentData()
        return Path(raw) if raw else None

    def _start_fingerprint_worker(self, path: Path) -> None:
        if self._key_store is None:
            return
        self._stop_worker()
        self._thread = QThread(self)
        self._worker = _FingerprintWorker(self._key_store, path)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.finished.connect(self._apply_fingerprint)
        self._worker.finished.connect(self._thread.quit)
        self._thread.finished.connect(self._clear_worker)
        self._thread.start()

    def _stop_worker(self) -> None:
        if self._thread is not None and self._thread.isRunning():
            self._thread.quit()
            self._thread.wait(500)
        self._clear_worker()

    def _clear_worker(self) -> None:
        self._worker = None
        self._thread = None

    def _apply_fingerprint(self, fingerprint: str) -> None:
        self._fingerprint.setText(tr("keys.fingerprint_value", fp=fingerprint))

    def _create_key(self) -> None:
        if self._profile is None or self._key_store is None:
            return
        keys_dir = self._profile.ssh_keys_dir.expanduser()
        if not keys_dir.is_dir():
            self.message.emit(tr("keys.configure_dir"))
            return

        default = "pde_key_rsa" if self._type.currentIndex() == 0 else "pde_key_ecdsa"
        stem = self._new_name.text().strip() or default
        private = keys_dir / stem
        if private.exists():
            self.message.emit(tr("keys.exists", path=private))
            return

        key_type = "rsa" if self._type.currentIndex() == 0 else "ecdsa"
        try:
            info = self._key_store.generate(private, key_type)
        except OSError as exc:
            self.message.emit(tr("keys.create_fail", error=exc))
            return

        self._new_name.clear()
        self._profile.private_key_path = info.private_path
        self.refresh()
        self.message.emit(
            tr(
                "keys.created",
                path=info.private_path,
                fp=info.fingerprint,
            )
        )

    def set_actions_enabled(self, enabled: bool) -> None:
        self._test.setEnabled(enabled)
        self._save.setEnabled(enabled)

    def show_feedback(self, text: str) -> None:
        cleaned = text.strip() or tr("detail.dash")
        self._status.setText(cleaned)
        self._showing_default_status = False
