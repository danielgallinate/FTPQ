"""U-P3 — Asistente; alterna con paneles de config embebidos."""
from __future__ import annotations

from PySide6.QtWidgets import QFrame, QLabel, QStackedWidget, QTextEdit, QVBoxLayout

from core.app_profile import AppProfile
from core.key_store import IKeyStore
from ui.i18n import tr
from ui.panels.compare_report_panel import CompareReportPanel
from ui.panels.keys_panel import KeysPanel
from ui.panels.paths_panel import PathsPanel


class AssistantPanel(QFrame):
    _MODE_DEFAULT = "default"
    _MODE_KEYS = "keys"
    _MODE_PATHS = "paths"
    _MODE_COMPARE = "compare"

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("panel")
        self.setFrameShape(QFrame.Shape.NoFrame)

        self._mode = self._MODE_DEFAULT
        self._title = QLabel()
        self._title.setObjectName("panelTitle")

        self._default_body = QTextEdit()
        self._default_body.setObjectName("panelBody")
        self._default_body.setReadOnly(True)
        self._default_body.setFrameShape(QFrame.Shape.NoFrame)

        self._keys = KeysPanel()
        self._paths = PathsPanel()
        self._compare = CompareReportPanel()

        self._stack = QStackedWidget()
        self._stack.addWidget(self._default_body)
        self._stack.addWidget(self._keys)
        self._stack.addWidget(self._paths)
        self._stack.addWidget(self._compare)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self._title)
        layout.addWidget(self._stack, stretch=1)

        self.retranslate_ui()

    @property
    def keys_panel(self) -> KeysPanel:
        return self._keys

    @property
    def paths_panel(self) -> PathsPanel:
        return self._paths

    @property
    def compare_panel(self) -> CompareReportPanel:
        return self._compare

    def retranslate_ui(self) -> None:
        if self._mode == self._MODE_KEYS:
            self._title.setText(tr("panel.settings_keys"))
        elif self._mode == self._MODE_PATHS:
            self._title.setText(tr("panel.settings_paths"))
        elif self._mode == self._MODE_COMPARE:
            self._title.setText(tr("panel.compare_report"))
        else:
            self._title.setText(tr("panel.assistant"))
            self._default_body.setPlainText(tr("panel.assistant_body"))
        self._keys.retranslate_ui()
        self._paths.retranslate_ui()
        self._compare.retranslate_ui()

    def enter_keys_mode(self, profile: AppProfile, key_store: IKeyStore) -> None:
        self._leave_sub_mode()
        self._mode = self._MODE_KEYS
        self._title.setText(tr("panel.settings_keys"))
        self._keys.bind(profile, key_store)
        self._stack.setCurrentWidget(self._keys)

    def enter_paths_mode(self, profile: AppProfile) -> None:
        self._leave_sub_mode()
        self._mode = self._MODE_PATHS
        self._title.setText(tr("panel.settings_paths"))
        self._paths.bind(profile)
        self._stack.setCurrentWidget(self._paths)

    def show_compare_report(self, text: str) -> None:
        self._keys.stop_background_work()
        self._mode = self._MODE_COMPARE
        self._title.setText(tr("panel.compare_report"))
        self._compare.set_report(text)
        self._stack.setCurrentWidget(self._compare)

    def leave_compare_report(self) -> None:
        if self._mode != self._MODE_COMPARE:
            return
        self._leave_sub_mode()

    def leave_keys_mode(self) -> None:
        self._keys.stop_background_work()
        self._leave_sub_mode()

    def leave_paths_mode(self) -> None:
        self._leave_sub_mode()

    def _leave_sub_mode(self) -> None:
        self._keys.stop_background_work()
        self._mode = self._MODE_DEFAULT
        self._title.setText(tr("panel.assistant"))
        self._default_body.setPlainText(tr("panel.assistant_body"))
        self._stack.setCurrentWidget(self._default_body)

    def is_keys_mode(self) -> bool:
        return self._stack.currentWidget() is self._keys

    def is_paths_mode(self) -> bool:
        return self._stack.currentWidget() is self._paths

    def is_compare_mode(self) -> bool:
        return self._stack.currentWidget() is self._compare
