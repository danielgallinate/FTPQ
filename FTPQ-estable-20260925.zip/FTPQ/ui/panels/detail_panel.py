"""U-P2 — Detalle / mensajes o visualizador tabular pantalla completa."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QStackedWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from core.analysis_types import TabularDataset
from ui.i18n import tr
from ui.panels.local_file_panel import LocalFilePanel
from ui.widgets.data_viewer import DataViewerWidget


class DetailPanel(QFrame):
    _PAGE_MESSAGE = 0
    _PAGE_DATA = 1
    _PAGE_LOCAL = 2

    close_tabular_requested = Signal()
    cancel_operation_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("panel")
        self.setFrameShape(QFrame.Shape.NoFrame)

        self._title = QLabel()
        self._title.setObjectName("panelTitle")

        self._cancel = QPushButton()
        self._cancel.setObjectName("cancelOperation")
        self._cancel.setVisible(False)
        self._cancel.clicked.connect(self._on_cancel_clicked)

        self._close_view = QPushButton()
        self._close_view.setObjectName("closeDataViewer")
        self._close_view.setVisible(False)
        self._close_view.clicked.connect(self._on_close_view_clicked)

        self._title_row = QWidget()
        title_layout = QHBoxLayout(self._title_row)
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(0)
        title_layout.addWidget(self._title, stretch=1)
        title_layout.addWidget(self._cancel)
        title_layout.addWidget(self._close_view)

        self._body = QTextEdit()
        self._body.setObjectName("panelBody")
        self._body.setReadOnly(True)
        self._body.setFrameShape(QFrame.Shape.NoFrame)

        self._data_viewer = DataViewerWidget()
        self._data_viewer.close_requested.connect(self._on_close_tabular)

        self._local_files = LocalFilePanel(title_key="panel.local_side_b")

        self._stack = QStackedWidget()
        self._stack.addWidget(self._body)
        self._stack.addWidget(self._data_viewer)
        self._stack.addWidget(self._local_files)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self._title_row)
        layout.addWidget(self._stack, stretch=1)

        self._showing_default_empty = True
        self._text_view_mode = False
        self.retranslate_ui()

    def _sync_title_row(self) -> None:
        page = self._stack.currentIndex()
        if page in (self._PAGE_DATA, self._PAGE_LOCAL):
            self._title_row.setVisible(False)
            return
        self._title_row.setVisible(True)
        self._title.setVisible(True)
        self._close_view.setVisible(self._text_view_mode)

    def _clear_text_view_mode(self) -> None:
        self._text_view_mode = False
        self._close_view.setVisible(False)

    def retranslate_ui(self) -> None:
        self._title.setText(tr("panel.detail"))
        self._cancel.setText(tr("action.stop"))
        self._close_view.setText(tr("action.close"))
        if self._stack.currentIndex() == self._PAGE_MESSAGE and self._showing_default_empty:
            self._body.setPlainText(tr("panel.detail_empty"))
        self._data_viewer.retranslate_ui()
        self._local_files.retranslate_ui()

    @property
    def local_files(self) -> LocalFilePanel:
        return self._local_files

    def is_local_browser_active(self) -> bool:
        return self._stack.currentIndex() == self._PAGE_LOCAL

    def show_local_browser(self) -> None:
        self._stack.setCurrentIndex(self._PAGE_LOCAL)
        self._sync_title_row()

    def hide_local_browser(self) -> None:
        if self._stack.currentIndex() != self._PAGE_LOCAL:
            return
        self._stack.setCurrentIndex(self._PAGE_MESSAGE)
        self._showing_default_empty = True
        self.retranslate_ui()
        self._sync_title_row()

    def set_operation_cancel_visible(self, visible: bool) -> None:
        self._cancel.setVisible(visible)
        self._cancel.setEnabled(visible)

    def _on_cancel_clicked(self) -> None:
        self.cancel_operation_requested.emit()

    def set_title_visible(self, visible: bool) -> None:
        self._title.setVisible(visible)

    def show_detail(self, payload: dict) -> None:
        if self._stack.currentIndex() in (self._PAGE_DATA, self._PAGE_LOCAL):
            return
        self._stack.setCurrentIndex(self._PAGE_MESSAGE)
        self._showing_default_empty = False
        dash = tr("detail.dash")
        lines = [
            f"{tr('detail.field.name')}   {payload.get('name', dash)}",
            f"{tr('detail.field.ext')}      {payload.get('ext', dash)}",
            f"{tr('detail.field.size')}   {payload.get('size', dash)}",
            f"{tr('detail.field.date')}    {payload.get('modified', dash)}",
            f"{tr('detail.field.path')}     {payload.get('path', dash)}",
        ]
        self._body.setPlainText("\n".join(lines))
        self._sync_title_row()

    def show_message(self, text: str, *, force: bool = False) -> None:
        if not force and self._stack.currentIndex() in (self._PAGE_DATA, self._PAGE_LOCAL):
            return
        self._clear_text_view_mode()
        self._stack.setCurrentIndex(self._PAGE_MESSAGE)
        self._showing_default_empty = False
        self._body.setPlainText(text)
        self._sync_title_row()

    def show_text_view(self, text: str, *, filename: str) -> None:
        self._text_view_mode = True
        self._showing_default_empty = False
        self._title.setText(filename)
        self._body.setPlainText(text)
        self._stack.setCurrentIndex(self._PAGE_MESSAGE)
        self._sync_title_row()

    def restore_active_view(self) -> None:
        """Mantiene la vista activa tras cambios de tema u otras acciones globales."""
        if self._stack.currentWidget() is self._data_viewer:
            self.restore_tabular_view()
            return
        if self._text_view_mode:
            self._sync_title_row()

    def exit_view_mode(self) -> None:
        self._clear_text_view_mode()

    def show_tabular(
        self,
        dataset: TabularDataset,
        *,
        filename: str,
        file_size_bytes: int | None = None,
    ) -> None:
        self._data_viewer.load(
            dataset,
            filename=filename,
            file_size_bytes=file_size_bytes,
        )
        self._stack.setCurrentIndex(self._PAGE_DATA)
        self._sync_title_row()

    def restore_tabular_view(self) -> None:
        """Mantiene la tabla visible tras cambios de tema u otras acciones globales."""
        if self._stack.currentWidget() is not self._data_viewer:
            return
        self._stack.setCurrentIndex(self._PAGE_DATA)
        self._sync_title_row()

    def _on_close_tabular(self) -> None:
        self._stack.setCurrentIndex(self._PAGE_MESSAGE)
        self._showing_default_empty = True
        self._clear_text_view_mode()
        self._body.setPlainText(tr("panel.detail_empty"))
        self._sync_title_row()
        self.close_tabular_requested.emit()

    def _on_close_view_clicked(self) -> None:
        self._clear_text_view_mode()
        self.close_tabular_requested.emit()

    def append_message(self, text: str) -> None:
        if self._stack.currentIndex() == self._PAGE_DATA:
            return
        self._stack.setCurrentIndex(self._PAGE_MESSAGE)
        self._showing_default_empty = False
        current = self._body.toPlainText()
        self._body.setPlainText(f"{current}\n\n{text}".strip())
        self._sync_title_row()
