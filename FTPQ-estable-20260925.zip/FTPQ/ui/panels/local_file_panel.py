"""Panel explorador local — descargas y unidades (solo lectura)."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHeaderView,
    QLabel,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from ui.i18n import tr
from ui.panels.local_file_sort import (
    COL_EXT,
    COL_MODIFIED,
    COL_NAME,
    COL_SIZE,
    sort_browser_entries,
)
from ui.widgets.table_clipboard import install_table_copy_shortcut


class LocalFilePanel(QFrame):
    folder_open_requested = Signal(str)
    file_actions_requested = Signal(dict)
    selection_changed = Signal(dict)
    compare_pick_requested = Signal(str, dict)

    def __init__(self, parent=None, *, title_key: str = "panel.local_files") -> None:
        super().__init__(parent)
        self.setObjectName("panel")
        self.setFrameShape(QFrame.Shape.NoFrame)
        self._title_key = title_key
        self._path = ""
        self._entries: list[dict] = []
        self._sort_column = COL_NAME
        self._sort_order = Qt.SortOrder.AscendingOrder

        self._title = QLabel()
        self._title.setObjectName("panelTitle")

        self._path_label = QLabel()
        self._path_label.setObjectName("panelSubhead")
        self._path_label.setWordWrap(True)

        self._table = QTableWidget(0, 4)
        self._table.setObjectName("panelBody")
        self._table.setFrameShape(QFrame.Shape.NoFrame)
        self._table.setHorizontalHeaderLabels(self._column_labels())
        self._table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self._table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._table.setSortingEnabled(False)
        self._table.verticalHeader().setVisible(False)
        header = self._table.horizontalHeader()
        header.setMinimumSectionSize(48)
        header.setSortIndicatorShown(True)
        header.setSectionsClickable(True)
        self._apply_column_layout()
        header.sectionClicked.connect(self._on_header_clicked)
        self._table.itemSelectionChanged.connect(self._on_selection)
        self._table.cellDoubleClicked.connect(self._on_cell_activate)
        install_table_copy_shortcut(self._table)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self._title)
        layout.addWidget(self._path_label)
        layout.addWidget(self._table, stretch=1)

        self.retranslate_ui()

    def _apply_column_layout(self) -> None:
        header = self._table.horizontalHeader()
        header.setSectionResizeMode(COL_NAME, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(COL_EXT, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(COL_SIZE, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(COL_MODIFIED, QHeaderView.ResizeMode.ResizeToContents)
        header.setStretchLastSection(False)
        if self._table.viewport().width() > 0:
            header.resizeSection(COL_NAME, max(220, self._table.viewport().width() - 260))

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._apply_column_layout()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self._apply_column_layout()

    @staticmethod
    def _column_labels() -> list[str]:
        return [
            tr("nav.col.name"),
            tr("nav.col.ext"),
            tr("nav.col.size"),
            tr("nav.col.modified"),
        ]

    def retranslate_ui(self) -> None:
        self._title.setText(tr(self._title_key))
        self._table.setHorizontalHeaderLabels(self._column_labels())
        if self._path:
            self._path_label.setText(self._path)

    def set_path(self, path: str) -> None:
        self._path = path
        self._path_label.setText(path)

    def set_entries(self, entries: list[dict]) -> None:
        self._entries = list(entries)
        self._apply_sort()

    def _on_header_clicked(self, column: int) -> None:
        if self._sort_column == column:
            self._sort_order = (
                Qt.SortOrder.DescendingOrder
                if self._sort_order == Qt.SortOrder.AscendingOrder
                else Qt.SortOrder.AscendingOrder
            )
        else:
            self._sort_column = column
            self._sort_order = Qt.SortOrder.AscendingOrder
        self._apply_sort()

    def _apply_sort(self) -> None:
        sorted_entries = sort_browser_entries(
            self._entries,
            sort_column=self._sort_column,
            ascending=self._sort_order == Qt.SortOrder.AscendingOrder,
        )
        self._populate_table(sorted_entries)
        header = self._table.horizontalHeader()
        header.setSortIndicator(self._sort_column, self._sort_order)

    def _populate_table(self, entries: list[dict]) -> None:
        self._table.setRowCount(0)
        for row, entry in enumerate(entries):
            self._table.insertRow(row)
            values = (
                entry.get("name", ""),
                entry.get("ext", ""),
                entry.get("size", ""),
                entry.get("modified", ""),
            )
            for col, text in enumerate(values):
                item = QTableWidgetItem(str(text))
                if col == COL_NAME:
                    item.setData(Qt.ItemDataRole.UserRole, entry.get("absolute_path", ""))
                self._table.setItem(row, col, item)
        self._apply_column_layout()

    def _on_cell_activate(self, row: int, _col: int) -> None:
        name = self._item_text(row, 0)
        size = self._item_text(row, 2)
        if not name:
            return
        if name == ".." or size == tr("nav.dir_marker"):
            self.folder_open_requested.emit(name.rstrip("/") or "..")
            return
        item = self._table.item(row, 0)
        if item is None:
            return
        absolute_path = item.data(Qt.ItemDataRole.UserRole) or ""
        rect = self._table.visualItemRect(item)
        global_pos = self._table.viewport().mapToGlobal(rect.center())
        self.file_actions_requested.emit(
            {
                "name": name.rstrip("/"),
                "ext": self._item_text(row, 1),
                "size": size,
                "modified": self._item_text(row, 3),
                "path": self._path,
                "absolute_path": absolute_path,
                "global_pos": global_pos,
            }
        )

    def _on_selection(self) -> None:
        rows = self._table.selectionModel().selectedRows()
        if not rows:
            return
        row = rows[0].row()
        item = self._table.item(row, 0)
        absolute_path = ""
        if item is not None:
            absolute_path = item.data(Qt.ItemDataRole.UserRole) or ""
        payload = {
            "name": self._item_text(row, 0),
            "ext": self._item_text(row, 1),
            "size": self._item_text(row, 2),
            "modified": self._item_text(row, 3),
            "path": self._path,
            "absolute_path": absolute_path,
        }
        self.selection_changed.emit(payload)

    def _item_text(self, row: int, col: int) -> str:
        item = self._table.item(row, col)
        return item.text() if item else ""
