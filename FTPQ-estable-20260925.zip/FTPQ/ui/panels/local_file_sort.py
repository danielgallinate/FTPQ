"""Orden estilo Norton Commander para el explorador local."""
from __future__ import annotations

COL_NAME = 0
COL_EXT = 1
COL_SIZE = 2
COL_MODIFIED = 3


def is_parent_entry(entry: dict) -> bool:
    if "is_parent" in entry:
        return bool(entry["is_parent"])
    return str(entry.get("name", "")).rstrip("/") == ".."


def is_dir_entry(entry: dict) -> bool:
    if entry.get("is_dir") is True:
        return True
    name = str(entry.get("name", ""))
    if name.rstrip("/") == "..":
        return True
    if name.endswith("/"):
        return True
    size = str(entry.get("size", ""))
    return size in {"<DIR>", "<dir>"}


def entry_sort_key(entry: dict, column: int) -> tuple | str | float | int:
    if column == COL_NAME:
        return str(entry.get("name", "")).rstrip("/").casefold()
    if column == COL_EXT:
        return str(entry.get("ext", "")).casefold()
    if column == COL_SIZE:
        if "size_bytes" in entry:
            return int(entry.get("size_bytes") or 0)
        return _size_sort_key(str(entry.get("size", "")))
    if column == COL_MODIFIED:
        if "modified_ts" in entry:
            return float(entry.get("modified_ts") or 0.0)
        return str(entry.get("modified", ""))
    return ""


def sort_browser_entries(
    entries: list[dict],
    *,
    sort_column: int,
    ascending: bool = True,
) -> list[dict]:
    """``..`` primero; carpetas; archivos; dentro de cada grupo el criterio elegido."""
    parent_rows = [entry for entry in entries if is_parent_entry(entry)]
    directories = [
        entry
        for entry in entries
        if is_dir_entry(entry) and not is_parent_entry(entry)
    ]
    files = [entry for entry in entries if not is_dir_entry(entry)]
    reverse = not ascending
    directories.sort(key=lambda item: entry_sort_key(item, sort_column), reverse=reverse)
    files.sort(key=lambda item: entry_sort_key(item, sort_column), reverse=reverse)
    return parent_rows + directories + files


def _size_sort_key(text: str) -> tuple[int, float]:
    value = text.strip()
    if value in {"<DIR>", "<dir>"}:
        return (0, -1.0)
    if value.endswith("M"):
        try:
            return (1, float(value[:-1]) * 1_000_000)
        except ValueError:
            return (2, 0.0)
    if value.endswith("K"):
        try:
            return (1, float(value[:-1]) * 1_000)
        except ValueError:
            return (2, 0.0)
    try:
        return (1, float(value))
    except ValueError:
        return (2, 0.0)


def local_entry_to_row(entry) -> dict:
    """Convierte ``LocalEntry`` a fila UI con metadatos de ordenación."""
    from ui.i18n import tr

    is_parent = entry.name.rstrip("/") == ".."
    is_dir = entry.is_dir or is_parent
    size = tr("nav.dir_marker") if is_dir else _format_size(entry.size_bytes)
    modified = ""
    modified_ts = 0.0
    if entry.modified is not None:
        modified = entry.modified.strftime("%Y-%m-%d %H:%M")
        modified_ts = entry.modified.timestamp()
    return {
        "name": entry.name,
        "ext": entry.ext,
        "size": size,
        "modified": modified,
        "absolute_path": str(entry.absolute_path),
        "is_dir": is_dir,
        "is_parent": is_parent,
        "size_bytes": int(entry.size_bytes or 0),
        "modified_ts": modified_ts,
    }


def _format_size(size_bytes: int) -> str:
    if size_bytes >= 1_048_576:
        return f"{size_bytes / 1_048_576:.1f}M"
    if size_bytes >= 1024:
        return f"{size_bytes / 1024:.1f}K"
    return str(size_bytes)
