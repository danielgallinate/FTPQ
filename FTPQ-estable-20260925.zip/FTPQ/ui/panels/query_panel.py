"""U-P4 — Consulta (panel independiente bajo asistente)."""
from __future__ import annotations

from PySide6.QtWidgets import QFrame, QHBoxLayout, QLineEdit, QPushButton, QVBoxLayout


class QueryPanel(QFrame):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("panel")
        self.setFrameShape(QFrame.Shape.NoFrame)

        self._input = QLineEdit()
        self._input.setObjectName("panelBody")
        self._input.setPlaceholderText("Escriba una consulta… (deshabilitado en prototipo)")
        self._input.setEnabled(False)

        self._send = QPushButton("Enviar")
        self._send.setObjectName("sendButton")
        self._send.setEnabled(False)

        row = QHBoxLayout()
        row.setContentsMargins(10, 10, 10, 10)
        row.setSpacing(10)
        row.addWidget(self._input, stretch=1)
        row.addWidget(self._send)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addLayout(row)
