"""Panel embebido — informe compare en Asistente PDE."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
)

from ui.i18n import tr


class CompareReportPanel(QFrame):
    export_requested = Signal()
    close_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("compareReportPanel")

        self._body = QTextEdit()
        self._body.setObjectName("panelBody")
        self._body.setReadOnly(True)
        self._body.setFrameShape(QFrame.Shape.NoFrame)

        self._export = QPushButton()
        self._export.setObjectName("saveAction")
        self._export.clicked.connect(self.export_requested.emit)
        self._close = QPushButton()
        self._close.clicked.connect(self.close_requested.emit)

        footer = QFrame()
        footer.setObjectName("configActionBar")
        actions = QHBoxLayout(footer)
        actions.setContentsMargins(8, 8, 8, 8)
        actions.setSpacing(8)
        actions.addWidget(self._export)
        actions.addStretch(1)
        actions.addWidget(self._close)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self._body, stretch=1)
        layout.addWidget(footer, stretch=0)
        self.retranslate_ui()

    def retranslate_ui(self) -> None:
        self._export.setText(tr("compare.export"))
        self._close.setText(tr("action.back"))

    def set_report(self, text: str) -> None:
        self._body.setPlainText(text)
        cursor = self._body.textCursor()
        cursor.movePosition(cursor.MoveOperation.Start)
        self._body.setTextCursor(cursor)
