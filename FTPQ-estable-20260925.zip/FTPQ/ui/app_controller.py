"""Estado de aplicación — perfil único + SFTP test/save."""
from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtWidgets import QFileDialog, QWidget

from adapters.local_key_store import LocalKeyStore
from adapters.sftp_browser_factory import create_sftp_browser
from core.app_profile import AppProfile
from core.download_progress import DownloadProgressCallback
from core.env_import import (
    apply_env_import,
    discover_env_files,
    import_env_file,
    merge_missing,
)
from core.profile_store import IProfileStore, JsonProfileStore
from core.result import Err, Ok, Result
from core.sftp_types import SftpListing, VisualizeResult
from core.sftp_browser import ISftpBrowser
from core.sftp_errors import SftpError, TransferCancelledError
from core.ui_preferences import normalize_ui_language
from ui.i18n import set_language, tr
from ui.i18n.locale import load_legacy_language_file


def bootstrap_profile(store: IProfileStore | None = None) -> AppProfile:
    """Carga perfil y migra idioma legado si aplica."""
    st = store or JsonProfileStore()
    profile = st.load()
    _migrate_language_legacy(st, profile)
    return profile


def _migrate_language_legacy(store: IProfileStore, profile: AppProfile) -> None:
    path = getattr(store, "path", None)
    if path is None or not Path(path).is_file():
        return
    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return
    ui = raw.get("ui")
    if isinstance(ui, dict) and "language" in ui:
        return
    legacy = load_legacy_language_file()
    if legacy is None:
        return
    profile.language = legacy
    store.save(profile)


class AppController:
    def __init__(
        self,
        profile_store: IProfileStore | None = None,
        key_store: LocalKeyStore | None = None,
        browser: ISftpBrowser | None = None,
    ) -> None:
        self._store = profile_store or JsonProfileStore()
        self._keys = key_store or LocalKeyStore()
        self._browser = browser
        self.profile: AppProfile = bootstrap_profile(self._store)
        self._last_env_import: Path | None = None
        self._download_progress_handler: DownloadProgressCallback | None = None
        self._transfer_cancelled = False
        self._maybe_bootstrap_from_env()

    def set_download_progress_handler(
        self, handler: DownloadProgressCallback | None
    ) -> None:
        self._download_progress_handler = handler

    def begin_transfer(self) -> None:
        self._transfer_cancelled = False

    def request_cancel_transfer(self) -> None:
        """Marca cancelación — seguro desde el hilo UI; el callback SFTP la aplica."""
        self._transfer_cancelled = True

    def cancel_transfer(self) -> None:
        """Cancelación completa — debe ejecutarse en el hilo SFTP (Paramiko)."""
        self._transfer_cancelled = True
        browser = self._browser
        if browser is None:
            return
        abort = getattr(browser, "abort_transfer", None)
        if callable(abort):
            abort()

    def _on_download_bytes(self, transferred: int, total: int) -> None:
        if self._transfer_cancelled:
            browser = self._browser
            if browser is not None:
                abort = getattr(browser, "abort_transfer", None)
                if callable(abort):
                    abort()
            raise TransferCancelledError(tr("err.download_cancelled"))
        if self._download_progress_handler is not None:
            self._download_progress_handler(transferred, total)

    @property
    def browser(self) -> ISftpBrowser:
        if self._browser is None:
            self._browser = create_sftp_browser()
        return self._browser

    @property
    def key_store(self) -> LocalKeyStore:
        return self._keys

    @property
    def last_env_import(self) -> Path | None:
        return self._last_env_import

    def save_profile(self, profile: AppProfile | None = None) -> None:
        if profile is not None:
            self.profile = profile
        self._store.save(self.profile)

    def set_ui_language(self, code: str) -> None:
        """Persiste idioma en perfil y aplica en memoria."""
        normalized = normalize_ui_language(code)
        self.profile.language = normalized
        self._store.save(self.profile)
        set_language(normalized)

    def import_env_path(self, path: Path) -> AppProfile:
        imported = import_env_file(path)
        self.profile = apply_env_import(self.profile, imported)
        self._last_env_import = path
        self._store.save(self.profile)
        return self.profile

    def pick_and_import_env(self, parent: QWidget) -> Path | None:
        start = discover_env_files()
        initial = str(start[0].parent) if start else str(Path.home())
        chosen, _ = QFileDialog.getOpenFileName(
            parent,
            tr("dialog.import_env"),
            initial,
            tr("filter.env"),
        )
        if not chosen:
            return None
        self.import_env_path(Path(chosen))
        return Path(chosen)

    def test_sftp(self, draft: AppProfile) -> Result[None, SftpError]:
        missing = _validate_sftp_profile(draft)
        if missing is not None:
            return missing

        browser = create_sftp_browser()
        sftp = draft.to_sftp_profile()
        try:
            browser.connect(sftp)
            result = browser.test_auth()
        except SftpError as exc:
            result = Err(exc)
        finally:
            browser.disconnect()
        return result

    def connect_and_list(
        self, profile: AppProfile | None = None
    ) -> Result[SftpListing, SftpError]:
        draft = profile or self.profile
        missing = _validate_sftp_profile(draft)
        if missing is not None:
            return missing

        browser = self.browser
        browser.disconnect()
        sftp = draft.to_sftp_profile()
        from core.sftp_paths import SFTP_ROOT, display_path

        try:
            browser.connect(sftp)
            auth = browser.test_auth()
            if isinstance(auth, Err):
                browser.disconnect()
                return auth
            entries = browser.list_dir(SFTP_ROOT)
            path = browser.current_remote_path or SFTP_ROOT
            return Ok(
                SftpListing(
                    remote_path=path,
                    display_path=display_path(draft.user, path),
                    entries=entries,
                )
            )
        except SftpError as exc:
            browser.disconnect()
            return Err(exc)

    def list_remote_dir(self, remote_path: str) -> Result[SftpListing, SftpError]:
        from core.sftp_paths import display_path
        from core.sftp_types import SessionState

        browser = self.browser
        if browser.state != SessionState.CONNECTED:
            return Err(_connection_error(tr("err.no_session")))
        try:
            entries = browser.list_dir(remote_path)
            path = browser.current_remote_path or remote_path
            return Ok(
                SftpListing(
                    remote_path=path,
                    display_path=display_path(self.profile.user, path),
                    entries=entries,
                )
            )
        except SftpError as exc:
            return Err(exc)

    def remote_file_path(self, filename: str) -> str:
        from core.sftp_paths import join_remote_path

        browser = self.browser
        current = browser.current_remote_path or "."
        return join_remote_path(current, filename)

    def pick_download_path(self, parent: QWidget, filename: str) -> Path | None:
        default_dir = self.profile.download_dir.expanduser()
        try:
            default_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            default_dir = Path.home() / "Downloads"
            default_dir.mkdir(parents=True, exist_ok=True)
        default_file = default_dir / Path(filename).name
        dest, _ = QFileDialog.getSaveFileName(
            parent,
            tr("dialog.download"),
            str(default_file),
            tr("filter.download"),
        )
        if not dest:
            return None
        return Path(dest)

    def download_remote_file(
        self,
        filename: str,
        local_path: Path | None = None,
        *,
        force: bool = False,
    ) -> Result[Path, SftpError]:
        from core.sftp_types import SessionState

        browser = self.browser
        if browser.state != SessionState.CONNECTED:
            return Err(_connection_error(tr("err.no_session")))
        remote = self.remote_file_path(filename)
        if local_path is None:
            local_dir = self.profile.download_dir.expanduser()
            try:
                local_dir.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                from core.sftp_errors import SftpPathError

                return Err(
                    SftpPathError(
                        tr("err.download_dir", error=exc),
                        path=str(local_dir),
                    )
                )
            local = local_dir / Path(filename).name
        else:
            local = local_path.expanduser()
            try:
                local.parent.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                from core.sftp_errors import SftpPathError

                return Err(
                    SftpPathError(
                        tr("err.local_dest", error=exc),
                        path=str(local.parent),
                    )
                )
        try:
            self.begin_transfer()
            browser.download(
                remote,
                local,
                on_progress=self._on_download_bytes,
                force=force,
            )
            return Ok(local)
        except TransferCancelledError:
            local.unlink(missing_ok=True)
            return Err(TransferCancelledError(tr("err.download_cancelled")))
        except SftpError as exc:
            return Err(exc)
        except OSError as exc:
            from core.sftp_errors import SftpPathError

            return Err(
                SftpPathError(tr("err.save_local", error=exc), path=str(local))
            )

    def visualize_remote_file(self, filename: str) -> Result[VisualizeResult, SftpError]:
        """Descarga el archivo completo; tabular → análisis pandas; resto → texto local."""
        from core.analysis_types import is_tabular_extension
        from core.file_view import (
            is_viewable_extension,
            read_visualize_file,
            visualize_local_path,
        )
        from core.sftp_types import SessionState

        browser = self.browser
        if browser.state != SessionState.CONNECTED:
            return Err(_connection_error(tr("err.no_session")))
        if not is_viewable_extension(filename):
            from core.sftp_errors import PreviewNotSupported

            remote = self.remote_file_path(filename)
            return Err(
                PreviewNotSupported(
                    tr("err.visualize_unsupported"),
                    path=remote,
                )
            )
        remote = self.remote_file_path(filename)
        local = visualize_local_path(filename)
        try:
            self.begin_transfer()
            local.parent.mkdir(parents=True, exist_ok=True)
            browser.download(remote, local, on_progress=self._on_download_bytes)
        except TransferCancelledError:
            local.unlink(missing_ok=True)
            return Err(TransferCancelledError(tr("err.visualize_cancelled")))
        except SftpError as exc:
            return Err(exc)
        except OSError as exc:
            from core.sftp_errors import SftpPathError

            return Err(
                SftpPathError(tr("err.local_folder", error=exc), path=str(local))
            )

        if is_tabular_extension(filename):
            file_size = local.stat().st_size
            from core.visualization_policy import tabular_uses_pandas
            from core.file_view import read_text_head_preview

            if tabular_uses_pandas(self.profile, file_size):
                return Ok(
                    VisualizeResult(
                        local_path=local,
                        content="",
                        file_size=file_size,
                        line_count=0,
                        display_truncated=False,
                        tabular=True,
                    )
                )
            return read_text_head_preview(local, text_fallback=True)

        sftp_profile = self.profile.to_sftp_profile()
        return read_visualize_file(
            local,
            max_display_lines=sftp_profile.preview_max_lines,
        )

    def _maybe_bootstrap_from_env(self) -> None:
        if self.profile.host.strip():
            return
        for path in discover_env_files():
            self.profile = merge_missing(self.profile, import_env_file(path))
            self._last_env_import = path
            self._store.save(self.profile)
            return


def _validate_sftp_profile(draft: AppProfile) -> Err[SftpError] | None:
    if not draft.host.strip():
        return Err(_connection_error(tr("err.host_missing")))
    if not draft.user.strip():
        return Err(_auth_error(tr("err.user_empty")))
    key_path = draft.private_key_path.expanduser()
    if not key_path.is_file():
        return Err(
            _key_missing(tr("err.key_missing", path=key_path), str(key_path))
        )
    return None


def _auth_error(message: str):
    from core.sftp_errors import SftpAuthError

    return SftpAuthError(message)


def _connection_error(message: str):
    from core.sftp_errors import SftpConnectionError

    return SftpConnectionError(message)


def _key_missing(message: str, path: str):
    from core.sftp_errors import KeyNotFoundError

    return KeyNotFoundError(message, path=path)
