"""Resolución segura de rutas relativas en assets."""
from __future__ import annotations

from pathlib import Path


def resolve_pref_path(root: Path, rel: str) -> Path | None:
    """Resuelve `rel` bajo `root`; rechaza rutas fuera del directorio."""
    cleaned = rel.strip()
    if not cleaned:
        return None
    root_resolved = root.resolve()
    candidate = (root / cleaned).resolve()
    try:
        candidate.relative_to(root_resolved)
    except ValueError:
        return None
    return candidate
