"""Fondo de pantalla — copia local al proyecto y preferencia JSON."""
from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QFileDialog, QWidget

from ui.theme.asset_paths import resolve_pref_path

_ASSETS = Path(__file__).resolve().parent.parent / "assets"
DEFAULT_WALLPAPER = _ASSETS / "pexels-pixabay-33109.jpg"
_WALLPAPERS_DIR_NAME = "wallpapers"
_PREFS_FILENAME = "wallpaper.json"

ACCEPTED_EXTENSIONS = frozenset({".jpg", ".jpeg", ".png", ".webp", ".bmp"})
FILE_FILTER = "Imágenes (*.jpg *.jpeg *.png *.webp *.bmp);;Todos (*.*)"


def assets_dir(assets_root: Path | None = None) -> Path:
    return assets_root or _ASSETS


def wallpapers_dir(assets_root: Path | None = None) -> Path:
    return assets_dir(assets_root) / _WALLPAPERS_DIR_NAME


def prefs_path(assets_root: Path | None = None) -> Path:
    return assets_dir(assets_root) / _PREFS_FILENAME


def _default_wallpaper_candidates(root: Path) -> tuple[Path, ...]:
    bundled = root / DEFAULT_WALLPAPER.name
    return (bundled, DEFAULT_WALLPAPER)


def resolve_wallpaper_path(assets_root: Path | None = None) -> Path:
    """Preferencia JSON → JPG por defecto → ruta bundled. Nunca lanza excepción."""
    root = assets_dir(assets_root)
    prefs = prefs_path(root)
    if prefs.is_file():
        try:
            data = json.loads(prefs.read_text(encoding="utf-8"))
            rel = str(data.get("wallpaper", "")).strip()
            candidate = resolve_pref_path(root, rel) if rel else None
            if candidate is not None and candidate.is_file():
                return candidate
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            pass
    for candidate in _default_wallpaper_candidates(root):
        if candidate.is_file():
            return candidate
    return _default_wallpaper_candidates(root)[0]


def load_wallpaper_pixmap(path: Path) -> QPixmap:
    """Carga segura: pixmap vacío si el archivo no existe o es inválido."""
    if not path.is_file():
        return QPixmap()
    pixmap = QPixmap(str(path))
    return pixmap if not pixmap.isNull() else QPixmap()


def _sanitize_filename(name: str) -> str:
    cleaned = re.sub(r"[^\w.\-]+", "_", name).strip("._")
    return cleaned or "fondo"


def install_wallpaper(source: Path, *, assets_root: Path | None = None) -> Path:
    src = source.expanduser().resolve()
    if not src.is_file():
        raise FileNotFoundError(f"Imagen no encontrada: {src}")
    ext = src.suffix.lower()
    if ext not in ACCEPTED_EXTENSIONS:
        supported = ", ".join(sorted(ACCEPTED_EXTENSIONS))
        raise ValueError(f"Formato no soportado ({ext}). Use: {supported}")

    root = assets_dir(assets_root)
    target_dir = wallpapers_dir(root)
    target_dir.mkdir(parents=True, exist_ok=True)

    dest = target_dir / _sanitize_filename(src.name)
    counter = 1
    while dest.exists():
        dest = target_dir / f"{src.stem}_{counter}{ext}"
        counter += 1

    shutil.copy2(src, dest)
    rel = dest.relative_to(root)
    prefs_path(root).write_text(
        json.dumps({"wallpaper": rel.as_posix()}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return dest


def pick_wallpaper_source(parent: QWidget, *, assets_root: Path | None = None) -> Path | None:
    root = assets_dir(assets_root)
    start_dir = wallpapers_dir(root)
    if not start_dir.is_dir():
        start_dir = root if root.is_dir() else Path.home()
    chosen, _ = QFileDialog.getOpenFileName(
        parent,
        "Elegir fondo",
        str(start_dir),
        FILE_FILTER,
    )
    if not chosen:
        return None
    return Path(chosen)
