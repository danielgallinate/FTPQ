"""Icono de ventana / barra de tareas."""
from __future__ import annotations

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from ui.theme.icon_store import resolve_app_icon_path


def load_app_icon() -> QIcon | None:
    path = resolve_app_icon_path()
    if path is None:
        return None
    icon = QIcon(str(path))
    return icon if not icon.isNull() else None


def apply_app_icon(app: QApplication) -> bool:
    icon = load_app_icon()
    if icon is None:
        return False
    app.setWindowIcon(icon)
    for widget in app.topLevelWidgets():
        widget.setWindowIcon(icon)
    return True
