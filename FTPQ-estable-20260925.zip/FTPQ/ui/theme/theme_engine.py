"""Capa 0–1: wallpaper cover + scrim. Capa 2: QSS vía ThemeEngine."""
from __future__ import annotations

import sys
from enum import Enum
from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPixmap
from PySide6.QtWidgets import QApplication, QLabel, QWidget

from ui.version import display_version

from ui.i18n import tr
from ui.theme.wallpaper_store import DEFAULT_WALLPAPER, load_wallpaper_pixmap


class ChromeMode(str, Enum):
    """Chrome visual — ciclo: oscuro → claro → neutro → sólido."""

    DARK = "dark"
    LIGHT = "light"
    NEUTRAL = "neutral"
    SOLID = "solid"


_CHROME_CYCLE = (
    ChromeMode.DARK,
    ChromeMode.LIGHT,
    ChromeMode.NEUTRAL,
    ChromeMode.SOLID,
)

SOLID_BACKGROUND = "#2a2a2e"


class ThemeEngine:
    SCRIM_OPACITY = 0.42
    BORDER_WIDTH = 1
    RADIUS_PANEL = 10
    RADIUS_CONTROL = 6
    SECTION_GAP = 14
    OUTER_MARGIN = 16

    def __init__(self, app: QApplication) -> None:
        self._app = app
        self._mode = ChromeMode.DARK

    @property
    def mode(self) -> ChromeMode:
        return self._mode

    def toggle_chrome(self) -> ChromeMode:
        index = _CHROME_CYCLE.index(self._mode)
        self._mode = _CHROME_CYCLE[(index + 1) % len(_CHROME_CYCLE)]
        self.apply()
        return self._mode

    def apply(self) -> None:
        self._app.setStyleSheet(_build_qss(self._mode))

    def scrim_rgba(self) -> tuple[int, int, int, int]:
        if self._mode == ChromeMode.SOLID:
            return (0, 0, 0, 0)
        if self._mode == ChromeMode.NEUTRAL:
            return (96, 96, 100, int(255 * 0.58))
        alpha = int(255 * self.SCRIM_OPACITY)
        if self._mode == ChromeMode.DARK:
            return (0, 0, 0, alpha)
        return (255, 255, 255, alpha)

    def mode_label(self) -> str:
        labels = {
            ChromeMode.DARK: tr("theme.dark"),
            ChromeMode.LIGHT: tr("theme.light"),
            ChromeMode.NEUTRAL: tr("theme.neutral"),
            ChromeMode.SOLID: tr("theme.solid"),
        }
        return labels[self._mode]


class WallpaperHost(QWidget):
    """Fondo imagen + scrim; hijos transparentes encima."""

    scrim_changed = Signal()

    def __init__(
        self,
        theme: ThemeEngine,
        wallpaper_path: Path | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._theme = theme
        self._wallpaper_path = wallpaper_path or DEFAULT_WALLPAPER
        self._pixmap = load_wallpaper_pixmap(self._wallpaper_path)
        self.setObjectName("wallpaperHost")

        self._version_badge = QLabel(display_version(), self)
        self._version_badge.setObjectName("versionBadge")
        self._version_badge.setFont(_badge_font())
        self._version_badge.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._position_version_badge()

    def _position_version_badge(self) -> None:
        margin = 10
        self._version_badge.adjustSize()
        x = self.width() - self._version_badge.width() - margin
        y = self.height() - self._version_badge.height() - margin
        self._version_badge.move(max(margin, x), max(margin, y))
        self._version_badge.raise_()

    def set_wallpaper(self, path: Path) -> None:
        self._wallpaper_path = path
        self._pixmap = load_wallpaper_pixmap(path)
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

        if self._theme.mode == ChromeMode.SOLID:
            painter.fillRect(self.rect(), QColor(SOLID_BACKGROUND))
            return

        if self._pixmap.isNull():
            painter.fillRect(self.rect(), QColor("#1a1a1a"))
        else:
            _paint_cover(painter, self._pixmap, self.rect())

        r, g, b, a = self._theme.scrim_rgba()
        if a > 0:
            painter.fillRect(self.rect(), QColor(r, g, b, a))

    def refresh_scrim(self) -> None:
        self.update()
        self.scrim_changed.emit()


def _paint_cover(painter: QPainter, pixmap: QPixmap, target) -> None:
    if pixmap.isNull() or target.isEmpty():
        return
    scaled = pixmap.scaled(
        target.size(),
        Qt.AspectRatioMode.KeepAspectRatioByExpanding,
        Qt.TransformationMode.SmoothTransformation,
    )
    x = (target.width() - scaled.width()) // 2
    y = (target.height() - scaled.height()) // 2
    painter.drawPixmap(x, y, scaled)


def _ui_font_family() -> str:
    if sys.platform == "darwin":
        return '"Helvetica Neue", "Lucida Grande", ".AppleSystemUIFont"'
    if sys.platform == "win32":
        return '"Segoe UI"'
    return '"Ubuntu", "Cantarell", "DejaVu Sans"'


def _badge_font() -> QFont:
    if sys.platform == "darwin":
        font = QFont("Menlo", 11)
    elif sys.platform == "win32":
        font = QFont("Consolas", 11)
    else:
        font = QFont("DejaVu Sans Mono", 11)
    font.setWeight(QFont.Weight.DemiBold)
    return font


def _build_qss(mode: ChromeMode) -> str:
    bw = ThemeEngine.BORDER_WIDTH
    rp = ThemeEngine.RADIUS_PANEL
    rc = ThemeEngine.RADIUS_CONTROL

    if mode == ChromeMode.DARK:
        fg = "#FFFFFF"
        line = "rgba(255, 255, 255, 0.28)"
        line_soft = "rgba(255, 255, 255, 0.16)"
        title_bg = "rgba(255, 255, 255, 0.06)"
        menu_bg = "rgba(0, 0, 0, 0.30)"
        input_bg = "rgba(0, 0, 0, 0.20)"
        sel_bg, sel_fg = "#FFFFFF", "#111111"
        grid = "rgba(255, 255, 255, 0.18)"
        btn_bg = "rgba(0, 0, 0, 0.16)"
        btn_hover_bg, btn_hover_fg = "#FFFFFF", "#111111"
        send_bg = "rgba(160, 160, 160, 0.38)"
        send_fg = "#111111"
        status_bg = "rgba(0, 0, 0, 0.30)"
        section_bg = "rgba(255, 255, 255, 0.04)"
        field_label = "rgba(255, 255, 255, 0.62)"
        hint_fg = "rgba(255, 255, 255, 0.72)"
        save_bg = "#3b6ea8"
        save_fg = "#FFFFFF"
        cell_bg = "rgba(28, 28, 32, 0.86)"
        cell_alt = "rgba(38, 38, 44, 0.86)"
        sidebar_bg = "rgba(18, 18, 22, 0.82)"
    elif mode == ChromeMode.LIGHT:
        fg = "#111111"
        line = "rgba(0, 0, 0, 0.22)"
        line_soft = "rgba(0, 0, 0, 0.12)"
        title_bg = "rgba(0, 0, 0, 0.05)"
        menu_bg = "rgba(255, 255, 255, 0.48)"
        input_bg = "rgba(255, 255, 255, 0.38)"
        sel_bg, sel_fg = "#111111", "#FFFFFF"
        grid = "rgba(0, 0, 0, 0.12)"
        btn_bg = "rgba(255, 255, 255, 0.38)"
        btn_hover_bg, btn_hover_fg = "#111111", "#FFFFFF"
        send_bg = "rgba(140, 140, 140, 0.48)"
        send_fg = "#FFFFFF"
        status_bg = "rgba(255, 255, 255, 0.48)"
        section_bg = "rgba(0, 0, 0, 0.04)"
        field_label = "rgba(0, 0, 0, 0.55)"
        hint_fg = "rgba(0, 0, 0, 0.65)"
        save_bg = "#2563eb"
        save_fg = "#FFFFFF"
        cell_bg = "rgba(255, 255, 255, 0.86)"
        cell_alt = "rgba(245, 245, 248, 0.86)"
        sidebar_bg = "rgba(252, 252, 254, 0.82)"
    elif mode == ChromeMode.NEUTRAL:
        fg = "#F0F0F0"
        line = "rgba(220, 220, 224, 0.32)"
        line_soft = "rgba(200, 200, 204, 0.20)"
        title_bg = "rgba(255, 255, 255, 0.08)"
        menu_bg = "rgba(72, 72, 76, 0.72)"
        input_bg = "rgba(48, 48, 52, 0.55)"
        sel_bg, sel_fg = "#ECECEC", "#2A2A2E"
        grid = "rgba(220, 220, 224, 0.22)"
        btn_bg = "rgba(48, 48, 52, 0.55)"
        btn_hover_bg, btn_hover_fg = "#ECECEC", "#2A2A2E"
        send_bg = "rgba(120, 120, 124, 0.72)"
        send_fg = "#111111"
        status_bg = "rgba(58, 58, 62, 0.82)"
        section_bg = "rgba(255, 255, 255, 0.06)"
        field_label = "rgba(240, 240, 240, 0.68)"
        hint_fg = "rgba(240, 240, 240, 0.78)"
        save_bg = "#4a6fa8"
        save_fg = "#FFFFFF"
        cell_bg = "rgba(58, 58, 62, 0.92)"
        cell_alt = "rgba(68, 68, 72, 0.92)"
        sidebar_bg = "rgba(50, 50, 54, 0.88)"
    else:
        fg = "#ECECEC"
        line = "rgba(210, 210, 214, 0.35)"
        line_soft = "rgba(190, 190, 194, 0.22)"
        title_bg = "#3a3a3e"
        menu_bg = "#3c3c40"
        input_bg = "#333337"
        sel_bg, sel_fg = "#ECECEC", "#1E1E22"
        grid = "rgba(210, 210, 214, 0.24)"
        btn_bg = "#3a3a3e"
        btn_hover_bg, btn_hover_fg = "#ECECEC", "#1E1E22"
        send_bg = "#5a5a5e"
        send_fg = "#111111"
        status_bg = "#333337"
        section_bg = "#36363a"
        field_label = "rgba(236, 236, 236, 0.72)"
        hint_fg = "rgba(236, 236, 236, 0.82)"
        save_bg = "#3b6ea8"
        save_fg = "#FFFFFF"
        cell_bg = "#333337"
        cell_alt = "#3a3a3e"
        sidebar_bg = "#2e2e32"

    font = _ui_font_family()
    return f"""
QMainWindow, QWidget#wallpaperHost, QWidget {{
    background: transparent;
    color: {fg};
    font-family: {font};
    font-size: 13px;
}}

QFrame {{
    border: none;
    background: transparent;
}}

QWidget#toolbar {{
    padding-bottom: 4px;
}}

QWidget#colorButton QPushButton {{
    border: none;
    background: transparent;
}}

QWidget#colorButton QPushButton:hover {{
    background-color: {title_bg};
    border-radius: {rc}px;
}}

QMenuBar {{
    background-color: {menu_bg};
    border: {bw}px solid {line};
    border-radius: {rc}px;
    padding: 2px 6px;
    color: {fg};
}}

QWidget#headerBar {{
    background-color: {menu_bg};
    border: {bw}px solid {line};
    border-radius: {rc}px;
}}

QWidget#headerBar QMenuBar {{
    background: transparent;
    border: none;
    padding: 2px 6px;
}}

QMenuBar::item {{
    padding: 4px 10px;
    border-radius: {rc}px;
    background: transparent;
}}

QMenuBar::item:selected {{
    background-color: {sel_bg};
    color: {sel_fg};
}}

QMenu {{
    background-color: {menu_bg};
    border: {bw}px solid {line};
    border-radius: {rc}px;
    color: {fg};
    padding: 4px;
}}

QMenu::item {{
    padding: 6px 20px;
    border-radius: {rc}px;
}}

QSplitter::handle {{
    background: transparent;
}}

QSplitter::handle:horizontal {{
    width: {ThemeEngine.SECTION_GAP}px;
}}

QSplitter::handle:vertical {{
    height: {ThemeEngine.SECTION_GAP}px;
}}

QFrame#panel {{
    background: transparent;
    border: {bw}px solid {line};
    border-style: solid;
    border-radius: {rp}px;
}}

QLabel#panelTitle {{
    color: {fg};
    font-weight: 600;
    padding: 8px 12px;
    border: none;
    border-bottom: {bw}px solid {line_soft};
    border-top-left-radius: {rp}px;
    border-top-right-radius: {rp}px;
    background-color: {title_bg};
}}

QLabel#panelSubhead {{
    color: {fg};
    padding: 6px 12px;
    opacity: 0.92;
}}

QTableWidget#panelBody {{
    background: transparent;
    color: {fg};
    gridline-color: {grid};
    selection-background-color: {sel_bg};
    selection-color: {sel_fg};
    border: none;
    margin: 0;
    padding: 0 4px 4px 4px;
}}

QTableWidget#templateEditTable {{
    background-color: {cell_bg};
    color: {fg};
    gridline-color: {grid};
    selection-background-color: transparent;
    selection-color: {fg};
    border: {bw}px solid {line};
    border-radius: {rc}px;
    outline: none;
}}

QTableWidget#templateEditTable::item {{
    padding: 4px 8px;
    border: none;
}}

QTableWidget#templateEditTable::item:selected {{
    background-color: rgba(120, 160, 210, 45);
    color: {fg};
    border: 1px solid {line_soft};
}}

QTableWidget#templateEditTable QLineEdit {{
    background-color: {cell_bg};
    color: {fg};
    border: 1px solid {line_soft};
    border-radius: 2px;
    padding: 1px 4px;
    selection-background-color: {sel_bg};
    selection-color: {sel_fg};
}}

QTableWidget#qaMetricsTable {{
    background-color: {cell_bg};
    alternate-background-color: {cell_alt};
    color: {fg};
    gridline-color: {grid};
    selection-background-color: {sel_bg};
    selection-color: {sel_fg};
    border: {bw}px solid {line};
    border-radius: {rc}px;
}}

QTableWidget#qaMetricsTable::item {{
    padding: 4px 8px;
}}

QDialog#referenceMetricsDialog {{
    background: transparent;
    color: {fg};
}}

QDialog#referenceMetricsDialog QWidget#wallpaperHost {{
    background: transparent;
}}

QWidget#referenceMetricsScrollHost {{
    background: transparent;
}}

QWidget#referenceMetricsReportView {{
    background: transparent;
}}

QScrollArea#referenceMetricsScroll {{
    background: transparent;
    border: none;
}}

QScrollArea#referenceMetricsScroll > QWidget > QWidget {{
    background: transparent;
}}

QWidget#referenceMetricsCharts {{
    background: transparent;
}}

QDialog#qaMetricsDialog {{
    background: transparent;
    color: {fg};
}}

QDialog#qaMetricsDialog QWidget#wallpaperHost {{
    background: transparent;
}}

QWidget#qaMetricsScrollHost {{
    background: transparent;
}}

QWidget#qaMetricsReportView {{
    background: transparent;
}}

QScrollArea#qaMetricsScroll {{
    background: transparent;
    border: none;
}}

QScrollArea#qaMetricsScroll > QWidget > QWidget {{
    background: transparent;
}}

QWidget#qaMetricsTemplateBoard {{
    background: transparent;
}}

QWidget#qaMetricsCharts {{
    background: transparent;
}}

QChartView {{
    background: transparent;
    border: none;
}}

QTableView#dataTable {{
    background-color: {cell_bg};
    alternate-background-color: {cell_alt};
    color: {fg};
    gridline-color: {grid};
    selection-background-color: {sel_bg};
    selection-color: {sel_fg};
    border: {bw}px solid {line};
    border-radius: {rc}px;
    padding: 2px;
}}

QTableView#dataTable::item {{
    padding: 4px 8px;
    border: none;
}}

QFrame#dataViewerSidebar {{
    background-color: {sidebar_bg};
    border: {bw}px solid {line};
    border-radius: {rc}px;
}}

QTextEdit#dataViewerStats {{
    background-color: {cell_bg};
    color: {fg};
    border: {bw}px solid {line_soft};
    border-radius: {rc}px;
    padding: 6px 8px;
}}

QFrame#dataViewerPanel {{
    background: transparent;
    border: none;
}}

QPushButton#closeDataViewer {{
    background-color: {btn_bg};
    color: {fg};
    border: {bw}px solid {line};
    border-radius: {rc}px;
    padding: 6px 16px;
    font-weight: 600;
}}

QPushButton#closeDataViewer:hover {{
    background-color: {btn_hover_bg};
    color: {btn_hover_fg};
}}

QTextEdit#panelBody, QLineEdit#panelBody {{
    background: transparent;
    color: {fg};
    border: none;
    border-radius: 0;
    padding: 8px 12px;
    margin: 0;
}}

QListWidget#panelBody {{
    background: transparent;
    color: {fg};
    border: none;
    padding: 4px 8px;
    outline: none;
}}

QListWidget#panelBody::item {{
    padding: 4px 6px;
    border-radius: {rc}px;
}}

QListWidget#panelBody::item:selected {{
    background-color: {sel_bg};
    color: {sel_fg};
}}

QHeaderView::section {{
    background-color: {title_bg};
    color: {fg};
    border: none;
    border-bottom: {bw}px solid {grid};
    padding: 6px 8px;
}}

QLineEdit:disabled {{
    color: {fg};
    opacity: 0.55;
}}

QPushButton#sendButton {{
    background-color: {send_bg};
    color: {send_fg};
    border: {bw}px solid {line_soft};
    border-radius: {rc}px;
    padding: 6px 18px;
    font-weight: 600;
}}

QPushButton#sendButton:hover {{
    background-color: {btn_hover_bg};
    color: {btn_hover_fg};
    border-color: {line};
}}

QPushButton {{
    background-color: {btn_bg};
    color: {fg};
    border: {bw}px solid {line_soft};
    border-radius: {rc}px;
    padding: 5px 14px;
}}

QPushButton:hover {{
    background-color: {btn_hover_bg};
    color: {btn_hover_fg};
    border-color: {line};
}}

QPushButton:pressed {{
    background-color: {btn_bg};
    border-color: {line_soft};
}}

QStatusBar {{
    background-color: {status_bg};
    color: {fg};
    border-top: {bw}px solid {line_soft};
    padding: 2px 8px;
}}

QLabel#versionBadge {{
    color: #3ddc84;
    font-size: 11px;
    font-weight: 600;
    background: rgba(0, 0, 0, 0.38);
    padding: 4px 8px;
    border: {bw}px solid {line_soft};
    border-radius: {rc}px;
}}

QFrame#configSection {{
    background-color: {section_bg};
    border: {bw}px solid {line_soft};
    border-radius: {rc}px;
}}

QLabel#configSectionTitle {{
    font-weight: 700;
    letter-spacing: 0.4px;
    color: {fg};
}}

QLabel#configFieldLabel {{
    color: {field_label};
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.6px;
}}

QLabel#configHint {{
    color: {hint_fg};
    font-size: 11px;
}}

QLabel#copyToast {{
    color: {fg};
    background-color: {status_bg};
    padding: 4px 12px;
    border-radius: {rc}px;
    font-size: 11px;
}}

QLineEdit#configField, QComboBox#configField {{
    background-color: {input_bg};
    color: {fg};
    border: {bw}px solid {line_soft};
    border-radius: {rc}px;
    padding: 6px 8px;
    min-height: 18px;
}}

QComboBox#configField::drop-down {{
    border: none;
    width: 18px;
}}

QPushButton#saveAction {{
    background-color: {save_bg};
    color: {save_fg};
    border: {bw}px solid {save_bg};
    border-radius: {rc}px;
    padding: 8px 20px;
    font-weight: 600;
    min-height: 20px;
}}

QPushButton#saveAction:hover {{
    background-color: {save_bg};
    color: {save_fg};
    border: {bw}px solid {save_fg};
}}

QPushButton#saveAction:pressed {{
    padding-top: 9px;
    padding-bottom: 7px;
}}

QPushButton#primaryAction {{
    background-color: {btn_bg};
    color: {fg};
    border: {bw}px solid {line};
    border-radius: {rc}px;
    padding: 6px 16px;
    font-weight: 600;
}}

QFrame#configActionBar {{
    background-color: {section_bg};
    border-top: {bw}px solid {line_soft};
}}
"""
