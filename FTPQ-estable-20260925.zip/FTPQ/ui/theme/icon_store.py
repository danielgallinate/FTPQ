"""Icono de app — copia local al proyecto y preferencia JSON."""
from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

from PySide6.QtWidgets import QFileDialog, QWidget

from ui.i18n import tr
from ui.theme.asset_paths import resolve_pref_path

_ASSETS_ICON = Path(__file__).resolve().parent.parent / "assets" / "icon"
_CUSTOM_DIR_NAME = "icons"
_PREFS_FILENAME = "icon.json"
DEFAULT_ICON_ICO = _ASSETS_ICON / "app.ico"
DEFAULT_ICON_ICNS = _ASSETS_ICON / "app.icns"
DEFAULT_ICON_PNG = _ASSETS_ICON / "app.png"

ACCEPTED_EXTENSIONS = frozenset({".ico", ".icns", ".png"})


def icon_assets_dir(assets_root: Path | None = None) -> Path:
    return assets_root or _ASSETS_ICON


def custom_icons_dir(assets_root: Path | None = None) -> Path:
    return icon_assets_dir(assets_root) / _CUSTOM_DIR_NAME


def icon_prefs_path(assets_root: Path | None = None) -> Path:
    return icon_assets_dir(assets_root) / _PREFS_FILENAME


def file_filter_text() -> str:
    return tr("dialog.icon_filter")


def resolve_app_icon_path(assets_root: Path | None = None) -> Path | None:
    """Preferencia JSON → defaults locales. None si no hay icono usable."""
    root = icon_assets_dir(assets_root)
    prefs = icon_prefs_path(root)
    if prefs.is_file():
        try:
            data = json.loads(prefs.read_text(encoding="utf-8"))
            rel = str(data.get("icon", "")).strip()
            candidate = resolve_pref_path(root, rel) if rel else None
            if candidate is not None and candidate.is_file():
                return candidate
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            pass
    if sys.platform == "darwin":
        icns = root / DEFAULT_ICON_ICNS.name
        if icns.is_file():
            return icns
    ico = root / DEFAULT_ICON_ICO.name
    if ico.is_file():
        return ico
    png = root / DEFAULT_ICON_PNG.name
    if png.is_file():
        return png
    return None


def _sanitize_filename(name: str) -> str:
    cleaned = re.sub(r"[^\w.\-]+", "_", name).strip("._")
    return cleaned or "icono"


def install_icon(source: Path, *, assets_root: Path | None = None) -> Path:
    src = source.expanduser().resolve()
    if not src.is_file():
        raise FileNotFoundError(f"Icono no encontrado: {src}")
    ext = src.suffix.lower()
    if ext not in ACCEPTED_EXTENSIONS:
        supported = ", ".join(sorted(ACCEPTED_EXTENSIONS))
        raise ValueError(f"Formato no soportado ({ext}). Use: {supported}")

    root = icon_assets_dir(assets_root)
    target_dir = custom_icons_dir(root)
    target_dir.mkdir(parents=True, exist_ok=True)

    dest = target_dir / _sanitize_filename(src.name)
    counter = 1
    while dest.exists():
        dest = target_dir / f"{src.stem}_{counter}{ext}"
        counter += 1

    shutil.copy2(src, dest)
    rel = dest.relative_to(root)
    icon_prefs_path(root).write_text(
        json.dumps({"icon": rel.as_posix()}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return dest


def pick_icon_source(parent: QWidget, *, assets_root: Path | None = None) -> Path | None:
    root = icon_assets_dir(assets_root)
    start_dir = custom_icons_dir(root)
    if not start_dir.is_dir():
        start_dir = root if root.is_dir() else Path.home()
    chosen, _ = QFileDialog.getOpenFileName(
        parent,
        tr("dialog.icon"),
        str(start_dir),
        file_filter_text(),
    )
    if not chosen:
        return None
    return Path(chosen)
