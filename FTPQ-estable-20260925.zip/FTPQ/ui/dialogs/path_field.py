"""Campo ruta + botón Examinar."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QFileDialog, QHBoxLayout, QLineEdit, QPushButton, QWidget


class PathField(QWidget):
    def __init__(
        self,
        *,
        pick: str = "file",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._pick = pick
        self._edit = QLineEdit()
        browse = QPushButton("…")
        browse.setFixedWidth(32)
        browse.clicked.connect(self._browse)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._edit, stretch=1)
        layout.addWidget(browse)

    def text(self) -> str:
        return self._edit.text().strip()

    def setText(self, text: str) -> None:  # noqa: N802
        self._edit.setText(text)

    def path(self) -> Path:
        return Path(self.text()).expanduser()

    def _browse(self) -> None:
        if self._pick == "dir":
            chosen = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta", self.text())
            if chosen:
                self._edit.setText(chosen)
            return
        chosen, _ = QFileDialog.getOpenFileName(self, "Seleccionar archivo", self.text())
        if chosen:
            self._edit.setText(chosen)
