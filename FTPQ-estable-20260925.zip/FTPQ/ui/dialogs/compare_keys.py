"""Diálogo — elegir columnas llave para compare."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QLabel,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from ui.i18n import tr


def ask_compare_keys(parent, columns: list[str]) -> tuple[bool, tuple[str, ...]]:
    """Retorna (accepted, keys). keys vacío = comparar fila completa."""
    dialog = QDialog(parent)
    dialog.setWindowTitle(tr("compare.keys.title"))
    dialog.resize(420, 360)

    hint = QLabel(tr("compare.keys.hint"))
    hint.setWordWrap(True)

    host = QWidget()
    checks_layout = QVBoxLayout(host)
    checks_layout.setContentsMargins(4, 4, 4, 4)
    checks: list[QCheckBox] = []
    for name in columns:
        box = QCheckBox(name)
        checks_layout.addWidget(box)
        checks.append(box)
    checks_layout.addStretch(1)

    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setWidget(host)

    buttons = QDialogButtonBox(
        QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
    )
    skip = buttons.addButton(tr("compare.keys.skip"), QDialogButtonBox.ButtonRole.ActionRole)
    skip.clicked.connect(lambda: dialog.done(2))
    buttons.accepted.connect(dialog.accept)
    buttons.rejected.connect(dialog.reject)

    root = QVBoxLayout(dialog)
    root.addWidget(hint)
    root.addWidget(scroll, stretch=1)
    root.addWidget(buttons)

    code = dialog.exec()
    if code not in (1, 2):
        return False, ()
    if code == 2:
        return True, ()
    selected = tuple(box.text() for box in checks if box.isChecked())
    return True, selected
