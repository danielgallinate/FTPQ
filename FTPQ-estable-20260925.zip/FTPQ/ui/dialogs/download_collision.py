"""Diálogo — archivo local ya existe al descargar."""
from __future__ import annotations

from enum import Enum
from pathlib import Path

from PySide6.QtWidgets import QMessageBox, QWidget

from ui.i18n import tr


class DownloadCollisionChoice(str, Enum):
    CANCEL = "cancel"
    OVERWRITE = "overwrite"
    VERSION = "version"


def ask_download_collision(parent: QWidget, path: Path) -> DownloadCollisionChoice:
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Question)
    box.setWindowTitle(tr("dialog.download_collision.title"))
    box.setText(tr("dialog.download_collision.text", name=path.name))
    box.setInformativeText(tr("dialog.download_collision.info", path=str(path)))
    overwrite_btn = box.addButton(
        tr("dialog.download_collision.overwrite"),
        QMessageBox.ButtonRole.DestructiveRole,
    )
    version_btn = box.addButton(
        tr("dialog.download_collision.version"),
        QMessageBox.ButtonRole.AcceptRole,
    )
    cancel_btn = box.addButton(QMessageBox.StandardButton.Cancel)
    box.setDefaultButton(version_btn)
    box.exec()
    clicked = box.clickedButton()
    if clicked is overwrite_btn:
        return DownloadCollisionChoice.OVERWRITE
    if clicked is version_btn:
        return DownloadCollisionChoice.VERSION
    if clicked is cancel_btn:
        return DownloadCollisionChoice.CANCEL
    return DownloadCollisionChoice.CANCEL
