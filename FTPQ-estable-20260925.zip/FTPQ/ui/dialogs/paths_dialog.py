"""Configuración → Rutas — paths SFTP (sin conectar)."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from core.app_profile import AppProfile
from ui.dialogs.path_field import PathField


class PathsDialog(QDialog):
    def __init__(self, profile: AppProfile, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Configuración — Rutas")
        self.setMinimumWidth(520)

        self._profile = profile

        self._keys_dir = PathField(pick="dir")
        self._keys_dir.setText(str(profile.ssh_keys_dir))

        self._user = QLineEdit(profile.user)
        self._host = QLineEdit(profile.host)
        self._port = QSpinBox()
        self._port.setRange(1, 65535)
        self._port.setValue(profile.port)

        self._remote = QLineEdit(profile.default_remote_path)
        self._download = PathField(pick="dir")
        self._download.setText(str(profile.download_dir))

        form = QFormLayout()
        form.addRow("Carpeta de llaves", self._keys_dir)
        form.addRow("Usuario SFTP", self._user)
        form.addRow("Host SFTP", self._host)
        port_row = QHBoxLayout()
        port_row.addWidget(self._port)
        port_row.addStretch()
        form.addRow("Puerto", port_row)
        form.addRow("Ruta remota inicial", self._remote)
        form.addRow("Carpeta descargas", self._download)

        hint = QLabel("Guardar no abre conexión SFTP.")
        hint.setWordWrap(True)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(hint)
        layout.addWidget(buttons)

    def updated_profile(self) -> AppProfile:
        p = self._profile
        p.profile_id = "default"
        p.ssh_keys_dir = self._keys_dir.path()
        p.user = self._user.text().strip()
        p.host = self._host.text().strip()
        p.port = self._port.value()
        p.default_remote_path = self._remote.text().strip()
        p.download_dir = self._download.path()
        return p
