"""Copiar selección de tablas al portapapeles (TSV)."""
from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import QEvent, QObject, Qt, QModelIndex
from PySide6.QtGui import QClipboard, QKeySequence, QMouseEvent, QShortcut
from PySide6.QtWidgets import QAbstractItemView, QApplication

try:
    from shiboken6 import isValid as _qt_is_valid
except ImportError:  # pragma: no cover
    def _qt_is_valid(_obj) -> bool:
        return True


def indices_to_tsv(indexes) -> str:
    by_row: dict[int, dict[int, str]] = {}
    for index in indexes:
        if not index.isValid():
            continue
        value = index.data(Qt.ItemDataRole.DisplayRole)
        text = "" if value is None else str(value)
        by_row.setdefault(index.row(), {})[index.column()] = text
    lines: list[str] = []
    for row in sorted(by_row):
        columns = by_row[row]
        lines.append("\t".join(columns[column] for column in sorted(columns)))
    return "\n".join(lines)


def _mouse_event_pos(event: QMouseEvent):
    if hasattr(event, "position"):
        return event.position().toPoint()
    return event.pos()


def copy_view_cell(view: QAbstractItemView, index: QModelIndex) -> str | None:
    if not index.isValid():
        return None
    model = view.model()
    if model is None:
        return None
    value = model.data(index, Qt.ItemDataRole.DisplayRole)
    text = "" if value is None else str(value)
    clipboard = QApplication.clipboard()
    if clipboard is None:
        return None
    clipboard.setText(text, QClipboard.Mode.Clipboard)
    return text


def copy_view_selection(view: QAbstractItemView) -> bool:
    selection = view.selectionModel()
    if selection is None:
        return False
    indexes = selection.selectedIndexes()
    if not indexes:
        return False
    text = indices_to_tsv(indexes)
    if not text:
        return False
    clipboard = QApplication.clipboard()
    if clipboard is None:
        return False
    clipboard.setText(text, QClipboard.Mode.Clipboard)
    return True


class _TableDoubleClickCopyFilter(QObject):
    def __init__(
        self,
        view: QAbstractItemView,
        *,
        on_copied: Callable[[], None] | None = None,
    ) -> None:
        super().__init__(view)
        self._table_view = view
        self._viewport = view.viewport()
        self._on_copied = on_copied

    def eventFilter(self, watched, event) -> bool:  # noqa: N802
        viewport = getattr(self, "_viewport", None)
        table_view = getattr(self, "_table_view", None)
        if viewport is None or table_view is None:
            return False
        if watched is not viewport:
            return False
        if not _qt_is_valid(table_view):
            return False
        if event.type() != QEvent.Type.MouseButtonDblClick:
            return False
        if not isinstance(event, QMouseEvent):
            return False
        if event.button() != Qt.MouseButton.LeftButton:
            return False
        index = table_view.indexAt(_mouse_event_pos(event))
        if copy_view_cell(table_view, index) is None:
            return False
        if self._on_copied is not None:
            self._on_copied()
        event.accept()
        return True


def install_table_copy_shortcut(view: QAbstractItemView) -> None:
    shortcut = QShortcut(QKeySequence.StandardKey.Copy, view)
    shortcut.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
    shortcut.activated.connect(lambda: copy_view_selection(view))


def install_table_double_click_copy(
    view: QAbstractItemView,
    *,
    on_copied: Callable[[], None] | None = None,
) -> None:
    copy_filter = _TableDoubleClickCopyFilter(view, on_copied=on_copied)
    view.viewport().installEventFilter(copy_filter)
    view._table_copy_filter = copy_filter  # type: ignore[attr-defined]
