"""Ordenación del grid en tab QA — asc/desc y por estado de validación."""
from __future__ import annotations

from enum import IntEnum

from PySide6.QtCore import Qt

CELL_GREEN = 0
CELL_RED = 1
CELL_NEUTRAL = 2


class QaGridSortMode(IntEnum):
    ASCENDING = 0
    DESCENDING = 1
    GREEN_RED_NEUTRAL = 2
    RED_GREEN_NEUTRAL = 3

    def next_mode(self) -> QaGridSortMode:
        return QaGridSortMode((int(self) + 1) % 4)


def validation_cell_bucket(
    *,
    in_passed: bool,
    in_failed: bool,
    in_conflict: bool,
) -> int:
    """0=verde, 1=rojo (fallo o discrepancia), 2=neutro."""
    if in_failed or in_conflict:
        return CELL_RED
    if in_passed:
        return CELL_GREEN
    return CELL_NEUTRAL


def status_rank(bucket: int, mode: QaGridSortMode) -> int:
    if mode == QaGridSortMode.GREEN_RED_NEUTRAL:
        order = (CELL_GREEN, CELL_RED, CELL_NEUTRAL)
    elif mode == QaGridSortMode.RED_GREEN_NEUTRAL:
        order = (CELL_RED, CELL_GREEN, CELL_NEUTRAL)
    else:
        return bucket
    return order.index(bucket)


def text_sort_key(text: str, mode: QaGridSortMode) -> tuple:
    fold = text.casefold()
    if mode == QaGridSortMode.ASCENDING:
        return (0, fold, text)
    if mode == QaGridSortMode.DESCENDING:
        return (0, _desc_key(fold), text)
    return (0, fold, text)


def validation_sort_key(
    *,
    bucket: int,
    text: str,
    mode: QaGridSortMode,
) -> tuple:
    fold = text.casefold()
    return (status_rank(bucket, mode), fold, text)


def _desc_key(fold: str) -> str:
    return "".join(chr(0xFFFF - ord(ch)) if ord(ch) <= 0xFFFF else ch for ch in fold)


def sort_indicator(mode: QaGridSortMode) -> Qt.SortOrder | None:
    if mode == QaGridSortMode.ASCENDING:
        return Qt.SortOrder.AscendingOrder
    if mode == QaGridSortMode.DESCENDING:
        return Qt.SortOrder.DescendingOrder
    return None
