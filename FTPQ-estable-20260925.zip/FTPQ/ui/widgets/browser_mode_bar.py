"""Barra modo navegador — SFTP / SFTP+local / local×2 + Compare."""
from __future__ import annotations

from enum import Enum

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFrame, QHBoxLayout, QPushButton, QWidget

from ui.i18n import tr


class BrowserLayoutMode(str, Enum):
    SFTP_ONLY = "sftp_only"
    SFTP_LOCAL = "sftp_local"
    LOCAL_LOCAL = "local_local"


class BrowserModeBar(QFrame):
    mode_changed = Signal(object)
    compare_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("browserModeBar")
        self._mode = BrowserLayoutMode.SFTP_LOCAL

        self._sftp = QPushButton()
        self._sftp_local = QPushButton()
        self._local_local = QPushButton()
        self._compare = QPushButton()
        self._compare.setEnabled(False)

        for button in (self._sftp, self._sftp_local, self._local_local):
            button.setCheckable(True)

        self._sftp.clicked.connect(lambda: self._set_mode(BrowserLayoutMode.SFTP_ONLY))
        self._sftp_local.clicked.connect(lambda: self._set_mode(BrowserLayoutMode.SFTP_LOCAL))
        self._local_local.clicked.connect(lambda: self._set_mode(BrowserLayoutMode.LOCAL_LOCAL))
        self._compare.clicked.connect(self.compare_requested.emit)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(6)
        layout.addWidget(self._sftp)
        layout.addWidget(self._sftp_local)
        layout.addWidget(self._local_local)
        layout.addStretch(1)
        layout.addWidget(self._compare)
        self.retranslate_ui()
        self._sync_checks()

    def retranslate_ui(self) -> None:
        self._sftp.setText(tr("browser.mode.sftp"))
        self._sftp_local.setText(tr("browser.mode.sftp_local"))
        self._local_local.setText(tr("browser.mode.local_local"))
        self._compare.setText(tr("compare.action"))

    @property
    def mode(self) -> BrowserLayoutMode:
        return self._mode

    def set_compare_enabled(self, enabled: bool) -> None:
        self._compare.setEnabled(enabled)

    def _set_mode(self, mode: BrowserLayoutMode) -> None:
        self._mode = mode
        self._sync_checks()
        self.mode_changed.emit(mode)

    def _sync_checks(self) -> None:
        self._sftp.setChecked(self._mode is BrowserLayoutMode.SFTP_ONLY)
        self._sftp_local.setChecked(self._mode is BrowserLayoutMode.SFTP_LOCAL)
        self._local_local.setChecked(self._mode is BrowserLayoutMode.LOCAL_LOCAL)
