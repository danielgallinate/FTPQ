"""Pintado de resaltados — el QSS global no respeta BackgroundRole en celdas/cabeceras."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal, QRect
from PySide6.QtGui import QBrush, QColor, QPainter
from PySide6.QtWidgets import QHeaderView, QStyledItemDelegate, QStyleOptionViewItem

from ui.widgets.highlight_palette import PALETTE_FOREGROUND


class TabularHighlightDelegate(QStyledItemDelegate):
    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index) -> None:
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)

        bg = index.data(Qt.ItemDataRole.BackgroundRole)
        if isinstance(bg, QBrush) and bg.style() != Qt.BrushStyle.NoBrush:
            fg = index.data(Qt.ItemDataRole.ForegroundRole)
            text = index.data(Qt.ItemDataRole.DisplayRole)
            painter.save()
            painter.fillRect(opt.rect, bg)
            painter.setPen(
                fg if isinstance(fg, QColor) else QColor(PALETTE_FOREGROUND)
            )
            painter.drawText(
                opt.rect.adjusted(8, 0, 8, 0),
                int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft),
                "" if text is None else str(text),
            )
            painter.restore()
            return

        super().paint(painter, opt, index)


class _HighlightHeaderView(QHeaderView):
    """Cabecera que pinta fondo de columna/fila cuando el modelo lo indica."""

    def _header_text_color(self, model, logical_index: int) -> QColor:
        fg = model.headerData(
            logical_index,
            self.orientation(),
            Qt.ItemDataRole.ForegroundRole,
        )
        if isinstance(fg, QColor):
            return fg
        return self.palette().color(self.foregroundRole())

    def paintSection(self, painter: QPainter, rect, logical_index: int) -> None:
        model = self.model()
        if model is None:
            super().paintSection(painter, rect, logical_index)
            return

        bg = model.headerData(
            logical_index,
            self.orientation(),
            Qt.ItemDataRole.BackgroundRole,
        )
        if not isinstance(bg, QBrush) or bg.style() == Qt.BrushStyle.NoBrush:
            super().paintSection(painter, rect, logical_index)
            return

        text = model.headerData(
            logical_index,
            self.orientation(),
            Qt.ItemDataRole.DisplayRole,
        )

        painter.save()
        painter.fillRect(rect, bg)
        painter.setPen(self._header_text_color(model, logical_index))
        align = int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
        text_rect = rect.adjusted(8, 0, -4, 0)
        if self.orientation() == Qt.Orientation.Vertical:
            align = int(Qt.AlignmentFlag.AlignCenter)
            text_rect = rect.adjusted(2, 0, 2, 0)
        painter.drawText(text_rect, align, "" if text is None else str(text))
        painter.restore()


class HighlightHorizontalHeaderView(_HighlightHeaderView):
    def __init__(self, parent=None) -> None:
        super().__init__(Qt.Orientation.Horizontal, parent)


class HighlightVerticalHeaderView(_HighlightHeaderView):
    row_add_requested = Signal(int)

    def __init__(self, parent=None) -> None:
        super().__init__(Qt.Orientation.Vertical, parent)
        self._build_actions_enabled = False
        self._add_button_width = 22
        self.setDefaultSectionSize(24)

    def set_build_actions_enabled(self, enabled: bool) -> None:
        self._build_actions_enabled = enabled
        self.setDefaultSectionSize(32 if enabled else 24)
        self.viewport().update()

    def paintSection(self, painter: QPainter, rect, logical_index: int) -> None:
        model = self.model()
        if model is None:
            super().paintSection(painter, rect, logical_index)
            return

        bg = model.headerData(
            logical_index,
            self.orientation(),
            Qt.ItemDataRole.BackgroundRole,
        )
        has_custom_bg = isinstance(bg, QBrush) and bg.style() != Qt.BrushStyle.NoBrush
        if has_custom_bg:
            super().paintSection(painter, rect, logical_index)
        else:
            painter.save()
            painter.fillRect(rect, self.palette().window())
            painter.restore()

        text = model.headerData(
            logical_index,
            self.orientation(),
            Qt.ItemDataRole.DisplayRole,
        )
        label = "" if text is None else str(text)
        painter.save()
        painter.setPen(self._header_text_color(model, logical_index))
        number_rect = rect.adjusted(2, 0, -(self._add_button_width + 2 if self._build_actions_enabled else 2), 0)
        painter.drawText(
            number_rect,
            int(Qt.AlignmentFlag.AlignCenter),
            label,
        )
        if self._build_actions_enabled:
            add_rect = rect.adjusted(rect.width() - self._add_button_width, 2, -2, -2)
            painter.fillRect(add_rect, QColor("#d8e8ff"))
            painter.drawText(
                add_rect,
                int(Qt.AlignmentFlag.AlignCenter),
                "+",
            )
        painter.restore()

    def mousePressEvent(self, event) -> None:
        if self._build_actions_enabled and event.button() == Qt.MouseButton.LeftButton:
            pos = event.position().toPoint() if hasattr(event, "position") else event.pos()
            logical_index = self.logicalIndexAt(pos)
            if logical_index >= 0:
                section_rect = self._section_rect(logical_index)
                add_rect = section_rect.adjusted(
                    section_rect.width() - self._add_button_width,
                    0,
                    0,
                    0,
                )
                if add_rect.contains(pos):
                    self.row_add_requested.emit(logical_index)
                    event.accept()
                    return
        super().mousePressEvent(event)

    def _section_rect(self, logical_index: int) -> QRect:
        top = self.sectionViewportPosition(logical_index)
        return QRect(0, top, self.width(), self.sectionSize(logical_index))
