"""Widgets reutilizables de UI."""
