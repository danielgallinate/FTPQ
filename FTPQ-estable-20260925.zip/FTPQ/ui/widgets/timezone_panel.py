"""Pestaña sidebar — conversión de zona horaria."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from core.timezone_transform import (
    TimezoneTransformConfig,
    UTC_NAME,
    common_timezone_options,
    default_target_timezone,
)
from ui.i18n import tr


class TimezonePanel(QFrame):
    apply_requested = Signal()
    config_changed = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("timezonePanel")
        self.setFrameShape(QFrame.Shape.NoFrame)
        self._column_checks: dict[str, QCheckBox] = {}
        self._sync_blocked = False

        self._hint = QLabel()
        self._hint.setObjectName("configHint")
        self._hint.setWordWrap(True)

        self._source_label = QLabel()
        self._source_label.setObjectName("panelSubtitle")
        self._source_combo = QComboBox()
        self._source_combo.setObjectName("configField")
        self._source_combo.currentTextChanged.connect(self._emit_config_changed)

        self._target_label = QLabel()
        self._target_label.setObjectName("panelSubtitle")
        self._target_combo = QComboBox()
        self._target_combo.setObjectName("configField")
        self._target_combo.currentTextChanged.connect(self._emit_config_changed)

        self._columns_label = QLabel()
        self._columns_label.setObjectName("panelSubtitle")

        self._select_detected = QPushButton()
        self._select_detected.clicked.connect(self._select_detected_columns)
        self._select_none = QPushButton()
        self._select_none.clicked.connect(self._select_no_columns)

        column_actions = QHBoxLayout()
        column_actions.setContentsMargins(0, 0, 0, 0)
        column_actions.addWidget(self._select_detected)
        column_actions.addWidget(self._select_none)
        column_actions.addStretch(1)

        self._column_host = QWidget()
        self._column_layout = QVBoxLayout(self._column_host)
        self._column_layout.setContentsMargins(4, 4, 4, 4)
        self._column_layout.setSpacing(4)

        self._column_scroll = QScrollArea()
        self._column_scroll.setWidgetResizable(True)
        self._column_scroll.setWidget(self._column_host)
        self._column_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._column_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self._status = QLabel()
        self._status.setObjectName("configHint")
        self._status.setWordWrap(True)

        self._apply = QPushButton()
        self._apply.clicked.connect(self.apply_requested.emit)
        self._clear = QPushButton()
        self._clear.clicked.connect(self._on_clear)

        actions = QHBoxLayout()
        actions.setContentsMargins(0, 0, 0, 0)
        actions.addWidget(self._apply)
        actions.addWidget(self._clear)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        layout.addWidget(self._hint)
        layout.addWidget(self._source_label)
        layout.addWidget(self._source_combo)
        layout.addWidget(self._target_label)
        layout.addWidget(self._target_combo)
        layout.addWidget(self._columns_label)
        layout.addLayout(column_actions)
        layout.addWidget(self._column_scroll, stretch=1)
        layout.addWidget(self._status)
        layout.addLayout(actions)

        self._populate_timezone_combos()
        self.retranslate_ui()

    def _populate_timezone_combos(self) -> None:
        names = common_timezone_options()
        for combo, default in (
            (self._source_combo, UTC_NAME),
            (self._target_combo, default_target_timezone()),
        ):
            combo.blockSignals(True)
            combo.clear()
            combo.addItems(names)
            index = combo.findText(default)
            combo.setCurrentIndex(index if index >= 0 else 0)
            combo.blockSignals(False)

    def retranslate_ui(self) -> None:
        self._hint.setText(tr("viewer.timezone.hint"))
        self._source_label.setText(tr("viewer.timezone.source"))
        self._target_label.setText(tr("viewer.timezone.target"))
        self._columns_label.setText(tr("viewer.timezone.columns"))
        self._select_detected.setText(tr("viewer.timezone.select_detected"))
        self._select_none.setText(tr("viewer.timezone.select_none"))
        self._apply.setText(tr("viewer.timezone.apply"))
        self._clear.setText(tr("viewer.timezone.clear"))
        self._refresh_status()

    def set_columns(
        self,
        column_names: list[str],
        *,
        suggested: list[str] | None = None,
        selected: set[str] | None = None,
    ) -> None:
        suggested_set = set(suggested or [])
        selected_set = set(selected if selected is not None else suggested_set)
        while self._column_layout.count():
            item = self._column_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._column_checks.clear()
        self._sync_blocked = True
        for name in column_names:
            box = QCheckBox(name)
            box.setChecked(name in selected_set)
            if name in suggested_set:
                box.setToolTip(tr("viewer.timezone.detected_hint"))
            box.toggled.connect(self._emit_config_changed)
            self._column_layout.addWidget(box)
            self._column_checks[name] = box
        self._column_layout.addStretch(1)
        self._sync_blocked = False
        self._refresh_status()

    def config(self) -> TimezoneTransformConfig:
        columns = frozenset(
            name for name, box in self._column_checks.items() if box.isChecked()
        )
        return TimezoneTransformConfig(
            source_tz=self._source_combo.currentText().strip() or UTC_NAME,
            target_tz=self._target_combo.currentText().strip() or UTC_NAME,
            columns=columns,
        )

    def set_column_selected(self, column_name: str, selected: bool) -> None:
        box = self._column_checks.get(column_name)
        if box is None:
            return
        box.setChecked(selected)

    def toggle_column_selected(self, column_name: str) -> bool:
        box = self._column_checks.get(column_name)
        if box is None:
            return False
        box.setChecked(not box.isChecked())
        return box.isChecked()

    def is_transform_active(self) -> bool:
        return self.config().is_active

    def _select_detected_columns(self) -> None:
        for name, box in self._column_checks.items():
            if box.toolTip():
                box.setChecked(True)

    def _select_no_columns(self) -> None:
        for box in self._column_checks.values():
            box.setChecked(False)

    def _on_clear(self) -> None:
        for box in self._column_checks.values():
            box.setChecked(False)
        self._refresh_status()
        self.apply_requested.emit()

    def _emit_config_changed(self) -> None:
        if self._sync_blocked:
            return
        self._refresh_status()
        self.config_changed.emit()

    def _refresh_status(self) -> None:
        cfg = self.config()
        if not cfg.columns:
            self._status.setText(tr("viewer.timezone.status_idle"))
            return
        self._status.setText(
            tr(
                "viewer.timezone.status_ready",
                source=cfg.source_tz,
                target=cfg.target_tz,
                count=len(cfg.columns),
            )
        )
