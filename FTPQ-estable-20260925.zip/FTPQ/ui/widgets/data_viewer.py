"""Visualizador tabular pantalla completa — sidebar columnas + tabla."""
from __future__ import annotations

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QIntValidator
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMenu,
    QPushButton,
    QScrollArea,
    QSplitter,
    QTabWidget,
    QTableView,
    QTextEdit,
    QVBoxLayout,
    QWidget,
    QWidgetAction,
)

from core.analysis_limits import (
    MANAGEABLE_CELL_BUDGET,
    REFERENCE_COLUMN_COUNT,
    SAMPLE_ROW_MIN,
    ReloadRowChoice,
    estimate_cell_volume,
    exceeds_manageable_volume,
    parse_reload_row_input,
    reload_row_choices,
    should_offer_row_reload,
)
from core.analysis_types import ColumnSummary, TabularDataset
from ui.i18n import tr
from ui.widgets.table_clipboard import (
    copy_view_cell,
    install_table_copy_shortcut,
    install_table_double_click_copy,
)
from ui.widgets.highlight_delegate import (
    HighlightHorizontalHeaderView,
    HighlightVerticalHeaderView,
    TabularHighlightDelegate,
)
from ui.widgets.highlight_palette import PALETTE_SIZE, palette_label, palette_text_stylesheet
from ui.widgets.qa_grid_sort import QaGridSortMode, sort_indicator
from ui.widgets.tabular_table_model import TabularTableModel
from ui.widgets.timezone_panel import TimezonePanel

_SIDEBAR_WIDTH = 240


def _format_file_size(size_bytes: int) -> str:
    if size_bytes >= 1_048_576:
        return f"{size_bytes / 1_048_576:.1f} MB"
    if size_bytes >= 1024:
        return f"{size_bytes / 1024:.1f} KB"
    return f"{size_bytes} B"


def _format_header(
    filename: str,
    dataset: TabularDataset,
    file_size_bytes: int,
) -> str:
    trunc = tr("viewer.truncated") if dataset.display_truncated else ""
    if dataset.sampled:
        trunc += tr("viewer.sampled")
    return tr(
        "viewer.header",
        filename=filename,
        rows=f"{dataset.total_rows:,}",
        cols=len(dataset.columns),
        size=_format_file_size(file_size_bytes),
        trunc=trunc,
    )


class DataViewerWidget(QFrame):
    close_requested = Signal()
    columns_visibility_changed = Signal()
    row_add_requested = Signal(int)
    add_all_requested = Signal()
    reload_requested = Signal(int)
    timezone_apply_requested = Signal()
    catalog_column_requested = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("dataViewerPanel")
        self.setFrameShape(QFrame.Shape.NoFrame)

        self._dataset: TabularDataset | None = None
        self._loaded_filename = ""
        self._loaded_size: int | None = None
        self._column_checks: list[QCheckBox] = []
        self._column_sync_blocked = False
        self._sort_source_column: int | None = None
        self._sort_order = Qt.SortOrder.AscendingOrder
        self._qa_header_sort = False
        self._qa_sort_mode = QaGridSortMode.ASCENDING
        self._catalog_menu_enabled = False
        self._dedup_key_column_indices: list[int] = []
        self._load_total_rows = 0
        self._load_column_count = 0
        self._load_current_limit = 0

        self._close = QPushButton()
        self._close.setObjectName("closeDataViewer")
        self._close.clicked.connect(self.close_requested.emit)

        self._header = QLabel("")
        self._header.setObjectName("panelTitle")
        self._header.setWordWrap(True)

        self._load_bar = QFrame()
        self._load_bar.setObjectName("loadBar")
        load_layout = QVBoxLayout(self._load_bar)
        load_layout.setContentsMargins(8, 6, 8, 6)
        load_layout.setSpacing(4)

        self._load_title = QLabel()
        self._load_title.setObjectName("panelSubtitle")

        self._load_status = QLabel()
        self._load_status.setObjectName("configHint")
        self._load_status.setWordWrap(True)

        self._load_hint = QLabel()
        self._load_hint.setObjectName("configHint")
        self._load_hint.setWordWrap(True)

        load_controls = QHBoxLayout()
        load_controls.setContentsMargins(0, 0, 0, 0)
        load_controls.setSpacing(6)
        self._load_rows_label = QLabel()
        self._load_rows_combo = QComboBox()
        self._load_rows_combo.setObjectName("configField")
        self._load_rows_combo.setEditable(True)
        self._load_row_validator = QIntValidator(SAMPLE_ROW_MIN, 999_999_999, self)
        line_edit = self._load_rows_combo.lineEdit()
        if line_edit is not None:
            line_edit.setValidator(self._load_row_validator)
            line_edit.textChanged.connect(self._on_load_text_changed)
        self._load_rows_combo.currentIndexChanged.connect(self._on_load_preset_changed)
        self._load_btn = QPushButton()
        self._load_btn.clicked.connect(self._on_load_clicked)
        load_controls.addWidget(self._load_rows_label)
        load_controls.addWidget(self._load_rows_combo, stretch=1)
        load_controls.addWidget(self._load_btn)

        load_layout.addWidget(self._load_title)
        load_layout.addWidget(self._load_status)
        load_layout.addWidget(self._load_hint)
        load_layout.addLayout(load_controls)
        self._load_bar.hide()

        top_bar = QHBoxLayout()
        top_bar.setContentsMargins(8, 6, 8, 6)
        top_bar.addWidget(self._header, stretch=1)
        top_bar.addWidget(self._close)

        self._columns_label = QLabel()
        self._columns_label.setObjectName("panelSubtitle")

        self._column_filter = QLineEdit()
        self._column_filter.setObjectName("configField")
        self._column_filter.textChanged.connect(self._apply_column_filter)

        self._select_all = QPushButton()
        self._select_none = QPushButton()
        self._select_all.clicked.connect(self._select_all_columns)
        self._select_none.clicked.connect(self._select_no_columns)

        column_actions = QHBoxLayout()
        column_actions.setContentsMargins(0, 0, 0, 0)
        column_actions.addWidget(self._select_all)
        column_actions.addWidget(self._select_none)
        column_actions.addStretch(1)

        self._columns_hint = QLabel()
        self._columns_hint.setObjectName("configHint")
        self._columns_hint.setWordWrap(True)

        self._column_host = QWidget()
        self._column_layout = QVBoxLayout(self._column_host)
        self._column_layout.setContentsMargins(4, 4, 4, 4)
        self._column_layout.setSpacing(4)

        self._column_scroll = QScrollArea()
        self._column_scroll.setWidgetResizable(True)
        self._column_scroll.setWidget(self._column_host)
        self._column_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._column_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )

        self._stats_label = QLabel()
        self._stats_label.setObjectName("panelSubtitle")

        self._stats = QTextEdit()
        self._stats.setObjectName("dataViewerStats")
        self._stats.setReadOnly(True)
        self._stats.setFrameShape(QFrame.Shape.StyledPanel)

        self._rows_view_label = QLabel()
        self._rows_view_label.setObjectName("panelSubtitle")

        self._unique_rows = QCheckBox()
        self._unique_rows.toggled.connect(self._on_unique_rows_toggled)

        self._unique_rows_hint = QLabel()
        self._unique_rows_hint.setObjectName("configHint")
        self._unique_rows_hint.setWordWrap(True)

        columns_page = QWidget()
        columns_layout = QVBoxLayout(columns_page)
        columns_layout.setContentsMargins(0, 0, 0, 0)
        columns_layout.setSpacing(6)
        columns_layout.addWidget(self._columns_label)
        columns_layout.addWidget(self._column_filter)
        columns_layout.addLayout(column_actions)
        columns_layout.addWidget(self._columns_hint)
        columns_layout.addWidget(self._column_scroll, stretch=1)
        columns_layout.addWidget(self._stats_label)
        columns_layout.addWidget(self._stats)
        columns_layout.addWidget(self._rows_view_label)
        columns_layout.addWidget(self._unique_rows)
        columns_layout.addWidget(self._unique_rows_hint)

        self._timezone_panel = TimezonePanel()
        self._timezone_panel.apply_requested.connect(self.timezone_apply_requested.emit)
        self._timezone_panel.config_changed.connect(self._on_timezone_config_changed)

        self._sidebar_tabs = QTabWidget()
        self._sidebar_tabs.setObjectName("dataViewerSidebarTabs")
        self._sidebar_tabs.addTab(columns_page, "")
        self._sidebar_tabs.addTab(self._timezone_panel, "")

        sidebar = QFrame()
        sidebar.setObjectName("dataViewerSidebar")
        sidebar.setFrameShape(QFrame.Shape.StyledPanel)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(8, 8, 8, 8)
        sidebar_layout.setSpacing(6)
        sidebar_layout.addWidget(self._sidebar_tabs)
        sidebar.setMinimumWidth(_SIDEBAR_WIDTH)
        sidebar.setMaximumWidth(320)
        self._sidebar = sidebar

        self._model = TabularTableModel()
        self._table = QTableView()
        self._table.setObjectName("dataTable")
        self._table.setModel(self._model)
        self._table.setItemDelegate(TabularHighlightDelegate(self._table))
        self._table.setAlternatingRowColors(True)
        self._table.setSortingEnabled(False)
        self._table.setShowGrid(True)
        self._table.setGridStyle(Qt.PenStyle.SolidLine)
        self._table.setSelectionBehavior(QTableView.SelectionBehavior.SelectItems)
        self._table.setSelectionMode(QTableView.SelectionMode.ExtendedSelection)
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self._copy_toast = QLabel(self._table.viewport())
        self._copy_toast.setObjectName("copyToast")
        self._copy_toast.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._copy_toast.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._copy_toast.hide()
        self._copy_toast_timer = QTimer(self)
        self._copy_toast_timer.setSingleShot(True)
        self._copy_toast_timer.timeout.connect(self._copy_toast.hide)
        header = HighlightHorizontalHeaderView(self._table)
        self._table.setHorizontalHeader(header)
        header.setStretchLastSection(True)
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setSortIndicatorShown(True)
        header.setSectionsClickable(True)
        header.setSectionsMovable(True)
        header.setSortIndicator(-1, Qt.SortOrder.AscendingOrder)
        header.sectionClicked.connect(self._on_header_section_clicked)
        header.sectionMoved.connect(self._on_header_section_moved)
        header.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        header.customContextMenuRequested.connect(self._on_header_context_menu)
        header.setDefaultSectionSize(120)
        vheader = HighlightVerticalHeaderView(self._table)
        self._vheader = vheader
        self._table.setVerticalHeader(vheader)
        vheader.setDefaultSectionSize(24)
        vheader.setVisible(True)
        vheader.row_add_requested.connect(self.row_add_requested.emit)
        vheader.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        vheader.customContextMenuRequested.connect(self._on_row_header_context_menu)
        self._table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self._table.customContextMenuRequested.connect(self._on_table_context_menu)
        selection = self._table.selectionModel()
        if selection is not None:
            selection.currentChanged.connect(self._on_cell_selection_changed)
        install_table_copy_shortcut(self._table)
        install_table_double_click_copy(self._table, on_copied=self._show_copy_toast)

        self._build_bar = QWidget()
        self._build_bar.setObjectName("buildBar")
        build_layout = QHBoxLayout(self._build_bar)
        build_layout.setContentsMargins(8, 4, 8, 4)
        build_layout.setSpacing(6)
        self._mark_rows_btn = QPushButton()
        self._mark_rows_btn.clicked.connect(self._on_toggle_mark_selected_rows)
        self._clear_marks_btn = QPushButton()
        self._clear_marks_btn.clicked.connect(self._on_clear_marks)
        self._dedup_grid_btn = QPushButton()
        self._dedup_grid_btn.clicked.connect(self._on_remove_duplicate_rows)
        self._add_all_btn = QPushButton()
        self._add_all_btn.clicked.connect(self.add_all_requested.emit)
        build_layout.addWidget(self._mark_rows_btn)
        build_layout.addWidget(self._clear_marks_btn)
        build_layout.addWidget(self._dedup_grid_btn)
        build_layout.addWidget(self._add_all_btn)
        build_layout.addStretch(1)
        self._build_hint = QLabel()
        self._build_hint.setObjectName("configHint")
        build_layout.addWidget(self._build_hint)
        self._build_bar.hide()

        body_split = QSplitter(Qt.Orientation.Horizontal)
        body_split.addWidget(sidebar)
        body_split.addWidget(self._table)
        body_split.setStretchFactor(0, 0)
        body_split.setStretchFactor(1, 1)
        body_split.setSizes([_SIDEBAR_WIDTH, 800])
        body_split.setCollapsible(0, False)
        body_split.setCollapsible(1, False)
        self._body_split = body_split
        self._sidebar_embedded = True

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addLayout(top_bar)
        layout.addWidget(self._load_bar)
        layout.addWidget(self._build_bar)
        layout.addWidget(body_split, stretch=1)

        self.retranslate_ui()

    @property
    def table_model(self) -> TabularTableModel:
        return self._model

    @property
    def table_view(self) -> QTableView:
        return self._table

    def visible_column_indices(self) -> list[int]:
        return [idx for idx, box in enumerate(self._column_checks) if box.isChecked()]

    def sync_column_selection_by_name(self, selected_names: set[str]) -> None:
        if self._dataset is None:
            return
        checked: set[int] = set()
        for index, column in enumerate(self._dataset.columns):
            if column.name in selected_names:
                checked.add(index)
        if not checked:
            checked.add(0)
        self._apply_column_check_state(checked)

    def set_qa_header_sort(self, enabled: bool) -> None:
        if self._qa_header_sort == enabled:
            return
        self._qa_header_sort = enabled
        if enabled:
            self._qa_sort_mode = QaGridSortMode.ASCENDING
        elif self._sort_source_column is not None:
            self._apply_sort_if_active()

    def set_catalog_column_menu_enabled(self, enabled: bool) -> None:
        self._catalog_menu_enabled = enabled

    def set_sidebar_visible(self, visible: bool) -> None:
        self._sidebar.setVisible(visible)

    def sidebar_widget(self) -> QFrame:
        return self._sidebar

    def set_sidebar_embedded(self, embedded: bool) -> None:
        if embedded == self._sidebar_embedded:
            return
        self._sidebar_embedded = embedded
        if embedded:
            if self._body_split.indexOf(self._sidebar) < 0:
                self._body_split.insertWidget(0, self._sidebar)
                self._body_split.setStretchFactor(0, 0)
                self._body_split.setStretchFactor(1, 1)
            self._sidebar.show()
            return
        if self._body_split.indexOf(self._sidebar) >= 0:
            self._sidebar.setParent(None)

    def apply_validation_overlay(
        self,
        *,
        evaluated_columns: set[str],
        passed_cells: set[tuple[int, int]],
        failed_cells: set[tuple[int, int]] | None = None,
        conflict_cells: set[tuple[int, int]] | None = None,
        gray_cells: set[tuple[int, int]] | None = None,
        gray_unevaluated: bool,
        cell_tooltips: dict[tuple[int, int], str] | None = None,
    ) -> None:
        self._model.apply_validation_overlay(
            evaluated_columns=evaluated_columns,
            passed_cells=passed_cells,
            failed_cells=failed_cells,
            conflict_cells=conflict_cells,
            gray_cells=gray_cells,
            gray_unevaluated=gray_unevaluated,
            cell_tooltips=cell_tooltips,
        )

    def clear_validation_overlay(self) -> None:
        self._model.clear_validation_overlay()

    def apply_catalog_displays(
        self,
        displays: dict[tuple[int, int], str],
        misses: set[tuple[int, int]],
        bound_columns: set[int],
    ) -> None:
        self._model.set_catalog_displays(displays, misses, bound_columns)

    def clear_catalog_displays(self) -> None:
        self._model.clear_catalog_displays()

    def set_build_mode(self, enabled: bool, *, key_column_names: list[str] | None = None) -> None:
        self._model.set_build_mode(enabled)
        self._vheader.set_build_actions_enabled(enabled)
        self._dedup_key_column_indices = []
        if enabled and self._dataset is not None and key_column_names:
            name_to_index = {
                column.name: idx for idx, column in enumerate(self._dataset.columns)
            }
            self._dedup_key_column_indices = [
                name_to_index[name] for name in key_column_names if name in name_to_index
            ]
        self._build_bar.setVisible(enabled)
        if enabled:
            self.clear_validation_overlay()
            self._refresh_build_hint()

    def marked_source_rows(self) -> set[int]:
        return self._model.marked_source_rows()

    def toggle_mark_selected_rows(self) -> int:
        selection = self._table.selectionModel()
        if selection is None:
            return 0
        toggled = 0
        seen_rows: set[int] = set()
        for index in selection.selectedIndexes():
            source_row = self._model.source_row_at(index.row())
            if source_row is None or source_row in seen_rows:
                continue
            seen_rows.add(source_row)
            self._model.toggle_mark_source_row(source_row)
            toggled += 1
        self._refresh_build_hint()
        return toggled

    def clear_marked_rows(self) -> None:
        self._model.clear_marked_rows()
        self._refresh_build_hint()

    def remove_duplicate_rows(self) -> int:
        removed = self._model.remove_duplicate_rows(self._dedup_key_column_indices)
        self._refresh_build_hint()
        return removed

    def _refresh_build_hint(self) -> None:
        marked = len(self._model.marked_source_rows())
        self._build_hint.setText(tr("viewer.build.marked_count", count=marked))

    def _on_toggle_mark_selected_rows(self) -> None:
        if self.toggle_mark_selected_rows() == 0:
            self._build_hint.setText(tr("viewer.build.select_rows"))

    def _on_clear_marks(self) -> None:
        self.clear_marked_rows()

    def _on_remove_duplicate_rows(self) -> None:
        if not self._dedup_key_column_indices:
            self._build_hint.setText(tr("viewer.build.no_key"))
            return
        removed = self.remove_duplicate_rows()
        if removed == 0:
            self._build_hint.setText(tr("viewer.build.no_duplicates"))
        else:
            self._build_hint.setText(tr("viewer.build.duplicates_removed", count=removed))

    def source_row_at_view_row(self, view_row: int) -> int | None:
        return self._model.source_row_at(view_row)

    def all_visible_source_rows(self) -> set[int]:
        rows: set[int] = set()
        for view_row in range(self._model.rowCount()):
            source_row = self._model.source_row_at(view_row)
            if source_row is not None:
                rows.add(source_row)
        return rows

    def dataset(self) -> TabularDataset | None:
        return self._dataset

    def timezone_config(self):
        return self._timezone_panel.config()

    def setup_timezone_columns(
        self,
        column_names: list[str],
        *,
        suggested: list[str] | None = None,
        selected: set[str] | None = None,
    ) -> None:
        self._timezone_panel.set_columns(
            column_names,
            suggested=suggested,
            selected=selected,
        )

    def refresh_dataset_values(self, dataset: TabularDataset) -> None:
        self._dataset = dataset
        if self._loaded_filename:
            size = self._loaded_size
            if size is None:
                size = dataset.local_path.stat().st_size
            self._loaded_size = size
            self._header.setText(_format_header(self._loaded_filename, dataset, size))
        self._model.set_dataset(dataset)
        self._refresh_column_stats()

    def is_timezone_transform_pending(self) -> bool:
        return self._timezone_panel.is_transform_active()

    def _on_timezone_config_changed(self) -> None:
        return

    def retranslate_ui(self) -> None:
        self._close.setText(tr("action.close"))
        self._columns_label.setText(tr("viewer.columns_visible"))
        self._column_filter.setPlaceholderText(tr("viewer.filter_ph"))
        self._select_all.setText(tr("action.all"))
        self._select_none.setText(tr("action.none"))
        self._columns_hint.setText(tr("viewer.columns_hint"))
        self._stats_label.setText(tr("viewer.column_stats"))
        self._rows_view_label.setText(tr("viewer.rows_view"))
        self._unique_rows.setText(tr("viewer.unique_rows"))
        self._unique_rows_hint.setText(tr("viewer.unique_hint"))
        self._sidebar_tabs.setTabText(0, tr("viewer.tab.columns"))
        self._sidebar_tabs.setTabText(1, tr("viewer.tab.timezone"))
        self._timezone_panel.retranslate_ui()
        self._mark_rows_btn.setText(tr("viewer.build.mark_rows"))
        self._clear_marks_btn.setText(tr("viewer.build.clear_marks"))
        self._dedup_grid_btn.setText(tr("viewer.build.remove_duplicates"))
        self._add_all_btn.setText(tr("viewer.build.add_all"))
        if self._build_bar.isVisible():
            self._refresh_build_hint()
        if self._dataset is not None and self._loaded_filename:
            size = self._loaded_size
            if size is None:
                size = self._dataset.local_path.stat().st_size
            self._header.setText(_format_header(self._loaded_filename, self._dataset, size))
        self._load_title.setText(tr("viewer.load.title"))
        self._load_rows_label.setText(tr("viewer.load.rows_label"))
        self._refresh_load_bar()
        self._refresh_column_stats()

    def configure_load_limits(
        self,
        *,
        total_rows: int,
        column_count: int,
        current_limit: int,
    ) -> None:
        self._load_total_rows = max(total_rows, 0)
        self._load_column_count = max(column_count, 0)
        self._load_current_limit = max(current_limit, 0)
        self._refresh_load_bar()

    def _refresh_load_bar(self) -> None:
        dataset = self._dataset
        if dataset is None or self._load_total_rows <= 0:
            self._load_bar.hide()
            return

        shown = len(dataset.rows)
        if not should_offer_row_reload(self._load_total_rows, shown):
            self._load_bar.hide()
            return

        truncated = shown < self._load_total_rows
        self._load_bar.show()
        if truncated:
            self._load_title.setText(tr("viewer.load.title"))
            self._load_rows_label.setText(tr("viewer.load.rows_label"))
            volume = estimate_cell_volume(shown, self._load_column_count)
            self._load_status.setText(
                tr(
                    "viewer.load.status",
                    shown=f"{shown:,}",
                    total=f"{self._load_total_rows:,}",
                    cols=self._load_column_count,
                    volume=f"{volume:,}",
                    ref_cols=REFERENCE_COLUMN_COUNT,
                )
            )
        else:
            self._load_title.setText(tr("viewer.load.sample_title"))
            self._load_rows_label.setText(tr("viewer.load.sample_rows_label"))
            self._load_status.setText(
                tr(
                    "viewer.load.sample_status",
                    shown=f"{shown:,}",
                    total=f"{self._load_total_rows:,}",
                    cols=self._load_column_count,
                )
            )

        self._load_rows_combo.blockSignals(True)
        self._load_rows_combo.clear()
        self._load_row_validator.setTop(max(self._load_total_rows, SAMPLE_ROW_MIN))
        line_edit = self._load_rows_combo.lineEdit()
        for choice in reload_row_choices(self._load_total_rows):
            self._load_rows_combo.addItem(self._reload_choice_label(choice), choice.rows)
        target = min(shown, self._load_total_rows)
        idx = self._load_rows_combo.findData(target)
        if idx >= 0:
            self._load_rows_combo.setCurrentIndex(idx)
        else:
            self._load_rows_combo.setCurrentIndex(-1)
            if line_edit is not None:
                line_edit.setText(f"{target:,}")
        self._load_rows_combo.blockSignals(False)
        self._refresh_load_hint(truncated=truncated)

    def _reload_choice_label(self, choice: ReloadRowChoice) -> str:
        rows = f"{choice.rows:,}"
        if choice.kind == "total":
            return tr("viewer.load.option_total", rows=rows)
        if choice.kind == "pct50":
            return tr("viewer.load.option_pct50", rows=rows)
        if choice.kind == "pct10":
            return tr("viewer.load.option_pct10", rows=rows)
        return tr("viewer.load.option_preset", rows=rows)

    def _selected_load_rows(self) -> int | None:
        if self._load_total_rows <= 0:
            return None
        parsed = parse_reload_row_input(
            self._load_rows_combo.currentText(),
            self._load_total_rows,
        )
        if parsed is not None:
            return parsed
        data = self._load_rows_combo.currentData()
        if data is None:
            return None
        return int(data)

    def _refresh_load_hint(self, *, truncated: bool) -> None:
        selected = self._selected_load_rows()
        if selected is None:
            self._load_hint.clear()
            self._load_btn.setEnabled(False)
            return

        shown = len(self._dataset.rows) if self._dataset is not None else 0
        if exceeds_manageable_volume(selected, self._load_column_count):
            self._load_hint.setText(
                tr(
                    "viewer.load.hint_warn",
                    budget=f"{MANAGEABLE_CELL_BUDGET:,}",
                )
            )
            self._load_btn.setText(tr("viewer.load.authorize"))
        elif truncated:
            self._load_hint.setText(
                tr(
                    "viewer.load.hint_ok",
                    budget=f"{MANAGEABLE_CELL_BUDGET:,}",
                )
            )
            self._load_btn.setText(tr("viewer.load.button"))
        else:
            self._load_hint.setText(
                tr(
                    "viewer.load.sample_hint",
                    min=SAMPLE_ROW_MIN,
                )
            )
            self._load_btn.setText(tr("viewer.load.sample_button"))

        self._load_btn.setEnabled(selected != shown)

    def _on_load_text_changed(self, _text: str) -> None:
        dataset = self._dataset
        if dataset is None or self._load_total_rows <= 0:
            return
        shown = len(dataset.rows)
        truncated = shown < self._load_total_rows
        self._refresh_load_hint(truncated=truncated)

    def _on_load_preset_changed(self, _index: int) -> None:
        dataset = self._dataset
        if dataset is None or self._load_total_rows <= 0:
            return
        shown = len(dataset.rows)
        truncated = shown < self._load_total_rows
        self._refresh_load_hint(truncated=truncated)

    def _on_load_clicked(self) -> None:
        selected = self._selected_load_rows()
        if selected is None:
            return
        self.reload_requested.emit(selected)

    def load(
        self,
        dataset: TabularDataset,
        *,
        filename: str,
        file_size_bytes: int | None = None,
    ) -> None:
        self._dataset = dataset
        self._loaded_filename = filename
        size = file_size_bytes
        if size is None:
            size = dataset.local_path.stat().st_size
        self._loaded_size = size
        self._header.setText(_format_header(filename, dataset, size))
        self._unique_rows.setChecked(False)
        self._column_filter.clear()
        self._sort_source_column = None
        self._sort_order = Qt.SortOrder.AscendingOrder
        self._qa_sort_mode = QaGridSortMode.ASCENDING
        self._table.horizontalHeader().setSortIndicator(-1, Qt.SortOrder.AscendingOrder)
        self._rebuild_column_checks()
        self._model.set_dataset(dataset)
        if dataset.columns:
            self._show_column_stats(dataset.columns[0])

    def _rebuild_column_checks(self) -> None:
        while self._column_layout.count():
            item = self._column_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._column_checks.clear()
        if self._dataset is None:
            return
        for index, column in enumerate(self._dataset.columns):
            box = QCheckBox(column.name)
            box.setChecked(True)
            box.toggled.connect(
                lambda checked, idx=index: self._on_column_toggled(idx, checked)
            )
            self._column_layout.addWidget(box)
            self._column_checks.append(box)
        self._column_layout.addStretch(1)
        self._apply_column_filter(self._column_filter.text())

    def _apply_column_filter(self, text: str) -> None:
        needle = text.strip().casefold()
        for box in self._column_checks:
            if not needle:
                box.setVisible(True)
                continue
            box.setVisible(needle in box.text().casefold())

    def _filtered_column_indices(self) -> list[int]:
        needle = self._column_filter.text().strip().casefold()
        if not needle:
            return list(range(len(self._column_checks)))
        return [
            idx
            for idx, box in enumerate(self._column_checks)
            if needle in box.text().casefold()
        ]

    def _apply_column_check_state(self, checked_indices: set[int]) -> None:
        self._column_sync_blocked = True
        try:
            for idx, box in enumerate(self._column_checks):
                box.setChecked(idx in checked_indices)
        finally:
            self._column_sync_blocked = False
        visible = [idx for idx, box in enumerate(self._column_checks) if box.isChecked()]
        if visible:
            self._model.set_visible_columns(visible)
            self._refresh_column_stats()
            self._apply_sort_if_active()
        self.columns_visibility_changed.emit()

    def _on_unique_rows_toggled(self, checked: bool) -> None:
        self._model.set_unique_rows_only(checked)
        self._refresh_column_stats()
        self._apply_sort_if_active()

    def _view_column_for_source(self, source_col: int) -> int | None:
        for view_col in range(self._model.columnCount()):
            if self._model.column_index_at(view_col) == source_col:
                return view_col
        return None

    def _apply_sort_if_active(self) -> None:
        if self._sort_source_column is None:
            return
        view_col = self._view_column_for_source(self._sort_source_column)
        if view_col is None:
            self._sort_source_column = None
            self._table.horizontalHeader().setSortIndicator(-1, Qt.SortOrder.AscendingOrder)
            return
        header = self._table.horizontalHeader()
        if self._qa_header_sort:
            self._model.sort(view_col, qa_mode=self._qa_sort_mode)
            indicator = sort_indicator(self._qa_sort_mode)
            if indicator is None:
                header.setSortIndicatorShown(False)
            else:
                header.setSortIndicatorShown(True)
                header.setSortIndicator(view_col, indicator)
            return
        self._model.sort(view_col, self._sort_order)
        header.setSortIndicatorShown(True)
        header.setSortIndicator(view_col, self._sort_order)

    def _select_all_columns(self) -> None:
        indices = set(self._filtered_column_indices())
        if not indices:
            return
        self._apply_column_check_state(indices)

    def _select_no_columns(self) -> None:
        filtered = self._filtered_column_indices()
        if not filtered:
            return
        self._apply_column_check_state({filtered[0]})

    def _on_column_toggled(self, index: int, checked: bool) -> None:
        if self._column_sync_blocked or self._dataset is None:
            return
        visible = [idx for idx, box in enumerate(self._column_checks) if box.isChecked()]
        if not visible:
            self._column_sync_blocked = True
            try:
                self._column_checks[index].setChecked(True)
            finally:
                self._column_sync_blocked = False
            return
        self._model.set_visible_columns(visible)
        self._refresh_column_stats()
        self._apply_sort_if_active()
        self.columns_visibility_changed.emit()

    def _on_header_section_moved(
        self,
        _logical: int,
        _old_visual: int,
        _new_visual: int,
    ) -> None:
        self._sync_column_order_from_header()

    def _sync_column_order_from_header(self) -> None:
        header = self._table.horizontalHeader()
        ordered: list[int] = []
        for visual in range(header.count()):
            logical = header.logicalIndex(visual)
            source = self._model.column_index_at(logical)
            if source is not None:
                ordered.append(source)
        if ordered:
            self._model.reorder_visible_columns(ordered)
            self._apply_sort_if_active()

    def _append_color_actions(
        self,
        menu: QMenu,
        *,
        on_pick,
        on_clear,
        current: int | None,
    ) -> None:
        colors_menu = menu.addMenu(tr("viewer.color_menu"))
        for index in range(PALETTE_SIZE):
            action = QWidgetAction(colors_menu)
            row = _ColorMenuRow(index, checked=(current == index), parent=colors_menu)
            row.pick_requested.connect(lambda idx=index: on_pick(idx))
            action.setDefaultWidget(row)
            colors_menu.addAction(action)
        menu.addSeparator()
        clear = menu.addAction(tr("viewer.color_clear"))
        clear.setEnabled(current is not None)
        clear.triggered.connect(on_clear)

    def _on_header_context_menu(self, pos) -> None:
        header = self._table.horizontalHeader()
        logical = header.logicalIndexAt(pos)
        if logical < 0:
            return
        source_col = self._model.column_index_at(logical)
        if source_col is None:
            return
        name = self._model.column_name_at(logical) or tr(
            "viewer.col_section", n=source_col + 1
        )
        column_name = self._model.column_name_at(logical) or name
        menu = QMenu(self)
        menu.addSection(name)
        current = self._model.column_highlight(source_col)

        def pick(index: int) -> None:
            self._model.set_column_highlight(source_col, index)

        def clear() -> None:
            self._model.set_column_highlight(source_col, None)

        self._append_color_actions(menu, on_pick=pick, on_clear=clear, current=current)
        menu.addSeparator()
        if self._catalog_menu_enabled:
            catalog_action = menu.addAction(tr("emr.catalog.use_menu"))
            catalog_action.triggered.connect(
                lambda: self.catalog_column_requested.emit(column_name)
            )
            menu.addSeparator()
        toggle_tz = menu.addAction(tr("viewer.timezone.toggle_column"))
        toggle_tz.setCheckable(True)
        toggle_tz.setChecked(column_name in self._timezone_panel.config().columns)
        toggle_tz.toggled.connect(
            lambda checked, col=column_name: self._timezone_panel.set_column_selected(col, checked)
        )
        apply_tz = menu.addAction(tr("viewer.timezone.apply"))
        apply_tz.triggered.connect(self.timezone_apply_requested.emit)
        menu.exec(header.mapToGlobal(pos))

    def _show_row_color_menu(self, source_row: int, global_pos) -> None:
        menu = QMenu(self)
        menu.addSection(tr("viewer.row_section", n=source_row + 1))
        current = self._model.row_highlight(source_row)

        def pick(color_index: int) -> None:
            self._model.set_row_highlight(source_row, color_index)

        def clear() -> None:
            self._model.set_row_highlight(source_row, None)

        self._append_color_actions(menu, on_pick=pick, on_clear=clear, current=current)
        menu.exec(global_pos)

    def _show_copy_toast(self) -> None:
        self._copy_toast.setText(tr("viewer.cell_copied"))
        self._copy_toast.adjustSize()
        viewport = self._table.viewport()
        x = (viewport.width() - self._copy_toast.width()) // 2
        y = viewport.height() - self._copy_toast.height() - 12
        self._copy_toast.move(max(8, x), max(8, y))
        self._copy_toast.show()
        self._copy_toast.raise_()
        self._copy_toast_timer.start(1200)

    def _copy_cell_at_index(self, index) -> None:
        if copy_view_cell(self._table, index) is None:
            return
        self._show_copy_toast()

    def _on_row_header_context_menu(self, pos) -> None:
        vheader = self._table.verticalHeader()
        view_row = vheader.logicalIndexAt(pos)
        if view_row < 0:
            return
        source_row = self._model.source_row_at(view_row)
        if source_row is None:
            return
        self._show_row_color_menu(source_row, vheader.mapToGlobal(pos))

    def _on_table_context_menu(self, pos) -> None:
        index = self._table.indexAt(pos)
        if not index.isValid():
            return
        source_row = self._model.source_row_at(index.row())
        if source_row is None:
            return
        menu = QMenu(self)
        copy_action = menu.addAction(tr("viewer.copy_cell"))
        copy_action.triggered.connect(lambda: self._copy_cell_at_index(index))
        menu.addSeparator()
        menu.addSection(tr("viewer.row_section", n=source_row + 1))
        current = self._model.row_highlight(source_row)

        def pick(color_index: int) -> None:
            self._model.set_row_highlight(source_row, color_index)

        def clear() -> None:
            self._model.set_row_highlight(source_row, None)

        self._append_color_actions(menu, on_pick=pick, on_clear=clear, current=current)
        menu.exec(self._table.viewport().mapToGlobal(pos))

    def _on_header_section_clicked(self, logical_index: int) -> None:
        source_col = self._model.column_index_at(logical_index)
        if source_col is None:
            return
        header = self._table.horizontalHeader()
        if self._qa_header_sort:
            if self._sort_source_column == source_col:
                self._qa_sort_mode = self._qa_sort_mode.next_mode()
            else:
                self._sort_source_column = source_col
                self._qa_sort_mode = QaGridSortMode.ASCENDING
            self._model.sort(logical_index, qa_mode=self._qa_sort_mode)
            indicator = sort_indicator(self._qa_sort_mode)
            if indicator is None:
                header.setSortIndicatorShown(False)
            else:
                header.setSortIndicatorShown(True)
                header.setSortIndicator(logical_index, indicator)
        else:
            if self._sort_source_column == source_col:
                self._sort_order = (
                    Qt.SortOrder.DescendingOrder
                    if self._sort_order == Qt.SortOrder.AscendingOrder
                    else Qt.SortOrder.AscendingOrder
                )
            else:
                self._sort_source_column = source_col
                self._sort_order = Qt.SortOrder.AscendingOrder
            header.setSortIndicatorShown(True)
            header.setSortIndicator(logical_index, self._sort_order)
            self._model.sort(logical_index, self._sort_order)
        self._show_stats_for_column_index(logical_index)

    def _on_cell_selection_changed(self, current, _previous) -> None:
        if not current.isValid():
            return
        self._show_stats_for_column_index(current.column())

    def _show_stats_for_column_index(self, view_col: int) -> None:
        if self._dataset is None:
            return
        name = self._model.column_name_at(view_col)
        if name is None:
            return
        for column in self._dataset.columns:
            if column.name == name:
                self._show_column_stats(column)
                break

    def _refresh_column_stats(self) -> None:
        if self._dataset is None:
            return
        from PySide6.QtCore import QModelIndex

        selection = self._table.selectionModel()
        if selection is not None and selection.currentIndex().isValid():
            self._show_stats_for_column_index(selection.currentIndex().column())
            return
        visible = [idx for idx, box in enumerate(self._column_checks) if box.isChecked()]
        if visible:
            self._show_column_stats(self._dataset.columns[visible[0]])

    def _on_column_index_changed(self, current, _previous) -> None:
        if self._dataset is None or not current.isValid():
            return
        self._show_stats_for_column_index(current.column())

    def _show_column_stats(self, column: ColumnSummary) -> None:
        lines = [
            f"{tr('viewer.stat.column')} {column.name}",
            f"{tr('viewer.stat.type')}    {column.dtype}",
            f"{tr('viewer.stat.nulls')}   {column.null_count}",
            f"{tr('viewer.stat.uniques')}  {column.unique_count}",
        ]
        if column.sum_value is not None:
            lines.extend(
                [
                    f"{tr('viewer.stat.sum')}    {column.sum_value:,.4g}",
                    f"{tr('viewer.stat.mean')}   {column.mean_value:,.4g}",
                    f"{tr('viewer.stat.min')}     {column.min_value:,.4g}",
                    f"{tr('viewer.stat.max')}     {column.max_value:,.4g}",
                ]
            )
        else:
            lines.append(tr("viewer.stat.non_numeric"))
        if self._model.unique_rows_only:
            lines.append(
                tr(
                    "viewer.stat.row_count",
                    count=f"{self._model.displayed_row_count:,}",
                )
            )
        self._stats.setPlainText("\n".join(lines))


class _ColorMenuRow(QWidget):
    pick_requested = Signal()

    def __init__(self, index: int, *, checked: bool, parent=None) -> None:
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 6, 16, 6)
        label = QLabel(palette_label(index))
        label.setStyleSheet(palette_text_stylesheet(index))
        layout.addWidget(label, stretch=1)
        if checked:
            mark = QLabel("●")
            mark.setStyleSheet(palette_text_stylesheet(index))
            layout.addWidget(mark)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.pick_requested.emit()
        super().mouseReleaseEvent(event)
