"""Modelo Qt para tabla tabular con columnas visibles configurables."""
from __future__ import annotations

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt
from PySide6.QtGui import QBrush, QColor

from core.analysis_types import TabularDataset
from ui.widgets.highlight_palette import PALETTE_FOREGROUND, PALETTE_SIZE, palette_brush


VALIDATION_GREEN = QBrush(QColor("#56bd56"))
VALIDATION_RED = QBrush(QColor("#e05555"))
VALIDATION_ORANGE = QBrush(QColor("#ffb74d"))
VALIDATION_GRAY = QBrush(QColor("#d0d0d0"))
BUILD_MARKED = QBrush(QColor("#b8d4f0"))


from ui.widgets.qa_grid_sort import QaGridSortMode, text_sort_key, validation_cell_bucket, validation_sort_key


def _cell_sort_key(value: str) -> tuple[int, float | str]:
    text = value.strip()
    if not text:
        return (2, "")
    try:
        return (0, float(text.replace(",", "")))
    except ValueError:
        return (1, text.casefold())


class TabularTableModel(QAbstractTableModel):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._dataset: TabularDataset | None = None
        self._visible_indices: list[int] = []
        self._unique_rows_only = False
        self._row_map: list[int] = []
        self._column_highlights: dict[int, int] = {}
        self._row_highlights: dict[int, int] = {}
        self._validation_enabled = False
        self._evaluated_columns: set[int] = set()
        self._passed_cells: set[tuple[int, int]] = set()
        self._failed_cells: set[tuple[int, int]] = set()
        self._conflict_cells: set[tuple[int, int]] = set()
        self._gray_cells: set[tuple[int, int]] = set()
        self._gray_unevaluated = False
        self._cell_tooltips: dict[tuple[int, int], str] = {}
        self._catalog_displays: dict[tuple[int, int], str] = {}
        self._catalog_misses: set[tuple[int, int]] = set()
        self._catalog_columns: set[int] = set()
        self._marked_source_rows: set[int] = set()
        self._build_mode = False

    def set_dataset(self, dataset: TabularDataset) -> None:
        self.beginResetModel()
        self._dataset = dataset
        self._visible_indices = list(range(len(dataset.columns)))
        self._column_highlights.clear()
        self._row_highlights.clear()
        self.clear_validation_overlay()
        self._catalog_displays.clear()
        self._catalog_misses.clear()
        self._catalog_columns.clear()
        self._marked_source_rows.clear()
        self._build_mode = False
        self._rebuild_row_map()
        self.endResetModel()

    def clear_validation_overlay(self) -> None:
        self._validation_enabled = False
        self._evaluated_columns.clear()
        self._passed_cells.clear()
        self._failed_cells.clear()
        self._conflict_cells.clear()
        self._gray_cells.clear()
        self._gray_unevaluated = False
        self._cell_tooltips.clear()
        self._emit_highlight_changed()

    def set_catalog_displays(
        self,
        displays: dict[tuple[int, int], str],
        misses: set[tuple[int, int]],
        bound_columns: set[int],
    ) -> None:
        self._catalog_displays = dict(displays)
        self._catalog_misses = set(misses)
        self._catalog_columns = set(bound_columns)
        self._emit_catalog_display_changed()

    def clear_catalog_displays(self) -> None:
        if not self._catalog_displays and not self._catalog_columns:
            return
        self._catalog_displays.clear()
        self._catalog_misses.clear()
        self._catalog_columns.clear()
        self._emit_catalog_display_changed()

    def _emit_catalog_display_changed(self) -> None:
        if self.rowCount() == 0 or self.columnCount() == 0:
            if self.columnCount() > 0:
                self.headerDataChanged.emit(
                    Qt.Orientation.Horizontal,
                    0,
                    self.columnCount() - 1,
                )
            return
        top_left = self.index(0, 0)
        bottom_right = self.index(self.rowCount() - 1, self.columnCount() - 1)
        self.dataChanged.emit(
            top_left,
            bottom_right,
            [Qt.ItemDataRole.DisplayRole],
        )
        self.headerDataChanged.emit(
            Qt.Orientation.Horizontal,
            0,
            self.columnCount() - 1,
        )

    def set_build_mode(self, enabled: bool) -> None:
        if self._build_mode == enabled:
            return
        self._build_mode = enabled
        if not enabled:
            self._marked_source_rows.clear()
        self._emit_highlight_changed()

    def marked_source_rows(self) -> set[int]:
        return set(self._marked_source_rows)

    def clear_marked_rows(self) -> None:
        if not self._marked_source_rows:
            return
        self._marked_source_rows.clear()
        self._emit_highlight_changed()

    def toggle_mark_source_row(self, source_row: int) -> None:
        if source_row in self._marked_source_rows:
            self._marked_source_rows.remove(source_row)
        else:
            self._marked_source_rows.add(source_row)
        self._emit_highlight_changed()

    def remove_duplicate_rows(self, source_column_indices: list[int]) -> int:
        if self._dataset is None or not source_column_indices:
            return 0
        before = len(self._row_map)
        seen: set[tuple[str, ...]] = set()
        filtered: list[int] = []
        for source_row in self._row_map:
            row = self._dataset.rows[source_row]
            key = tuple(
                row[col].strip().casefold() if col < len(row) else ""
                for col in source_column_indices
            )
            if key in seen:
                continue
            seen.add(key)
            filtered.append(source_row)
        removed = before - len(filtered)
        if removed <= 0:
            return 0
        self.beginResetModel()
        self._row_map = filtered
        self._marked_source_rows = {
            row for row in self._marked_source_rows if row in set(filtered)
        }
        self.endResetModel()
        self._emit_highlight_changed()
        return removed

    def apply_validation_overlay(
        self,
        *,
        evaluated_columns: set[str],
        passed_cells: set[tuple[int, int]],
        failed_cells: set[tuple[int, int]] | None = None,
        conflict_cells: set[tuple[int, int]] | None = None,
        gray_cells: set[tuple[int, int]] | None = None,
        gray_unevaluated: bool,
        cell_tooltips: dict[tuple[int, int], str] | None = None,
    ) -> None:
        if self._dataset is None:
            return
        name_to_index = {column.name: idx for idx, column in enumerate(self._dataset.columns)}
        self._validation_enabled = True
        self._evaluated_columns = {
            name_to_index[name] for name in evaluated_columns if name in name_to_index
        }
        self._passed_cells = set(passed_cells)
        self._failed_cells = set(failed_cells or set())
        self._conflict_cells = set(conflict_cells or set())
        self._gray_cells = set(gray_cells or set())
        self._gray_unevaluated = gray_unevaluated
        self._cell_tooltips = dict(cell_tooltips or {})
        self._emit_highlight_changed()

    def set_visible_columns(self, indices: list[int]) -> None:
        index_set = set(indices)
        ordered = [idx for idx in self._visible_indices if idx in index_set]
        for idx in indices:
            if idx not in ordered:
                ordered.append(idx)
        self.beginResetModel()
        self._visible_indices = ordered
        self._prune_highlights()
        self._rebuild_row_map()
        self.endResetModel()

    def reorder_visible_columns(self, ordered_source_indices: list[int]) -> None:
        if ordered_source_indices == self._visible_indices:
            return
        self.beginResetModel()
        self._visible_indices = list(ordered_source_indices)
        self.endResetModel()

    def set_unique_rows_only(self, enabled: bool) -> None:
        if self._unique_rows_only == enabled:
            return
        self.beginResetModel()
        self._unique_rows_only = enabled
        self._rebuild_row_map()
        self.endResetModel()

    def set_column_highlight(self, source_col: int, palette_index: int | None) -> None:
        if palette_index is not None and not 0 <= palette_index < PALETTE_SIZE:
            return
        if palette_index is None:
            self._column_highlights.pop(source_col, None)
        else:
            self._column_highlights[source_col] = palette_index
        self._emit_highlight_changed()

    def set_row_highlight(self, source_row: int, palette_index: int | None) -> None:
        if palette_index is not None and not 0 <= palette_index < PALETTE_SIZE:
            return
        if palette_index is None:
            self._row_highlights.pop(source_row, None)
        else:
            self._row_highlights[source_row] = palette_index
        self._emit_highlight_changed()

    def column_highlight(self, source_col: int) -> int | None:
        return self._column_highlights.get(source_col)

    def row_highlight(self, source_row: int) -> int | None:
        return self._row_highlights.get(source_row)

    @property
    def unique_rows_only(self) -> bool:
        return self._unique_rows_only

    @property
    def displayed_row_count(self) -> int:
        return len(self._row_map)

    def source_row_at(self, view_row: int) -> int | None:
        if view_row < 0 or view_row >= len(self._row_map):
            return None
        return self._row_map[view_row]

    def _prune_highlights(self) -> None:
        if self._dataset is None:
            self._column_highlights.clear()
            self._row_highlights.clear()
            return
        col_count = len(self._dataset.columns)
        row_count = len(self._dataset.rows)
        self._column_highlights = {
            col: color
            for col, color in self._column_highlights.items()
            if 0 <= col < col_count
        }
        self._row_highlights = {
            row: color
            for row, color in self._row_highlights.items()
            if 0 <= row < row_count
        }

    def _emit_highlight_changed(self) -> None:
        if self.columnCount() > 0:
            self.headerDataChanged.emit(
                Qt.Orientation.Horizontal,
                0,
                self.columnCount() - 1,
            )
        if self.rowCount() > 0:
            self.headerDataChanged.emit(
                Qt.Orientation.Vertical,
                0,
                self.rowCount() - 1,
            )
        if self.rowCount() == 0 or self.columnCount() == 0:
            top_left = self.index(0, 0)
            self.dataChanged.emit(top_left, top_left, [Qt.ItemDataRole.BackgroundRole])
            return
        top_left = self.index(0, 0)
        bottom_right = self.index(self.rowCount() - 1, self.columnCount() - 1)
        self.dataChanged.emit(
            top_left,
            bottom_right,
            [
                Qt.ItemDataRole.BackgroundRole,
                Qt.ItemDataRole.ForegroundRole,
                Qt.ItemDataRole.ToolTipRole,
            ],
        )

    def _row_key(self, row: tuple[str, ...]) -> tuple[str, ...]:
        return tuple(row[col] if col < len(row) else "" for col in self._visible_indices)

    def _rebuild_row_map(self) -> None:
        if self._dataset is None:
            self._row_map = []
            return
        rows = self._dataset.rows
        if not self._unique_rows_only:
            self._row_map = list(range(len(rows)))
            return
        seen: set[tuple[str, ...]] = set()
        row_map: list[int] = []
        for index, row in enumerate(rows):
            key = self._row_key(row)
            if key in seen:
                continue
            seen.add(key)
            row_map.append(index)
        self._row_map = row_map

    def sort(  # noqa: N802
        self,
        column: int,
        order: Qt.SortOrder = Qt.SortOrder.AscendingOrder,
        *,
        qa_mode: QaGridSortMode | None = None,
    ) -> None:
        if self._dataset is None or column < 0 or column >= len(self._visible_indices):
            return
        source_col = self._visible_indices[column]
        mode = qa_mode
        if mode is None:
            mode = (
                QaGridSortMode.DESCENDING
                if order == Qt.SortOrder.DescendingOrder
                else QaGridSortMode.ASCENDING
            )

        reverse = mode == QaGridSortMode.DESCENDING

        if mode in (QaGridSortMode.GREEN_RED_NEUTRAL, QaGridSortMode.RED_GREEN_NEUTRAL):

            def sort_key(source_row: int) -> tuple:
                row = self._dataset.rows[source_row]
                value = row[source_col] if source_col < len(row) else ""
                bucket = validation_cell_bucket(
                    in_passed=(source_row, source_col) in self._passed_cells,
                    in_failed=(source_row, source_col) in self._failed_cells,
                    in_conflict=(source_row, source_col) in self._conflict_cells,
                )
                return validation_sort_key(bucket=bucket, text=value, mode=mode)

            reverse = False
        else:

            def sort_key(source_row: int) -> tuple[int, float | str]:
                row = self._dataset.rows[source_row]
                value = row[source_col] if source_col < len(row) else ""
                return _cell_sort_key(value)

        self.layoutAboutToBeChanged.emit()
        self._row_map.sort(key=sort_key, reverse=reverse)
        self.layoutChanged.emit()

    def column_index_at(self, view_col: int) -> int | None:
        try:
            col = int(view_col)
        except (TypeError, ValueError):
            return None
        if col < 0 or col >= len(self._visible_indices):
            return None
        return self._visible_indices[col]

    def column_name_at(self, view_col: int) -> str | None:
        idx = self.column_index_at(view_col)
        if idx is None or self._dataset is None:
            return None
        return self._dataset.columns[idx].name

    def rowCount(self, parent: QModelIndex | None = None) -> int:  # noqa: N802
        if parent and parent.isValid():
            return 0
        return len(self._row_map)

    def columnCount(self, parent: QModelIndex | None = None) -> int:  # noqa: N802
        if parent and parent.isValid():
            return 0
        return len(self._visible_indices)

    def flags(self, index: QModelIndex) -> Qt.ItemFlag:  # noqa: N802
        if not index.isValid():
            return Qt.ItemFlag.NoItemFlags
        return Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable

    def _validation_brush(self, index: QModelIndex) -> QBrush | None:
        if not self._validation_enabled or self._dataset is None:
            return None
        source_row = self.source_row_at(index.row())
        source_col = self.column_index_at(index.column())
        if source_row is None or source_col is None:
            return None
        coord = (source_row, source_col)
        if coord in self._failed_cells:
            return VALIDATION_RED
        if coord in self._conflict_cells:
            return VALIDATION_ORANGE
        if coord in self._passed_cells:
            return VALIDATION_GREEN
        if coord in self._gray_cells:
            return VALIDATION_GRAY
        if source_col not in self._evaluated_columns:
            if self._gray_unevaluated:
                return VALIDATION_GRAY
            return None
        if self._gray_unevaluated:
            return VALIDATION_GRAY
        return None

    def _header_validation_brush(self, source_col: int | None) -> QBrush | None:
        if not self._validation_enabled or source_col is None:
            return None
        if source_col not in self._evaluated_columns and self._gray_unevaluated:
            return VALIDATION_GRAY
        return None

    def _highlight_brush(self, index: QModelIndex) -> QBrush | None:
        source_row = self.source_row_at(index.row())
        source_col = self.column_index_at(index.column())
        if (
            self._build_mode
            and source_row is not None
            and source_row in self._marked_source_rows
        ):
            return BUILD_MARKED
        if source_row is not None and source_row in self._row_highlights:
            return palette_brush(self._row_highlights[source_row])
        if source_col is not None and source_col in self._column_highlights:
            return palette_brush(self._column_highlights[source_col])
        return None

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or self._dataset is None:
            return None
        if role == Qt.ItemDataRole.BackgroundRole:
            validation = self._validation_brush(index)
            if validation is not None:
                return validation
            return self._highlight_brush(index)
        if role == Qt.ItemDataRole.ForegroundRole:
            if self._validation_brush(index) is not None:
                return QColor(PALETTE_FOREGROUND)
            if self._highlight_brush(index) is not None:
                return QColor(PALETTE_FOREGROUND)
            return None
        source_col = self.column_index_at(index.column())
        if source_col is None:
            return None
        source_row = self._row_map[index.row()]
        if role == Qt.ItemDataRole.ToolTipRole:
            tip = self._cell_tooltips.get((source_row, source_col))
            return tip or None
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        row = self._dataset.rows[source_row]
        if source_col >= len(row):
            return ""
        raw = row[source_col]
        translation = self._catalog_displays.get((source_row, source_col))
        if translation:
            return f"{raw} ({translation})"
        return raw

    def headerData(  # noqa: N802
        self,
        section: int,
        orientation: Qt.Orientation,
        role: int = Qt.ItemDataRole.DisplayRole,
    ):
        if self._dataset is None:
            return None
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.BackgroundRole:
            source_col = self.column_index_at(section)
            header_validation = self._header_validation_brush(source_col)
            if header_validation is not None:
                return header_validation
            if source_col is not None and source_col in self._column_highlights:
                return palette_brush(self._column_highlights[source_col])
            return None
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.ForegroundRole:
            source_col = self.column_index_at(section)
            if source_col is not None and source_col in self._column_highlights:
                return QColor(PALETTE_FOREGROUND)
            return None
        if orientation == Qt.Orientation.Vertical and role == Qt.ItemDataRole.BackgroundRole:
            source_row = self.source_row_at(section)
            if source_row is not None and source_row in self._row_highlights:
                return palette_brush(self._row_highlights[source_row])
            return None
        if orientation == Qt.Orientation.Vertical and role == Qt.ItemDataRole.ForegroundRole:
            source_row = self.source_row_at(section)
            if source_row is not None and source_row in self._row_highlights:
                return QColor(PALETTE_FOREGROUND)
            return None
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == Qt.Orientation.Horizontal:
            name = self.column_name_at(section) or ""
            source_col = self.column_index_at(section)
            if source_col is not None and source_col in self._catalog_columns:
                return f"{name} ↗"
            return name
        return str(section + 1)
