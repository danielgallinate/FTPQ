"""Paleta de 12 colores para resaltado temporal en visualización tabular."""
from __future__ import annotations

from PySide6.QtGui import QBrush, QColor, QIcon, QPixmap

from ui.i18n import tr

# Tonos legibles sobre fondo claro/oscuro de la tabla (referencia visual, no persistido).
PALETTE_HEX: tuple[str, ...] = (
    "#FFE082",  # 1 ámbar
    "#FFAB91",  # 2 salmón
    "#EF9A9A",  # 3 rojo claro
    "#F48FB1",  # 4 rosa
    "#CE93D8",  # 5 púrpura
    "#B39DDB",  # 6 violeta
    "#9FA8DA",  # 7 índigo
    "#90CAF9",  # 8 azul
    "#80DEEA",  # 9 cian
    "#80CBC4",  # 10 teal
    "#A5D6A7",  # 11 verde
    "#E6EE9C",  # 12 lima
)

PALETTE_FOREGROUND = "#111111"
PALETTE_SIZE = len(PALETTE_HEX)


def palette_label(index: int) -> str:
    return tr("viewer.color_label", n=index + 1)


def palette_brush(index: int) -> QBrush:
    return QBrush(QColor(PALETTE_HEX[index]))


def palette_text_stylesheet(index: int) -> str:
    return f"color: {PALETTE_HEX[index]}; font-weight: 700; background: transparent;"


def palette_icon(index: int, size: int = 14) -> QIcon:
    pixmap = QPixmap(size, size)
    pixmap.fill(QColor(PALETTE_HEX[index]))
    return QIcon(pixmap)
