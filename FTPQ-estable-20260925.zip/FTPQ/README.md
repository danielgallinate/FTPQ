# FTPQ — validador de archivos tabulares

Ayuda local para **revisar textos tabulares** (CSV, TSV) con **pandas** y PySide6 (`emr-qa/`). Alcance y disclaimer: [`documentacion/alcance-validador-tabular.md`](documentacion/alcance-validador-tabular.md).

**Línea activa:** este repo (`FTPQ/`) · [`documentacion/linea-desarrollo.md`](documentacion/linea-desarrollo.md)

Baseline histórico: [`release/STABLE-1.0.0.md`](release/STABLE-1.0.0.md)

---

## Ejecutar

| Plataforma | Requisito | Comandos |
|------------|-----------|----------|
| **macOS nativo** | Python **3.12+** | `./scripts/setup.sh` → `./scripts/run_emr_qa_editor.sh` |
| **Windows** | **WSL2** + Python **3.12+** | Mismo repo en WSL → mismos scripts |

Legacy UI/SFTP (opcional): `./scripts/run_ui.sh`

Mock sin VPN:

```bash
PDE_DESKTOP_MOCK=1 ./scripts/run_ui.sh
```

Tests:

```bash
.venv/bin/pytest -q
```

Documentación: [`documentacion/plataformas/README.md`](documentacion/plataformas/README.md)

**Guía paso a paso + ticket IT:** [`instalacion/README.md`](instalacion/README.md)

---

## Estructura (raíz)

```text
core/           # dominio SFTP, perfiles, compare
adapters/       # paramiko, pandas
ui/             # PySide6
documentacion/  # spec por módulo
scripts/        # setup.sh, run_ui.sh (solo .sh)
tests/
profiles/
draft/          # material previo — limpieza pendiente
```

Instaladores portable/embed/handoff **eliminados** en 1.0.0: [`scripts/ARCHIVADO-INSTALADORES.md`](scripts/ARCHIVADO-INSTALADORES.md)

---

## Agentes / contexto

[`AGENTS.md`](AGENTS.md) · Skills en [`skills/`](skills/README.md)
