"""Extensiones tabulares — csv, tsv, psv."""
from __future__ import annotations

from core.analysis_types import is_tabular_extension
from core.file_view import is_viewable_extension


def test_psv_is_tabular_and_viewable() -> None:
    assert is_tabular_extension("report.psv")
    assert is_viewable_extension("report.psv")


def test_psv_case_insensitive() -> None:
    assert is_tabular_extension("REPORT.PSV")
    assert is_viewable_extension("data.Psv")
