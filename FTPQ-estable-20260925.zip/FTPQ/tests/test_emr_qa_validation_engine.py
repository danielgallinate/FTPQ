"""Tests EMR QA — motor de validación v2.0."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


@pytest.fixture
def engine_modules():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    import emrqa.validation_storage as validation_storage
    from emrqa.validation_engine import validate_rows

    yield validation_storage, validate_rows


def _load_example(validation_storage):
    path = EMR_QA_ROOT / "knowledge_bases/default/templates/tpl_example_patient_encounter.json"
    return validation_storage.load_validation_template(path)


def test_all_rows_pass_unique_and_rules(engine_modules):
    validation_storage, validate_rows = engine_modules
    template = _load_example(validation_storage)
    template.minibase.records = []
    rows = [
        {"mrn": "001234", "encounter_id": "ENC-1", "visit_date": "2026-07-01", "status": "A"},
        {"mrn": "005678", "encounter_id": "ENC-2", "visit_date": "2026-07-02", "status": "I"},
    ]
    result = validate_rows(template, rows)
    assert result.summary.total_cells == 8
    assert result.summary.passed_cells == 8
    assert result.summary.percent == 100.0
    assert result.is_green(0, "mrn")
    assert not result.failed_keys()


def test_duplicate_key_in_file_fails(engine_modules):
    validation_storage, validate_rows = engine_modules
    template = _load_example(validation_storage)
    rows = [
        {"mrn": "001234", "encounter_id": "ENC-99", "visit_date": "2026-07-01", "status": "A"},
        {"mrn": "001234", "encounter_id": "ENC-99", "visit_date": "2026-07-02", "status": "A"},
    ]
    result = validate_rows(template, rows)
    assert result.summary.percent < 100.0
    assert result.summary.rows_with_key_errors == 2
    assert not result.is_green(0, "mrn")
    assert not result.is_green(1, "encounter_id")
    assert any("duplicada" in alert.lower() for alert in result.summary.alerts)


def test_unevaluated_columns_excluded(engine_modules):
    validation_storage, validate_rows = engine_modules
    template = _load_example(validation_storage)
    rows = [
        {"mrn": "", "encounter_id": "ENC-1", "visit_date": "2026-07-01", "status": "Z"},
    ]
    result = validate_rows(template, rows, evaluated_columns={"mrn", "encounter_id"})
    assert result.summary.total_cells == 2
    state_status = result.cell_state(0, "status")
    assert state_status is not None
    assert not state_status.evaluated


def test_invalid_status_value(engine_modules):
    validation_storage, validate_rows = engine_modules
    template = _load_example(validation_storage)
    rows = [
        {"mrn": "001234", "encounter_id": "ENC-3", "visit_date": "2026-07-01", "status": "Z"},
    ]
    result = validate_rows(template, rows)
    cell = result.cell_state(0, "status")
    assert cell is not None
    assert cell.evaluated
    assert not cell.passed
    assert not result.is_green(0, "status")


def test_percent_calculation_partial(engine_modules):
    validation_storage, validate_rows = engine_modules
    template = _load_example(validation_storage)
    template.minibase.records = []
    rows = [
        {"mrn": "001234", "encounter_id": "ENC-4", "visit_date": "2026-07-01", "status": "A"},
        {"mrn": "", "encounter_id": "ENC-5", "visit_date": "2026-07-02", "status": "A"},
    ]
    result = validate_rows(template, rows)
    assert result.summary.total_cells == 8
    assert result.summary.passed_cells == 7
    assert result.summary.percent == 87.5


def test_minibase_tuple_match_and_miss(engine_modules):
    validation_storage, validate_rows = engine_modules
    template = _load_example(validation_storage)
    rows = [
        {"mrn": "001234", "encounter_id": "ENC-99", "visit_date": "2026-07-01", "status": "A"},
        {"mrn": "009999", "encounter_id": "ENC-NEW", "visit_date": "2026-07-02", "status": "A"},
    ]
    result = validate_rows(template, rows)
    assert result.is_green(0, "mrn")
    assert result.is_green(0, "encounter_id")
    assert not result.is_green(1, "mrn")
    assert result.summary.rows_with_key_errors == 1
    assert any("minibase" in alert.lower() for alert in result.summary.alerts)
