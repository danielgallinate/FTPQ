"""Tests — catálogo → template QA."""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


def _import_modules():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))
    from core.catalog_store import CatalogStore, create_catalog_from_dataset
    from core.emr_qa_job import EmrQaJob, JobQaCatalogSpec, JobQaSection
    from emrqa.catalog_to_template import build_validation_template_from_catalog
    from job_runner import run_emr_qa_job
    from shell.validation_runner import run_multi_template_validation

    return (
        CatalogStore,
        EmrQaJob,
        JobQaCatalogSpec,
        JobQaSection,
        build_validation_template_from_catalog,
        create_catalog_from_dataset,
        run_emr_qa_job,
        run_multi_template_validation,
    )


def _write_csv(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def test_build_template_from_catalog(tmp_path, monkeypatch) -> None:
    (
        CatalogStore,
        _EmrQaJob,
        _JobQaCatalogSpec,
        _JobQaSection,
        build_validation_template_from_catalog,
        create_catalog_from_dataset,
        _run_emr_qa_job,
        run_multi_template_validation,
    ) = _import_modules()

    kb_root = tmp_path / "knowledge_bases" / "default" / "catalogs"
    kb_root.mkdir(parents=True)
    monkeypatch.setattr(
        "core.catalog_store.catalogs_dir",
        lambda knowledge_base_id="default": kb_root,
    )

    create_catalog_from_dataset(
        name="clinic QA",
        columns=["CLINIC_ID", "CLINIC_NAME"],
        key_column="CLINIC_ID",
        dataset_rows=[
            {"CLINIC_ID": "10354", "CLINIC_NAME": "QA Release Clinic"},
            {"CLINIC_ID": "99999", "CLINIC_NAME": "Manual Insert Clinic"},
        ],
        source_file="clinic.csv",
        knowledge_base_id="default",
        catalog_id="clinic_qa",
    )
    table = CatalogStore("default").load("clinic_qa")
    template = build_validation_template_from_catalog(table)
    assert template.header.name == "clinic QA"
    assert len(template.minibase.records) == 2

    rows = [
        {"CLINIC_ID": "10354", "CLINIC_NAME": "QA Release Clinic"},
        {"CLINIC_ID": "99999", "CLINIC_NAME": "Wrong Name"},
    ]
    result = run_multi_template_validation(
        [template],
        rows,
        evaluated_columns={"CLINIC_ID", "CLINIC_NAME"},
        name_to_index={"CLINIC_ID": 0, "CLINIC_NAME": 1},
    )
    assert result.overlay.failed_cells


def test_qa_job_with_catalogs_passes_and_reports(tmp_path, monkeypatch) -> None:
    (
        CatalogStore,
        EmrQaJob,
        JobQaCatalogSpec,
        JobQaSection,
        _build_validation_template_from_catalog,
        create_catalog_from_dataset,
        run_emr_qa_job,
        _run_multi,
    ) = _import_modules()

    kb_root = tmp_path / "knowledge_bases" / "default" / "catalogs"
    kb_root.mkdir(parents=True)
    monkeypatch.setattr(
        "core.catalog_store.catalogs_dir",
        lambda knowledge_base_id="default": kb_root,
    )

    create_catalog_from_dataset(
        name="clinic QA",
        columns=["CLINIC_ID", "CLINIC_NAME"],
        key_column="CLINIC_ID",
        dataset_rows=[
            {"CLINIC_ID": "10354", "CLINIC_NAME": "QA Release Clinic"},
        ],
        source_file="clinic.csv",
        knowledge_base_id="default",
        catalog_id="clinic_qa",
    )

    file_csv = tmp_path / "cases.csv"
    _write_csv(
        file_csv,
        "CLINIC_ID,CLINIC_NAME\n10354,QA Release Clinic\n",
    )

    job = EmrQaJob(
        name="qa-catalog",
        mode="qa",
        evaluated_columns=("CLINIC_ID", "CLINIC_NAME"),
        qa=JobQaSection(
            catalogs=(JobQaCatalogSpec(catalog_id="clinic_qa"),),
        ),
    )

    result = run_emr_qa_job(job, file_path=file_csv)
    assert result.ok is True
    assert result.qa_metrics_report is not None
    assert "clinic QA" in result.qa_metrics_report.by_template
    assert result.qa_metrics_report.nok_cells == 0


def test_qa_job_with_catalogs_fails_on_mismatch(tmp_path, monkeypatch) -> None:
    (
        CatalogStore,
        EmrQaJob,
        JobQaCatalogSpec,
        JobQaSection,
        _build_validation_template_from_catalog,
        create_catalog_from_dataset,
        run_emr_qa_job,
        _run_multi,
    ) = _import_modules()

    kb_root = tmp_path / "knowledge_bases" / "default" / "catalogs"
    kb_root.mkdir(parents=True)
    monkeypatch.setattr(
        "core.catalog_store.catalogs_dir",
        lambda knowledge_base_id="default": kb_root,
    )

    create_catalog_from_dataset(
        name="clinic QA",
        columns=["CLINIC_ID", "CLINIC_NAME"],
        key_column="CLINIC_ID",
        dataset_rows=[
            {"CLINIC_ID": "10354", "CLINIC_NAME": "Expected After Deploy"},
        ],
        source_file="clinic.csv",
        knowledge_base_id="default",
        catalog_id="clinic_qa",
    )

    file_csv = tmp_path / "cases.csv"
    _write_csv(
        file_csv,
        "CLINIC_ID,CLINIC_NAME\n10354,Old Name\n",
    )

    job = EmrQaJob(
        name="qa-catalog-fail",
        mode="qa",
        evaluated_columns=("CLINIC_ID", "CLINIC_NAME"),
        qa=JobQaSection(
            catalogs=(JobQaCatalogSpec(catalog_id="clinic_qa"),),
        ),
    )

    result = run_emr_qa_job(job, file_path=file_csv)
    assert result.ok is False
    assert result.qa_metrics_report is not None
    assert result.qa_metrics_report.nok_cells >= 1
