"""Tests — job JSON + runner CLI EMR QA."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


def _import_job_modules():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))
    from core.emr_qa_job import (
        JOB_SCHEMA_VERSION,
        EmrQaJob,
        JobQaCatalogSpec,
        JobQaSection,
        JobReferenceSection,
        load_job,
        save_job,
    )
    from core.reference_compare_types import ComparePairMapping
    from job_runner import run_emr_qa_job

    return (
        JOB_SCHEMA_VERSION,
        EmrQaJob,
        JobQaCatalogSpec,
        JobQaSection,
        JobReferenceSection,
        ComparePairMapping,
        load_job,
        save_job,
        run_emr_qa_job,
    )


def _write_csv(path: Path, content: str) -> Path:
    path.write_text(content, encoding="utf-8")
    return path


def _reference_job():
    (
        _version,
        EmrQaJob,
        _JobQaCatalogSpec,
        _JobQaSection,
        JobReferenceSection,
        ComparePairMapping,
        _load_job,
        _save_job,
        _run_emr_qa_job,
    ) = _import_job_modules()
    return EmrQaJob(
        name="reference-sample",
        mode="reference",
        evaluated_columns=("mrn", "status"),
        reference=JobReferenceSection(
            duplicate_policy="first",
            pairs=[
                ComparePairMapping(
                    left_column="mrn",
                    right_column="mrn",
                    enabled=True,
                    is_join_key=True,
                ),
                ComparePairMapping(
                    left_column="status",
                    right_column="status",
                    enabled=True,
                ),
            ],
        ),
    )


def test_job_roundtrip(tmp_path: Path) -> None:
    (
        _version,
        _EmrQaJob,
        _JobQaCatalogSpec,
        _JobQaSection,
        _JobReferenceSection,
        _ComparePairMapping,
        load_job,
        save_job,
        _run,
    ) = _import_job_modules()
    job_path = tmp_path / "sample.job.json"
    save_job(job_path, _reference_job())
    loaded = load_job(job_path)
    assert loaded.mode == "reference"
    assert loaded.evaluated_columns == ("mrn", "status")
    assert loaded.reference.pairs[0].is_join_key is True


def test_run_reference_job_passes(tmp_path: Path) -> None:
    (
        _version,
        _EmrQaJob,
        _JobQaCatalogSpec,
        _JobQaSection,
        _JobReferenceSection,
        _ComparePairMapping,
        load_job,
        save_job,
        run_emr_qa_job,
    ) = _import_job_modules()
    file_csv = _write_csv(
        tmp_path / "file.csv",
        "mrn,status\n001,A\n",
    )
    ref_csv = _write_csv(
        tmp_path / "ref.csv",
        "mrn,status\n001,A\n",
    )
    job_path = tmp_path / "ref.job.json"
    save_job(job_path, _reference_job())

    result = run_emr_qa_job(
        load_job(job_path),
        file_path=file_csv,
        reference_path=ref_csv,
    )
    assert result.ok is True
    assert result.reference_report is not None
    assert result.reference_report.cells_nok == 0


def test_run_reference_job_fails_on_mismatch(tmp_path: Path) -> None:
    (
        _version,
        _EmrQaJob,
        _JobQaCatalogSpec,
        _JobQaSection,
        _JobReferenceSection,
        _ComparePairMapping,
        load_job,
        save_job,
        run_emr_qa_job,
    ) = _import_job_modules()
    file_csv = _write_csv(tmp_path / "file.csv", "mrn,status\n001,B\n")
    ref_csv = _write_csv(tmp_path / "ref.csv", "mrn,status\n001,A\n")
    job_path = tmp_path / "ref.job.json"
    save_job(job_path, _reference_job())

    result = run_emr_qa_job(
        load_job(job_path),
        file_path=file_csv,
        reference_path=ref_csv,
    )
    assert result.ok is False
    assert result.reference_report is not None
    assert result.reference_report.cells_nok >= 1


def test_cli_exit_codes(tmp_path: Path) -> None:
    (
        _version,
        _EmrQaJob,
        _JobQaCatalogSpec,
        _JobQaSection,
        _JobReferenceSection,
        _ComparePairMapping,
        _load_job,
        save_job,
        _run,
    ) = _import_job_modules()
    file_csv = _write_csv(tmp_path / "file.csv", "mrn,status\n001,A\n")
    ref_csv = _write_csv(tmp_path / "ref.csv", "mrn,status\n001,A\n")
    job_path = tmp_path / "ref.job.json"
    save_job(job_path, _reference_job())
    script = REPO_ROOT / "scripts" / "run_emr_qa_job.sh"

    pass_cmd = [
        str(script),
        str(job_path),
        "--file",
        str(file_csv),
        "--reference",
        str(ref_csv),
        "--quiet",
    ]
    fail_cmd = [
        str(script),
        str(job_path),
        "--file",
        str(_write_csv(tmp_path / "bad.csv", "mrn,status\n001,B\n")),
        "--reference",
        str(ref_csv),
        "--quiet",
    ]

    if not script.is_file():
        pytest.skip("run_emr_qa_job.sh missing")

    pass_proc = subprocess.run(pass_cmd, cwd=REPO_ROOT, capture_output=True, text=True)
    assert pass_proc.returncode == 0, pass_proc.stderr
    assert "PASS" in pass_proc.stdout

    fail_proc = subprocess.run(fail_cmd, cwd=REPO_ROOT, capture_output=True, text=True)
    assert fail_proc.returncode == 1
    assert "FAIL" in fail_proc.stdout


def test_job_qa_catalog_ids_roundtrip(tmp_path: Path) -> None:
    (
        _version,
        EmrQaJob,
        JobQaCatalogSpec,
        JobQaSection,
        _JobReferenceSection,
        _ComparePairMapping,
        load_job,
        save_job,
        _run,
    ) = _import_job_modules()
    job_path = tmp_path / "qa.job.json"
    save_job(
        job_path,
        EmrQaJob(
            name="qa-catalog",
            mode="qa",
            evaluated_columns=("CLINIC_ID",),
            qa=JobQaSection(
                catalogs=(JobQaCatalogSpec(catalog_id="clinic_qa", link_column="CLINIC_ID"),),
            ),
        ),
    )
    loaded = load_job(job_path)
    assert loaded.mode == "qa"
    assert loaded.qa.catalogs[0].catalog_id == "clinic_qa"
    loaded.validate_ready()


def test_job_schema_version_constant() -> None:
    version, *_rest = _import_job_modules()
    assert version == 1


def test_repo_job_files_are_valid() -> None:
    _version, EmrQaJob, *_rest = _import_job_modules()
    jobs_dir = EMR_QA_ROOT / "knowledge_bases" / "default" / "jobs"
    paths = sorted(jobs_dir.glob("*.job.json"))
    if not paths:
        pytest.skip("no job files in repo")
    for path in paths:
        raw = json.loads(path.read_text(encoding="utf-8"))
        job = EmrQaJob.from_dict(raw)
        assert job.mode in ("reference", "qa", "validation", "schema"), path.name
        job.validate_ready()


def test_cli_pandas_limit_is_1_gib() -> None:
    from adapters.pandas_analyzer import DEFAULT_MAX_BYTES
    from core.analysis_limits import CLI_PANDAS_MAX_BYTES

    assert CLI_PANDAS_MAX_BYTES == 1024 ** 3
    assert CLI_PANDAS_MAX_BYTES > DEFAULT_MAX_BYTES


def test_run_emr_qa_job_forwards_cli_byte_limit(monkeypatch, tmp_path: Path) -> None:
    _import_job_modules()
    from core.analysis_limits import CLI_PANDAS_MAX_BYTES
    from core.analysis_types import ColumnSummary, TabularDataset
    from core.emr_qa_job import EmrQaJob, JobSchemaSection
    from core.result import Ok
    from job_runner import run_emr_qa_job
    import adapters.pandas_analyzer as pandas_analyzer

    seen: dict[str, int] = {}

    def fake_analyze(path, *, max_display_rows=5000, max_bytes=209_715_200):
        seen["max_bytes"] = max_bytes
        seen["max_display_rows"] = max_display_rows
        return Ok(
            TabularDataset(
                local_path=path,
                columns=(ColumnSummary(name="id", dtype="string", null_count=0, unique_count=0),),
                rows=(),
                total_rows=0,
                display_truncated=False,
            )
        )

    monkeypatch.setattr(pandas_analyzer, "analyze_tabular_file", fake_analyze)
    monkeypatch.setattr("job_runner.analyze_tabular_file", fake_analyze)

    csv_path = tmp_path / "empty.csv"
    csv_path.write_text("id\n", encoding="utf-8")
    job = EmrQaJob(
        name="schema-limit",
        mode="schema",
        schema=JobSchemaSection(schema_id="sample_encounters"),
    )
    run_emr_qa_job(job, file_path=csv_path, max_bytes=CLI_PANDAS_MAX_BYTES)
    assert seen["max_bytes"] == CLI_PANDAS_MAX_BYTES
