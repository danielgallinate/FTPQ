"""Tests icono — copia al proyecto y preferencia."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from ui.theme.icon_store import (
    custom_icons_dir,
    icon_prefs_path,
    install_icon,
    resolve_app_icon_path,
)


def test_install_icon_copies_into_project_assets(tmp_path: Path) -> None:
    assets = tmp_path / "icon"
    assets.mkdir()
    source = tmp_path / "mi icono.ico"
    source.write_bytes(b"fake ico")

    installed = install_icon(source, assets_root=assets)

    assert installed.is_file()
    assert installed.parent == custom_icons_dir(assets)
    assert resolve_app_icon_path(assets) == installed


def test_icon_pref_persists_until_file_removed(tmp_path: Path) -> None:
    assets = tmp_path / "icon"
    assets.mkdir()
    default = assets / "app.ico"
    default.write_bytes(b"default ico")
    source = tmp_path / "elegido.ico"
    source.write_bytes(b"chosen ico")

    installed = install_icon(source, assets_root=assets)
    prefs = json.loads(icon_prefs_path(assets).read_text(encoding="utf-8"))
    assert prefs["icon"].startswith("icons/")
    assert resolve_app_icon_path(assets) == installed

    installed.unlink()
    assert resolve_app_icon_path(assets) == default


def test_resolve_icon_pref_missing_falls_back_to_default(tmp_path: Path) -> None:
    assets = tmp_path / "icon"
    assets.mkdir()
    default = assets / "app.ico"
    default.write_bytes(b"default ico")
    icon_prefs_path(assets).write_text(
        json.dumps({"icon": "icons/no_existe.ico"}) + "\n",
        encoding="utf-8",
    )

    assert resolve_app_icon_path(assets) == default


def test_resolve_icon_returns_none_when_nothing_available(tmp_path: Path) -> None:
    assets = tmp_path / "icon"
    assets.mkdir()
    assert resolve_app_icon_path(assets) is None


def test_install_icon_rejects_unknown_extension(tmp_path: Path) -> None:
    assets = tmp_path / "icon"
    assets.mkdir()
    source = tmp_path / "not-icon.gif"
    source.write_bytes(b"GIF89a")

    with pytest.raises(ValueError, match="Formato no soportado"):
        install_icon(source, assets_root=assets)


def test_resolve_icon_falls_back_to_default_ico(tmp_path: Path) -> None:
    assets = tmp_path / "icon"
    assets.mkdir()
    default = assets / "app.ico"
    default.write_bytes(b"fake ico")

    assert resolve_app_icon_path(assets) == default
