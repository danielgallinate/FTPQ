"""Tests índice minibase."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


@pytest.fixture
def lookup_module():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from emrqa.minibase_lookup import MinibaseLookup
    from emrqa.validation_models import MinibaseRecord, MinibaseSection
    from shell.template_factory import build_empty_template

    return MinibaseLookup, MinibaseRecord, MinibaseSection, build_empty_template


def test_candidate_records_index_limits_scan(lookup_module) -> None:
    (
        MinibaseLookup,
        MinibaseRecord,
        MinibaseSection,
        build_empty_template,
    ) = lookup_module
    template = build_empty_template(
        name="demo",
        column_names=["A", "B", "C"],
        key_column_names=["A", "B"],
    )
    records = [
        MinibaseRecord(
            record_id=f"r{index}",
            key_fingerprint=f"fp{index}",
            key_id=template.header.keys[0].key_id,
            saved_at="2026-01-01T00:00:00Z",
            values={
                template.header.fields[0].field_id: f"a{index}",
                template.header.fields[1].field_id: f"b{index}",
                template.header.fields[2].field_id: f"c{index}",
            },
        )
        for index in range(50)
    ]
    template.minibase.records = records
    lookup = MinibaseLookup.from_template(template)
    dedup_key = template.dedup_key()
    assert dedup_key is not None
    candidates = lookup.candidate_records(
        template,
        dedup_key,
        {"A": "a7", "B": "other"},
    )
    assert len(candidates) == 1
    assert candidates[0].record_id == "r7"
