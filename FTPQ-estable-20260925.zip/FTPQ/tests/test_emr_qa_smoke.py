"""Smoke EMR QA — arranque offscreen sin SFTP ni archivos reales."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"

if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
if str(EMR_QA_ROOT) not in sys.path:
    sys.path.append(str(EMR_QA_ROOT))

from PySide6.QtWidgets import QApplication  # noqa: E402

from shell.main_window import MainWindow  # noqa: E402
from shell.validation_panel import ValidationPanel, ValidationTab, _TAB_STACK_ORDER  # noqa: E402
from ui.i18n import init_locale  # noqa: E402
from ui.theme.theme_engine import ThemeEngine  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    init_locale("es")
    return app


def test_validation_panel_instantiates(qapp: QApplication) -> None:
    panel = ValidationPanel()
    assert panel.active_tab().value == "view"


def test_validation_panel_tab_index_mapping(qapp: QApplication) -> None:
    panel = ValidationPanel()
    for index, expected in enumerate(_TAB_STACK_ORDER):
        panel._activate_tab(expected, emit_signal=False)
        assert panel.active_tab() == expected, f"index {index} expected {expected}"


def test_emr_qa_main_window_instantiates(qapp: QApplication) -> None:
    theme = ThemeEngine(qapp)
    theme.apply()
    window = MainWindow(theme=theme)
    window.shutdown_workers()
    assert window.windowTitle()  # smoke: no crash en __init__
