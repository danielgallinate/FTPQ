"""Smoke tests UI — offscreen (sin pantalla)."""
from __future__ import annotations

import os
import re
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from ui.chrome.color_button import ColorButton
from ui.i18n import init_locale, tr
from ui.shell.main_window import MainWindow
from ui.theme.theme_engine import ChromeMode, ThemeEngine
from ui.version import display_version
from ui.widgets.browser_mode_bar import BrowserLayoutMode


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


@pytest.fixture(scope="module", autouse=True)
def _locale():
    init_locale()
    yield


@pytest.fixture
def window(qapp, tmp_path):
    from core.profile_store import JsonProfileStore
    from ui.app_controller import AppController

    store = JsonProfileStore(tmp_path)
    controller = AppController(profile_store=store)
    theme = ThemeEngine(qapp)
    theme.apply()
    w = MainWindow(theme=theme, controller=controller)
    w.show()
    qapp.processEvents()
    yield w
    w.shutdown_workers()
    w._analysis_thread.quit()
    w._analysis_thread.wait(2000)
    w._compare_thread.quit()
    w._compare_thread.wait(2000)
    w._sftp_thread.quit()
    w._sftp_thread.wait(2000)
    w.close()
    qapp.processEvents()


def _pump_until(qapp, predicate, *, timeout_ms: int = 5000) -> bool:
    from PySide6.QtCore import QElapsedTimer, QEventLoop, QTimer

    timer = QElapsedTimer()
    timer.start()
    while timer.elapsed() < timeout_ms:
        qapp.processEvents()
        if predicate():
            return True
        loop = QEventLoop()
        QTimer.singleShot(20, loop.quit)
        loop.exec()
    return predicate()


def test_color_button_visible_and_sized(window: MainWindow) -> None:
    btn = window._color_button
    assert isinstance(btn, ColorButton)
    assert btn.isVisible()
    assert btn.width() > 20
    assert btn.height() > 10


def test_toggle_chrome_changes_mode(window: MainWindow, qapp) -> None:
    theme = window._theme
    before = theme.mode
    window._toggle_chrome()
    qapp.processEvents()
    assert theme.mode != before


def test_toggle_chrome_cycles_four_modes(window: MainWindow, qapp) -> None:
    theme = window._theme
    start = theme.mode
    for _ in range(4):
        window._toggle_chrome()
        qapp.processEvents()
    assert theme.mode == start


def test_four_panel_types(window: MainWindow) -> None:
    from ui.panels.assistant_panel import AssistantPanel
    from ui.panels.detail_panel import DetailPanel
    from ui.panels.navigator_panel import NavigatorPanel
    from ui.panels.query_panel import QueryPanel

    host = window.centralWidget()
    assert host is not None
    assert host.findChild(NavigatorPanel) is not None
    assert host.findChild(DetailPanel) is not None
    assert host.findChild(AssistantPanel) is not None
    assert host.findChild(QueryPanel) is not None


def test_detail_body_has_no_frame(window: MainWindow) -> None:
    from PySide6.QtWidgets import QFrame

    assert window._detail._body.frameShape() == QFrame.Shape.NoFrame


def test_query_panel_hidden(window: MainWindow) -> None:
    assert not window._query.isVisible()


def test_starts_dark_chrome(window: MainWindow) -> None:
    assert window._theme.mode == ChromeMode.DARK


def test_version_badge_visible(window: MainWindow) -> None:
    badge = window._host._version_badge
    assert badge.isVisible()
    text = badge.text()
    assert re.match(r"^\d+\.\d+\.\d+(-[\w.]+)?$", text) or re.match(
        r"^\d+\.\d+\.\d{6}\.\d{4}$", text
    )
    assert text == display_version()


def test_window_title_includes_version(window: MainWindow) -> None:
    assert display_version() in window.windowTitle()


def test_keys_save_persists(window: MainWindow, qapp, tmp_path) -> None:
    from adapters.local_key_store import LocalKeyStore

    ks = LocalKeyStore()
    key = tmp_path / "test_key"
    ks.generate(key, "rsa", bits=2048)

    p = window._controller.profile
    p.host = "sftp.example.com"
    p.user = "Daniel_test"
    p.private_key_path = key
    p.ssh_keys_dir = tmp_path

    window._open_keys()
    qapp.processEvents()
    window._assistant.keys_panel._user.setText("Daniel_test_config15")
    window._save_sftp_keys()
    assert window._controller.profile.user == "Daniel_test_config15"
    assert window._controller.profile.host == "sftp.example.com"
    assert window._controller.profile.profile_id == "Daniel_test_config15"


def test_keys_test_reenables_buttons(window: MainWindow, qapp, tmp_path) -> None:
    import os

    os.environ["PDE_DESKTOP_MOCK"] = "1"
    from adapters.local_key_store import LocalKeyStore
    from mocks.mock_sftp_browser import MockSftpBrowser
    from ui.app_controller import AppController

    ks = LocalKeyStore()
    key = tmp_path / "k"
    ks.generate(key, "rsa", bits=2048)
    store = window._controller._store
    ctrl = AppController(profile_store=store, key_store=ks, browser=MockSftpBrowser())
    ctrl.profile.host = "sftp.example.com"
    ctrl.profile.user = "u1"
    ctrl.profile.private_key_path = key
    ctrl.profile.ssh_keys_dir = tmp_path
    window._controller = ctrl

    window._open_keys()
    qapp.processEvents()
    window._test_sftp_keys()
    for _ in range(100):
        qapp.processEvents()
        if window._assistant.keys_panel._test.isEnabled():
            break
    assert window._assistant.keys_panel._test.isEnabled()


def test_keys_action_buttons_visible(window: MainWindow, qapp) -> None:
    window._open_keys()
    qapp.processEvents()
    keys = window._assistant.keys_panel
    assert keys._test.isVisible()
    assert keys._save.isVisible()
    assert keys._footer.isVisible()
    assert keys._test.width() > 40
    assert keys._save.width() > 40


def test_keys_mode_hides_browser_and_detail(window: MainWindow, qapp) -> None:
    assert window._top_split.isVisible()

    window._open_keys()
    qapp.processEvents()
    assert not window._top_split.isVisible()
    assert not window._navigator.isVisible()
    assert not window._detail.isVisible()

    window._leave_keys_mode()
    qapp.processEvents()
    assert window._top_split.isVisible()


def test_paths_mode_hides_browser_and_detail(window: MainWindow, qapp) -> None:
    assert window._top_split.isVisible()

    window._open_paths()
    qapp.processEvents()
    assert window._assistant.is_paths_mode()
    assert not window._top_split.isVisible()
    assert not window._navigator.isVisible()
    assert not window._detail.isVisible()

    window._leave_paths_mode()
    qapp.processEvents()
    assert window._top_split.isVisible()


def test_paths_save_restores_browser(window: MainWindow, qapp) -> None:
    window._open_paths()
    qapp.processEvents()
    assert not window._top_split.isVisible()

    window._save_paths_config()
    qapp.processEvents()
    assert not window._assistant.is_paths_mode()
    assert window._top_split.isVisible()


def test_main_menubar_hidden(window: MainWindow) -> None:
    assert not window.menuBar().isVisible()


def test_menu_actions_use_main_window_parent(window: MainWindow) -> None:
    mb = window._menu_bar
    help_label = tr("menu.help")
    version_prefix = tr("action.version").rstrip("…")[:5]
    for top in mb.actions():
        if top.text() != help_label:
            continue
        for sub in top.menu().actions():
            if version_prefix in sub.text():
                assert sub.parent() is mb
                return
    raise AssertionError("Versión action not found")


def _menu_action(menubar, menu_label: str, action_label: str):
    for top in menubar.actions():
        if menu_label not in top.text():
            continue
        menu = top.menu()
        if menu is None:
            continue
        for action in menu.actions():
            if action_label in action.text():
                return action
    raise AssertionError(f"{action_label!r} not found under {menu_label!r}")


def test_config_llaves_from_menu_bar(window: MainWindow, qapp) -> None:
    keys = _menu_action(window._menu_bar, tr("menu.settings"), tr("action.keys").rstrip("…"))
    keys.trigger()
    qapp.processEvents()
    assert window._assistant.is_keys_mode()


def test_file_connect_from_menu_bar(window: MainWindow, qapp) -> None:
    connect = _menu_action(window._menu_bar, tr("menu.file"), tr("action.connect"))
    connect.trigger()
    qapp.processEvents()
    expected = tr(
        "msg.connecting",
        host=tr("detail.dash"),
        user=tr("detail.dash"),
    ).split("\n", 1)[0]
    assert expected in window._detail._body.toPlainText()


def test_version_dialog_uses_main_window(window: MainWindow, qapp, monkeypatch) -> None:
    from PySide6.QtWidgets import QDialog

    owners: list[object] = []

    def fake_exec(self) -> int:
        owners.append(self.parent())
        return 0

    monkeypatch.setattr(QDialog, "exec", fake_exec)
    version = _menu_action(
        window._menu_bar,
        tr("menu.help"),
        tr("action.version").rstrip("…")[:5],
    )
    version.trigger()
    qapp.processEvents()
    assert owners == [window]


def test_compare_result_shows_in_assistant(window: MainWindow, qapp) -> None:
    from core.compare_types import CompareFileSide, CompareResult

    window._present_compare_result(
        CompareResult(
            status="diff",
            file_a=CompareFileSide(label="a.tsv", path=Path("a.tsv"), file_size=10, row_count=1),
            file_b=CompareFileSide(label="b.tsv", path=Path("b.tsv"), file_size=20, row_count=2),
            only_in_b=1,
        )
    )
    qapp.processEvents()
    assert window._assistant.is_compare_mode()
    assert window._detail.is_local_browser_active() or not window._file_manager_active


def test_compare_cancel_hides_stop_button(window: MainWindow, qapp) -> None:
    window._compare_busy = True
    window._set_operation_cancel_visible(True)
    window._cancel_active_operation()
    qapp.processEvents()
    assert window._compare_cancel_requested
    assert not window._detail._cancel.isVisible()


def test_compare_abort_restores_local_b(window: MainWindow, qapp) -> None:
    window._enter_file_manager()
    window._browser_mode = BrowserLayoutMode.LOCAL_LOCAL
    window._apply_browser_mode(BrowserLayoutMode.LOCAL_LOCAL)
    qapp.processEvents()
    assert window._detail.is_local_browser_active()

    window._detail.show_message("ABORT — A vs B\nLas columnas no coinciden.", force=True)
    assert not window._detail.is_local_browser_active()

    window._restore_file_manager_detail_view()
    qapp.processEvents()
    assert window._detail.is_local_browser_active()


def test_browser_mode_reclick_reapplies_layout(window: MainWindow, qapp) -> None:
    window._enter_file_manager()
    window._browser_mode = BrowserLayoutMode.SFTP_LOCAL
    window._apply_browser_mode(BrowserLayoutMode.SFTP_LOCAL)
    window._detail.show_message("stuck error", force=True)
    qapp.processEvents()

    window._browser_mode_bar._set_mode(BrowserLayoutMode.SFTP_LOCAL)
    qapp.processEvents()
    assert window._detail.is_local_browser_active()


def test_file_manager_opens_local_panel(window: MainWindow, qapp) -> None:
    action = _menu_action(
        window._menu_bar,
        tr("menu.file"),
        tr("action.file_manager"),
    )
    action.trigger()
    qapp.processEvents()
    assert window._file_manager_active
    assert window._detail.is_local_browser_active()
    assert not window._detail._title_row.isVisible()
    assert window._detail.local_files._title.isVisible()
    action.trigger()
    qapp.processEvents()
    assert not window._file_manager_active
    assert not window._detail.is_local_browser_active()


def test_file_manager_visualize_local_csv(window: MainWindow, qapp, tmp_path) -> None:
    downloads = tmp_path / "downloads"
    downloads.mkdir()
    csv = downloads / "sample.csv"
    csv.write_text("a,b\n1,2\n3,4\n", encoding="utf-8")
    window._controller.profile.download_dir = downloads

    action = _menu_action(
        window._menu_bar,
        tr("menu.file"),
        tr("action.file_manager"),
    )
    action.trigger()
    qapp.processEvents()

    window._pending_local_file = {
        "absolute_path": str(csv),
        "name": "sample.csv",
    }
    window._visualize_local_file()
    assert _pump_until(qapp, lambda: window._visualize_mode_active)

    assert window._visualize_mode_active
    assert window._detail._stack.currentIndex() == window._detail._PAGE_DATA
    assert not window._browser_left.isVisible()
    assert not window._assistant.isVisible()
    assert not window._browser_mode_bar.isVisible()
    top_sizes = window._top_split.sizes()
    assert top_sizes[0] == 0
    assert top_sizes[1] > 0
    root_sizes = window._root_split.sizes()
    assert root_sizes[0] > 0
    assert root_sizes[1] == 0

    window._leave_visualize_mode()
    qapp.processEvents()
    assert not window._visualize_mode_active
    assert window._browser_left.isVisible()
    assert window._assistant.isVisible()
    assert window._browser_mode_bar.isVisible()


def test_file_manager_visualize_local_txt_has_close(window: MainWindow, qapp, tmp_path) -> None:
    downloads = tmp_path / "downloads"
    downloads.mkdir()
    txt = downloads / "DIFF20260716165500.txt"
    txt.write_text("line-a\nline-b\n", encoding="utf-8")
    window._controller.profile.download_dir = downloads

    action = _menu_action(
        window._menu_bar,
        tr("menu.file"),
        tr("action.file_manager"),
    )
    action.trigger()
    qapp.processEvents()

    window._pending_local_file = {
        "absolute_path": str(txt),
        "name": txt.name,
    }
    window._visualize_local_file()
    qapp.processEvents()

    assert window._visualize_mode_active
    assert window._detail._text_view_mode
    assert window._detail._close_view.isVisible()
    assert not window._browser_left.isVisible()

    window._detail._close_view.click()
    qapp.processEvents()

    assert not window._visualize_mode_active
    assert window._file_manager_active
    assert window._detail.is_local_browser_active()
    assert window._browser_left.isVisible()


def test_file_manager_refreshes_after_download_in_view(window: MainWindow, qapp, tmp_path) -> None:
    downloads = tmp_path / "downloads"
    downloads.mkdir()
    (downloads / "existing.psv").write_text("a|b\n1|2\n", encoding="utf-8")
    window._controller.profile.download_dir = downloads

    action = _menu_action(
        window._menu_bar,
        tr("menu.file"),
        tr("action.file_manager"),
    )
    action.trigger()
    qapp.processEvents()
    assert window._detail.local_files._table.rowCount() >= 2  # .. + existing

    new_file = downloads / "new_from_sftp.psv"
    new_file.write_text("x|y\n3|4\n", encoding="utf-8")
    window._refresh_local_if_watching(new_file)
    qapp.processEvents()

    names = {
        window._detail.local_files._item_text(row, 0).rstrip("/")
        for row in range(window._detail.local_files._table.rowCount())
    }
    assert "new_from_sftp.psv" in names


def test_connect_from_menu_lists_navigator(window: MainWindow, qapp, tmp_path) -> None:
    import os

    os.environ["PDE_DESKTOP_MOCK"] = "1"
    from adapters.local_key_store import LocalKeyStore
    from mocks.mock_sftp_browser import MockSftpBrowser
    from ui.app_controller import AppController

    ks = LocalKeyStore()
    key = tmp_path / "k"
    ks.generate(key, "rsa", bits=2048)
    store = window._controller._store
    ctrl = AppController(profile_store=store, key_store=ks, browser=MockSftpBrowser())
    ctrl.profile.host = "sftp.example.com"
    ctrl.profile.user = "u1"
    ctrl.profile.private_key_path = key
    ctrl.profile.ssh_keys_dir = tmp_path
    window._controller = ctrl

    window._connect_sftp()
    for _ in range(100):
        qapp.processEvents()
        if window._navigator._table.rowCount() > 0:
            break

    assert window._navigator._table.rowCount() == 3
    assert "u1 /" in window._navigator._path_label.text()
