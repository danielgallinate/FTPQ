"""Tests — conversión de zona horaria."""
from __future__ import annotations

from pathlib import Path

from core.analysis_types import ColumnSummary, TabularDataset
from core.timezone_transform import (
    TimezoneTransformConfig,
    apply_timezone_transform,
    column_name_suggests_utc,
    convert_datetime_cell,
    guess_datetime_columns,
    is_date_only_cell,
)


def _date_only_dataset() -> TabularDataset:
    return TabularDataset(
        local_path=Path("/tmp/date-only.csv"),
        columns=(
            ColumnSummary(
                name="AUTH_START_DATE",
                dtype="string",
                null_count=0,
                unique_count=2,
            ),
            ColumnSummary(
                name="EXTRACT_DATE_TIME_UTC",
                dtype="string",
                null_count=0,
                unique_count=1,
            ),
        ),
        rows=(
            ("2024-04-28", "2026-08-13 01:06:12.232000"),
            ("2025-12-01", "2026-08-13 01:06:12.232000"),
        ),
        total_rows=2,
        display_truncated=False,
    )


def _sample_dataset() -> TabularDataset:
    return TabularDataset(
        local_path=Path("/tmp/sample.csv"),
        columns=(
            ColumnSummary(
                name="START_DATE_UTC",
                dtype="object",
                null_count=0,
                unique_count=2,
            ),
            ColumnSummary(
                name="STATUS",
                dtype="object",
                null_count=0,
                unique_count=1,
            ),
        ),
        rows=(
            ("2025-11-25 22:45:00", "A"),
            ("2025-11-25 18:00:00", "B"),
        ),
        total_rows=2,
        display_truncated=False,
    )


def test_column_name_suggests_utc():
    assert column_name_suggests_utc("START_DATE_UTC")
    assert not column_name_suggests_utc("STATUS")


def test_guess_datetime_columns():
    dataset = _sample_dataset()
    guessed = guess_datetime_columns(dataset)
    assert "START_DATE_UTC" in guessed
    assert "STATUS" not in guessed


def test_convert_datetime_cell_utc_to_new_york():
    converted = convert_datetime_cell(
        "2025-11-25 22:45:00",
        source_tz="UTC",
        target_tz="America/New_York",
    )
    assert converted == "2025-11-25 17:45:00"


def test_is_date_only_cell():
    assert is_date_only_cell("2024-04-28")
    assert is_date_only_cell("04/28/2024")
    assert not is_date_only_cell("2024-04-28 00:00:00")
    assert not is_date_only_cell("")
    assert not is_date_only_cell("A")


def test_date_only_column_is_not_guessed():
    guessed = guess_datetime_columns(_date_only_dataset())
    assert "AUTH_START_DATE" not in guessed
    assert "EXTRACT_DATE_TIME_UTC" in guessed


def test_convert_leaves_date_only_untouched():
    converted = convert_datetime_cell(
        "2024-04-28",
        source_tz="UTC",
        target_tz="America/New_York",
    )
    assert converted == "2024-04-28"


def test_apply_timezone_transform_keeps_date_only_column():
    dataset = _date_only_dataset()
    config = TimezoneTransformConfig(
        source_tz="UTC",
        target_tz="America/New_York",
        columns=frozenset({"AUTH_START_DATE", "EXTRACT_DATE_TIME_UTC"}),
    )
    transformed = apply_timezone_transform(dataset, config)
    assert transformed.rows[0][0] == "2024-04-28"
    assert transformed.rows[0][1] == "2026-08-12 21:06:12.232"


def test_apply_timezone_transform_selected_columns_only():
    dataset = _sample_dataset()
    config = TimezoneTransformConfig(
        source_tz="UTC",
        target_tz="America/New_York",
        columns=frozenset({"START_DATE_UTC"}),
    )
    transformed = apply_timezone_transform(dataset, config)
    assert transformed.rows[0][0] == "2025-11-25 17:45:00"
    assert transformed.rows[0][1] == "A"
