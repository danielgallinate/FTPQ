"""Tests para copiar selección de tablas."""
from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import Qt
from PySide6.QtGui import QMouseEvent, QStandardItem, QStandardItemModel
from PySide6.QtWidgets import QApplication, QTableView

from ui.widgets.table_clipboard import (
    copy_view_cell,
    indices_to_tsv,
    install_table_double_click_copy,
)


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def test_indices_to_tsv_single_row():
    model = QStandardItemModel(2, 3)
    model.setItem(0, 0, QStandardItem("a"))
    model.setItem(0, 1, QStandardItem("b"))
    indexes = [model.index(0, 0), model.index(0, 1)]
    assert indices_to_tsv(indexes) == "a\tb"


def test_indices_to_tsv_multiple_rows():
    model = QStandardItemModel(2, 2)
    model.setItem(0, 0, QStandardItem("r0c0"))
    model.setItem(0, 1, QStandardItem("r0c1"))
    model.setItem(1, 0, QStandardItem("r1c0"))
    indexes = [
        model.index(0, 0),
        model.index(0, 1),
        model.index(1, 0),
    ]
    assert indices_to_tsv(indexes) == "r0c0\tr0c1\nr1c0"


def test_copy_view_cell(qapp: QApplication):
    model = QStandardItemModel(1, 1)
    model.setItem(0, 0, QStandardItem("hello@example.com"))
    view = QTableView()
    view.setModel(model)
    copied = copy_view_cell(view, model.index(0, 0))
    assert copied == "hello@example.com"
    assert qapp.clipboard().text() == "hello@example.com"


def test_double_click_copy(qapp: QApplication):
    model = QStandardItemModel(1, 1)
    model.setItem(0, 0, QStandardItem("cell-value"))
    view = QTableView()
    view.resize(320, 120)
    view.setModel(model)
    view.show()
    copied: list[bool] = []

    install_table_double_click_copy(view, on_copied=lambda: copied.append(True))
    qapp.processEvents()

    index = model.index(0, 0)
    pos = view.visualRect(index).center()
    viewport = view.viewport()
    global_pos = viewport.mapToGlobal(pos)
    event = QMouseEvent(
        QMouseEvent.Type.MouseButtonDblClick,
        pos,
        global_pos,
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    qapp.sendEvent(viewport, event)
    qapp.processEvents()

    assert qapp.clipboard().text() == "cell-value"
    assert copied == [True]
