"""Smoke SftpSessionWorker — connect/list/visualize serializados sin SFTP real."""
from __future__ import annotations

import os
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QThread
from PySide6.QtWidgets import QApplication

from adapters.local_key_store import LocalKeyStore
from core.app_profile import AppProfile
from core.profile_store import JsonProfileStore
from core.result import Ok
from mocks.mock_sftp_browser import MockSftpBrowser
from ui.app_controller import AppController
from ui.shell.sftp_session_worker import SftpSessionWorker


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def _make_controller(tmp_path: Path) -> AppController:
    keys = LocalKeyStore()
    private = tmp_path / "test_key"
    keys.generate(private, "rsa", bits=2048)

    profile = AppProfile.default()
    profile.host = "sftp.example.com"
    profile.user = "Daniel_test_config10"
    profile.private_key_path = private
    profile.ssh_keys_dir = tmp_path

    store = JsonProfileStore(tmp_path / "profiles")
    return AppController(
        profile_store=store,
        key_store=keys,
        browser=MockSftpBrowser(),
    )


def _run_worker_op(
    qapp: QApplication,
    worker: SftpSessionWorker,
    emit,
    *,
    max_ticks: int = 200,
) -> object:
    results: list[object] = []
    worker.finished.connect(results.append)
    emit()
    for _ in range(max_ticks):
        qapp.processEvents()
        if results:
            return results[-1]
    raise AssertionError("worker no emitió finished a tiempo")


@pytest.fixture
def session_worker(qapp, tmp_path):
    controller = _make_controller(tmp_path)
    thread = QThread()
    worker = SftpSessionWorker(controller)
    worker.moveToThread(thread)
    thread.start()
    yield worker, controller, thread
    thread.quit()
    thread.wait(2000)


def test_session_worker_connect_list_visualize(
    qapp: QApplication, session_worker
) -> None:
    worker, controller, _thread = session_worker
    profile = controller.profile

    connect_result = _run_worker_op(
        qapp, worker, lambda: worker.connect_requested.emit(profile)
    )
    assert isinstance(connect_result, Ok)

    list_result = _run_worker_op(
        qapp, worker, lambda: worker.list_requested.emit("scheduled")
    )
    assert isinstance(list_result, Ok)

    visualize_result = _run_worker_op(
        qapp,
        worker,
        lambda: worker.visualize_requested.emit("example_extract_20260701.csv"),
    )
    assert isinstance(visualize_result, Ok)
    view = visualize_result.value
    assert view.tabular is True
    assert view.local_path.is_file()


def test_analysis_worker_emits_dataset(qapp: QApplication, tmp_path: Path) -> None:
    pytest.importorskip("pandas")
    from PySide6.QtCore import QThread

    from ui.shell.analysis_worker import AnalysisWorker

    csv_path = tmp_path / "sample.csv"
    csv_path.write_text("id,value\n1,10\n2,20\n", encoding="utf-8")

    thread = QThread()
    worker = AnalysisWorker()
    worker.moveToThread(thread)
    thread.start()

    results: list[object] = []
    worker.analyze_requested.connect(worker._do_analyze)
    worker.finished.connect(results.append)
    worker.analyze_requested.emit(str(csv_path), 5000)
    for _ in range(200):
        qapp.processEvents()
        if results:
            break

    thread.quit()
    thread.wait(2000)
    assert results
    assert isinstance(results[-1], Ok)
    assert results[-1].value.total_rows == 2


def test_analysis_worker_samples_files_over_byte_limit(
    qapp: QApplication, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    pytest.importorskip("pandas")
    from core.analysis_limits import UI_SAMPLE_MAX_ROWS
    from ui.shell import analysis_worker as worker_module

    csv_path = tmp_path / "big.csv"
    csv_path.write_text("id\n" + "".join(f"{i}\n" for i in range(50)), encoding="utf-8")

    captured: dict[str, object] = {}

    def fake_analyze(path, *, max_display_rows, sample_rows=None, **kwargs):
        captured["sample_rows"] = sample_rows
        return Ok(object())

    monkeypatch.setattr(worker_module, "analyze_tabular_file", fake_analyze)

    worker = worker_module.AnalysisWorker()
    worker._do_analyze(str(csv_path), 10_000_000)

    assert captured["sample_rows"] == UI_SAMPLE_MAX_ROWS
