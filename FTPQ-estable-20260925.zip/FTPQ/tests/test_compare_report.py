"""Tests export path y líneas en informe compare."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest

from adapters.pandas_compare import compare_tabular_files
from core.app_profile import AppProfile
from core.compare_export_paths import suggest_compare_export_path
from core.result import Ok
from ui.compare_report import default_export_path, format_compare_result


@pytest.fixture
def profile() -> AppProfile:
    return AppProfile.default()


def test_export_path_suffix_when_exists(tmp_path: Path) -> None:
    clock = datetime(2026, 7, 16, 16, 33)
    first = suggest_compare_export_path(tmp_path, "diff", clock=clock)
    assert first.name == "DIFF20260716163300.txt"
    first.write_text("x", encoding="utf-8")
    second = suggest_compare_export_path(tmp_path, "diff", clock=clock)
    assert second.name == "DIFF20260716163301.txt"


def test_export_path_match_prefix(tmp_path: Path) -> None:
    path = default_export_path(
        _fake_result("match"),
        tmp_path,
    )
    assert path.name.startswith("MATCH")


def test_examples_include_line_numbers(tmp_path: Path, profile: AppProfile) -> None:
    pytest.importorskip("pandas")
    path_a = tmp_path / "a.csv"
    path_b = tmp_path / "b.csv"
    path_a.write_text("id,name\n1,alpha\n2,beta\n", encoding="utf-8")
    path_b.write_text("id,name\n1,alpha\n2,gamma\n3,delta\n", encoding="utf-8")

    result = compare_tabular_files(
        path_a, path_b, label_a="a.csv", label_b="b.csv", profile=profile
    )
    assert isinstance(result, Ok)
    report = format_compare_result(result.value)
    assert "B L3:" in report or "B L4:" in report
    assert result.value.row_delta != 0
    assert "Resumen" in report or "Summary" in report


def _fake_result(status: str):
    from core.compare_types import CompareFileSide, CompareResult

    return CompareResult(
        status=status,
        file_a=CompareFileSide(label="a", path=Path("a.csv"), file_size=1),
        file_b=CompareFileSide(label="b", path=Path("b.csv"), file_size=2),
    )
