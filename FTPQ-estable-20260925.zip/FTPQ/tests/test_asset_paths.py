"""Tests resolución segura de rutas en assets."""
from __future__ import annotations

from pathlib import Path

from ui.theme.asset_paths import resolve_pref_path


def test_resolve_pref_path_accepts_relative_under_root(tmp_path: Path) -> None:
    root = tmp_path / "assets"
    root.mkdir()
    target = root / "icons" / "app.ico"
    target.parent.mkdir()
    target.write_bytes(b"x")

    resolved = resolve_pref_path(root, "icons/app.ico")
    assert resolved == target.resolve()


def test_resolve_pref_path_rejects_escape(tmp_path: Path) -> None:
    root = tmp_path / "assets"
    root.mkdir()
    outside = tmp_path / "outside.ico"
    outside.write_bytes(b"x")

    assert resolve_pref_path(root, "../outside.ico") is None
