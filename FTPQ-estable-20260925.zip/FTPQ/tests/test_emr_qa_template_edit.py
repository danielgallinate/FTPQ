"""Tests — edición tabular de template."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


@pytest.fixture
def edit_modules():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from emrqa.validation_models import DuplicateRecordError
    from shell.template_edit import (
        apply_table_rows_to_template,
        restore_template,
        snapshot_template,
    )
    from shell.template_factory import build_empty_template

    yield apply_table_rows_to_template, restore_template, snapshot_template, build_empty_template, DuplicateRecordError


def test_apply_and_restore_table_rows(edit_modules):
    apply_table_rows, restore_template, snapshot_template, build_empty_template, DuplicateRecordError = edit_modules
    template = build_empty_template(
        name="Edit me",
        column_names=["id", "name"],
        key_column_names=["id"],
    )
    template.append_record({"id": "1", "name": "Alice"})
    template.append_record({"id": "2", "name": "Bob"})
    baseline = snapshot_template(template)

    field_id = template.header.fields[0].field_id
    name_id = template.header.fields[1].field_id
    apply_table_rows(
        template,
        [
            {field_id: "1", name_id: "Alice Updated"},
            {field_id: "2", name_id: "Bob"},
        ],
    )
    assert template.minibase.records[0].values[name_id] == "Alice Updated"

    restore_template(template, baseline)
    assert template.minibase.records[0].values[name_id] == "Alice"

    with pytest.raises(DuplicateRecordError):
        apply_table_rows(
            template,
            [
                {field_id: "1", name_id: "Alice"},
                {field_id: "1", name_id: "Duplicate"},
            ],
        )
