"""Tests log local de la app."""
from __future__ import annotations

from core import app_log


def test_log_line_writes_to_custom_file(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr("core.app_log.user_data_dir", lambda: tmp_path)
    log_file = tmp_path / "app.log"

    app_log.log_event("prueba ok")

    text = log_file.read_text(encoding="utf-8")
    assert "prueba ok" in text


def test_log_exception_includes_traceback(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr("core.app_log.user_data_dir", lambda: tmp_path)
    log_file = tmp_path / "app.log"

    try:
        raise RuntimeError("fallo simulado")
    except RuntimeError as exc:
        app_log.log_exception("test", exc)

    text = log_file.read_text(encoding="utf-8")
    assert "fallo simulado" in text
    assert "RuntimeError" in text


def test_session_lock_detects_unclean_shutdown(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr("core.app_log.user_data_dir", lambda: tmp_path)
    lock_file = tmp_path / "session.lock"

    assert not app_log.previous_session_unclean()
    app_log.mark_session_started()
    assert app_log.previous_session_unclean()
    app_log.mark_session_stopped()
    assert not app_log.previous_session_unclean()
