"""Tests — modo build minibase EMR QA."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


@pytest.fixture(scope="module")
def emr_modules():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))
    from emrqa.validation_storage import slugify_template_name, template_filename
    from shell.minibase_rows import append_marked_rows
    from shell.template_factory import build_empty_template

    return {
        "slugify_template_name": slugify_template_name,
        "template_filename": template_filename,
        "append_marked_rows": append_marked_rows,
        "build_empty_template": build_empty_template,
    }


def test_template_filename_from_name(emr_modules):
    template = emr_modules["build_empty_template"](
        name="Correos",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    assert emr_modules["template_filename"](template) == "correos.json"
    assert emr_modules["slugify_template_name"]("Correos QA") == "correos_qa"


def test_append_marked_rows(tmp_path, emr_modules):
    from core.analysis_types import ColumnSummary, TabularDataset

    dataset = TabularDataset(
        local_path=tmp_path / "t.csv",
        columns=[
            ColumnSummary(name="Email", dtype="text", null_count=0, unique_count=2),
            ColumnSummary(name="Name", dtype="text", null_count=0, unique_count=2),
        ],
        rows=[
            ("a@x.com", "Ada"),
            ("b@x.com", "Bob"),
        ],
        total_rows=2,
        display_truncated=False,
    )
    template = emr_modules["build_empty_template"](
        name="Demo",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    added, errors = emr_modules["append_marked_rows"](
        template,
        dataset,
        {0, 1},
        file_path=tmp_path / "t.csv",
    )
    assert added == 2
    assert not errors
    assert len(template.minibase.records) == 2
    assert template.minibase.records[0].source.row_index == 0
