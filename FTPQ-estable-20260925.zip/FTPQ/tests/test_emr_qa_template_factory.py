"""Tests — template_factory EMR QA."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


def test_build_empty_template_and_key_update():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from shell.template_factory import build_empty_template, set_primary_key_fields

    template = build_empty_template(
        name="Demo",
        column_names=["a", "b", "c"],
        key_column_names=["a"],
    )
    assert template.header.name == "Demo"
    assert len(template.minibase.records) == 0
    assert template.header.primary_key() is not None
    assert template.header.primary_key().field_ids == [template.header.fields[0].field_id]

    field_b = template.header.fields[1].field_id
    set_primary_key_fields(template, [template.header.fields[0].field_id, field_b])
    assert len(template.header.primary_key().field_ids) == 2


def test_cannot_set_all_fields_as_key():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from shell.template_factory import build_empty_template, set_primary_key_fields

    template = build_empty_template(
        name="Demo2",
        column_names=["a", "b", "c"],
        key_column_names=["a"],
    )
    all_ids = [field.field_id for field in template.header.fields]
    with pytest.raises(ValueError, match="fuera de la llave"):
        set_primary_key_fields(template, all_ids)
