"""Tests política pandas vs texto y lectura parcial."""
from __future__ import annotations

from pathlib import Path

from core.app_profile import AppProfile
from core.file_view import read_text_head_preview, read_visualize_file
from core.result import Ok
from core.visualization_policy import (
    PANDAS_HARD_MAX_BYTES,
    tabular_uses_pandas,
)


def test_auto_mode_uses_pandas_under_threshold() -> None:
    profile = AppProfile.default()
    profile.tabular_mode = "auto"
    profile.pandas_max_bytes = 52_428_800
    assert tabular_uses_pandas(profile, 1_000_000) is True


def test_auto_mode_skips_pandas_over_threshold() -> None:
    profile = AppProfile.default()
    profile.tabular_mode = "auto"
    profile.pandas_max_bytes = 52_428_800
    assert tabular_uses_pandas(profile, 60_000_000) is False


def test_text_only_never_uses_pandas() -> None:
    profile = AppProfile.default()
    profile.tabular_mode = "text_only"
    assert tabular_uses_pandas(profile, 100) is False


def test_full_mode_uses_pandas_until_hard_cap() -> None:
    profile = AppProfile.default()
    profile.tabular_mode = "full"
    assert tabular_uses_pandas(profile, 100_000_000) is True
    assert tabular_uses_pandas(profile, PANDAS_HARD_MAX_BYTES + 1) is False


def test_read_text_head_preview_reads_partial(tmp_path: Path) -> None:
    path = tmp_path / "big.csv"
    path.write_text("h1,h2\n" + "x,y\n" * 5000, encoding="utf-8")
    result = read_text_head_preview(path, max_read_bytes=256, text_fallback=True)
    assert isinstance(result, Ok)
    view = result.value
    assert view.text_fallback is True
    assert view.file_size == path.stat().st_size
    assert len(view.content.encode("utf-8")) <= 256 + 50
    assert view.display_truncated is True


def test_read_visualize_large_file_uses_head(tmp_path: Path) -> None:
    path = tmp_path / "huge.txt"
    payload = ("line\n" * 100_000).encode("utf-8")
    path.write_bytes(payload)
    assert path.stat().st_size > 1024

    result = read_visualize_file(path, max_bytes=1024, max_display_lines=10)
    assert isinstance(result, Ok)
    view = result.value
    assert view.text_fallback is True
    assert view.content.count("\n") <= 10


def test_profile_persists_tabular_policy(tmp_path) -> None:
    from core.profile_store import JsonProfileStore

    store = JsonProfileStore(tmp_path)
    profile = AppProfile.default()
    profile.tabular_mode = "text_only"
    profile.pandas_max_bytes = 104_857_600
    store.save(profile)

    loaded = store.load()
    assert loaded.tabular_mode == "text_only"
    assert loaded.pandas_max_bytes == 104_857_600
