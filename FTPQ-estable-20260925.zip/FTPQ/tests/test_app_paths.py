"""Tests rutas portable vs instalado."""
from __future__ import annotations

from pathlib import Path

from core import app_paths


def test_portable_root_from_marker(tmp_path: Path) -> None:
    marker = tmp_path / app_paths.PORTABLE_MARKER
    marker.write_text("portable\n", encoding="utf-8")
    nested = tmp_path / "PDE Desktop.app" / "Contents" / "MacOS"
    nested.mkdir(parents=True)
    assert app_paths.find_portable_root(nested) == tmp_path


def test_user_data_dir_portable(tmp_path: Path, monkeypatch) -> None:
    marker = tmp_path / app_paths.PORTABLE_MARKER
    marker.write_text("portable\n", encoding="utf-8")
    monkeypatch.setattr(app_paths, "portable_root", lambda: tmp_path)
    data = app_paths.user_data_dir()
    assert data == tmp_path / "data"
    assert data.is_dir()


def test_resolve_profile_path_relative_to_portable(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setattr(app_paths, "portable_root", lambda: tmp_path)
    resolved = app_paths.resolve_profile_path("data/downloads")
    assert resolved == (tmp_path / "data/downloads").resolve()


def test_path_for_json_portable_relative(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setattr(app_paths, "portable_root", lambda: tmp_path)
    path = tmp_path / "data" / "downloads"
    path.mkdir(parents=True)
    assert app_paths.path_for_json(path) == "data/downloads"
