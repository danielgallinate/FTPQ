"""Tests progreso de validación."""
from __future__ import annotations

from shell.validation_progress import PROGRESS_ROW_STEP, emit_row_progress


def test_emit_row_progress_throttles() -> None:
    seen: list[tuple[int, int]] = []

    def capture(current: int, total: int) -> None:
        seen.append((current, total))

    total = PROGRESS_ROW_STEP * 3 + 1
    for row in range(1, total + 1):
        emit_row_progress(capture, row, total)

    assert seen[0] == (1, total)
    assert seen[-1] == (total, total)
    assert len(seen) < total
