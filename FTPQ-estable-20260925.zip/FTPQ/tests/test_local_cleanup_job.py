"""Tests — job local_cleanup (borra coincidencias locales; el CI decide cuándo)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]


def _write_job(path: Path, **overrides) -> Path:
    payload = {
        "schema_version": 1,
        "kind": "local_cleanup",
        "name": "purge-csv",
        "local_dir": str(path.parent / "work"),
        "patterns": ["*.csv"],
    }
    payload.update(overrides)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return path


def test_load_rejects_wrong_kind(tmp_path: Path) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.local_cleanup_job import load_job

    job_path = _write_job(tmp_path / "bad.json", kind="sftp_fetch")
    with pytest.raises(ValueError, match="local_cleanup"):
        load_job(job_path)


def test_deletes_matching_files_keeps_logs(tmp_path: Path) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.local_cleanup_job import load_job
    from local_jobs.cleanup_runner import run_local_cleanup

    work = tmp_path / "work"
    work.mkdir()
    (work / "a.csv").write_text("1\n", encoding="utf-8")
    (work / "b.tsv").write_text("2\n", encoding="utf-8")
    log = work / "run.log"
    log.write_text("kept\n", encoding="utf-8")
    report = work / "schema.json"
    report.write_text("{}\n", encoding="utf-8")
    job_path = _write_job(tmp_path / "c.json", local_dir=str(work), patterns=["*.csv"])
    result = run_local_cleanup(load_job(job_path))
    assert result.ok
    assert not (work / "a.csv").exists()
    assert (work / "b.tsv").is_file()
    assert log.read_text(encoding="utf-8") == "kept\n"
    assert report.is_file()
    assert result.deleted == ["a.csv"]


def test_refuses_path_outside_local_dir(tmp_path: Path) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.local_cleanup_job import load_job
    from local_jobs.cleanup_runner import run_local_cleanup

    work = tmp_path / "work"
    work.mkdir()
    job_path = _write_job(
        tmp_path / "escape.json",
        local_dir=str(work),
        patterns=["../secret.csv"],
    )
    result = run_local_cleanup(load_job(job_path))
    assert not result.ok
    assert result.expects[0]["status"] == "REFUSED"


def test_cli_local_dir_and_error_file(tmp_path: Path) -> None:
    job_path = _write_job(tmp_path / "cli.json", local_dir="", patterns=["*.csv"])
    dest = tmp_path / "param"
    dest.mkdir()
    (dest / "x.csv").write_text("x\n", encoding="utf-8")
    json_out = tmp_path / "out.json"
    script = REPO_ROOT / "scripts" / "run_local_cleanup.sh"
    proc = subprocess.run(
        [
            str(script),
            str(job_path),
            "--local-dir",
            str(dest),
            "--json-out",
            str(json_out),
            "--quiet",
        ],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr
    assert not (dest / "x.csv").exists()
    data = json.loads(json_out.read_text(encoding="utf-8"))
    assert data["ok"] is True


def test_cli_writes_error_file_when_dir_missing(tmp_path: Path) -> None:
    job_path = _write_job(
        tmp_path / "missing.json",
        local_dir=str(tmp_path / "no-such-dir"),
        patterns=["*.csv"],
    )
    error_out = tmp_path / "error.json"
    script = REPO_ROOT / "scripts" / "run_local_cleanup.sh"
    proc = subprocess.run(
        [
            str(script),
            str(job_path),
            "--error-out",
            str(error_out),
            "--quiet",
        ],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 2
    payload = json.loads(error_out.read_text(encoding="utf-8"))
    assert payload["ok"] is False
    assert payload["exit_code"] == 2
    assert "local_dir" in payload["error"].lower() or "not found" in payload["error"].lower() or "exist" in payload["error"].lower()
