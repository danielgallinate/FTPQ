"""Tests — ordenación del grid en tab QA."""
from __future__ import annotations

from ui.widgets.qa_grid_sort import (
    QaGridSortMode,
    validation_cell_bucket,
    validation_sort_key,
)


def test_sort_mode_cycle():
    mode = QaGridSortMode.ASCENDING
    mode = mode.next_mode()
    assert mode == QaGridSortMode.DESCENDING
    mode = mode.next_mode()
    assert mode == QaGridSortMode.GREEN_RED_NEUTRAL
    mode = mode.next_mode()
    assert mode == QaGridSortMode.RED_GREEN_NEUTRAL
    mode = mode.next_mode()
    assert mode == QaGridSortMode.ASCENDING


def test_validation_sort_by_status():
    green = validation_cell_bucket(in_passed=True, in_failed=False, in_conflict=False)
    red = validation_cell_bucket(in_passed=False, in_failed=True, in_conflict=False)
    neutral = validation_cell_bucket(in_passed=False, in_failed=False, in_conflict=False)
    keys = [
        validation_sort_key(bucket=green, text="a", mode=QaGridSortMode.GREEN_RED_NEUTRAL),
        validation_sort_key(bucket=red, text="b", mode=QaGridSortMode.GREEN_RED_NEUTRAL),
        validation_sort_key(bucket=neutral, text="c", mode=QaGridSortMode.GREEN_RED_NEUTRAL),
    ]
    assert keys[0] < keys[1]
    assert keys[1] < keys[2]
