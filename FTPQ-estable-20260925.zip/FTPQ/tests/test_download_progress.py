"""Tests ThrottledDownloadProgress."""
from __future__ import annotations

from core.download_progress import ThrottledDownloadProgress


def test_throttled_progress_emits_final() -> None:
    seen: list[tuple[int, int]] = []
    progress = ThrottledDownloadProgress(lambda t, tot: seen.append((t, tot)), min_interval_seconds=10.0)
    progress(100, 1000)
    progress(500, 1000)
    progress(1000, 1000)

    assert seen[-1] == (1000, 1000)
    assert len(seen) >= 2
