"""Tests — catálogos tabulares locales."""
from __future__ import annotations

import pytest

from core.catalog_store import (
    CatalogStore,
    build_catalog_displays,
    create_catalog_from_dataset,
    dedupe_rows,
    resolve_catalog_compare_value,
)
from core.catalog_types import CatalogKeyConflictError, ColumnCatalogBinding


@pytest.fixture
def catalog_kb(monkeypatch, tmp_path):
    kb_root = tmp_path / "knowledge_bases"

    def _knowledge_bases_root():
        return kb_root

    def _catalogs_dir(knowledge_base_id: str = "default"):
        path = kb_root / knowledge_base_id / "catalogs"
        path.mkdir(parents=True, exist_ok=True)
        return path

    monkeypatch.setattr("core.catalog_store.knowledge_bases_root", _knowledge_bases_root)
    monkeypatch.setattr("core.catalog_store.catalogs_dir", _catalogs_dir)
    return kb_root


def test_dedupe_rows_keeps_first(catalog_kb):
    rows = [
        {"code": "A", "label": "Active"},
        {"code": "B", "label": "Inactive"},
    ]
    result, skipped = dedupe_rows(rows, columns=["code", "label"], key_column="code")
    assert len(result) == 2
    assert skipped == 0
    assert result[0]["label"] == "Active"


def test_dedupe_rows_rejects_conflicting_key(catalog_kb):
    rows = [
        {"code": "A", "label": "Active"},
        {"code": "A", "label": "Archived"},
    ]
    with pytest.raises(CatalogKeyConflictError) as exc:
        dedupe_rows(rows, columns=["code", "label"], key_column="code")
    assert exc.value.key_value == "A"


def test_create_catalog_and_lookup(catalog_kb):
    meta, _skipped = create_catalog_from_dataset(
        name="Status codes",
        columns=["code", "label"],
        key_column="code",
        dataset_rows=[
            {"code": "A", "label": "Active"},
            {"code": "B", "label": "Inactive"},
        ],
        catalog_id="statuses",
    )
    assert meta.catalog_id == "statuses"
    store = CatalogStore()
    hit = store.lookup("statuses", "code", "A")
    assert hit is not None
    assert hit["label"] == "Active"


def test_resolve_catalog_compare_value(catalog_kb):
    create_catalog_from_dataset(
        name="Status codes",
        columns=["code", "label"],
        key_column="code",
        dataset_rows=[{"code": "A", "label": "Active"}],
        catalog_id="statuses",
    )
    store = CatalogStore()
    binding = ColumnCatalogBinding(
        catalog_id="statuses",
        match_column="code",
        display_columns=("label",),
        compare_column="label",
    )
    compare_value, display, found = resolve_catalog_compare_value(store, binding, "A")
    assert found is True
    assert compare_value == "Active"
    assert display == "Active"

    compare_value, display, found = resolve_catalog_compare_value(store, binding, "Z")
    assert found is False
    assert compare_value == "Z"
    assert display == ""


def test_dedupe_rows_keep_first_skips_conflicts(catalog_kb):
    rows = [
        {"code": "A", "label": "Active"},
        {"code": "A", "label": "Archived"},
        {"code": "B", "label": "Inactive"},
    ]
    result, skipped = dedupe_rows(
        rows,
        columns=["code", "label"],
        key_column="code",
        on_duplicate="keep_first",
    )
    assert len(result) == 2
    assert skipped == 1
    assert result[0]["label"] == "Active"


def test_resolve_catalog_multi_comma(catalog_kb):
    create_catalog_from_dataset(
        name="ICD",
        columns=["ICD_ID", "ICD_CODE"],
        key_column="ICD_ID",
        dataset_rows=[
            {"ICD_ID": "4452", "ICD_CODE": "J45.2"},
            {"ICD_ID": "3681", "ICD_CODE": "E11.9"},
        ],
        catalog_id="icd",
    )
    store = CatalogStore()
    binding = ColumnCatalogBinding(
        catalog_id="icd",
        match_column="ICD_ID",
        display_columns=("ICD_CODE",),
        compare_column="ICD_CODE",
        multi_value_separator=",",
    )
    compare_value, display, found = resolve_catalog_compare_value(
        store, binding, "4452, 3681"
    )
    assert found is True
    assert compare_value == "J45.2, E11.9"
    assert display == "J45.2, E11.9"

    compare_value, display, found = resolve_catalog_compare_value(
        store, binding, "4452, 9999"
    )
    assert found is False
    assert "?" in display
    assert "J45.2" in display


def test_build_catalog_displays(catalog_kb):
    create_catalog_from_dataset(
        name="Clinics",
        columns=["CLINIC_ID", "CLINIC_NAME"],
        key_column="CLINIC_ID",
        dataset_rows=[
            {"CLINIC_ID": "1", "CLINIC_NAME": "Alpha"},
            {"CLINIC_ID": "2", "CLINIC_NAME": "Beta"},
        ],
        catalog_id="clinics",
    )
    binding = ColumnCatalogBinding(
        catalog_id="clinics",
        match_column="CLINIC_ID",
        display_columns=("CLINIC_NAME",),
        compare_column="CLINIC_NAME",
    )
    rows = [("1",), ("9",)]
    displays, misses = build_catalog_displays(
        rows,
        {"CLINIC_ID": binding},
        {"CLINIC_ID": 0},
    )
    assert displays[(0, 0)] == "Alpha"
    assert (1, 0) in misses
    assert displays[(1, 0)] == "?"
