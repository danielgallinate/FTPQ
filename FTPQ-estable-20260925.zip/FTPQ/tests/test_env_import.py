from __future__ import annotations

from pathlib import Path

from core.app_profile import AppProfile
from core.env_import import (
    apply_env_import,
    merge_missing,
    parse_env_text,
    profile_from_env,
    sync_config_name,
)

_ENV_SAMPLE = """
CONFIG_NAME=Daniel_test_config10
SFTP_USER=Daniel_test_config10
SFTP_KEY_PATH=~/.ssh/pde_key_rsa
DEFAULT_FOLDER=scheduled
SFTP_HOST=s-5fd7062c5c8e4ce08.server.transfer.us-west-2.amazonaws.com
DOWNLOAD_DIR=./downloads
DB_RO_USER=ro_user
DB_RO_PASSWORD=secret
"""


def test_profile_from_env_example() -> None:
    values = parse_env_text(_ENV_SAMPLE)
    assert "DB_RO_USER" not in values
    assert "DB_RO_PASSWORD" not in values
    profile = profile_from_env(values)
    assert profile.host == "s-5fd7062c5c8e4ce08.server.transfer.us-west-2.amazonaws.com"
    assert profile.profile_id == "Daniel_test_config10"
    assert profile.user == "Daniel_test_config10"
    assert profile.default_remote_path == "config/Daniel_test_config10/scheduled"


def test_merge_missing_only_fills_empty_host() -> None:
    base = AppProfile.default()
    incoming = AppProfile(host="s-host.example.com", user="u1")
    merged = merge_missing(base, incoming)
    assert merged.host == "s-host.example.com"
    assert merged.user == "u1"


def test_apply_env_import_overwrites_existing_host() -> None:
    base = AppProfile(
        host="s-old.example.com",
        user="old_user",
        private_key_path=Path("~/.ssh/old_key"),
        profile_id="old_config",
    )
    incoming = profile_from_env(parse_env_text(_ENV_SAMPLE))
    applied = apply_env_import(base, incoming)
    assert applied.host == "s-5fd7062c5c8e4ce08.server.transfer.us-west-2.amazonaws.com"
    assert applied.user == "Daniel_test_config10"
    assert applied.profile_id == "Daniel_test_config10"
    assert str(applied.private_key_path).endswith("pde_key_rsa")


def test_sync_config_name_updates_profile_id() -> None:
    profile = AppProfile(
        profile_id="Daniel_test_config10",
        user="Daniel_test_config15",
    )
    sync_config_name(profile)
    assert profile.profile_id == "Daniel_test_config15"
