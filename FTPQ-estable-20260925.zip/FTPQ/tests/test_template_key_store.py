"""Tests — almacén de llave de cifrado."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


@pytest.fixture
def key_store_modules(tmp_path):
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from emrqa.template_key_store import InvalidKeyFileError, NoActiveKeyError, TemplateKeyStore

    key_path = tmp_path / "template_encryption.key"
    store = TemplateKeyStore(default_path=key_path)
    yield TemplateKeyStore, NoActiveKeyError, InvalidKeyFileError, store, key_path


def test_generate_and_save(key_store_modules):
    TemplateKeyStore, _, _, store, key_path = key_store_modules
    assert not store.has_active_key()
    key_id = store.generate_and_save()
    assert store.has_active_key()
    assert store.active_key_id() == key_id
    assert key_path.is_file()
    raw = json.loads(key_path.read_text(encoding="utf-8"))
    assert raw["key_id"] == key_id


def test_load_from_file(key_store_modules, tmp_path):
    TemplateKeyStore, _, InvalidKeyFileError, store, key_path = key_store_modules
    store.generate_and_save()
    backup = tmp_path / "backup.key"
    store.export_to_file(backup)

    other = TemplateKeyStore(default_path=tmp_path / "other.key")
    assert not other.has_active_key()
    loaded_id = other.load_from_file(backup, persist_default=False)
    assert other.has_active_key()
    assert loaded_id == store.active_key_id()

    bad = tmp_path / "bad.key"
    bad.write_text('{"key_id": "abc", "key_b64": "!!!"}', encoding="utf-8")
    with pytest.raises(InvalidKeyFileError):
        other.load_from_file(bad, persist_default=False)


def test_no_active_key_raises(key_store_modules):
    _, NoActiveKeyError, _, store, _ = key_store_modules
    with pytest.raises(NoActiveKeyError):
        store.active_key_bytes()
