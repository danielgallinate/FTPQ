"""Tests — tema claro export PDF métricas."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest
from PySide6.QtWidgets import QApplication, QLabel

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


@pytest.fixture(scope="module", autouse=True)
def _offscreen_qt():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


@pytest.fixture(scope="module")
def qapp() -> QApplication:
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def _import_theme():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))
    from shell.metrics_pdf_export_theme import apply_pdf_light_theme, restore_pdf_theme

    return apply_pdf_light_theme, restore_pdf_theme


def test_pdf_light_theme_restores_widget(qapp: QApplication):
    apply_pdf_light_theme, restore_pdf_theme = _import_theme()
    host = QLabel("metric")
    host.setObjectName("configHint")
    original_stylesheet = "color: red;"
    host.setStyleSheet(original_stylesheet)

    snapshot = apply_pdf_light_theme(host)
    assert "#FFFFFF" in host.styleSheet()
    assert host.palette().color(host.foregroundRole()).name().upper() in {"#1A1A1A", "#1A1A1AFF"}

    restore_pdf_theme(host, snapshot)
    assert host.styleSheet() == original_stylesheet
    host.deleteLater()
