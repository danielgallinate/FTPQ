"""Tests — comparación referencia con catálogos."""
from __future__ import annotations

import pytest

from core.catalog_store import create_catalog_from_dataset
from core.catalog_types import ColumnCatalogBinding
from core.reference_compare import validate_reference_overlay
from core.reference_compare_types import (
    ComparePairMapping,
    JoinKeyMapping,
    ReferenceCompareConfig,
)


@pytest.fixture
def catalog_kb(monkeypatch, tmp_path):
    kb_root = tmp_path / "knowledge_bases"

    def _knowledge_bases_root():
        return kb_root

    def _catalogs_dir(knowledge_base_id: str = "default"):
        path = kb_root / knowledge_base_id / "catalogs"
        path.mkdir(parents=True, exist_ok=True)
        return path

    monkeypatch.setattr("core.catalog_store.knowledge_bases_root", _knowledge_bases_root)
    monkeypatch.setattr("core.catalog_store.catalogs_dir", _catalogs_dir)
    return kb_root


def test_reference_compare_resolves_left_catalog(catalog_kb):
    create_catalog_from_dataset(
        name="Status codes",
        columns=["code", "label"],
        key_column="code",
        dataset_rows=[
            {"code": "A", "label": "Active"},
            {"code": "B", "label": "Inactive"},
        ],
        catalog_id="statuses",
    )
    left_rows = [{"id": "1", "status_code": "A"}]
    reference_rows = [{"MRN": "1", "status_label": "Active"}]
    binding = ColumnCatalogBinding(
        catalog_id="statuses",
        match_column="code",
        display_columns=("label",),
        compare_column="label",
    )
    config = ReferenceCompareConfig(
        join_keys=[JoinKeyMapping(left_column="id", right_column="MRN")],
        pairs=[
            ComparePairMapping(left_column="status_code", right_column="status_label"),
        ],
        left_catalog_bindings={"status_code": binding},
        enabled=True,
    )
    result = validate_reference_overlay(
        left_rows,
        reference_rows,
        config,
        evaluated_columns={"id", "status_code"},
        name_to_index={"id": 0, "status_code": 1},
    )
    assert (0, 1) in result.passed_cells
    assert result.cell_catalog_displays[(0, 1)] == "Active"


def test_reference_compare_catalog_miss_marks_nok(catalog_kb):
    create_catalog_from_dataset(
        name="Status codes",
        columns=["code", "label"],
        key_column="code",
        dataset_rows=[{"code": "A", "label": "Active"}],
        catalog_id="statuses",
    )
    left_rows = [{"id": "1", "status_code": "Z"}]
    reference_rows = [{"MRN": "1", "status_label": "Active"}]
    binding = ColumnCatalogBinding(
        catalog_id="statuses",
        match_column="code",
        display_columns=("label",),
        compare_column="label",
    )
    config = ReferenceCompareConfig(
        join_keys=[JoinKeyMapping(left_column="id", right_column="MRN")],
        pairs=[
            ComparePairMapping(left_column="status_code", right_column="status_label"),
        ],
        left_catalog_bindings={"status_code": binding},
        enabled=True,
    )
    result = validate_reference_overlay(
        left_rows,
        reference_rows,
        config,
        evaluated_columns={"id", "status_code"},
        name_to_index={"id": 0, "status_code": 1},
    )
    assert (0, 1) in result.failed_cells
    assert (0, 1) in result.catalog_lookup_misses
