"""Tests fondo — copia al proyecto y preferencia."""
from __future__ import annotations

from pathlib import Path

import pytest
from PySide6.QtWidgets import QApplication

from ui.theme.wallpaper_store import (
    install_wallpaper,
    load_wallpaper_pixmap,
    resolve_wallpaper_path,
    wallpapers_dir,
)


@pytest.fixture
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    yield app


def test_install_wallpaper_copies_into_project_assets(tmp_path: Path) -> None:
    assets = tmp_path / "assets"
    assets.mkdir()
    source = tmp_path / "mi fondo.JPG"
    source.write_bytes(b"\xff\xd8\xff fake jpeg")

    installed = install_wallpaper(source, assets_root=assets)

    assert installed.is_file()
    assert installed.parent == wallpapers_dir(assets)
    assert resolve_wallpaper_path(assets) == installed


def test_install_wallpaper_rejects_unknown_extension(tmp_path: Path) -> None:
    assets = tmp_path / "assets"
    assets.mkdir()
    source = tmp_path / "not-image.gif"
    source.write_bytes(b"GIF89a")

    with pytest.raises(ValueError, match="Formato no soportado"):
        install_wallpaper(source, assets_root=assets)


def test_resolve_wallpaper_falls_back_without_prefs(tmp_path: Path) -> None:
    assets = tmp_path / "assets"
    assets.mkdir()
    default = assets / "pexels-pixabay-33109.jpg"
    default.write_bytes(b"\xff\xd8\xff")

    resolved = resolve_wallpaper_path(assets)
    assert resolved == default


def test_wallpaper_pref_persists_until_file_removed(tmp_path: Path) -> None:
    assets = tmp_path / "assets"
    assets.mkdir()
    default = assets / "pexels-pixabay-33109.jpg"
    default.write_bytes(b"\xff\xd8\xff")
    source = tmp_path / "fondo.png"
    source.write_bytes(b"\x89PNG")

    installed = install_wallpaper(source, assets_root=assets)
    assert resolve_wallpaper_path(assets) == installed

    installed.unlink()
    assert resolve_wallpaper_path(assets) == default


def test_resolve_wallpaper_pref_missing_falls_back_to_default(tmp_path: Path) -> None:
    assets = tmp_path / "assets"
    assets.mkdir()
    default = assets / "pexels-pixabay-33109.jpg"
    default.write_bytes(b"\xff\xd8\xff")
    from ui.theme.wallpaper_store import prefs_path

    prefs_path(assets).write_text('{"wallpaper": "wallpapers/ausente.jpg"}\n', encoding="utf-8")

    assert resolve_wallpaper_path(assets) == default


def test_load_wallpaper_pixmap_empty_when_missing(qapp, tmp_path: Path) -> None:
    pixmap = load_wallpaper_pixmap(tmp_path / "no.jpg")
    assert pixmap.isNull()
