"""Tests for SFTP core contract and mock browser."""
from __future__ import annotations

from pathlib import Path

import pytest

from core.result import Ok
from core.sftp_types import SessionState, SftpProfile
from mocks.mock_sftp_browser import MockSftpBrowser


@pytest.fixture
def profile() -> SftpProfile:
    path = Path(__file__).resolve().parents[1] / "profiles" / "example_profile.json"
    return SftpProfile.load_json_file(path)


@pytest.fixture
def browser() -> MockSftpBrowser:
    return MockSftpBrowser()


def test_starts_disconnected(browser: MockSftpBrowser) -> None:
    assert browser.state == SessionState.DISCONNECTED
    assert browser.current_remote_path is None


@pytest.mark.parametrize("spec_id", ["S05"])
def test_test_auth_without_connect_is_ok(browser: MockSftpBrowser, spec_id: str) -> None:
    result = browser.test_auth()
    assert isinstance(result, Ok)


@pytest.mark.parametrize("spec_id", ["S06", "S07"])
def test_list_dir_after_user_connect(
    profile: SftpProfile, browser: MockSftpBrowser, spec_id: str
) -> None:
    browser.connect(profile)
    entries = browser.list_dir(profile.normalized_default_remote_path())
    names = [e.name for e in entries]
    assert ".." in names
    assert any(e.name.endswith(".csv") for e in entries)
    assert browser.current_remote_path == profile.normalized_default_remote_path()


@pytest.mark.parametrize("spec_id", ["S09"])
def test_download_writes_file(
    profile: SftpProfile, browser: MockSftpBrowser, tmp_path: Path, spec_id: str
) -> None:
    browser.connect(profile)
    target = tmp_path / "out.csv"
    browser.download("config/example_config/scheduled/file.csv", target)
    assert target.is_file()


@pytest.mark.parametrize("spec_id", ["S08"])
def test_preview_respects_limit(
    profile: SftpProfile, browser: MockSftpBrowser, spec_id: str
) -> None:
    browser.connect(profile)
    result = browser.preview("config/example_config/scheduled/file.csv", max_bytes=1024)
    assert "mock preview" in result.content


@pytest.mark.parametrize("spec_id", ["S03", "R2"])
def test_disconnect_on_reconnect(
    profile: SftpProfile, browser: MockSftpBrowser, spec_id: str
) -> None:
    browser.connect(profile)
    browser.list_dir(profile.normalized_default_remote_path())
    browser.connect(profile)
    assert browser.state == SessionState.CONNECTED
