"""Tests — métricas resumen referencia."""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"
if str(EMR_QA_ROOT) not in sys.path:
    sys.path.insert(0, str(EMR_QA_ROOT))

from core.reference_compare import validate_reference_overlay
from core.reference_compare_types import (
    ComparePairMapping,
    JoinKeyMapping,
    ReferenceCompareConfig,
)
from shell.reference_metrics import build_reference_compare_report


def test_build_reference_compare_report():
    left_rows = [
        {"id": "1", "name": "Alice", "status": "OK"},
        {"id": "2", "name": "Bob", "status": "BAD"},
        {"id": "3", "name": "Carol", "status": "OK"},
    ]
    reference_rows = [
        {"MRN": "1", "patient": "Alice", "state": "OK"},
        {"MRN": "2", "patient": "Bob", "state": "OK"},
    ]
    config = ReferenceCompareConfig(
        reference_path=None,
        join_keys=[JoinKeyMapping(left_column="id", right_column="MRN")],
        pairs=[
            ComparePairMapping(left_column="name", right_column="patient"),
            ComparePairMapping(left_column="status", right_column="state"),
        ],
        enabled=True,
    )
    name_to_index = {"id": 0, "name": 1, "status": 2}
    result = validate_reference_overlay(
        left_rows,
        reference_rows,
        config,
        evaluated_columns={"id", "name", "status"},
        name_to_index=name_to_index,
    )
    report = build_reference_compare_report(
        file_name="test.tsv",
        config=config,
        result=result,
        rows_compared=3,
        reference_rows_loaded=2,
        reference_rows_total=2,
        name_to_index=name_to_index,
    )
    assert report.rows_compared == 3
    assert report.rows_matched_key == 2
    assert report.rows_without_match == 1
    assert report.cells_nok >= 1
    assert report.status in ("deltas", "no_match", "mostly_ok")
    assert len(report.column_metrics) == 2


def test_reference_report_csv_nok_only():
    from core.reference_compare import validate_reference_overlay

    left_rows = [
        {"id": "1", "good": "x", "bad": "1"},
        {"id": "2", "good": "y", "bad": "2"},
    ]
    reference_rows = [
        {"MRN": "1", "good": "x", "bad": "9"},
        {"MRN": "2", "good": "y", "bad": "2"},
    ]
    config = ReferenceCompareConfig(
        join_keys=[JoinKeyMapping(left_column="id", right_column="MRN")],
        pairs=[
            ComparePairMapping(left_column="good", right_column="good"),
            ComparePairMapping(left_column="bad", right_column="bad"),
        ],
        enabled=True,
    )
    result = validate_reference_overlay(
        left_rows,
        reference_rows,
        config,
        evaluated_columns={"id", "good", "bad"},
        name_to_index={"id": 0, "good": 1, "bad": 2},
    )
    report = build_reference_compare_report(
        file_name="test.tsv",
        config=config,
        result=result,
        rows_compared=2,
        reference_rows_loaded=2,
        reference_rows_total=2,
        name_to_index={"id": 0, "good": 1, "bad": 2},
    )
    full_csv = report.to_csv(nok_only=False)
    nok_csv = report.to_csv(nok_only=True)
    assert full_csv.count("\n") >= 3
    assert "bad" in nok_csv
    assert "good" not in nok_csv.split("\n")[1]
