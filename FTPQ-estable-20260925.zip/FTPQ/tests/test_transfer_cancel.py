"""Cancelación segura de descarga / visualización."""
from __future__ import annotations

from pathlib import Path

import pytest

from adapters.local_key_store import LocalKeyStore
from core.app_profile import AppProfile
from core.profile_store import JsonProfileStore
from core.result import Err
from core.sftp_errors import TransferCancelledError
from mocks.mock_sftp_browser import MockSftpBrowser
from ui.app_controller import AppController


class _SlowCancellableBrowser(MockSftpBrowser):
    """Simula descarga lenta; cancela en el segundo chunk de progreso."""

    def __init__(self, controller: AppController) -> None:
        super().__init__()
        self._controller = controller
        self._chunks = 0

    def download(
        self,
        remote_path: str,
        local_path: Path,
        *,
        on_progress=None,
        force: bool = False,
    ) -> None:
        local_path.parent.mkdir(parents=True, exist_ok=True)
        total = 1000
        for transferred in range(0, total, 100):
            self._chunks += 1
            if self._chunks >= 2:
                self._controller.cancel_transfer()
            if on_progress is not None:
                on_progress(transferred, total)
        local_path.write_bytes(b"done")


def _make_controller(tmp_path: Path, browser: MockSftpBrowser) -> AppController:
    keys = LocalKeyStore()
    private = tmp_path / "test_key"
    keys.generate(private, "rsa", bits=2048)

    profile = AppProfile.default()
    profile.host = "sftp.example.com"
    profile.user = "u1"
    profile.private_key_path = private
    profile.ssh_keys_dir = tmp_path

    store = JsonProfileStore(tmp_path / "profiles")
    controller = AppController(
        profile_store=store,
        key_store=keys,
        browser=browser,
    )
    controller.profile = profile
    browser.connect(profile.to_sftp_profile())
    browser.list_dir("scheduled")
    return controller


def test_on_download_bytes_raises_when_cancelled() -> None:
    controller = AppController(browser=MockSftpBrowser())
    controller.begin_transfer()
    controller.request_cancel_transfer()
    with pytest.raises(TransferCancelledError):
        controller._on_download_bytes(10, 100)


def test_request_cancel_visible_to_progress_callback(tmp_path: Path) -> None:
    placeholder = AppController(browser=MockSftpBrowser())
    slow = _SlowCancellableBrowser(placeholder)
    controller = _make_controller(tmp_path, slow)
    slow._controller = controller

    def cancel_midway(transferred: int, total: int) -> None:
        if transferred >= 200:
            controller.request_cancel_transfer()

    controller.set_download_progress_handler(cancel_midway)
    controller.begin_transfer()
    result = controller.download_remote_file("example_extract_20260701.csv")
    controller.set_download_progress_handler(None)
    assert isinstance(result, Err)
    assert isinstance(result.error, TransferCancelledError)


def test_download_remote_file_cancelled_removes_partial(tmp_path: Path) -> None:
    placeholder = AppController(browser=MockSftpBrowser())
    slow = _SlowCancellableBrowser(placeholder)
    controller = _make_controller(tmp_path, slow)
    slow._controller = controller

    result = controller.download_remote_file("example_extract_20260701.csv")
    assert isinstance(result, Err)
    assert isinstance(result.error, TransferCancelledError)
    dest = controller.profile.download_dir.expanduser() / "example_extract_20260701.csv"
    assert not dest.is_file()


def test_visualize_remote_file_cancelled(tmp_path: Path) -> None:
    placeholder = AppController(browser=MockSftpBrowser())
    slow = _SlowCancellableBrowser(placeholder)
    controller = _make_controller(tmp_path, slow)
    slow._controller = controller

    result = controller.visualize_remote_file("example_extract_20260701.csv")
    assert isinstance(result, Err)
    assert isinstance(result.error, TransferCancelledError)
