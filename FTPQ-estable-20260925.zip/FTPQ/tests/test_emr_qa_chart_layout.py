"""Tests — layout vertical de gráficos QA."""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


def _import_layout():
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))
    from shell.qa_metrics_chart_layout import (
        CHART_SIZE_RATIO,
        MINI_PIES_PER_ROW,
        compute_chart_stack_layout,
    )

    return CHART_SIZE_RATIO, MINI_PIES_PER_ROW, compute_chart_stack_layout


def test_stack_uses_thirty_percent_base():
    ratio, _, compute = _import_layout()
    assert ratio == 0.30
    spec = compute(content_width=1000, template_count=2, column_count=2)
    assert spec.rows[2].chart.height >= 300
    assert spec.stack_width >= 1000


def test_main_charts_one_row_each():
    _, _, compute = _import_layout()
    spec = compute(content_width=800, template_count=2, column_count=2)
    assert len(spec.rows) == 3
    assert spec.template_board is not None


def test_template_board_uses_three_columns_per_row():
    _, per_row, compute = _import_layout()
    one = compute(content_width=800, template_count=1, column_count=2)
    two = compute(content_width=800, template_count=2, column_count=2)
    six = compute(content_width=800, template_count=6, column_count=2)
    assert one.template_board is None
    assert two.template_board is not None
    assert six.template_board is not None
    board = six.template_board
    assert per_row == 3
    assert board.count == 6
    assert board.columns_per_row == 3
    assert board.grid_rows == 2
    assert board.board_width == 3 * board.cell_width + 2 * 14
    assert board.cell_width >= 160
    assert board.pie_size >= 120
    assert board.cell_height >= board.pie_size + 150
    assert board.board_height > board.pies_height
