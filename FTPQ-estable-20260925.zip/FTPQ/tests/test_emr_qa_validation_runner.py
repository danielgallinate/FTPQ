"""Tests — validation_runner multi-template."""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


def _import_runner():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))
    from shell.template_factory import build_empty_template
    from shell.validation_runner import QaHighlightMode, run_multi_template_validation

    return build_empty_template, QaHighlightMode, run_multi_template_validation


def test_multi_template_union_green():
    build_empty_template, _mode, run_multi_template_validation = _import_runner()

    template_a = build_empty_template(
        name="A",
        column_names=["id", "name"],
        key_column_names=["id"],
    )
    template_a.append_record({"id": "1", "name": "Alice"})
    template_b = build_empty_template(
        name="B",
        column_names=["id", "name"],
        key_column_names=["id"],
    )
    template_b.append_record({"id": "2", "name": "Bob"})

    rows = [
        {"id": "1", "name": "Alice"},
        {"id": "2", "name": "Bob"},
        {"id": "3", "name": "Carol"},
    ]
    result = run_multi_template_validation(
        [template_a, template_b],
        rows,
        evaluated_columns={"id", "name"},
        name_to_index={"id": 0, "name": 1},
    )
    overlay = result.overlay
    assert (0, 0) in overlay.passed_cells
    assert (1, 0) in overlay.passed_cells
    assert (2, 0) not in overlay.passed_cells
    assert (2, 0) not in overlay.failed_cells
    assert (2, 0) not in overlay.gray_cells


def test_fail_any_red_overrides_green():
    build_empty_template, QaHighlightMode, run_multi_template_validation = _import_runner()

    ok = build_empty_template(
        name="ok_fei",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    ok.append_record({"Email": "fei.yang@webpt.com", "Name": "fei.yang"})

    bad = build_empty_template(
        name="bad_fei",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    bad.append_record({"Email": "fei.yang@webpt.com", "Name": "fei.yang.edited"})

    rows = [{"Email": "fei.yang@webpt.com", "Name": "fei.yang"}]
    result = run_multi_template_validation(
        [ok, bad],
        rows,
        evaluated_columns={"Email", "Name"},
        name_to_index={"Email": 0, "Name": 1},
        highlight_mode=QaHighlightMode.FAIL_ANY,
    )
    overlay = result.overlay
    assert (0, 0) in overlay.passed_cells
    assert (0, 1) in overlay.failed_cells
    assert (0, 0) not in overlay.failed_cells


def test_discrepancy_orange_when_templates_disagree():
    build_empty_template, QaHighlightMode, run_multi_template_validation = _import_runner()

    ok = build_empty_template(
        name="ok_fei",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    ok.append_record({"Email": "fei.yang@webpt.com", "Name": "fei.yang"})

    bad = build_empty_template(
        name="bad_fei",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    bad.append_record({"Email": "fei.yang@webpt.com", "Name": "fei.yang.edited"})

    rows = [{"Email": "fei.yang@webpt.com", "Name": "fei.yang"}]
    result = run_multi_template_validation(
        [ok, bad],
        rows,
        evaluated_columns={"Email", "Name"},
        name_to_index={"Email": 0, "Name": 1},
        highlight_mode=QaHighlightMode.DISCREPANCY,
    )
    overlay = result.overlay
    assert (0, 1) in overlay.conflict_cells
    assert (0, 0) in overlay.passed_cells
    assert (0, 0) not in overlay.conflict_cells


def test_single_template_failure_is_red():
    build_empty_template, QaHighlightMode, run_multi_template_validation = _import_runner()

    template = build_empty_template(
        name="correo_fail_test",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    template.append_record({"Email": "fei.yang@webpt.com", "Name": "fei.yang.edited"})

    rows = [{"Email": "fei.yang@webpt.com", "Name": "fei.yang"}]
    result = run_multi_template_validation(
        [template],
        rows,
        evaluated_columns={"Email", "Name"},
        name_to_index={"Email": 0, "Name": 1},
    )
    overlay = result.overlay
    assert (0, 0) in overlay.passed_cells
    assert (0, 1) in overlay.failed_cells
