"""Tests — exportación PDF de métricas QA."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest
from PySide6.QtWidgets import QApplication

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


@pytest.fixture(scope="module", autouse=True)
def _offscreen_qt():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


@pytest.fixture(scope="module")
def qapp() -> QApplication:
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def _import_modules():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))
    from shell.qa_metrics import build_qa_metrics
    from shell.qa_metrics_charts import QaMetricsChartsWidget
    from shell.qa_metrics_pdf_export import default_pdf_filename, export_qa_metrics_pdf
    from shell.qa_metrics_report_view import QaMetricsReportView
    from shell.template_factory import build_empty_template
    from shell.validation_runner import QaHighlightMode, run_multi_template_validation

    return (
        build_empty_template,
        build_qa_metrics,
        export_qa_metrics_pdf,
        default_pdf_filename,
        QaHighlightMode,
        QaMetricsChartsWidget,
        QaMetricsReportView,
        run_multi_template_validation,
    )


def test_default_pdf_filename():
    _, _, _, default_pdf_filename, *_ = _import_modules()
    assert default_pdf_filename("sample.csv") == "sample_qa_report.pdf"
    assert default_pdf_filename("").endswith("_qa_report.pdf")


def test_export_qa_metrics_pdf(qapp: QApplication, tmp_path):
    (
        build_empty_template,
        build_qa_metrics,
        export_qa_metrics_pdf,
        _default_name,
        QaHighlightMode,
        QaMetricsChartsWidget,
        QaMetricsReportView,
        run_multi,
    ) = _import_modules()

    template = build_empty_template(
        name="pdf_tpl",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    template.append_record({"Email": "a@x.com", "Name": "Alice"})
    rows = [{"Email": "a@x.com", "Name": "Alice"}]
    result = run_multi(
        [template],
        rows,
        evaluated_columns={"Email", "Name"},
        name_to_index={"Email": 0, "Name": 1},
    )
    report = build_qa_metrics(
        file_name="sample.csv",
        visible_columns=["Email", "Name"],
        rows=rows,
        templates=[template],
        template_overlays=result.template_overlays,
        merged=result.overlay,
        name_to_index={"Email": 0, "Name": 1},
        highlight_mode=QaHighlightMode.FAIL_ANY,
    )

    report_view = QaMetricsReportView()
    charts = QaMetricsChartsWidget()
    report_view.set_report(report, nok_only=False)
    charts.set_report(report)
    report_view.show()
    charts.show()
    qapp.processEvents()

    out = tmp_path / "sample_qa_report.pdf"
    export_qa_metrics_pdf(out, report_view=report_view, charts=charts)

    assert out.is_file()
    assert out.stat().st_size > 512
    assert out.read_bytes()[:4] == b"%PDF"
