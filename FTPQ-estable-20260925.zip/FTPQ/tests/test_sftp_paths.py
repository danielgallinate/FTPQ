"""Tests mapeo rutas SFTP."""
from __future__ import annotations

from core.sftp_paths import display_path, list_path_candidates, resolve_list_path, to_sftp_path


def test_to_sftp_path_from_config_prefix() -> None:
    assert to_sftp_path("config/Daniel_test_config15/scheduled") == "scheduled"


def test_to_sftp_path_passthrough_folder() -> None:
    assert to_sftp_path("requested") == "requested"


def test_list_path_candidates_root() -> None:
    assert list_path_candidates(".") == ["."]


def test_resolve_list_path_parent_from_folder() -> None:
    assert resolve_list_path("scheduled", "..") == "."


def test_display_path_root() -> None:
    assert display_path("Daniel_test_config15", ".") == "Daniel_test_config15 /"


def test_join_remote_path() -> None:
    from core.sftp_paths import join_remote_path

    assert join_remote_path(".", "scheduled") == "scheduled"
    assert join_remote_path("scheduled", "file.csv") == "scheduled/file.csv"
