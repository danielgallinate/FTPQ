"""Tests — comparación contra archivo de referencia."""
from __future__ import annotations

from core.cell_transform import CellTransform, normalize_cell_text, transform_cell
from core.reference_compare import (
    expand_evaluated_columns_for_reference,
    suggest_initial_pairs,
    validate_reference_overlay,
)
from core.reference_compare_types import (
    ComparePairMapping,
    JoinKeyMapping,
    ReferenceCompareConfig,
)


def test_transform_cell_regex_replace():
    value = transform_cell(
        "MRN000123",
        CellTransform(pattern=r"^MRN0+", replacement=""),
    )
    assert value == "123"


def test_transform_cell_regex_extract():
    value = transform_cell(
        "visit: 2024-01-15 end",
        CellTransform(pattern=r"(\d{4}-\d{2}-\d{2})"),
    )
    assert value == "2024-01-15"


def test_reference_compare_match_and_mismatch():
    left_rows = [
        {"id": "1", "name": "Alice", "status": "OK"},
        {"id": "2", "name": "Bob", "status": "BAD"},
    ]
    reference_rows = [
        {"MRN": "1", "patient": "Alice", "state": "OK"},
        {"MRN": "2", "patient": "Bob", "state": "OK"},
    ]
    config = ReferenceCompareConfig(
        join_keys=[JoinKeyMapping(left_column="id", right_column="MRN")],
        pairs=[
            ComparePairMapping(left_column="name", right_column="patient"),
            ComparePairMapping(left_column="status", right_column="state"),
        ],
        enabled=True,
    )
    name_to_index = {"id": 0, "name": 1, "status": 2}
    result = validate_reference_overlay(
        left_rows,
        reference_rows,
        config,
        evaluated_columns={"id", "name", "status"},
        name_to_index=name_to_index,
    )
    assert result.passed_cells == {(0, 0), (0, 1), (0, 2), (1, 0), (1, 1)}
    assert (1, 2) in result.failed_cells
    assert result.cell_reference_values[(1, 2)] == "OK"
    assert result.rows_without_match == 0


def test_reference_compare_no_key_match():
    left_rows = [{"id": "99", "value": "x"}]
    reference_rows = [{"MRN": "1", "value": "x"}]
    config = ReferenceCompareConfig(
        join_keys=[JoinKeyMapping(left_column="id", right_column="MRN")],
        pairs=[ComparePairMapping(left_column="value", right_column="value")],
        enabled=True,
    )
    result = validate_reference_overlay(
        left_rows,
        reference_rows,
        config,
        evaluated_columns={"id", "value"},
        name_to_index={"id": 0, "value": 1},
    )
    assert result.rows_without_match == 1
    assert (0, 0) in result.failed_cells
    assert (0, 0) in result.cells_without_reference


def test_reference_compare_ambiguous_duplicate_key():
    left_rows = [{"id": "1", "value": "a"}]
    reference_rows = [
        {"MRN": "1", "value": "a"},
        {"MRN": "1", "value": "b"},
    ]
    config = ReferenceCompareConfig(
        join_keys=[JoinKeyMapping(left_column="id", right_column="MRN")],
        pairs=[ComparePairMapping(left_column="value", right_column="value")],
        duplicate_policy="ambiguous",
        enabled=True,
    )
    result = validate_reference_overlay(
        left_rows,
        reference_rows,
        config,
        evaluated_columns={"id", "value"},
        name_to_index={"id": 0, "value": 1},
    )
    assert result.rows_ambiguous_key == 1
    assert result.duplicate_reference_keys == 1


def test_reference_compare_with_regex_on_both_sides():
    left_rows = [{"id": "MRN001", "date": "01/15/2024"}]
    reference_rows = [{"key": "1", "date": "2024-01-15"}]
    config = ReferenceCompareConfig(
        join_keys=[
            JoinKeyMapping(
                left_column="id",
                right_column="key",
                left_transform=CellTransform(pattern=r"MRN0*(\d+)", replacement=r"\1"),
            )
        ],
        pairs=[
            ComparePairMapping(
                left_column="date",
                right_column="date",
                left_transform=CellTransform(
                    pattern=r"(\d{2})/(\d{2})/(\d{4})",
                    replacement=r"\3-\1-\2",
                ),
            )
        ],
        enabled=True,
    )
    result = validate_reference_overlay(
        left_rows,
        reference_rows,
        config,
        evaluated_columns={"id", "date"},
        name_to_index={"id": 0, "date": 1},
    )
    assert (0, 1) in result.passed_cells


def test_compare_pair_as_join_key():
    left_rows = [{"id": "1", "value": "x"}]
    reference_rows = [{"MRN": "1", "value": "x"}]
    config = ReferenceCompareConfig(
        pairs=[
            ComparePairMapping(
                left_column="id",
                right_column="MRN",
                enabled=True,
                is_join_key=True,
            ),
            ComparePairMapping(left_column="value", right_column="value"),
        ],
        enabled=True,
    )
    assert len(config.resolved_join_keys()) == 1
    result = validate_reference_overlay(
        left_rows,
        reference_rows,
        config,
        evaluated_columns={"id", "value"},
        name_to_index={"id": 0, "value": 1},
    )
    assert (0, 0) in result.passed_cells
    assert (0, 1) in result.passed_cells


def test_expand_evaluated_columns_includes_join_keys():
    config = ReferenceCompareConfig(
        pairs=[
            ComparePairMapping(
                left_column="mrn",
                right_column="MRN",
                enabled=True,
                is_join_key=True,
            ),
            ComparePairMapping(left_column="status", right_column="status"),
        ],
        enabled=True,
    )
    expanded = expand_evaluated_columns_for_reference({"status"}, config)
    assert expanded == {"status", "mrn"}


def test_suggest_initial_pairs_marks_key():
    pairs = suggest_initial_pairs(["id", "name"], ["MRN", "name"])
    assert any(p.is_join_key for p in pairs)


def test_normalize_cell_text_na_literals():
    assert normalize_cell_text("<NA>") == ""
    assert normalize_cell_text("nan") == ""
    assert normalize_cell_text(None) == ""


def test_reference_compare_na_matches_empty_on_both_sides():
    left_rows = [{"id": "1", "note": "<NA>"}]
    reference_rows = [{"MRN": "1", "note": ""}]
    config = ReferenceCompareConfig(
        join_keys=[JoinKeyMapping(left_column="id", right_column="MRN")],
        pairs=[ComparePairMapping(left_column="note", right_column="note")],
        enabled=True,
    )
    result = validate_reference_overlay(
        left_rows,
        reference_rows,
        config,
        evaluated_columns={"id", "note"},
        name_to_index={"id": 0, "note": 1},
    )
    assert (0, 1) in result.passed_cells
