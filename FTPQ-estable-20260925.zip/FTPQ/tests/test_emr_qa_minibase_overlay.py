"""Tests — overlay minibase verde/gris/rojo."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


def test_minibase_overlay_key_locates_compare_fields():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from emrqa.validation_engine import validate_minibase_overlay
    from shell.template_factory import build_empty_template

    template = build_empty_template(
        name="correos_overlay_a",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    template.append_record({"Email": "ryan.com", "Name": "ryan"})
    rows = [
        {"Email": "ryan.com", "Name": "ryan"},
        {"Email": "other.com", "Name": "ryan"},
        {"Email": "bob.com", "Name": "bob"},
    ]
    overlay = validate_minibase_overlay(
        template,
        rows,
        evaluated_columns={"Email", "Name"},
        name_to_index={"Email": 0, "Name": 1},
    )
    assert (0, 0) in overlay.passed_cells
    assert (0, 1) in overlay.passed_cells
    assert (1, 0) not in overlay.failed_cells
    assert (1, 1) not in overlay.failed_cells
    assert (2, 0) not in overlay.passed_cells


def test_minibase_overlay_compare_non_key_fields_only():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from emrqa.validation_engine import validate_minibase_overlay
    from shell.template_factory import build_empty_template

    template = build_empty_template(
        name="correos_overlay_b",
        column_names=["Email", "Name", "Phone"],
        key_column_names=["Email"],
    )
    template.append_record({"Email": "ryan.com", "Name": "ryan", "Phone": "555"})
    rows = [
        {"Email": "ryan.com", "Name": "ryan", "Phone": "999"},
        {"Email": "other.com", "Name": "ryan", "Phone": "111"},
    ]
    overlay = validate_minibase_overlay(
        template,
        rows,
        evaluated_columns={"Email", "Name", "Phone"},
        name_to_index={"Email": 0, "Name": 1, "Phone": 2},
    )
    assert (0, 0) in overlay.passed_cells
    assert (0, 1) in overlay.passed_cells
    assert (0, 2) in overlay.failed_cells
    assert (1, 0) not in overlay.passed_cells


def test_email_key_name_compared_fei_yang():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from emrqa.validation_engine import validate_minibase_overlay
    from shell.template_factory import build_empty_template

    template = build_empty_template(
        name="correo_email_pk_test",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    template.append_record({"Email": "fei.yang@webpt.com", "Name": "fei.yango"})
    rows = [{"Email": "fei.yang@webpt.com", "Name": "fei.yang"}]
    overlay = validate_minibase_overlay(
        template,
        rows,
        evaluated_columns={"Email", "Name"},
        name_to_index={"Email": 0, "Name": 1},
    )
    assert (0, 0) in overlay.passed_cells
    assert (0, 1) in overlay.failed_cells


def test_reject_all_fields_as_key():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from shell.template_factory import build_empty_template

    with pytest.raises(ValueError, match="fuera de la llave"):
        build_empty_template(
            name="invalid_all_key",
            column_names=["Email", "Name"],
            key_column_names=["Email", "Name"],
        )
