"""Tests core/local_browser — listado local filtrado."""
from __future__ import annotations

from pathlib import Path

from core.file_view import VIEWABLE_EXTENSIONS
from core.local_browser import (
    default_start_path,
    list_directory,
    navigate_up,
    resolve_folder_open,
    storage_roots,
)


def test_default_start_path_uses_download_dir(tmp_path: Path) -> None:
    downloads = tmp_path / "downloads"
    downloads.mkdir()
    assert default_start_path(downloads) == downloads.resolve()


def test_default_start_path_falls_back_to_home(tmp_path: Path) -> None:
    missing = tmp_path / "missing"
    start = default_start_path(missing)
    assert start == Path.home().resolve()


def test_list_directory_filters_extensions(tmp_path: Path) -> None:
    (tmp_path / "ok.csv").write_text("a,b\n1,2\n", encoding="utf-8")
    (tmp_path / "skip.bin").write_bytes(b"\x00\x01")
    (tmp_path / "nested").mkdir()
    listing = list_directory(tmp_path)
    names = {entry.name.rstrip("/") for entry in listing.entries if entry.name != ".."}
    assert "ok.csv" in names
    assert "skip.bin" not in names
    assert "nested" in names


def test_navigate_up_from_subfolder(tmp_path: Path) -> None:
    sub = tmp_path / "a" / "b"
    sub.mkdir(parents=True)
    assert navigate_up(sub.resolve()) == (tmp_path / "a").resolve()


def test_navigate_up_at_root_returns_none() -> None:
    for root in storage_roots():
        assert navigate_up(root) is None


def test_resolve_parent_folder(tmp_path: Path) -> None:
    sub = tmp_path / "child"
    sub.mkdir()
    assert resolve_folder_open(sub.resolve(), "..") == tmp_path.resolve()


def test_resolve_subfolder(tmp_path: Path) -> None:
    sub = tmp_path / "child"
    sub.mkdir()
    opened = resolve_folder_open(tmp_path.resolve(), "child")
    assert opened == sub.resolve()


def test_storage_roots_non_empty() -> None:
    roots = storage_roots()
    assert roots
    for root in roots:
        assert root.exists()


def test_resolve_parent_at_storage_root_returns_volumes_view() -> None:
    for root in storage_roots():
        assert resolve_folder_open(root.resolve(), "..") is None


def test_list_directory_includes_parent_at_storage_root(tmp_path: Path) -> None:
    for root in storage_roots():
        listing = list_directory(root.resolve())
        parent_names = [entry.name for entry in listing.entries if entry.name == ".."]
        assert parent_names == [".."]


def test_sanitize_browser_path_redirects_filesystem_root() -> None:
    from core.local_browser import home_path, sanitize_browser_path

    assert sanitize_browser_path(Path("/")) == home_path()
    assert sanitize_browser_path(home_path() / "Downloads") == (home_path() / "Downloads").resolve()
    assert sanitize_browser_path(None) is None
