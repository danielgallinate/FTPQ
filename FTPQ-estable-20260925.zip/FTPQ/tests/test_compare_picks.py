"""Compare picks — asignación SFTP y auto-selección."""
from __future__ import annotations

from pathlib import Path

import pytest
from PySide6.QtWidgets import QApplication

from core.compare_types import ComparePick
from core.profile_store import JsonProfileStore
from ui.app_controller import AppController
from ui.shell.main_window import MainWindow
from ui.theme.theme_engine import ThemeEngine
from ui.widgets.browser_mode_bar import BrowserLayoutMode


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    yield app


@pytest.fixture
def main_window(qapp, tmp_path):
    store = JsonProfileStore(tmp_path)
    controller = AppController(profile_store=store)
    theme = ThemeEngine(qapp)
    theme.apply()
    window = MainWindow(theme=theme, controller=controller)
    window.show()
    qapp.processEvents()
    yield window
    window.shutdown_workers()
    for thread in (window._analysis_thread, window._compare_thread, window._sftp_thread):
        thread.quit()
        thread.wait(2000)
    window.close()
    qapp.processEvents()


def test_sftp_compare_pick_does_not_raise(main_window: MainWindow) -> None:
    main_window._file_manager_active = True
    payload = {"name": "sample.tsv", "size": "1.0K"}
    main_window._assign_compare_pick("a", payload, local=False)
    assert main_window._compare_pick_a is not None
    assert main_window._compare_pick_a.is_remote
    assert main_window._compare_pick_a.label == "sample.tsv"


def test_auto_assign_on_selection_sftp_local(
    main_window: MainWindow, qapp, tmp_path: Path
) -> None:
    main_window._enter_file_manager()
    main_window._browser_mode = BrowserLayoutMode.SFTP_LOCAL
    qapp.processEvents()

    main_window._on_navigator_selection(
        {"name": "remote.tsv", "ext": ".tsv", "size": "2.0K", "modified": "", "path": "/x"}
    )
    local = tmp_path / "local.tsv"
    local.write_text("a\n", encoding="utf-8")
    main_window._on_local_b_selection(
        {
            "name": "local.tsv",
            "ext": ".tsv",
            "size": "10",
            "modified": "",
            "path": str(tmp_path),
            "absolute_path": str(local),
        }
    )
    qapp.processEvents()
    assert main_window._compare_pick_a is not None
    assert main_window._compare_pick_b is not None
    assert main_window._browser_mode_bar._compare.isEnabled()
