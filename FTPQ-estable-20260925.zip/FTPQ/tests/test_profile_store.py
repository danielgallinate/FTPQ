"""Tests JsonProfileStore — perfil único default."""
from __future__ import annotations

import json
from pathlib import Path

from core.app_profile import AppProfile
from core.profile_store import JsonProfileStore


def test_save_and_load_roundtrip(tmp_path: Path) -> None:
    store = JsonProfileStore(tmp_path)
    profile = AppProfile.default()
    profile.user = "test_user"
    profile.host = "sftp.example.com"
    store.save(profile)

    loaded = store.load()
    assert loaded.user == "test_user"
    assert loaded.host == "sftp.example.com"


def test_load_creates_default_file(tmp_path: Path) -> None:
    store = JsonProfileStore(tmp_path)
    assert not store.path.is_file()
    profile = store.load()
    assert profile.profile_id == "default"
    assert store.path.is_file()
    data = json.loads(store.path.read_text(encoding="utf-8"))
    assert "sftp" in data
    assert "postgres" not in data
    assert "snowflake" not in data
