"""Tests — métricas QA."""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


def _import_modules():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))
    from shell.qa_metrics import build_qa_metrics
    from shell.template_factory import build_empty_template
    from shell.validation_runner import QaHighlightMode, run_multi_template_validation
    from ui.i18n import set_language, tr

    return build_empty_template, build_qa_metrics, QaHighlightMode, run_multi_template_validation, set_language, tr


def test_build_qa_metrics_counts_cells():
    build_empty_template, build_qa_metrics, QaHighlightMode, run_multi, _set_lang, tr = (
        _import_modules()
    )
    template = build_empty_template(
        name="metrics_test_tpl",
        column_names=["Email", "Name", "Notes"],
        key_column_names=["Email"],
    )
    template.append_record({"Email": "a@x.com", "Name": "Alice"})
    rows = [
        {"Email": "a@x.com", "Name": "Alice", "Notes": "x"},
        {"Email": "b@x.com", "Name": "Bob", "Notes": "y"},
    ]
    result = run_multi(
        [template],
        rows,
        evaluated_columns={"Email", "Name", "Notes"},
        name_to_index={"Email": 0, "Name": 1, "Notes": 2},
    )
    report = build_qa_metrics(
        file_name="sample.csv",
        visible_columns=["Email", "Name", "Notes"],
        rows=rows,
        templates=[template],
        template_overlays=result.template_overlays,
        merged=result.overlay,
        name_to_index={"Email": 0, "Name": 1, "Notes": 2},
        highlight_mode=QaHighlightMode.FAIL_ANY,
    )
    assert report.eligible_cells == 6
    assert report.judged_cells >= 2
    assert "Email" in report.by_column
    assert "metrics_test_tpl" in report.by_template
    text = report.to_copyable_text()
    assert "sample.csv" in text
    assert tr("emr.qa.metrics.report.section_kpis") in text
    assert report.to_csv().startswith(tr("emr.qa.metrics.csv.header").split(",")[0])


def test_qa_metrics_delta():
    build_empty_template, build_qa_metrics, mode, run_multi, _set_lang, _tr = _import_modules()
    template = build_empty_template(
        name="t1",
        column_names=["id", "val"],
        key_column_names=["id"],
    )
    template.append_record({"id": "1", "val": "ok"})
    rows = [{"id": "1", "val": "ok"}]
    result = run_multi(
        [template],
        rows,
        evaluated_columns={"id", "val"},
        name_to_index={"id": 0, "val": 1},
    )
    first = build_qa_metrics(
        file_name="f.csv",
        visible_columns=["id", "val"],
        rows=rows,
        templates=[template],
        template_overlays=result.template_overlays,
        merged=result.overlay,
        name_to_index={"id": 0, "val": 1},
        highlight_mode=mode.FAIL_ANY,
    )
    rows[0]["val"] = "bad"
    result2 = run_multi(
        [template],
        rows,
        evaluated_columns={"id", "val"},
        name_to_index={"id": 0, "val": 1},
    )
    second = build_qa_metrics(
        file_name="f.csv",
        visible_columns=["id", "val"],
        rows=rows,
        templates=[template],
        template_overlays=result2.template_overlays,
        merged=result2.overlay,
        name_to_index={"id": 0, "val": 1},
        highlight_mode=mode.FAIL_ANY,
        previous=first,
    )
    assert second.delta is not None
    assert second.delta.nok_cells >= first.nok_cells


def test_report_respects_ui_language():
    build_empty_template, build_qa_metrics, QaHighlightMode, run_multi, set_language, tr = (
        _import_modules()
    )
    set_language("en")
    try:
        template = build_empty_template(
            name="metrics_lang_tpl",
            column_names=["id", "val"],
            key_column_names=["id"],
        )
        template.append_record({"id": "1", "val": "ok"})
        rows = [{"id": "1", "val": "ok"}]
        result = run_multi(
            [template],
            rows,
            evaluated_columns={"id", "val"},
            name_to_index={"id": 0, "val": 1},
        )
        report = build_qa_metrics(
            file_name="f.csv",
            visible_columns=["id", "val"],
            rows=rows,
            templates=[template],
            template_overlays=result.template_overlays,
            merged=result.overlay,
            name_to_index={"id": 0, "val": 1},
            highlight_mode=QaHighlightMode.FAIL_ANY,
        )
        text = report.to_copyable_text()
        assert tr("emr.qa.metrics.report.generated", when=report.generated_at) in text
        assert "Generado:" not in text
    finally:
        set_language("es")


def test_template_profiles_in_meta_block():
    build_empty_template, build_qa_metrics, QaHighlightMode, run_multi, _set_lang, tr = (
        _import_modules()
    )
    template = build_empty_template(
        name="profile_test_tpl",
        column_names=["Email", "Name"],
        key_column_names=["Email"],
    )
    template.append_record({"Email": "a@x.com", "Name": "Alice"})
    rows = [{"Email": "a@x.com", "Name": "Alice"}]
    result = run_multi(
        [template],
        rows,
        evaluated_columns={"Email", "Name"},
        name_to_index={"Email": 0, "Name": 1},
    )
    report = build_qa_metrics(
        file_name="sample.csv",
        visible_columns=["Email", "Name"],
        rows=rows,
        templates=[template],
        template_overlays=result.template_overlays,
        merged=result.overlay,
        name_to_index={"Email": 0, "Name": 1},
        highlight_mode=QaHighlightMode.FAIL_ANY,
    )
    assert len(report.template_profiles) == 1
    profile = report.template_profiles[0]
    assert profile.name == "profile_test_tpl"
    assert profile.key_kind == "simple"
    assert profile.key_columns == ("Email",)
    assert profile.column_names == ("Email", "Name")
    assert profile.compare_columns == ("Name",)
    assert profile.minibase_records == 1
    block = report.meta_block_text()
    assert tr("emr.qa.metrics.report.template_profiles_title") in block
    assert "profile_test_tpl" in block
    assert "Email" in block
