"""Tests AppController — test SFTP con mock."""
from __future__ import annotations

import os
from pathlib import Path

from adapters.local_key_store import LocalKeyStore
from core.app_profile import AppProfile
from core.profile_store import JsonProfileStore
from core.result import Ok
from mocks.mock_sftp_browser import MockSftpBrowser
from ui.app_controller import AppController


def test_test_sftp_mock_success(tmp_path: Path) -> None:
    os.environ["PDE_DESKTOP_MOCK"] = "1"
    keys = LocalKeyStore()
    private = tmp_path / "test_key"
    keys.generate(private, "rsa", bits=2048)

    profile = AppProfile.default()
    profile.host = "s-example.server.transfer.us-west-2.amazonaws.com"
    profile.user = "Daniel_test_config10"
    profile.private_key_path = private
    profile.ssh_keys_dir = tmp_path

    store = JsonProfileStore(tmp_path / "profiles")
    controller = AppController(
        profile_store=store,
        key_store=keys,
        browser=MockSftpBrowser(),
    )
    controller.profile = profile

    result = controller.test_sftp(profile)
    assert isinstance(result, Ok)


def test_connect_and_list_mock(tmp_path: Path) -> None:
    keys = LocalKeyStore()
    private = tmp_path / "test_key"
    keys.generate(private, "rsa", bits=2048)

    profile = AppProfile.default()
    profile.host = "s-example.server.transfer.us-west-2.amazonaws.com"
    profile.user = "Daniel_test_config10"
    profile.private_key_path = private
    profile.ssh_keys_dir = tmp_path

    store = JsonProfileStore(tmp_path / "profiles")
    controller = AppController(
        profile_store=store,
        key_store=keys,
        browser=MockSftpBrowser(),
    )
    controller.profile = profile

    result = controller.connect_and_list(profile)
    assert isinstance(result, Ok)
    listing = result.value
    assert listing.remote_path == "."
    names = [entry.name for entry in listing.entries]
    assert "scheduled" in names
    assert "requested" in names


def test_download_remote_file_mock(tmp_path: Path) -> None:
    keys = LocalKeyStore()
    private = tmp_path / "test_key"
    keys.generate(private, "rsa", bits=2048)

    profile = AppProfile.default()
    profile.host = "sftp.example.com"
    profile.user = "u1"
    profile.private_key_path = private
    profile.ssh_keys_dir = tmp_path
    profile.download_dir = tmp_path / "downloads"

    browser = MockSftpBrowser()
    store = JsonProfileStore(tmp_path / "profiles")
    controller = AppController(
        profile_store=store,
        key_store=keys,
        browser=browser,
    )
    controller.profile = profile
    browser.connect(profile.to_sftp_profile())
    browser.list_dir("scheduled")

    result = controller.download_remote_file("example_extract_20260701.csv")
    assert isinstance(result, Ok)
    assert result.value.is_file()


def test_download_remote_file_to_explicit_path(tmp_path: Path) -> None:
    keys = LocalKeyStore()
    private = tmp_path / "test_key"
    keys.generate(private, "rsa", bits=2048)

    profile = AppProfile.default()
    profile.host = "sftp.example.com"
    profile.user = "u1"
    profile.private_key_path = private
    profile.ssh_keys_dir = tmp_path

    browser = MockSftpBrowser()
    store = JsonProfileStore(tmp_path / "profiles")
    controller = AppController(
        profile_store=store,
        key_store=keys,
        browser=browser,
    )
    controller.profile = profile
    browser.connect(profile.to_sftp_profile())
    browser.list_dir("scheduled")

    dest = tmp_path / "custom" / "saved.csv"
    result = controller.download_remote_file("example_extract_20260701.csv", dest)
    assert isinstance(result, Ok)
    assert result.value == dest
    assert dest.is_file()


def test_visualize_remote_file_downloads_and_reads(tmp_path: Path) -> None:
    keys = LocalKeyStore()
    private = tmp_path / "test_key"
    keys.generate(private, "rsa", bits=2048)

    profile = AppProfile.default()
    profile.host = "sftp.example.com"
    profile.user = "u1"
    profile.private_key_path = private
    profile.ssh_keys_dir = tmp_path

    browser = MockSftpBrowser()
    store = JsonProfileStore(tmp_path / "profiles")
    controller = AppController(
        profile_store=store,
        key_store=keys,
        browser=browser,
    )
    controller.profile = profile
    browser.connect(profile.to_sftp_profile())
    browser.list_dir("scheduled")

    result = controller.visualize_remote_file("example_extract_20260701.csv")
    assert isinstance(result, Ok)
    view = result.value
    assert view.tabular is True
    assert view.local_path.is_file()
