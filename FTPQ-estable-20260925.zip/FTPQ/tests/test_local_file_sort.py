"""Tests — orden Norton Commander del explorador local."""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]


def _rows() -> list[dict]:
    return [
        {"name": "..", "is_dir": True, "is_parent": True, "size_bytes": 0, "ext": "", "modified_ts": 0},
        {"name": "beta/", "is_dir": True, "is_parent": False, "size_bytes": 0, "ext": "", "modified_ts": 1},
        {"name": "alpha/", "is_dir": True, "is_parent": False, "size_bytes": 0, "ext": "", "modified_ts": 2},
        {"name": "large.csv", "is_dir": False, "is_parent": False, "size_bytes": 9000, "ext": ".csv", "modified_ts": 3},
        {"name": "small.csv", "is_dir": False, "is_parent": False, "size_bytes": 100, "ext": ".csv", "modified_ts": 4},
    ]


def test_sort_name_ascending_norton_style():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))

    from ui.panels.local_file_sort import COL_NAME, sort_browser_entries

    ordered = sort_browser_entries(_rows(), sort_column=COL_NAME, ascending=True)
    names = [row["name"] for row in ordered]
    assert names == ["..", "alpha/", "beta/", "large.csv", "small.csv"]


def test_sort_size_descending_keeps_dirs_on_top():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))

    from ui.panels.local_file_sort import COL_SIZE, sort_browser_entries

    ordered = sort_browser_entries(_rows(), sort_column=COL_SIZE, ascending=False)
    names = [row["name"] for row in ordered]
    assert names[0] == ".."
    assert set(names[1:3]) == {"alpha/", "beta/"}
    assert names[3:] == ["large.csv", "small.csv"]
