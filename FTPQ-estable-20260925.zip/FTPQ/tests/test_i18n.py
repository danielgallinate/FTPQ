"""Tests i18n — español por defecto y cambio a inglés."""
from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from ui.i18n import current_language, init_locale, set_language, tr


@pytest.fixture(scope="module", autouse=True)
def _reset_locale():
    init_locale()
    yield
    set_language("es")


@pytest.fixture
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def test_default_language_is_spanish() -> None:
    set_language("es")
    assert current_language() == "es"
    assert tr("menu.file") == "Archivo"


def test_switch_to_english(qapp) -> None:
    set_language("en")
    qapp.processEvents()
    assert current_language() == "en"
    assert tr("menu.file") == "File"
    assert tr("panel.navigator") == "Browser"


def test_switch_back_to_spanish(qapp) -> None:
    set_language("es")
    qapp.processEvents()
    assert tr("action.connect") == "Conectar"


def test_profile_persists_language(tmp_path) -> None:
    from core.profile_store import JsonProfileStore
    from ui.app_controller import AppController

    store = JsonProfileStore(tmp_path)
    controller = AppController(profile_store=store)
    controller.set_ui_language("en")

    reloaded = JsonProfileStore(tmp_path).load()
    assert reloaded.language == "en"

    data = store.path.read_text(encoding="utf-8")
    assert '"language": "en"' in data


def test_bootstrap_applies_saved_language(tmp_path) -> None:
    from core.profile_store import JsonProfileStore
    from ui.app_controller import bootstrap_profile
    from ui.i18n import current_language, init_locale

    store = JsonProfileStore(tmp_path)
    profile = store.load()
    profile.language = "en"
    store.save(profile)

    loaded = bootstrap_profile(store)
    assert loaded.language == "en"
    init_locale(loaded.language)
    assert current_language() == "en"


def test_main_window_retranslate_on_language_change(qapp, tmp_path) -> None:
    from core.profile_store import JsonProfileStore
    from ui.app_controller import AppController
    from ui.shell.main_window import MainWindow
    from ui.theme.theme_engine import ThemeEngine

    set_language("es")
    store = JsonProfileStore(tmp_path)
    controller = AppController(profile_store=store)
    theme = ThemeEngine(qapp)
    theme.apply()
    window = MainWindow(theme=theme, controller=controller)
    window.show()
    qapp.processEvents()

    assert window._navigator._title.text() == "Navegador"

    window._on_language_picked("en")
    qapp.processEvents()
    assert window._navigator._title.text() == "Browser"
    assert window._menu_state.file_menu.title() == "File"

    window.shutdown_workers()
    window._analysis_thread.quit()
    window._analysis_thread.wait(2000)
    window._compare_thread.quit()
    window._compare_thread.wait(2000)
    window._sftp_thread.quit()
    window._sftp_thread.wait(2000)
    window.close()
    qapp.processEvents()
    set_language("es")
