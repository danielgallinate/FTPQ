"""Tests compare tabular — multiset."""
from __future__ import annotations

from pathlib import Path

import pytest

from adapters.pandas_compare import compare_tabular_files
from core.app_profile import AppProfile
from core.result import Ok


@pytest.fixture
def profile() -> AppProfile:
    return AppProfile.default()


def test_compare_match_same_content_different_order(tmp_path: Path, profile: AppProfile) -> None:
    pytest.importorskip("pandas")
    path_a = tmp_path / "a.csv"
    path_b = tmp_path / "b.csv"
    path_a.write_text("id,name\n1,alpha\n2,beta\n", encoding="utf-8")
    path_b.write_text("id,name\n2,beta\n1,alpha\n", encoding="utf-8")

    result = compare_tabular_files(
        path_a, path_b, label_a="a.csv", label_b="b.csv", profile=profile
    )
    assert isinstance(result, Ok)
    assert result.value.status == "match"


def test_compare_diff_only_in_b(tmp_path: Path, profile: AppProfile) -> None:
    pytest.importorskip("pandas")
    path_a = tmp_path / "a.csv"
    path_b = tmp_path / "b.csv"
    path_a.write_text("id,name\n1,alpha\n", encoding="utf-8")
    path_b.write_text("id,name\n1,alpha\n2,beta\n", encoding="utf-8")

    result = compare_tabular_files(
        path_a, path_b, label_a="a.csv", label_b="b.csv", profile=profile
    )
    assert isinstance(result, Ok)
    assert result.value.status == "diff"
    assert result.value.only_in_b >= 1
    only_b = [ex for ex in result.value.examples if ex.kind == "only_b"]
    assert only_b
    assert only_b[0].line_b >= 3


def test_compare_abort_on_header_mismatch(tmp_path: Path, profile: AppProfile) -> None:
    pytest.importorskip("pandas")
    path_a = tmp_path / "a.csv"
    path_b = tmp_path / "b.csv"
    path_a.write_text("id,name\n1,a\n", encoding="utf-8")
    path_b.write_text("id,label\n1,a\n", encoding="utf-8")

    result = compare_tabular_files(
        path_a, path_b, label_a="a.csv", label_b="b.csv", profile=profile
    )
    assert isinstance(result, Ok)
    assert result.value.status == "abort"


def test_compare_duplicate_excess(tmp_path: Path, profile: AppProfile) -> None:
    pytest.importorskip("pandas")
    path_a = tmp_path / "a.csv"
    path_b = tmp_path / "b.csv"
    path_a.write_text("id,name\n1,alpha\n1,alpha\n", encoding="utf-8")
    path_b.write_text("id,name\n1,alpha\n", encoding="utf-8")

    result = compare_tabular_files(
        path_a, path_b, label_a="a.csv", label_b="b.csv", profile=profile
    )
    assert isinstance(result, Ok)
    assert result.value.status == "diff"
    assert result.value.duplicate_excess is True
