"""Tests EMR QA — filtro navegador local."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"
FIXTURES = EMR_QA_ROOT / "fixtures"


@pytest.fixture
def browser_listing():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))
    from shell.browser_listing import list_emr_directory

    return list_emr_directory


def test_valid_only_hides_non_tabular(browser_listing, tmp_path):
    (tmp_path / "ok.csv").write_text("a\n1", encoding="utf-8")
    (tmp_path / "notes.txt").write_text("x", encoding="utf-8")
    (tmp_path / "sub").mkdir()

    filtered = browser_listing(tmp_path, valid_files_only=True)
    names = {entry.name for entry in filtered.entries if not entry.is_dir}
    assert "ok.csv" in names
    assert "notes.txt" not in names
    assert any(entry.name.startswith("sub") for entry in filtered.entries)


def test_show_all_includes_non_tabular(browser_listing, tmp_path):
    (tmp_path / "ok.csv").write_text("a\n1", encoding="utf-8")
    (tmp_path / "notes.txt").write_text("x", encoding="utf-8")

    all_entries = browser_listing(tmp_path, valid_files_only=False)
    names = {entry.name for entry in all_entries.entries if not entry.is_dir}
    assert "ok.csv" in names
    assert "notes.txt" in names
