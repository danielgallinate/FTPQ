"""Tests — formato de números en gráficos."""
from __future__ import annotations

from core.chart_format import floor_pct, format_category_label, format_count, format_pct


def test_floor_pct_truncates_toward_zero():
    assert floor_pct(293313, 293374) == 99.97
    assert format_pct(293313, 293374) == "99.97"
    assert floor_pct(100, 100) == 100.0
    assert format_pct(100, 100) == "100.00"


def test_format_count_no_scientific():
    assert format_count(9989) == "9.989"
    assert format_count(500000) == "500.000"
    assert format_count(11) == "11"
    assert format_count(0) == "0"


def test_format_category_label_truncates():
    long_name = "correos_electronicos_paciente"
    assert format_category_label(long_name, max_len=18) == "correos_electroni…"
