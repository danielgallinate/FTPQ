"""Tests EMR QA — template v2.0 validación tabular."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


@pytest.fixture
def validation_modules():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from emrqa.validation_models import DuplicateRecordError, ValidationTemplate, compute_key_fingerprint
    import emrqa.validation_storage as validation_storage

    yield ValidationTemplate, DuplicateRecordError, compute_key_fingerprint, validation_storage


def test_compute_key_fingerprint_stable(validation_modules):
    _, _, compute_key_fingerprint, _ = validation_modules
    assert compute_key_fingerprint(["001234", "ENC-99"]) == compute_key_fingerprint(
        ["001234", "ENC-99"]
    )
    assert compute_key_fingerprint(["001234", "ENC-99"]) != compute_key_fingerprint(
        ["001234", "ENC-100"]
    )


def test_load_example_template(validation_modules):
    ValidationTemplate, _, _, validation_storage = validation_modules
    path = EMR_QA_ROOT / "knowledge_bases/default/templates/tpl_example_patient_encounter.json"
    template = validation_storage.load_validation_template(path)
    assert template.meta.schema_version == "2.0"
    assert template.header.name.startswith("Ejemplo")
    assert len(template.header.fields) == 4
    assert template.header.primary_key() is not None
    assert template.header.primary_key().key_id == "key_patient_encounter"


def test_append_record_and_dedup(validation_modules):
    ValidationTemplate, DuplicateRecordError, _, validation_storage = validation_modules
    path = EMR_QA_ROOT / "knowledge_bases/default/templates/tpl_example_patient_encounter.json"
    template = validation_storage.load_validation_template(path)
    initial_count = len(template.minibase.records)

    row = {
        "mrn": "009999",
        "encounter_id": "ENC-NEW",
        "visit_date": "2026-07-29",
        "status": "A",
    }
    template.append_record(row)
    assert len(template.minibase.records) == initial_count + 1

    with pytest.raises(DuplicateRecordError):
        template.append_record(row)


def test_fingerprint_matches_demo_record(validation_modules):
    ValidationTemplate, _, compute_key_fingerprint, validation_storage = validation_modules
    path = EMR_QA_ROOT / "knowledge_bases/default/templates/tpl_example_patient_encounter.json"
    template = validation_storage.load_validation_template(path)
    demo = template.minibase.records[0]
    key = template.header.key_by_id(demo.key_id)
    assert key is not None
    row = {"mrn": "001234", "encounter_id": "ENC-99"}
    expected = template.fingerprint_for_row(key, row)
    assert demo.key_fingerprint == expected
    assert expected == compute_key_fingerprint(["001234", "ENC-99"])


def test_encrypted_template_round_trip(validation_modules, tmp_path):
    ValidationTemplate, _, _, validation_storage = validation_modules
    from emrqa.template_key_store import TemplateKeyStore

    key_path = tmp_path / "key.json"
    store = TemplateKeyStore(default_path=key_path)
    store.generate_and_save()

    path = EMR_QA_ROOT / "knowledge_bases/default/templates/tpl_example_patient_encounter.json"
    template = validation_storage.load_validation_template(path, key_store=store)
    validation_storage.encrypt_template_minibase(template, store)
    saved = tmp_path / "encrypted_tpl.json"
    disk = validation_storage._disk_dict_from_template(template, store)
    saved.write_text(json.dumps(disk, indent=2, ensure_ascii=False), encoding="utf-8")

    raw = json.loads(saved.read_text(encoding="utf-8"))
    assert "minibase_sealed" in raw
    assert "minibase" not in raw
    assert raw["header"]["encryption"]["key_id"] == store.active_key_id()

    restored = validation_storage.load_validation_template(saved, key_store=store)
    assert restored.is_encrypted
    assert len(restored.minibase.records) == len(template.minibase.records)
    assert restored.minibase.records[0].values == template.minibase.records[0].values


def test_encrypted_template_requires_matching_key(validation_modules, tmp_path):
    ValidationTemplate, _, _, validation_storage = validation_modules
    from emrqa.template_key_store import TemplateKeyStore

    store_a = TemplateKeyStore(default_path=tmp_path / "a.key")
    store_a.generate_and_save()
    path = EMR_QA_ROOT / "knowledge_bases/default/templates/tpl_example_patient_encounter.json"
    template = validation_storage.load_validation_template(path, key_store=store_a)
    validation_storage.encrypt_template_minibase(template, store_a)
    saved = tmp_path / "sealed.json"
    saved.write_text(
        json.dumps(
            validation_storage._disk_dict_from_template(template, store_a),
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    store_b = TemplateKeyStore(default_path=tmp_path / "b.key")
    store_b.generate_and_save()
    with pytest.raises(validation_storage.TemplateKeyMismatchError):
        validation_storage.load_validation_template(saved, key_store=store_b)


def test_list_template_summaries_encrypted_count(validation_modules, tmp_path):
    _, _, _, validation_storage = validation_modules
    from emrqa.template_key_store import TemplateKeyStore

    store = TemplateKeyStore(default_path=tmp_path / "key.json")
    store.generate_and_save()
    path = EMR_QA_ROOT / "knowledge_bases/default/templates/tpl_example_patient_encounter.json"
    template = validation_storage.load_validation_template(path, key_store=store)
    record_count = len(template.minibase.records)
    validation_storage.encrypt_template_minibase(template, store)
    saved = tmp_path / "tpl_enc.json"
    disk = validation_storage._disk_dict_from_template(template, store)
    saved.write_text(json.dumps(disk, indent=2, ensure_ascii=False), encoding="utf-8")

    raw = json.loads(saved.read_text(encoding="utf-8"))
    assert validation_storage._record_count_from_raw(raw) == record_count
