"""Tests UI tabular — modelo y viewer sin flujo SFTP completo."""
from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pytest.importorskip("pandas")

from PySide6.QtWidgets import QApplication

from adapters.pandas_analyzer import analyze_tabular_file
from core.result import Ok
from ui.widgets.data_viewer import DataViewerWidget, _format_header
from ui.widgets.tabular_table_model import TabularTableModel


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def test_tabular_table_model_column_visibility(qapp: QApplication, tmp_path) -> None:
    path = tmp_path / "t.csv"
    path.write_text("a,b,c\n1,2,3\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    model = TabularTableModel()
    model.set_dataset(result.value)
    assert model.rowCount() == 1
    assert model.columnCount() == 3

    model.set_visible_columns([0, 2])
    assert model.columnCount() == 2
    assert model.data(model.index(0, 0)) == "1"
    assert model.data(model.index(0, 1)) == "3"


def test_tabular_table_model_unique_rows(qapp: QApplication, tmp_path) -> None:
    path = tmp_path / "t.csv"
    path.write_text("id,v\n1,a\n1,a\n2,b\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    model = TabularTableModel()
    model.set_dataset(result.value)
    assert model.rowCount() == 3

    model.set_unique_rows_only(True)
    assert model.rowCount() == 2
    assert model.data(model.index(0, 0)) == "1"
    assert model.data(model.index(1, 0)) == "2"


def test_unique_rows_uses_visible_columns_only(qapp: QApplication, tmp_path) -> None:
    path = tmp_path / "t.csv"
    path.write_text("a,b\n1,x\n1,y\n2,x\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    model = TabularTableModel()
    model.set_dataset(result.value)
    model.set_visible_columns([0])
    model.set_unique_rows_only(True)
    assert model.rowCount() == 2
    assert model.data(model.index(0, 0)) == "1"
    assert model.data(model.index(1, 0)) == "2"


def test_tabular_table_model_sorts_numeric_values(qapp: QApplication, tmp_path) -> None:
    from PySide6.QtCore import Qt

    path = tmp_path / "t.csv"
    path.write_text("n\n3\n1\n2\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    model = TabularTableModel()
    model.set_dataset(result.value)
    model.sort(0, Qt.SortOrder.AscendingOrder)
    values = [model.data(model.index(row, 0)) for row in range(model.rowCount())]
    assert values == ["1", "2", "3"]


def test_format_header_includes_file_stats(qapp: QApplication, tmp_path) -> None:
    path = tmp_path / "t.csv"
    path.write_text("id,amount\n1,10\n2,20\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    header = _format_header("demo.csv", result.value, 128)
    assert "Visualización — demo.csv" in header
    assert "2 filas" in header
    assert "2 columnas" in header
    assert "128 B" in header


def test_data_viewer_loads_dataset(qapp: QApplication, tmp_path) -> None:
    path = tmp_path / "t.csv"
    path.write_text("id,amount\n1,10\n2,20\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)
    dataset = result.value

    viewer = DataViewerWidget()
    viewer.load(dataset, filename="t.csv", file_size_bytes=64)
    viewer.configure_load_limits(
        total_rows=dataset.total_rows,
        column_count=len(dataset.columns),
        current_limit=len(dataset.rows),
    )
    qapp.processEvents()

    assert viewer._close.objectName() == "closeDataViewer"
    assert viewer._model.rowCount() == 2
    assert viewer._model.columnCount() == 2
    assert "Visualización — t.csv" in viewer._header.text()
    assert "2 filas" in viewer._header.text()
    assert not viewer._load_bar.isVisible()
    amount = next(c for c in dataset.columns if c.name == "amount")
    assert amount.sum_value == 30.0
    assert amount.mean_value == 15.0


def test_load_bar_visible_for_sample_when_more_than_min_rows(
    qapp: QApplication, tmp_path
) -> None:
    rows = ["id,value"] + [f"{index},{index}" for index in range(50)]
    path = tmp_path / "sample.csv"
    path.write_text("\n".join(rows), encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)
    dataset = result.value

    viewer = DataViewerWidget()
    viewer.load(dataset, filename="sample.csv")
    viewer.configure_load_limits(
        total_rows=dataset.total_rows,
        column_count=len(dataset.columns),
        current_limit=len(dataset.rows),
    )
    qapp.processEvents()

    assert not viewer._load_bar.isHidden()
    assert viewer._load_title.text() in ("Muestra de filas", "Row sample")
    assert viewer._load_rows_combo.isEditable()
    labels = [viewer._load_rows_combo.itemText(index) for index in range(viewer._load_rows_combo.count())]
    assert any("50%" in label for label in labels)
    assert any("10%" in label for label in labels)
    assert viewer._load_rows_combo.itemData(0) == dataset.total_rows
    assert not viewer._load_btn.isEnabled()

    viewer._load_rows_combo.setEditText("25")
    qapp.processEvents()
    assert viewer._load_btn.isEnabled()
    assert viewer._selected_load_rows() == 25


def test_load_bar_visible_when_truncated(qapp: QApplication, tmp_path) -> None:
    rows = ["id,value"] + [f"{index},{index}" for index in range(12_000)]
    path = tmp_path / "big.csv"
    path.write_text("\n".join(rows), encoding="utf-8")
    result = analyze_tabular_file(path, max_display_rows=5_000)
    assert isinstance(result, Ok)
    dataset = result.value

    viewer = DataViewerWidget()
    viewer.show()
    viewer.load(dataset, filename="big.csv")
    viewer.configure_load_limits(
        total_rows=dataset.total_rows,
        column_count=len(dataset.columns),
        current_limit=5_000,
    )
    qapp.processEvents()

    assert not viewer._load_bar.isHidden()
    assert viewer._load_rows_combo.count() >= 2
    assert viewer._load_btn.text() in ("Cargar", "Load", "Autorizar carga", "Authorize load")


def test_column_filter_hides_non_matching_checkboxes(
    qapp: QApplication, tmp_path
) -> None:
    path = tmp_path / "t.csv"
    path.write_text("alpha,beta,gamma\n1,2,3\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    viewer = DataViewerWidget()
    viewer.load(result.value, filename="t.csv")
    viewer._column_filter.setText("ta")
    qapp.processEvents()

    assert viewer._column_checks[0].isHidden()
    assert not viewer._column_checks[1].isHidden()
    assert viewer._column_checks[2].isHidden()


def test_unique_rows_checkbox_filters_table(qapp: QApplication, tmp_path) -> None:
    path = tmp_path / "t.csv"
    path.write_text("id,v\n1,a\n1,a\n2,b\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    viewer = DataViewerWidget()
    viewer.load(result.value, filename="t.csv")
    viewer._unique_rows.setChecked(True)
    qapp.processEvents()

    assert viewer._model.rowCount() == 2


def test_select_none_leaves_exactly_one_column(qapp: QApplication, tmp_path) -> None:
    path = tmp_path / "t.csv"
    path.write_text("a,b,c\n1,2,3\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    viewer = DataViewerWidget()
    viewer.load(result.value, filename="t.csv")
    viewer._select_no_columns()
    qapp.processEvents()

    checked = [idx for idx, box in enumerate(viewer._column_checks) if box.isChecked()]
    assert checked == [0]
    assert viewer._model.columnCount() == 1


def test_header_click_sorts_table(qapp: QApplication, tmp_path) -> None:
    from PySide6.QtCore import Qt

    path = tmp_path / "t.csv"
    path.write_text("n\n3\n1\n2\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    viewer = DataViewerWidget()
    viewer.load(result.value, filename="t.csv")
    viewer._on_header_section_clicked(0)
    qapp.processEvents()
    values = [viewer._model.data(viewer._model.index(row, 0)) for row in range(3)]
    assert values == ["1", "2", "3"]

    viewer._on_header_section_clicked(0)
    qapp.processEvents()
    values_desc = [viewer._model.data(viewer._model.index(row, 0)) for row in range(3)]
    assert values_desc == ["3", "2", "1"]


def test_column_index_changed_accepts_model_index(qapp: QApplication, tmp_path) -> None:
    path = tmp_path / "t.csv"
    path.write_text("id,amount\n1,10\n2,20\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    viewer = DataViewerWidget()
    viewer.load(result.value, filename="t.csv")
    current = viewer._model.index(0, 1)
    viewer._on_cell_selection_changed(current, current)
    qapp.processEvents()

    assert "amount" in viewer._stats.toPlainText()


def test_append_message_does_not_hide_tabular_view(qapp: QApplication, tmp_path) -> None:
    from ui.panels.detail_panel import DetailPanel

    path = tmp_path / "t.csv"
    path.write_text("id,v\n1,a\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    panel = DetailPanel()
    panel.show_tabular(result.value, filename="t.csv")
    panel.append_message("no debe cambiar de pagina")
    qapp.processEvents()

    assert panel._stack.currentIndex() == panel._PAGE_DATA
    assert not panel._title.isVisible()


def test_column_reorder_preserves_source_order(qapp: QApplication, tmp_path) -> None:
    path = tmp_path / "t.csv"
    path.write_text("a,b,c\n1,2,3\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    model = TabularTableModel()
    model.set_dataset(result.value)
    model.set_visible_columns([0, 1, 2])
    model.reorder_visible_columns([2, 0, 1])
    assert model.column_name_at(0) == "c"
    assert model.column_name_at(1) == "a"
    assert model.column_name_at(2) == "b"


def test_column_highlight_survives_hide_and_show(qapp: QApplication, tmp_path) -> None:
    from PySide6.QtCore import Qt

    path = tmp_path / "t.csv"
    path.write_text("a,b,c\n1,2,3\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    model = TabularTableModel()
    model.set_dataset(result.value)
    model.set_column_highlight(1, 3)
    model.set_visible_columns([0, 2])
    assert model.column_highlight(1) == 3
    model.set_visible_columns([0, 1, 2])
    view_col = next(
        col for col in range(model.columnCount()) if model.column_index_at(col) == 1
    )
    brush = model.data(model.index(0, view_col), Qt.ItemDataRole.BackgroundRole)
    assert brush is not None


def test_row_highlight_overrides_column(qapp: QApplication, tmp_path) -> None:
    from PySide6.QtCore import Qt

    path = tmp_path / "t.csv"
    path.write_text("a,b\n1,2\n3,4\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    model = TabularTableModel()
    model.set_dataset(result.value)
    model.set_column_highlight(0, 0)
    model.set_row_highlight(1, 5)
    row_brush = model.data(model.index(1, 0), Qt.ItemDataRole.BackgroundRole)
    col_brush = model.data(model.index(0, 0), Qt.ItemDataRole.BackgroundRole)
    assert row_brush is not None
    assert col_brush is not None
    assert row_brush != col_brush


def test_highlights_cleared_on_new_dataset(qapp: QApplication, tmp_path) -> None:
    path = tmp_path / "t.csv"
    path.write_text("a,b\n1,2\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    model = TabularTableModel()
    model.set_dataset(result.value)
    model.set_column_highlight(0, 2)
    model.set_row_highlight(0, 4)

    path2 = tmp_path / "t2.csv"
    path2.write_text("x\n9\n", encoding="utf-8")
    result2 = analyze_tabular_file(path2)
    assert isinstance(result2, Ok)
    model.set_dataset(result2.value)
    assert model.column_highlight(0) is None
    assert model.row_highlight(0) is None


def test_viewer_column_highlight_via_model(qapp: QApplication, tmp_path) -> None:
    from PySide6.QtCore import Qt

    path = tmp_path / "t.csv"
    path.write_text("id,amount\n1,10\n2,20\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    viewer = DataViewerWidget()
    viewer.load(result.value, filename="t.csv")
    viewer._model.set_column_highlight(1, 7)
    qapp.processEvents()
    brush = viewer._model.data(viewer._model.index(0, 1), Qt.ItemDataRole.BackgroundRole)
    assert brush is not None


def test_viewer_double_click_copies_cell(qapp: QApplication, tmp_path) -> None:
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QMouseEvent

    path = tmp_path / "t.csv"
    path.write_text("email,name\ntest@x.com,Ada\n", encoding="utf-8")
    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)

    viewer = DataViewerWidget()
    viewer.show()
    viewer.load(result.value, filename="t.csv")
    index = viewer._model.index(0, 0)
    pos = viewer._table.visualRect(index).center()
    viewport = viewer._table.viewport()
    global_pos = viewport.mapToGlobal(pos)
    event = QMouseEvent(
        QMouseEvent.Type.MouseButtonDblClick,
        pos,
        global_pos,
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    qapp.sendEvent(viewport, event)
    qapp.processEvents()

    assert qapp.clipboard().text() == "test@x.com"
    assert viewer._copy_toast.isVisible()
    assert viewer._copy_toast.text() in ("Copiado", "Copied")
