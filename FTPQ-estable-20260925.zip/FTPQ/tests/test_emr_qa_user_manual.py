"""Tests — manual de uso EMR QA."""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


def test_user_manual_paths_exist():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from shell.user_manual import user_manual_path

    es_path = user_manual_path("es")
    en_path = user_manual_path("en")
    assert es_path.is_file()
    assert en_path.is_file()
    assert es_path.name == "manual-es.txt"
    assert en_path.name == "manual-en.txt"
    assert "EMR QA" in es_path.read_text(encoding="utf-8")
    assert "EMR QA" in en_path.read_text(encoding="utf-8")
