"""Tests adapters/pandas_analyzer — análisis tabular local."""
from __future__ import annotations

from pathlib import Path

import pytest

pandas = pytest.importorskip("pandas")

from adapters.pandas_analyzer import analyze_tabular_file
from core.result import Ok


def test_analyze_csv_stats(tmp_path: Path) -> None:
    path = tmp_path / "sample.csv"
    path.write_text(
        "id,name,amount\n1,alpha,10\n2,beta,20\n3,alpha,10\n",
        encoding="utf-8",
    )

    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)
    dataset = result.value
    assert dataset.total_rows == 3
    assert len(dataset.columns) == 3
    assert len(dataset.rows) == 3

    by_name = {col.name: col for col in dataset.columns}
    assert by_name["amount"].sum_value == 40.0
    assert by_name["amount"].mean_value == pytest.approx(40 / 3)
    assert by_name["name"].unique_count == 2
    assert by_name["name"].sum_value is None


def test_analyze_respects_display_row_limit(tmp_path: Path) -> None:
    path = tmp_path / "big.csv"
    lines = ["id,value"] + [f"{i},{i}" for i in range(100)]
    path.write_text("\n".join(lines), encoding="utf-8")

    result = analyze_tabular_file(path, max_display_rows=10)
    assert isinstance(result, Ok)
    dataset = result.value
    assert dataset.total_rows == 100
    assert len(dataset.rows) == 10
    assert dataset.display_truncated is True


def test_analyze_psv_pipe_delimiter(tmp_path: Path) -> None:
    path = tmp_path / "sample.psv"
    path.write_text(
        "id|name|amount\n1|alpha|10\n2|beta|20\n",
        encoding="utf-8",
    )

    result = analyze_tabular_file(path)
    assert isinstance(result, Ok)
    dataset = result.value
    assert dataset.total_rows == 2
    assert len(dataset.columns) == 3
    by_name = {col.name: col for col in dataset.columns}
    assert by_name["amount"].sum_value == 30.0


def test_analyze_rejects_over_max_bytes(tmp_path: Path) -> None:
    from core.analysis_errors import AnalysisTooLargeError
    from core.result import Err

    path = tmp_path / "tiny.csv"
    path.write_text("id\n1\n", encoding="utf-8")
    result = analyze_tabular_file(path, max_bytes=1)
    assert isinstance(result, Err)
    assert isinstance(result.error, AnalysisTooLargeError)
    assert result.error.limit_bytes == 1


def test_analyze_accepts_file_when_limit_is_1_gib(tmp_path: Path) -> None:
    from core.analysis_limits import CLI_PANDAS_MAX_BYTES
    from core.result import Ok

    path = tmp_path / "ok.csv"
    path.write_text("id\n1\n", encoding="utf-8")
    result = analyze_tabular_file(path, max_bytes=CLI_PANDAS_MAX_BYTES)
    assert isinstance(result, Ok)


def test_analyze_over_limit_loads_sample_when_requested(tmp_path: Path) -> None:
    path = tmp_path / "huge.csv"
    lines = ["id,value"] + [f"{i},{i}" for i in range(500)]
    path.write_text("\n".join(lines), encoding="utf-8")

    result = analyze_tabular_file(path, max_bytes=10, sample_rows=25)
    assert isinstance(result, Ok)
    dataset = result.value
    assert dataset.sampled is True
    assert dataset.total_rows == 25
    assert len(dataset.rows) == 25


def test_analyze_sample_estimates_total_rows(tmp_path: Path) -> None:
    path = tmp_path / "huge.csv"
    lines = ["id,value"] + [f"{i:06d},{i:06d}" for i in range(1_000)]
    path.write_text("\n".join(lines), encoding="utf-8")

    result = analyze_tabular_file(path, max_bytes=10, sample_rows=50)
    assert isinstance(result, Ok)
    estimated = result.value.estimated_total_rows
    assert estimated is not None
    assert 900 <= estimated <= 1_100


def test_analyze_under_limit_is_not_sampled(tmp_path: Path) -> None:
    path = tmp_path / "small.csv"
    path.write_text("id,value\n1,a\n2,b\n", encoding="utf-8")

    result = analyze_tabular_file(path, sample_rows=1)
    assert isinstance(result, Ok)
    dataset = result.value
    assert dataset.sampled is False
    assert dataset.estimated_total_rows is None
    assert dataset.total_rows == 2
