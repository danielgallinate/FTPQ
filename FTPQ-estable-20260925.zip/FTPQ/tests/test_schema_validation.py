"""Tests — validación estructural de columnas."""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from core.schema_catalog_types import SchemaCatalog, SchemaColumnSpec
from core.schema_validation import cell_matches_type, is_null_cell, validate_schema_catalog


def _catalog(*, strict: bool = False) -> SchemaCatalog:
    return SchemaCatalog(
        schema_id="test",
        name="Test",
        strict=strict,
        columns=[
            SchemaColumnSpec(name="id", data_type="integer", allows_null=False, enabled=True),
            SchemaColumnSpec(name="flag", data_type="boolean", allows_null=True, enabled=True),
            SchemaColumnSpec(name="note", data_type="string", allows_null=True, enabled=False),
        ],
    )


def test_is_null_cell():
    assert is_null_cell(None)
    assert is_null_cell("")
    assert is_null_cell("  ")
    assert is_null_cell("<NA>")
    assert not is_null_cell("0")


def test_cell_matches_type():
    int_spec = SchemaColumnSpec(name="id", data_type="integer", allows_null=False)
    assert cell_matches_type("42", int_spec)
    assert not cell_matches_type("42.1", int_spec)
    assert not cell_matches_type(None, int_spec)

    bool_spec = SchemaColumnSpec(name="flag", data_type="boolean", allows_null=True)
    assert cell_matches_type("true", bool_spec)
    assert cell_matches_type(None, bool_spec)
    assert not cell_matches_type("maybe", bool_spec)


def test_date_type_requires_date_without_time():
    spec = SchemaColumnSpec(name="AUTH_START_DATE", data_type="date", allows_null=True)
    assert cell_matches_type("2024-04-28", spec)
    assert not cell_matches_type("2024-04-28 10:30:00", spec)
    assert not cell_matches_type("2024-04-28T10:30:00", spec)
    assert not cell_matches_type("28/04/2024", spec)


def test_datetime_type_requires_time_component():
    spec = SchemaColumnSpec(name="EXTRACT_DATE_TIME_UTC", data_type="datetime", allows_null=True)
    assert cell_matches_type("2026-03-15 23:02:10", spec)
    assert cell_matches_type("2026-03-15 23:02:10.805000", spec)
    assert cell_matches_type("2026-03-15T23:02:10", spec)
    assert cell_matches_type("2026-03-15T23:02:10Z", spec)
    assert cell_matches_type("2026-03-15T23:02:10+00:00", spec)
    assert not cell_matches_type("2026-03-15", spec)


def test_datetime_type_honours_explicit_format():
    spec = SchemaColumnSpec(
        name="RECORD_DATE",
        data_type="datetime",
        allows_null=True,
        date_format="%Y-%m-%d",
    )
    assert cell_matches_type("2026-03-15", spec)
    assert not cell_matches_type("2026-03-15 23:02:10", spec)


def test_validate_schema_non_strict_coverage():
    catalog = _catalog(strict=False)
    rows = [{"id": "1", "flag": "true", "extra": "x"}]
    name_to_index = {"id": 0, "flag": 1, "extra": 2}
    result = validate_schema_catalog(
        catalog,
        rows,
        file_columns=list(name_to_index.keys()),
        name_to_index=name_to_index,
    )
    assert "extra" in result.coverage_columns
    assert (0, 2) in result.gray_cells
    assert (0, 0) in result.passed_cells
    assert not result.structural_errors


def test_validate_schema_strict_column_mismatch():
    catalog = _catalog(strict=True)
    rows = [{"id": "1", "flag": "true", "extra": "x"}]
    name_to_index = {"id": 0, "flag": 1, "extra": 2, "note": 3}
    result = validate_schema_catalog(
        catalog,
        rows,
        file_columns=list(name_to_index.keys()),
        name_to_index=name_to_index,
    )
    assert result.structural_errors
    assert any("strict column mismatch" in item for item in result.structural_errors)


def test_validate_schema_type_failure():
    catalog = _catalog(strict=False)
    rows = [{"id": "not-int", "flag": "true"}]
    name_to_index = {"id": 0, "flag": 1}
    result = validate_schema_catalog(
        catalog,
        rows,
        file_columns=list(name_to_index.keys()),
        name_to_index=name_to_index,
    )
    assert (0, 0) in result.failed_cells


def test_validate_schema_unique_column():
    catalog = SchemaCatalog(
        schema_id="uniq",
        name="uniq",
        columns=[
            SchemaColumnSpec(
                name="code",
                data_type="string",
                allows_null=False,
                unique=True,
                enabled=True,
            ),
        ],
    )
    rows = [{"code": "A"}, {"code": "A"}, {"code": "B"}]
    name_to_index = {"code": 0}
    result = validate_schema_catalog(
        catalog,
        rows,
        file_columns=["code"],
        name_to_index=name_to_index,
    )
    assert (0, 0) in result.failed_cells
    assert (1, 0) in result.failed_cells
    assert (2, 0) in result.passed_cells


def test_empty_file_reports_no_data_instead_of_pass():
    """Archivo con encabezado y cero filas: alerta, no aprobado ni reprobado."""
    sys.path.insert(0, str(REPO_ROOT / "emr-qa"))
    from shell.schema_metrics import build_schema_validation_report

    catalog = _catalog(strict=False)
    name_to_index = {"id": 0, "flag": 1}
    result = validate_schema_catalog(
        catalog,
        [],
        file_columns=list(name_to_index.keys()),
        name_to_index=name_to_index,
    )
    report = build_schema_validation_report(
        file_name="vacio.csv",
        catalog=catalog,
        result=result,
        rows_total=0,
        name_to_index=name_to_index,
    )
    assert report.no_data is True
    assert report.cells_ok == 0
    assert report.cells_nok == 0
    assert "SIN DATOS" in report.headline or "NO DATA" in report.headline


def test_report_with_rows_is_not_flagged_no_data():
    sys.path.insert(0, str(REPO_ROOT / "emr-qa"))
    from shell.schema_metrics import build_schema_validation_report

    catalog = _catalog(strict=False)
    name_to_index = {"id": 0, "flag": 1}
    rows = [{"id": "1", "flag": "true"}]
    result = validate_schema_catalog(
        catalog,
        rows,
        file_columns=list(name_to_index.keys()),
        name_to_index=name_to_index,
    )
    report = build_schema_validation_report(
        file_name="con_datos.csv",
        catalog=catalog,
        result=result,
        rows_total=len(rows),
        name_to_index=name_to_index,
    )
    assert report.no_data is False


def test_run_result_verdict_has_three_states():
    sys.path.insert(0, str(REPO_ROOT / "emr-qa"))
    from job_runner import EmrQaJobRunResult

    base = {"mode": "schema", "file_path": Path("x.csv")}
    assert EmrQaJobRunResult(ok=True, **base).verdict == "PASS"
    assert EmrQaJobRunResult(ok=False, **base).verdict == "FAIL"
    assert EmrQaJobRunResult(ok=True, no_data=True, **base).verdict == "NO DATA"
    # Incremental: cero filas no es FAIL aunque haya ok=False (p. ej. umbral 0%).
    assert EmrQaJobRunResult(ok=False, no_data=True, **base).verdict == "NO DATA"


def test_schema_job_roundtrip(tmp_path: Path):
    sys.path.insert(0, str(REPO_ROOT / "emr-qa"))
    from core.emr_qa_job import EmrQaJob, JobSchemaSection, load_job, save_job

    job = EmrQaJob(
        name="schema-test",
        mode="schema",
        schema=JobSchemaSection(schema_id="sample_encounters"),
    )
    path = tmp_path / "job.job.json"
    save_job(path, job)
    loaded = load_job(path)
    assert loaded.mode == "schema"
    assert loaded.schema.schema_id == "sample_encounters"
