"""Registro visual de builds — ui/version_changelog.txt."""
from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from ui.i18n import set_language, tr
from ui.version import display_version, is_beta_release
from ui.version_changelog import (
    changelog_path,
    format_changelog_dialog_text,
    load_changelog_entries,
)


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def test_changelog_file_exists() -> None:
    assert changelog_path().is_file()


def test_current_build_in_changelog() -> None:
    version = display_version()
    versions = [entry[0] for entry in load_changelog_entries()]
    assert versions[0] == version


def test_format_includes_build_actual() -> None:
    set_language("es")
    text = format_changelog_dialog_text()
    assert display_version() in text
    assert tr("changelog.title") in text


def test_entries_use_pipe_format() -> None:
    for version, change in load_changelog_entries():
        assert version[0].isdigit()
        assert change


def test_stable_release_semver() -> None:
    assert not is_beta_release()
    assert display_version() == "1.0.0"


def test_build_counter_resets_each_day() -> None:
    """NNNN reinicia por día en entradas dev 0.0.YYMMDD.NNNN."""
    by_date: dict[str, list[int]] = {}
    for version, _ in load_changelog_entries():
        if not version.startswith("0.0."):
            continue
        _prefix, _minor, day, build_str = version.split(".")
        build = int(build_str)
        by_date.setdefault(day, []).append(build)

    for day, builds in by_date.items():
        builds_sorted = sorted(builds, reverse=True)
        assert builds == builds_sorted, f"{day}: entradas desordenadas"
        assert min(builds) == 1, f"{day}: el primer build del día debe ser 0001"
