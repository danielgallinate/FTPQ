"""Tests — job SFTP headless (S18/S19) con MockSftpBrowser."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import date
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]


def _write_job(path: Path, **overrides) -> Path:
    payload = {
        "schema_version": 1,
        "kind": "sftp_fetch",
        "name": "extracts-daily",
        "profile": str(REPO_ROOT / "profiles" / "example_profile.json"),
        "remote_dir": "scheduled",
        "local_dir": str(path.parent / "downloads"),
        "on_collision": "fail",
        "expect": [{"pattern": "example_extract_20260701.csv", "min_count": 1}],
    }
    payload.update(overrides)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return path


@pytest.fixture
def mock_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PDE_DESKTOP_MOCK", "1")


def test_load_job_rejects_wrong_kind(tmp_path: Path) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job

    job_path = _write_job(tmp_path / "bad.job.json", kind="schema")
    with pytest.raises(ValueError, match="sftp_fetch"):
        load_job(job_path)


def test_glob_downloads_one_file(tmp_path: Path, mock_env: None) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    local_dir = tmp_path / "out"
    job_path = _write_job(
        tmp_path / "one.job.json",
        local_dir=str(local_dir),
        expect=[{"pattern": "example_extract_20260701.csv", "min_count": 1}],
    )
    result = run_sftp_job(load_job(job_path))
    assert result.ok
    dest = local_dir / "example_extract_20260701.csv"
    assert dest.is_file()
    assert dest.stat().st_size > 0
    assert result.expects[0]["status"] == "PASS"
    assert result.expects[0]["matched"] == ["example_extract_20260701.csv"]


def test_min_count_not_met_does_not_download(tmp_path: Path, mock_env: None) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    local_dir = tmp_path / "out"
    job_path = _write_job(
        tmp_path / "missing.job.json",
        local_dir=str(local_dir),
        expect=[{"pattern": "Nope_*.csv", "min_count": 1}],
    )
    result = run_sftp_job(load_job(job_path))
    assert not result.ok
    assert result.expects[0]["status"] == "MISSING"
    assert not local_dir.exists() or not any(local_dir.iterdir())


def test_existence_only_accepts_date_token_without_local_dir(
    tmp_path: Path, mock_env: None
) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    job_path = _write_job(
        tmp_path / "exist.job.json",
        local_dir="",
        download=False,
        expect=[{"pattern": "*{date}.csv", "min_count": 1}],
    )
    result = run_sftp_job(load_job(job_path), as_of=date(2026, 7, 1))

    assert result.ok
    assert result.local_dir is None
    assert result.expects[0]["pattern"] == "*{date}.csv"
    assert result.expects[0]["resolved_pattern"] == "*20260701.csv"
    assert result.expects[0]["matched"] == ["example_extract_20260701.csv"]
    assert result.expects[0]["local_paths"] == []
    assert not (tmp_path / "downloads").exists()


def test_existence_only_supports_regular_expression(
    tmp_path: Path, mock_env: None
) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    job_path = _write_job(
        tmp_path / "regex.job.json",
        local_dir="",
        download=False,
        expect=[
            {
                "pattern": r"^example_extract_{date}\.csv$",
                "match_type": "regex",
                "min_count": 1,
            }
        ],
    )
    result = run_sftp_job(load_job(job_path), as_of=date(2026, 7, 2))

    assert result.ok
    assert result.expects[0]["match_type"] == "regex"
    assert result.expects[0]["matched"] == ["example_extract_20260702.csv"]


def test_existence_regex_accepts_csv_tsv_or_psv() -> None:
    from pathlib import PurePosixPath

    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from sftp_jobs.runner import _RemoteFile, _match

    files = [
        _RemoteFile("a.csv", "a.csv", PurePosixPath("a.csv"), 1),
        _RemoteFile("b.tsv", "b.tsv", PurePosixPath("b.tsv"), 1),
        _RemoteFile("c.psv", "c.psv", PurePosixPath("c.psv"), 1),
        _RemoteFile("d.json", "d.json", PurePosixPath("d.json"), 1),
    ]
    matched = _match(
        files,
        r"(?i).*\.(csv|tsv|psv)$",
        match_type="regex",
    )
    assert [item.name for item in matched] == ["a.csv", "b.tsv", "c.psv"]


def test_collision_fail_skips_overwrite(tmp_path: Path, mock_env: None) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    local_dir = tmp_path / "out"
    local_dir.mkdir()
    existing = local_dir / "example_extract_20260701.csv"
    existing.write_text("keep-me\n", encoding="utf-8")
    job_path = _write_job(
        tmp_path / "collision.job.json",
        local_dir=str(local_dir),
        on_collision="fail",
        expect=[{"pattern": "example_extract_20260701.csv", "min_count": 1}],
    )
    result = run_sftp_job(load_job(job_path))
    assert not result.ok
    assert result.expects[0]["status"] == "COLLISION"
    assert existing.read_text(encoding="utf-8") == "keep-me\n"


def test_sequence_of_two_patterns(tmp_path: Path, mock_env: None) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    local_dir = tmp_path / "out"
    job_path = _write_job(
        tmp_path / "seq.job.json",
        local_dir=str(local_dir),
        expect=[
            {"pattern": "*20260701.csv", "min_count": 1},
            {"pattern": "*20260702.csv", "min_count": 1},
        ],
    )
    result = run_sftp_job(load_job(job_path))
    assert result.ok
    assert (local_dir / "example_extract_20260701.csv").is_file()
    assert (local_dir / "example_extract_20260702.csv").is_file()
    assert [item["pattern"] for item in result.expects] == [
        "*20260701.csv",
        "*20260702.csv",
    ]


def test_fail_fast_skips_later_expect(tmp_path: Path, mock_env: None) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    local_dir = tmp_path / "out"
    job_path = _write_job(
        tmp_path / "fast.job.json",
        local_dir=str(local_dir),
        expect=[
            {"pattern": "Nope_*.csv", "min_count": 1},
            {"pattern": "*20260701.csv", "min_count": 1},
        ],
    )
    result = run_sftp_job(load_job(job_path))
    assert not result.ok
    assert result.expects[1]["status"] == "SKIPPED"
    assert not (local_dir / "example_extract_20260701.csv").exists()


def test_cli_mock_json_out(tmp_path: Path) -> None:
    job_path = _write_job(
        tmp_path / "cli.job.json",
        local_dir=str(tmp_path / "cli-out"),
        expect=[{"pattern": "example_extract_*.csv", "min_count": 2}],
    )
    json_out = tmp_path / "result.json"
    script = REPO_ROOT / "scripts" / "run_sftp_job.sh"
    env = os.environ.copy()
    env["PDE_DESKTOP_MOCK"] = "1"
    proc = subprocess.run(
        [str(script), str(job_path), "--json-out", str(json_out), "--quiet"],
        cwd=REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout.strip() == "PASS"
    data = json.loads(json_out.read_text(encoding="utf-8"))
    assert data["ok"] is True
    assert len(data["expects"][0]["matched"]) == 2


def test_cli_existence_only_accepts_as_of_date(tmp_path: Path) -> None:
    job_path = _write_job(
        tmp_path / "exist-cli.job.json",
        local_dir="",
        download=False,
        expect=[{"pattern": "*{date}.csv", "min_count": 1}],
    )
    json_out = tmp_path / "exist-result.json"
    script = REPO_ROOT / "scripts" / "run_sftp_job.sh"
    env = os.environ.copy()
    env["PDE_DESKTOP_MOCK"] = "1"
    proc = subprocess.run(
        [
            str(script),
            str(job_path),
            "--as-of",
            "20260702",
            "--json-out",
            str(json_out),
            "--quiet",
        ],
        cwd=REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert proc.returncode == 0, proc.stderr
    result = json.loads(json_out.read_text(encoding="utf-8"))
    assert result["local_dir"] is None
    assert result["expects"][0]["resolved_pattern"] == "*20260702.csv"
    assert result["expects"][0]["matched"] == ["example_extract_20260702.csv"]


def test_local_dir_override_ignores_job_json(tmp_path: Path, mock_env: None) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    json_dir = tmp_path / "from-json"
    override = tmp_path / "from-cli"
    job_path = _write_job(
        tmp_path / "override.job.json",
        local_dir=str(json_dir),
        expect=[{"pattern": "example_extract_20260701.csv", "min_count": 1}],
    )
    result = run_sftp_job(load_job(job_path), local_dir=override)
    assert result.ok
    assert result.local_dir == override.resolve()
    assert (override / "example_extract_20260701.csv").is_file()
    assert not json_dir.exists() or not any(json_dir.iterdir())


def test_cli_local_dir_flag(tmp_path: Path) -> None:
    job_path = _write_job(
        tmp_path / "cli-dir.job.json",
        local_dir=str(tmp_path / "unused"),
        expect=[{"pattern": "example_extract_20260701.csv", "min_count": 1}],
    )
    dest = tmp_path / "param-out"
    json_out = tmp_path / "result.json"
    script = REPO_ROOT / "scripts" / "run_sftp_job.sh"
    env = os.environ.copy()
    env["PDE_DESKTOP_MOCK"] = "1"
    proc = subprocess.run(
        [
            str(script),
            str(job_path),
            "--local-dir",
            str(dest),
            "--json-out",
            str(json_out),
            "--quiet",
        ],
        cwd=REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr
    data = json.loads(json_out.read_text(encoding="utf-8"))
    assert Path(data["local_dir"]) == dest.resolve()
    assert (dest / "example_extract_20260701.csv").is_file()


def test_missing_local_dir_without_flag_fails(tmp_path: Path, mock_env: None) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    job_path = _write_job(tmp_path / "no-dir.job.json", local_dir="")
    job = load_job(job_path)
    with pytest.raises(ValueError, match="local_dir"):
        run_sftp_job(job)


def test_recursive_download_preserves_tree_and_writes_manifest(
    tmp_path: Path, mock_env: None
) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    base = tmp_path / "downloads"
    job_path = _write_job(
        tmp_path / "recursive.job.json",
        remote_dir=".",
        local_dir=str(base),
        recursive=True,
        destination_name="{sftp_user}",
        expect=[{"pattern": "*.csv", "min_count": 2}],
    )
    result = run_sftp_job(load_job(job_path))

    target = base / "example_user"
    assert result.ok
    assert result.local_dir == target.resolve()
    assert (target / "scheduled" / "example_extract_20260701.csv").is_file()
    assert (target / "scheduled" / "example_extract_20260702.csv").is_file()
    assert (target / "requested" / "request_20260703.csv").is_file()
    manifest = json.loads(
        (target / "_download_manifest.json").read_text(encoding="utf-8")
    )
    assert manifest["sftp_user"] == "example_user"
    assert manifest["file_count"] == 3
    assert manifest["remote_dir"] == "."


def test_cli_runtime_connection_overrides(tmp_path: Path) -> None:
    job_path = _write_job(
        tmp_path / "runtime.job.json",
        remote_dir=".",
        local_dir="",
        recursive=True,
        destination_name="{sftp_user}",
        expect=[{"pattern": "*.csv", "min_count": 2}],
    )
    base = tmp_path / "runtime-downloads"
    key_path = tmp_path / "runtime-key"
    json_out = tmp_path / "result.json"
    error_out = tmp_path / "error.json"
    script = REPO_ROOT / "scripts" / "run_sftp_job.sh"
    env = os.environ.copy()
    env["PDE_DESKTOP_MOCK"] = "1"
    proc = subprocess.run(
        [
            str(script),
            str(job_path),
            "--sftp-user",
            "runtime_config",
            "--private-key",
            str(key_path),
            "--local-dir",
            str(base),
            "--json-out",
            str(json_out),
            "--error-out",
            str(error_out),
            "--quiet",
        ],
        cwd=REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert proc.returncode == 0, proc.stderr
    result = json.loads(json_out.read_text(encoding="utf-8"))
    assert result["sftp_user"] == "runtime_config"
    assert Path(result["local_dir"]) == (base / "runtime_config").resolve()
    assert (
        base
        / "runtime_config"
        / "scheduled"
        / "example_extract_20260701.csv"
    ).is_file()
    assert not error_out.exists()


def test_recursive_destination_refuses_existing_folder(
    tmp_path: Path, mock_env: None
) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from sftp_jobs.runner import run_sftp_job

    base = tmp_path / "downloads"
    existing = base / "example_user"
    existing.mkdir(parents=True)
    protected = existing / "keep.txt"
    protected.write_text("do not replace\n", encoding="utf-8")
    job_path = _write_job(
        tmp_path / "collision-tree.job.json",
        remote_dir=".",
        local_dir=str(base),
        recursive=True,
        destination_name="{sftp_user}",
        on_collision="fail",
        expect=[{"pattern": "*.csv", "min_count": 2}],
    )

    result = run_sftp_job(load_job(job_path))

    assert not result.ok
    assert result.expects[0]["status"] == "COLLISION"
    assert protected.read_text(encoding="utf-8") == "do not replace\n"


def test_runtime_user_and_key_override_profile(
    tmp_path: Path, mock_env: None
) -> None:
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.sftp_job import load_job
    from mocks.mock_sftp_browser import MockSftpBrowser
    from sftp_jobs.runner import run_sftp_job

    browser = MockSftpBrowser()
    key_path = tmp_path / "runtime-key"
    job_path = _write_job(
        tmp_path / "profile-overrides.job.json",
        local_dir=str(tmp_path / "out"),
    )

    result = run_sftp_job(
        load_job(job_path),
        browser=browser,
        sftp_user="runtime_config",
        private_key=key_path,
    )

    assert result.ok
    assert browser._profile is not None
    assert browser._profile.user == "runtime_config"
    assert browser._profile.private_key_path == key_path.resolve()


def test_cli_writes_error_json_for_existing_destination(tmp_path: Path) -> None:
    job_path = _write_job(
        tmp_path / "collision-cli.job.json",
        remote_dir=".",
        local_dir="",
        recursive=True,
        destination_name="{sftp_user}",
        expect=[{"pattern": "*.csv", "min_count": 1}],
    )
    base = tmp_path / "downloads"
    (base / "runtime_config").mkdir(parents=True)
    error_out = tmp_path / "sftp-error.json"
    script = REPO_ROOT / "scripts" / "run_sftp_job.sh"
    env = os.environ.copy()
    env["PDE_DESKTOP_MOCK"] = "1"

    proc = subprocess.run(
        [
            str(script),
            str(job_path),
            "--sftp-user",
            "runtime_config",
            "--private-key",
            str(tmp_path / "key"),
            "--local-dir",
            str(base),
            "--error-out",
            str(error_out),
            "--quiet",
        ],
        cwd=REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert proc.returncode == 1
    error = json.loads(error_out.read_text(encoding="utf-8"))
    assert error["exit_code"] == 1
    assert "destination folder exists" in error["error"]
