"""Tests — sesión Run job (overrides efímeros)."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
if str(EMR_QA_ROOT) not in sys.path:
    sys.path.append(str(EMR_QA_ROOT))

from core.emr_qa_job import EmrQaJob, JobQaCatalogSpec, JobQaSection, load_job
from shell.job_run_session import (
    JobRunSession,
    build_effective_job,
    session_ready,
    validation_tab_for_mode,
)
from shell.validation_panel import ValidationTab


def _sample_job(*, mode: str = "qa") -> EmrQaJob:
    return EmrQaJob(
        name="test",
        mode=mode,  # type: ignore[arg-type]
        knowledge_base_id="default",
        qa=JobQaSection(
            template_paths=("case_patient.json",),
            catalogs=(
                JobQaCatalogSpec(catalog_id="clinic_qa", link_column="CLINIC_ID"),
            ),
        ),
    )


def test_build_effective_job_applies_template_overrides(tmp_path: Path) -> None:
    job = _sample_job()
    session = JobRunSession(
        job_path=tmp_path / "run.job.json",
        base_job=job,
        file_path=tmp_path / "case.csv",
        template_paths=("only_one.json",),
    )
    effective = build_effective_job(session)
    assert effective.qa.template_paths == ("only_one.json",)


def test_job_description_roundtrip(tmp_path: Path) -> None:
    from core.emr_qa_job import save_job

    job = _sample_job()
    job = EmrQaJob(
        name=job.name,
        mode=job.mode,
        description="Valida paciente y clínica contra minibase QA.",
        qa=job.qa,
    )
    path = tmp_path / "doc.job.json"
    save_job(path, job)
    loaded = load_job(path)
    assert loaded.description == job.description


def test_session_ready_requires_templates_when_empty(tmp_path: Path) -> None:
    case = tmp_path / "case.csv"
    case.write_text("a\n1\n", encoding="utf-8")
    job = EmrQaJob(
        name="test",
        mode="qa",
        qa=JobQaSection(template_paths=("case_patient.json",)),
    )
    session = JobRunSession(
        job_path=tmp_path / "run.job.json",
        base_job=job,
        file_path=case,
        template_paths=(),
        catalog_specs=(),
    )
    ready, reason = session_ready(session)
    assert ready is False
    assert reason == "templates"


def test_build_effective_job_applies_catalog_overrides(tmp_path: Path) -> None:
    job = _sample_job()
    session = JobRunSession(
        job_path=tmp_path / "run.job.json",
        base_job=job,
        file_path=tmp_path / "case.csv",
        catalog_specs=(JobQaCatalogSpec(catalog_id="icd_qa", link_column="ICD_10"),),
    )
    effective = build_effective_job(session)
    assert len(effective.qa.catalogs) == 1
    assert effective.qa.catalogs[0].catalog_id == "icd_qa"
    assert effective.qa.template_paths == job.qa.template_paths


def test_session_ready_requires_file(tmp_path: Path) -> None:
    missing = tmp_path / "missing.csv"
    session = JobRunSession(
        job_path=tmp_path / "run.job.json",
        base_job=_sample_job(),
        file_path=missing,
    )
    ready, reason = session_ready(session)
    assert ready is False
    assert reason == "file"


def test_session_ready_reference_requires_reference_file(tmp_path: Path) -> None:
    case = tmp_path / "case.csv"
    case.write_text("a\n1\n", encoding="utf-8")
    session = JobRunSession(
        job_path=tmp_path / "run.job.json",
        base_job=_sample_job(mode="reference"),
        file_path=case,
        reference_path=None,
    )
    ready, reason = session_ready(session)
    assert ready is False
    assert reason == "reference"


@pytest.mark.parametrize(
    ("mode", "tab"),
    [
        ("reference", ValidationTab.REFERENCE),
        ("validation", ValidationTab.VALIDATION),
        ("qa", ValidationTab.QA),
    ],
)
def test_validation_tab_for_mode(mode: str, tab: ValidationTab) -> None:
    assert validation_tab_for_mode(mode) == tab
