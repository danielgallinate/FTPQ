"""Tests — cifrado de minibase."""
from __future__ import annotations

import secrets
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"


@pytest.fixture
def crypto_modules():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))

    from emrqa.template_crypto import (
        DecryptionError,
        SealedBlob,
        derive_key_id,
        seal_minibase,
        unseal_minibase,
    )

    yield derive_key_id, seal_minibase, unseal_minibase, DecryptionError, SealedBlob


def test_derive_key_id_stable(crypto_modules):
    derive_key_id, *_ = crypto_modules
    key = secrets.token_bytes(32)
    assert derive_key_id(key) == derive_key_id(key)
    assert len(derive_key_id(key)) == 16


def test_seal_unseal_round_trip(crypto_modules):
    _, seal_minibase, unseal_minibase, _, SealedBlob = crypto_modules
    key = secrets.token_bytes(32)
    payload = {
        "dedup": {"key_id": "key_1", "strategy": "composite_key"},
        "records": [{"record_id": "rec_1", "values": {"fld_mrn": "001"}}],
    }
    sealed = seal_minibase(payload, key)
    restored = unseal_minibase(sealed, key)
    assert restored == payload
    blob_dict = sealed.to_dict()
    restored2 = unseal_minibase(SealedBlob.from_dict(blob_dict), key)
    assert restored2 == payload


def test_unseal_wrong_key_fails(crypto_modules):
    _, seal_minibase, unseal_minibase, DecryptionError, _ = crypto_modules
    key_a = secrets.token_bytes(32)
    key_b = secrets.token_bytes(32)
    sealed = seal_minibase({"dedup": {"key_id": ""}, "records": []}, key_a)
    with pytest.raises(DecryptionError):
        unseal_minibase(sealed, key_b)
