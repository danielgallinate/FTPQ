"""Tests navegador — ordenación por cabecera."""
from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from ui.panels.navigator_panel import NavigatorPanel


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def _names(panel: NavigatorPanel) -> list[str]:
    return [panel._item_text(row, 0) for row in range(panel._table.rowCount())]


def test_navigator_sorts_by_name(qapp: QApplication) -> None:
    panel = NavigatorPanel()
    panel.set_entries(
        [
            {"name": "..", "ext": "", "size": "<DIR>", "modified": ""},
            {"name": "zebra.csv", "ext": ".csv", "size": "    10", "modified": ""},
            {"name": "alpha.csv", "ext": ".csv", "size": "   100", "modified": ""},
        ]
    )
    qapp.processEvents()
    assert _names(panel) == ["..", "alpha.csv", "zebra.csv"]

    panel._on_header_clicked(0)
    qapp.processEvents()
    assert _names(panel) == ["..", "zebra.csv", "alpha.csv"]


def test_navigator_sorts_by_size(qapp: QApplication) -> None:
    panel = NavigatorPanel()
    panel.set_entries(
        [
            {"name": "..", "ext": "", "size": "<DIR>", "modified": ""},
            {"name": "big.csv", "ext": ".csv", "size": "   2.0M", "modified": ""},
            {"name": "small.csv", "ext": ".csv", "size": "   1.0K", "modified": ""},
        ]
    )
    panel._sort_column = 2
    panel._sort_order = Qt.SortOrder.AscendingOrder
    panel._apply_sort()
    qapp.processEvents()

    assert _names(panel)[1:] == ["small.csv", "big.csv"]
