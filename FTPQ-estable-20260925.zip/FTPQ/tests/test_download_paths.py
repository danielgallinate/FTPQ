"""Tests core/download_paths — versionado de nombres."""
from __future__ import annotations

from pathlib import Path

from core.download_paths import next_versioned_path


def test_next_versioned_path_first_free(tmp_path: Path) -> None:
    original = tmp_path / "report.csv"
    original.write_text("old", encoding="utf-8")
    assert next_versioned_path(original) == tmp_path / "report (1).csv"


def test_next_versioned_path_skips_existing(tmp_path: Path) -> None:
    original = tmp_path / "report.csv"
    original.write_text("old", encoding="utf-8")
    (tmp_path / "report (1).csv").write_text("v1", encoding="utf-8")
    assert next_versioned_path(original) == tmp_path / "report (2).csv"
