"""Tests límites de visualización tabular."""
from __future__ import annotations

from core.analysis_limits import (
    DEFAULT_MAX_DISPLAY_ROWS,
    DISPLAY_ROW_PRESETS,
    MANAGEABLE_CELL_BUDGET,
    REFERENCE_COLUMN_COUNT,
    RELOAD_VOLUME_PRESETS,
    SAMPLE_ROW_MIN,
    clamp_reload_rows,
    display_row_options,
    estimate_cell_volume,
    exceeds_manageable_volume,
    normalize_max_display_rows,
    parse_reload_row_input,
    reference_column_count,
    reload_row_choices,
    reload_row_options,
    should_offer_row_reload,
    suggested_max_display_rows,
)
from core.app_profile import AppProfile


def test_display_row_presets_are_ordered() -> None:
    assert DISPLAY_ROW_PRESETS == (5_000, 10_000, 25_000, 50_000, 100_000)
    assert RELOAD_VOLUME_PRESETS == (50_000, 100_000, 200_000)
    assert DEFAULT_MAX_DISPLAY_ROWS == 5_000
    assert MANAGEABLE_CELL_BUDGET == 100_000
    assert REFERENCE_COLUMN_COUNT == 20


def test_normalize_max_display_rows_snaps_up() -> None:
    assert normalize_max_display_rows(1) == 5_000
    assert normalize_max_display_rows(5_001) == 10_000
    assert normalize_max_display_rows(99_999) == 100_000
    assert normalize_max_display_rows(500_000) == 100_000


def test_reference_column_count_caps_at_twenty() -> None:
    assert reference_column_count(1) == 1
    assert reference_column_count(20) == 20
    assert reference_column_count(100) == 20


def test_estimate_cell_volume_uses_reference_columns_only() -> None:
    assert estimate_cell_volume(1_000, 5) == 5_000
    assert estimate_cell_volume(1_000, 20) == 20_000
    assert estimate_cell_volume(1_000, 80) == 20_000


def test_exceeds_manageable_volume() -> None:
    assert not exceeds_manageable_volume(5_000, 20)
    assert exceeds_manageable_volume(5_001, 20)
    assert not exceeds_manageable_volume(20_000, 5)
    assert exceeds_manageable_volume(20_001, 5)


def test_suggested_max_display_rows() -> None:
    assert suggested_max_display_rows(10, 3_000) == 3_000
    assert suggested_max_display_rows(100, 8_000) == 5_000
    assert suggested_max_display_rows(5, 50_000) == 20_000


def test_display_row_options_includes_total_when_needed() -> None:
    assert display_row_options(3_000) == (3_000,)
    assert display_row_options(12_000) == (5_000, 10_000, 12_000)


def test_reload_row_choices_total_percent_and_presets() -> None:
    assert reload_row_choices(10) == ()
    small = reload_row_choices(174)
    kinds = [choice.kind for choice in small]
    rows = [choice.rows for choice in small]
    assert kinds[0] == "total"
    assert rows[0] == 174
    assert "pct50" in kinds
    assert "pct10" in kinds
    assert 87 in rows
    assert 17 in rows

    large = reload_row_choices(500_000)
    large_rows = reload_row_options(500_000)
    assert large_rows[0] == 500_000
    assert 250_000 in large_rows
    assert 50_000 in large_rows
    assert 100_000 in large_rows
    assert 200_000 in large_rows
    assert [choice.rows for choice in large] == list(large_rows)


def test_parse_reload_row_input() -> None:
    assert parse_reload_row_input("250", 1_000) == 250
    assert parse_reload_row_input("25%", 1_000) == 250
    assert parse_reload_row_input("Total (174)", 500) == 174
    assert parse_reload_row_input("abc", 500) is None
    assert clamp_reload_rows(999, 500) == 500
    assert clamp_reload_rows(3, 500) == SAMPLE_ROW_MIN


def test_should_offer_row_reload() -> None:
    assert not should_offer_row_reload(10, 10)
    assert should_offer_row_reload(50, 50)
    assert should_offer_row_reload(12_000, 5_000)
    assert not should_offer_row_reload(0, 0)


def test_profile_persists_max_display_rows(tmp_path) -> None:
    from core.profile_store import JsonProfileStore

    store = JsonProfileStore(tmp_path)
    profile = AppProfile.default()
    profile.max_display_rows = 25_000
    store.save(profile)

    loaded = store.load()
    assert loaded.max_display_rows == 25_000

    data = store.path.read_text(encoding="utf-8")
    assert '"max_display_rows": 25000' in data


def test_parse_job_row_limit_absolute_and_percent() -> None:
    from core.analysis_limits import parse_job_row_limit, resolve_job_display_rows

    assert parse_job_row_limit("100", 50_000) == 100
    assert parse_job_row_limit("10%", 50_000) == 5_000
    assert parse_job_row_limit("10 %", 1_000) == 100
    assert resolve_job_display_rows(row_limit="10%", max_rows=5000, total_rows=20_000) == 2_000
    assert resolve_job_display_rows(row_limit=None, max_rows=5000, total_rows=20_000) == 5000
    assert resolve_job_display_rows(row_limit=None, max_rows=None, total_rows=20_000) == 20_000
