"""Tests core/file_view — lectura local post-descarga."""
from __future__ import annotations

from pathlib import Path

from core.file_view import read_visualize_file
from core.result import Ok


def test_read_visualize_file_full_content(tmp_path: Path) -> None:
    path = tmp_path / "sample.csv"
    path.write_text("a,b\n1,2\n3,4\n", encoding="utf-8")

    result = read_visualize_file(path, max_display_lines=500)
    assert isinstance(result, Ok)
    view = result.value
    assert view.file_size == path.stat().st_size
    assert view.line_count == 3
    assert view.display_truncated is False
    assert "a,b" in view.content


def test_read_visualize_file_truncates_display(tmp_path: Path) -> None:
    path = tmp_path / "lines.txt"
    path.write_text("\n".join(f"line{i}" for i in range(10)), encoding="utf-8")

    result = read_visualize_file(path, max_display_lines=3)
    assert isinstance(result, Ok)
    view = result.value
    assert view.line_count == 10
    assert view.display_truncated is True
    assert view.content.count("\n") == 2
