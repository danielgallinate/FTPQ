"""Tests — emparejamiento batch job ↔ CSV."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
EMR_QA_ROOT = REPO_ROOT / "emr-qa"
JOBS_DIR = REPO_ROOT / "emr-qa/knowledge_bases/default/jobs"


def _import_batch_modules():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    if str(EMR_QA_ROOT) not in sys.path:
        sys.path.append(str(EMR_QA_ROOT))
    from core.batch_match import (
        BatchMatchCompileError,
        build_batch_plan,
        compile_batch_match,
        filename_matches,
        list_batch_job_configs,
        resolve_job_batch_match,
    )
    from core.batch_match_types import BatchMatchSpec
    from core.emr_qa_job import load_job

    return (
        BatchMatchCompileError,
        BatchMatchSpec,
        build_batch_plan,
        compile_batch_match,
        filename_matches,
        list_batch_job_configs,
        load_job,
        resolve_job_batch_match,
    )


DELIVERY_20260924 = (
    "Daniel_test_config15_PRM_Reach_Activities_20260924_050441.csv",
    "Daniel_test_config15_PRM_Reach_Communications_20260924_050441.csv",
    "Daniel_test_config15_PRM_Reach_DPI_20260924_050441.csv",
    "Daniel_test_config15_PRM_Reach_NPS_Data_Points_20260924_050441.csv",
    "Daniel_test_config15_PRM_Reach_Reactivation_Leads_20260924_050441.csv",
    "Daniel_test_config15_PRM_Reach_Ability_To_Engage_20260924_050441.csv",
    "Daniel_test_config15_EMR_Charges_20260924_050441.csv",
    "Daniel_test_config15_EMR_ICD_Codes_20260924_050441.csv",
    "Daniel_test_config15_EMR_Insurances_20260924_050441.csv",
    "Daniel_test_config15_EMR_Missed_And_Open_Notes_20260924_050441.csv",
    "Daniel_test_config15_EMR_Patient_20260924_050441.csv",
    "Daniel_test_config15_EMR_Patient_Insurance_20260924_050441.csv",
    "Daniel_test_config15_EMR_Physician_20260924_050441.csv",
    "Daniel_test_config15_EMR_Prescription_20260924_050441.csv",
    "Daniel_test_config15_EMR_User_20260924_050441.csv",
    "Daniel_test_config15_EMR_Visit_Notes_Extract_20260924_050441.csv",
    "Daniel_test_config15_EMR_Appointments_20260924_050441.csv",
    "Daniel_test_config15_EMR_Authorizations_20260924_050441.csv",
    "Daniel_test_config15_EMR_Cases_20260924_050441.csv",
    "Daniel_test_config15_EMR_Clinic_20260924_050441.csv",
    "Daniel_test_config15_Billing_Charge_20260924_050441.csv",
    "Daniel_test_config15_Billing_Patient_Credit_20260924_050441.csv",
    "Daniel_test_config15_Billing_Payment_Adjustment_20260924_050441.csv",
)


def test_config15_delivery_names_map_one_job_each():
    _, _, _, compile_batch_match, filename_matches, _, load_job, resolve_job_batch_match = (
        _import_batch_modules()
    )
    compiled = []
    for path in sorted(JOBS_DIR.glob("*_col.job.json")):
        job = load_job(path)
        rules = resolve_job_batch_match(job)
        if not rules or not rules.is_configured():
            continue
        compiled.append((path.name, compile_batch_match(rules, path.name)))
    sample = JOBS_DIR / "sample_encounters.job.json"
    if sample.exists():
        job = load_job(sample)
        rules = resolve_job_batch_match(job)
        if rules and rules.is_configured():
            compiled.append((sample.name, compile_batch_match(rules, sample.name)))

    unmatched = []
    collisions = []
    for name in DELIVERY_20260924:
        hits = [job for job, spec in compiled if filename_matches(spec, name)]
        if len(hits) != 1:
            (unmatched if not hits else collisions).append((name, hits))
    assert unmatched == []
    assert collisions == []


def test_billing_transactions_has_no_column_job_yet():
    _, _, _, compile_batch_match, filename_matches, _, load_job, resolve_job_batch_match = (
        _import_batch_modules()
    )
    name = "Daniel_test_config15_Billing_Transactions_20260924_050441.csv"
    hits = []
    for path in JOBS_DIR.glob("*_col.job.json"):
        job = load_job(path)
        rules = resolve_job_batch_match(job)
        if not rules or not rules.is_configured():
            continue
        if filename_matches(compile_batch_match(rules, path.name), name):
            hits.append(path.name)
    assert hits == []


def test_schema_catalog_has_batch_match_for_clinic():
    _, _, _, compile_batch_match, filename_matches, _, load_job, resolve_job_batch_match = (
        _import_batch_modules()
    )
    job = load_job(JOBS_DIR / "clinic_extract_col.job.json")
    rules = resolve_job_batch_match(job)
    assert rules is not None
    compiled = compile_batch_match(rules, "clinic")
    assert filename_matches(compiled, "ZZZTestConfig5_PDE_Clinic_20260904_222326.csv")
    assert filename_matches(compiled, "ZZZTestConfig5_PDE_Clinic_20260904_222326.tsv")
    assert not filename_matches(compiled, "ZZZTestConfig5_PDE_Patient_20260904_222326.csv")


def test_glued_delivery_stamp_matches_clinic_and_not_patient():
    _, _, _, compile_batch_match, filename_matches, _, load_job, resolve_job_batch_match = (
        _import_batch_modules()
    )
    job = load_job(JOBS_DIR / "clinic_extract_col.job.json")
    compiled = compile_batch_match(resolve_job_batch_match(job), "clinic")
    glued = "ZZZTestConfig1PDEClinic20260904_222326.csv"
    assert filename_matches(compiled, glued)
    assert not filename_matches(compiled, "ZZZTestConfig1PDEPatient20260904_222326.csv")


def test_glued_patient_excludes_credit():
    _, _, _, compile_batch_match, filename_matches, _, load_job, resolve_job_batch_match = (
        _import_batch_modules()
    )
    job = load_job(JOBS_DIR / "patient_extract_col.job.json")
    compiled = compile_batch_match(resolve_job_batch_match(job), "patient")
    assert filename_matches(compiled, "AcmePDEPatient20260904_222326.csv")
    assert not filename_matches(compiled, "AcmePDEPatient_Credit20260904_222326.csv")
    credit = load_job(JOBS_DIR / "patient-credit_extract_col.job.json")
    credit_rules = compile_batch_match(resolve_job_batch_match(credit), "credit")
    assert filename_matches(credit_rules, "AcmePDEPatient_Credit20260904_222326.csv")


def test_patient_excludes_credit_and_insurance():
    _, _, _, compile_batch_match, filename_matches, _, load_job, resolve_job_batch_match = (
        _import_batch_modules()
    )
    job = load_job(JOBS_DIR / "patient_extract_col.job.json")
    rules = resolve_job_batch_match(job)
    compiled = compile_batch_match(rules, "patient")
    assert filename_matches(compiled, "ZZZTestConfig5_PDE_Patient_20260904_222326.csv")
    assert not filename_matches(
        compiled, "ZZZTestConfig5_PDE_Patient_Credit_20260904_222326.csv"
    )
    assert not filename_matches(
        compiled, "ZZZTestConfig5_PDE_Patient_Insurance_20260904_222326.csv"
    )


def test_suggest_filename_pattern_matches_its_own_file():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.batch_match import compile_batch_match, filename_matches, suggest_filename_pattern
    from core.batch_match_types import BatchMatchSpec

    sample = "ZZZTestConfig5_PDE_PRM_Reach_NPS_Data_Points_20260904_222326.csv"
    pattern = suggest_filename_pattern(sample)
    compiled = compile_batch_match(BatchMatchSpec(filename_patterns=(pattern,)), "suggested")
    assert filename_matches(compiled, sample)
    # Sirve para otra corrida del mismo extracto y descarta extractos distintos.
    assert filename_matches(
        compiled, "OtroCliente_PDE_PRM_Reach_NPS_Data_Points_20270101_010101.xlsx"
    )
    assert not filename_matches(compiled, "ZZZTestConfig5_PDE_Clinic_20260904_222326.csv")


def test_suggest_filename_pattern_without_stamp_or_prefix():
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from core.batch_match import EXAMPLE_FILENAME_PATTERN, suggest_filename_pattern

    assert suggest_filename_pattern("Clinic.csv").endswith(
        r"\.(?:csv|tsv|psv|xlsx|xlsm|xls)$"
    )
    assert "Clinic" in suggest_filename_pattern("Clinic.csv")
    assert suggest_filename_pattern("20260904_222326.csv") == EXAMPLE_FILENAME_PATTERN
    assert suggest_filename_pattern("") == EXAMPLE_FILENAME_PATTERN


def test_invalid_regex_raises():
    _, BatchMatchSpec, _, compile_batch_match, _, _, _, _ = _import_batch_modules()
    rules = BatchMatchSpec(filename_patterns=("[invalid",))
    with pytest.raises(Exception):
        compile_batch_match(rules, "broken")


def test_job_without_batch_config_is_not_configured(tmp_path):
    _, BatchMatchSpec, _, _, _, _, load_job, resolve_job_batch_match = _import_batch_modules()
    job_path = tmp_path / "no-batch.job.json"
    job_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "name": "no-batch",
                "mode": "validation",
                "validation": {"template_path": "tpl.json"},
            }
        ),
        encoding="utf-8",
    )
    job = load_job(job_path)
    rules = resolve_job_batch_match(job)
    assert rules is None or not rules.is_configured()


def test_build_batch_plan_matches_clinic_csv():
    _, _, build_batch_plan, _, _, list_batch_job_configs, _, _ = _import_batch_modules()
    configs = list_batch_job_configs(JOBS_DIR)
    csv_path = Path("ZZZTestConfig5_PDE_Clinic_20260904_222326.csv")
    plan = build_batch_plan(configs, [csv_path])
    clinic_pairs = [pair for pair in plan.pairs if pair[0].name == "clinic_extract_col.job.json"]
    assert len(clinic_pairs) == 1


def test_batch_match_spec_roundtrip():
    _, BatchMatchSpec, _, _, _, _, _, _ = _import_batch_modules()
    spec = BatchMatchSpec(
        filename_patterns=("(?i).*clinic.*",),
        filename_excludes=("(?i).*credit.*",),
    )
    restored = BatchMatchSpec.from_dict(spec.to_dict())
    assert restored == spec
