"""Tests LocalKeyStore — discover, generate, fingerprint."""
from __future__ import annotations

from pathlib import Path

from adapters.local_key_store import LocalKeyStore


def test_generate_and_discover_rsa(tmp_path: Path) -> None:
    store = LocalKeyStore()
    private = tmp_path / "test_rsa"
    info = store.generate(private, "rsa", bits=2048)

    assert info.private_path.is_file()
    assert info.public_path.is_file()
    assert info.key_type == "rsa"

    found = store.discover(tmp_path)
    assert len(found) == 1
    assert found[0].path.resolve() == private.resolve()

    fp = store.fingerprint(private)
    assert ":" in fp
    assert store.validate(private) == []


def test_discover_ignores_pub_files(tmp_path: Path) -> None:
    store = LocalKeyStore()
    store.generate(tmp_path / "key_a", "ecdsa")
    (tmp_path / "dummy.pub").write_text("ssh-rsa AAA\n", encoding="utf-8")

    names = {c.label for c in store.discover(tmp_path)}
    assert "dummy.pub" not in names
    assert "key_a" in names
