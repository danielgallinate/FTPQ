# Referencia — PDE SFTP Validator 0.6.3

Zip en repo: [`../pde-sftp-validator-0.6.3-qa-20260707.zip`](../pde-sftp-validator-0.6.3-qa-20260707.zip)

**No es código oficial de PDE Desktop** — solo consulta al portar SFTP.

## Archivos útiles del validator

| Archivo en zip | Reutilizar en Desktop |
|----------------|----------------------|
| `pde_sftp_validator/sftp_client.py` | Adapter paramiko (S01, S06–S09) |
| `pde_sftp_validator/browse_service.py` | Navegación list_dir |
| `pde_sftp_validator/browser_format.py` | Columnas explorador P1 |
| `pde_sftp_validator/ssh_keys.py` | IKeyStore |
| `pde_sftp_validator/connectivity.py` | Patrón test_auth S05 |
| `docs/CONFIG_SCREEN.md` | Campos config → U-M03 Rutas |

## No portar

- `tui_app.py`, Textual
- `db_client.py`, F7 scan BD
- `.env` multi-sección como única config

## Extraer localmente

```bash
unzip -q pde-sftp-validator-0.6.3-qa-20260707.zip -d /tmp/pde-validator-ref
```
