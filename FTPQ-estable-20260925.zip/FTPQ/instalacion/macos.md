# macOS — instalación paso a paso

**PDE Desktop 1.0.0** · uso individual · Python **3.12+**

---

## 1. Python 3.12 o superior

Comprobar:

```bash
python3 --version
```

Debe mostrar `Python 3.12.x` o superior.

Si no lo tenés:

- **Opción A (recomendada):** [python.org/downloads](https://www.python.org/downloads/) → macOS installer 3.12+
- **Opción B:** Homebrew: `brew install python@3.12`

---

## 2. Copiar el repo

```bash
cd ~/repositorios   # o tu carpeta de trabajo
# git clone <url-interna> "SFTP TOOL"
# o descomprimir zip interno en esa ruta
cd "SFTP TOOL"
```

---

## 3. Llave SSH

1. Guardá la llave privada que te entregaron (solo vos, permisos restrictivos):

```bash
mkdir -p ~/.ssh
chmod 700 ~/.ssh
cp /ruta/entrega/tu_llave_rsa ~/.ssh/
chmod 600 ~/.ssh/tu_llave_rsa
```

2. Anotá la ruta: `~/.ssh/tu_llave_rsa`

---

## 4. Archivo `.env` (config SFTP)

1. Copiá [`ejemplo.env`](./ejemplo.env) a un sitio fuera del repo compartido, por ejemplo:

```bash
mkdir -p ~/.pde-desktop
cp instalacion/ejemplo.env ~/.pde-desktop/pde.env
chmod 600 ~/.pde-desktop/pde.env
```

2. Editá con tu editor (`nano`, VS Code, etc.):

| Variable | Qué poner |
|----------|-----------|
| `SFTP_HOST` | Host Transfer Family (ej. `s-….server.transfer.us-west-2.amazonaws.com`) |
| `SFTP_USER` | Tu usuario SFTP |
| `SFTP_KEY_PATH` | Ruta a la llave privada |
| `DOWNLOAD_DIR` | Carpeta local de descargas (ej. `~/PDE-Desktop/downloads`) |

3. **No** incluyas contraseñas de base de datos; PDE Desktop las ignora.

---

## 5. Entorno virtual e dependencias

Desde la raíz del repo:

```bash
chmod +x scripts/setup.sh scripts/run_ui.sh
./scripts/setup.sh
```

Crea `.venv/` e instala PySide6, pandas, paramiko.

---

## 6. Primera ejecución

```bash
./scripts/run_ui.sh
```

### En la app

1. **Settings → Paths → Import .env** → elegí `~/.pde-desktop/pde.env` (o tu `.env` del validator).
2. **Settings → Keys** → revisá host, usuario y ruta de llave → **Test connection** (con **VPN conectada**).
3. **File → Connect** (o menú Conexión) → navegá SFTP.

Prueba sin red (mock):

```bash
PDE_DESKTOP_MOCK=1 ./scripts/run_ui.sh
```

---

## 7. VPN

Conectá la **VPN corporativa antes** de probar SFTP real. Sin VPN verás timeout o lista vacía.

---

## 8. Problemas frecuentes

| Síntoma | Qué hacer |
|---------|-----------|
| `Python 3.12+ required` | Actualizá Python (paso 1) |
| Permission denied (SSH) | `chmod 600` en la llave |
| Timeout SFTP | VPN activa + host correcto en `.env` |
| App no abre | Reinstalá deps: `./scripts/setup.sh` |

---

## 9. Ticket a IT

Si falta permiso para Python, VPN o llaves: [plantilla-ticket-it.md](./plantilla-ticket-it.md)
