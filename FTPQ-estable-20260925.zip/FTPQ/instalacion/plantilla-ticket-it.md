# Plantilla — ticket IT / Service Desk

Copiá y adaptá. Reemplazá los `[...]`.

---

## Asunto

`Solicitud: entorno local PDE Desktop (Python 3.12 + WSL2) — uso individual autorizado`

---

## Tipo de solicitud

- [ ] Software / permiso de instalación  
- [ ] Red / VPN / firewall  
- [ ] Cuenta o acceso SFTP (si aplica)  
- [ ] Política / excepción (completar justificación abajo)

---

## Solicitante

| Campo | Valor |
|-------|-------|
| Nombre | `[Tu nombre]` |
| Usuario / email | `[usuario@empresa.com]` |
| Equipo | `[Data / Analytics / …]` |
| Manager | `[Nombre]` |
| Máquina | `[Mac serial / Windows hostname / WorkSpace ID]` |

---

## Resumen (1 párrafo para IT)

Solicito permiso para usar **PDE Desktop 1.0.0**, herramienta **local de uso individual** para conectar por **SFTP (SSH)** al entorno PDE (AWS Transfer Family), listar archivos y analizar extracts CSV/TSV en mi PC **sin instalar un `.exe` custom**. La app se ejecuta desde código fuente con **Python 3.12+** en **[macOS nativo / Windows WSL2]**. No comparto el software con otros usuarios ni lo publico fuera de la organización.

---

## Qué necesito que IT habilite

### A. Software (elegir según plataforma)

**macOS**

| Ítem | Detalle |
|------|---------|
| Instalar o permitir **Python 3.12+** | Desde python.org o Homebrew; uso en venv local del usuario |
| No se requiere | Instalador MSI firmado, PyInstaller, admin para “Unknown developer” de binario custom |

**Windows**

| Ítem | Detalle |
|------|---------|
| **WSL2** habilitado | `wsl --install` o feature “Windows Subsystem for Linux” |
| Distro **Ubuntu** (o similar) en WSL2 | Para correr los mismos scripts `.sh` que en Mac |
| **Python 3.12+** dentro de WSL | `apt install python3.12 python3.12-venv` |
| **WSLg** (UI) | Windows 11 recomendado para ventana gráfica; actualización WSL |
| No se requiere | Portable `.exe` sin firmar, Python embed corporativo bloqueado por GPO (sustituido por WSL) |

### B. Red

| Ítem | Detalle |
|------|---------|
| **VPN corporativa** | Activa en la sesión del usuario antes de SFTP |
| Salida **TCP 22 (SSH/SFTP)** | Hacia endpoint AWS Transfer Family: `[SFTP_HOST si lo conocés]` |
| DNS / proxy | Resolución del host Transfer Family sin bloqueo |

### C. Credenciales SFTP

| Ítem | Detalle |
|------|---------|
| Usuario SFTP PDE | `[usuario]` — si aún no lo tengo, derivar a equipo de provisioning PDE |
| Llave SSH privada | Almacenada en `~/.ssh/` del usuario (Mac o WSL), permisos 600 |
| Rotación | Seguir política estándar de llaves; no enviar la privada por email/Slack |

### D. Datos / compliance

| Ítem | Detalle |
|------|---------|
| Descargas locales | CSV/TSV en carpeta del usuario (`DOWNLOAD_DIR`); **puede contener PHI** |
| Responsabilidad | Uso solo en máquina autorizada; no reenviar extracts por canales no aprobados |
| No se usa | Conexión directa a Postgres/Snowflake desde esta herramienta (fase actual) |

### E. Active Directory / GPO (si aplica)

Solicito confirmación o excepción documentada si alguna política bloquea:

- [ ] Instalación de Python / Homebrew (Mac)  
- [ ] Feature WSL2 o virtualización (Windows)  
- [ ] Ejecución de scripts `.sh` en WSL  
- [ ] Cliente VPN simultáneo con WSL  
- [ ] Escritura en `%USERPROFILE%\.ssh` o equivalente WSL  

**Alternativa oficial de la org:** portal PDE web + cliente SFTP estándar (FileZilla, WinSCP, Cyberduck). PDE Desktop es **complemento de productividad individual**, no reemplazo del canal member-facing.

---

## Qué NO estoy pidiendo

- Distribución de binarios a otros usuarios  
- Firma de código / whitelist SmartScreen para `.exe` custom  
- Excepción para empaquetar llaves SSH en un zip compartible  
- Acceso a bases de datos de producción desde la app  

---

## Pasos que haré yo (post-aprobación)

1. Instalar Python 3.12+ **[Mac / WSL2 según tabla]**  
2. Clonar o copiar repo interno en carpeta local  
3. Configurar `~/.pde-desktop/pde.env` (host, user, ruta llave — **sin secretos de BD**)  
4. `./scripts/setup.sh` → `./scripts/run_ui.sh`  
5. Conectar VPN → Test SFTP en la app  

Guía completa: `instalacion/macos.md` o `instalacion/windows-wsl2.md` en el repo.

---

## Justificación de negocio

`[1–3 oraciones: ej. revisar extracts PDE antes de cargar a otro sistema, comparar archivos multiset localmente, reducir ida/vuelta con soporte SFTP estándar]`

---

## Aprobaciones

| Rol | Nombre | Fecha |
|-----|--------|-------|
| Manager | | |
| IT / Security | | |
| Data owner (si PHI) | | |

---

## Referencias internas (opcional)

- Canal PDE oficial: web + AWS Transfer Family  
- Política PHI en workstation: `[ticket/política DEA-8648 o equivalente]`  
- Alcance herramienta: `documentacion/alcance-uso-individual.md` en el repo  
