# Windows — instalación con WSL2

**PDE Desktop 1.0.0** no usa CMD/PowerShell nativo ni `.exe` portable. En Windows se corre **dentro de WSL2** (Linux) con Python **3.12+**.

---

## 1. Instalar WSL2 (una vez)

Abrí **PowerShell como administrador** en Windows:

```powershell
wsl --install
```

Reiniciá si lo pide. Por defecto instala **Ubuntu**.

Comprobar:

```powershell
wsl --version
wsl -l -v
```

La distro debe estar en **VERSION 2**.

Si ya tenés WSL1:

```powershell
wsl --set-default-version 2
wsl --update
```

---

## 2. Entrar a Ubuntu (WSL)

```powershell
wsl
```

Quedás en un shell Linux (`user@machine:~$`).

---

## 3. Python 3.12+ dentro de WSL

```bash
sudo apt update
sudo apt install -y python3.12 python3.12-venv python3-pip
python3.12 --version
```

Si `python3.12` no está en tu distro, usá el PPA deadsnakes o Ubuntu 24.04+.

Alias opcional:

```bash
sudo update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.12 1
```

---

## 4. Copiar el repo en WSL

**Opción A — repo en disco Windows** (fácil desde Explorer):

```bash
cd "/mnt/c/Users/TU_USUARIO/repositorios/SFTP TOOL"
```

**Opción B — repo solo en home WSL** (mejor rendimiento):

```bash
cp -r "/mnt/c/Users/TU_USUARIO/repositorios/SFTP TOOL" ~/pde-desktop
cd ~/pde-desktop
```

Usá comillas si la ruta tiene espacios.

---

## 5. Llave SSH (dentro de WSL)

```bash
mkdir -p ~/.ssh
chmod 700 ~/.ssh
cp /mnt/c/ruta/entrega/tu_llave_rsa ~/.ssh/
chmod 600 ~/.ssh/tu_llave_rsa
```

La ruta en `.env` será `~/.ssh/tu_llave_rsa` (WSL, no `C:\Users\...`).

---

## 6. Archivo `.env`

```bash
mkdir -p ~/.pde-desktop
cp instalacion/ejemplo.env ~/.pde-desktop/pde.env
chmod 600 ~/.pde-desktop/pde.env
nano ~/.pde-desktop/pde.env
```

Mismas variables que en Mac — ver [`ejemplo.env`](./ejemplo.env).

---

## 7. Setup y ejecución

```bash
chmod +x scripts/setup.sh scripts/run_ui.sh
./scripts/setup.sh
./scripts/run_ui.sh
```

### Interfaz gráfica (WSLg)

En **Windows 11** con WSLg, la ventana PySide6 suele abrir sola.

Si no aparece:

```powershell
wsl --update
```

Actualizá drivers gráficos Windows. Reiniciá WSL: `wsl --shutdown` y volvé a entrar.

---

## 8. VPN

Conectá la **VPN en Windows** (cliente corporativo en el host), **no solo dentro de WSL**.

Luego, desde WSL: `./scripts/run_ui.sh` → Test connection / Connect.

---

## 9. Importar `.env` en la app

Igual que Mac: **Settings → Paths → Import .env** → `~/.pde-desktop/pde.env`

---

## 10. Mock sin VPN

```bash
PDE_DESKTOP_MOCK=1 ./scripts/run_ui.sh
```

---

## 11. Problemas frecuentes

| Síntoma | Qué hacer |
|---------|-----------|
| `wsl: command not found` | Habilitar WSL (paso 1) o pedir a IT |
| No abre ventana UI | WSLg / `wsl --update` |
| SFTP timeout | VPN en Windows + `.env` correcto |
| Llave rechazada | Permisos `chmod 600` en WSL, ruta en `.env` Linux |

---

## 12. Ticket a IT

[plantilla-ticket-it.md](./plantilla-ticket-it.md)
