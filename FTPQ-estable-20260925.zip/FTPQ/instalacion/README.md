# Instalación PDE Desktop 1.0.0

Guías paso a paso para uso **individual** en tu máquina. No hay `.exe` ni `.dmg`: solo **Python 3.12+** y scripts del repo.

| Plataforma | Guía |
|------------|------|
| **macOS nativo** | [macos.md](./macos.md) |
| **Windows (WSL2)** | [windows-wsl2.md](./windows-wsl2.md) |

## Antes de empezar

1. Acceso **VPN corporativa** (para SFTP PDE / AWS Transfer Family).
2. **Llave SSH** autorizada para tu usuario SFTP (la entrega IT o el equipo de datos).
3. Copia del repo en una carpeta local (Git clone o zip interno — **no compartir** fuera de canales aprobados).

## Configuración SFTP (`.env`)

Plantilla: [`ejemplo.env`](./ejemplo.env)

La app puede importar el `.env` desde **Settings → Paths → Import .env** (equivalente al validator PDE, **solo sección SFTP**; credenciales de BD se ignoran).

Alternativa: editar `profiles/default.json` desde la UI (Settings / Keys).

## Si IT bloquea algo

Usá la plantilla: [plantilla-ticket-it.md](./plantilla-ticket-it.md)

## Ejecución rápida (resumen)

```bash
cd "/ruta/al/repo/SFTP TOOL"
chmod +x scripts/setup.sh scripts/run_ui.sh
./scripts/setup.sh
./scripts/run_ui.sh
```

Mock sin VPN (solo prueba UI):

```bash
PDE_DESKTOP_MOCK=1 ./scripts/run_ui.sh
```

---

Ver también: [`../documentacion/plataformas/`](../documentacion/plataformas/README.md) · [`../release/STABLE-1.0.0.md`](../release/STABLE-1.0.0.md)
