"""Diálogo Ejecutar job — documentación, rutas de sesión y templates editables."""
from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import QSettings, Qt
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QTextEdit,
    QVBoxLayout,
    QWidget,
    QFileDialog,
)

from core.emr_qa_job import EmrQaJob, JobQaCatalogSpec, load_job
from emrqa.validation_storage import templates_dir
from shell.automation_tab import list_job_paths
from shell.job_metadata_dialog import default_job_description
from shell.job_run_session import JobRunSession, session_ready
from ui.i18n import tr

_SETTINGS_ORG = "FTPQ"
_SETTINGS_APP = "EMRQA"
_SETTINGS_LAST_FILE = "job_run/last_file"


class JobRunDialog(QDialog):
    def __init__(self, parent=None, *, initial_job_path: Path | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("emr.action.run_job"))
        self.setMinimumSize(760, 620)
        self._settings = QSettings(_SETTINGS_ORG, _SETTINGS_APP)
        self._loaded_job: EmrQaJob | None = None
        self._job_path: Path | None = None
        self._catalog_rows: list[tuple[QLineEdit, QLineEdit]] = []
        self._template_rows: list[tuple[QLineEdit, QPushButton]] = []
        self._session: JobRunSession | None = None

        self._hint = QLabel()
        self._hint.setWordWrap(True)
        self._hint.setObjectName("configHint")

        self._job_label = QLabel()
        self._job_path_edit = QLineEdit()
        self._job_browse = QPushButton()
        self._job_browse.clicked.connect(self._browse_job)

        job_row = QHBoxLayout()
        job_row.addWidget(self._job_path_edit, stretch=1)
        job_row.addWidget(self._job_browse)

        self._meta = QLabel()
        self._meta.setWordWrap(True)
        self._meta.setObjectName("configHint")

        self._docs_title = QLabel()
        self._docs_title.setObjectName("panelSubtitle")
        self._docs = QTextEdit()
        self._docs.setReadOnly(True)
        self._docs.setMaximumHeight(96)

        self._json_title = QLabel()
        self._json_title.setObjectName("panelSubtitle")
        self._json = QTextEdit()
        self._json.setReadOnly(True)
        self._json.setMaximumHeight(120)

        self._file_label = QLabel()
        self._file = QLineEdit()
        self._file_browse = QPushButton()
        self._file_browse.clicked.connect(self._browse_file)

        file_row = QHBoxLayout()
        file_row.addWidget(self._file, stretch=1)
        file_row.addWidget(self._file_browse)

        self._row_limit_label = QLabel()
        self._row_limit = QLineEdit()
        self._row_limit_hint = QLabel()
        self._row_limit_hint.setWordWrap(True)
        self._row_limit_hint.setObjectName("configHint")

        self._reference_label = QLabel()
        self._reference = QLineEdit()
        self._reference_browse = QPushButton()
        self._reference_browse.clicked.connect(self._browse_reference)

        reference_row = QHBoxLayout()
        reference_row.addWidget(self._reference, stretch=1)
        reference_row.addWidget(self._reference_browse)

        self._reference_host = QWidget()
        ref_layout = QVBoxLayout(self._reference_host)
        ref_layout.setContentsMargins(0, 0, 0, 0)
        ref_layout.addWidget(self._reference_label)
        ref_layout.addLayout(reference_row)

        self._templates_label = QLabel()
        self._templates_hint = QLabel()
        self._templates_hint.setWordWrap(True)
        self._templates_hint.setObjectName("configHint")
        self._templates_host = QWidget()
        self._templates_layout = QVBoxLayout(self._templates_host)
        self._templates_layout.setContentsMargins(0, 0, 0, 0)
        self._templates_layout.setSpacing(4)
        templates_scroll = QScrollArea()
        templates_scroll.setWidgetResizable(True)
        templates_scroll.setWidget(self._templates_host)
        templates_scroll.setMaximumHeight(110)
        templates_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._add_template = QPushButton()
        self._add_template.clicked.connect(self._add_template_row)

        self._templates_panel = QWidget()
        templates_panel_layout = QVBoxLayout(self._templates_panel)
        templates_panel_layout.setContentsMargins(0, 0, 0, 0)
        templates_panel_layout.addWidget(self._templates_label)
        templates_panel_layout.addWidget(self._templates_hint)
        templates_panel_layout.addWidget(templates_scroll)
        templates_panel_layout.addWidget(self._add_template, alignment=Qt.AlignmentFlag.AlignLeft)

        self._validation_template_label = QLabel()
        self._validation_template = QLineEdit()
        self._validation_template_browse = QPushButton()
        self._validation_template_browse.clicked.connect(self._browse_validation_template)
        validation_row = QHBoxLayout()
        validation_row.addWidget(self._validation_template, stretch=1)
        validation_row.addWidget(self._validation_template_browse)
        self._validation_template_host = QWidget()
        validation_layout = QVBoxLayout(self._validation_template_host)
        validation_layout.setContentsMargins(0, 0, 0, 0)
        validation_layout.addWidget(self._validation_template_label)
        validation_layout.addLayout(validation_row)

        self._schema_id_label = QLabel()
        self._schema_id = QLineEdit()
        self._schema_host = QWidget()
        schema_layout = QVBoxLayout(self._schema_host)
        schema_layout.setContentsMargins(0, 0, 0, 0)
        schema_layout.addWidget(self._schema_id_label)
        schema_layout.addWidget(self._schema_id)

        self._catalogs_label = QLabel()
        self._catalogs_host = QWidget()
        self._catalogs_layout = QVBoxLayout(self._catalogs_host)
        self._catalogs_layout.setContentsMargins(0, 0, 0, 0)
        self._catalogs_layout.setSpacing(4)
        catalogs_scroll = QScrollArea()
        catalogs_scroll.setWidgetResizable(True)
        catalogs_scroll.setWidget(self._catalogs_host)
        catalogs_scroll.setMaximumHeight(100)
        catalogs_scroll.setFrameShape(QFrame.Shape.NoFrame)

        self._catalogs_panel = QWidget()
        catalogs_panel_layout = QVBoxLayout(self._catalogs_panel)
        catalogs_panel_layout.setContentsMargins(0, 0, 0, 0)
        catalogs_panel_layout.addWidget(self._catalogs_label)
        catalogs_panel_layout.addWidget(catalogs_scroll)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Cancel | QDialogButtonBox.StandardButton.Ok
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText(tr("emr.automation.run_job"))
        buttons.accepted.connect(self._on_run)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(self._hint)
        layout.addWidget(self._job_label)
        layout.addLayout(job_row)
        layout.addWidget(self._meta)
        layout.addWidget(self._docs_title)
        layout.addWidget(self._docs)
        layout.addWidget(self._json_title)
        layout.addWidget(self._json)
        layout.addWidget(self._file_label)
        layout.addLayout(file_row)
        layout.addWidget(self._row_limit_label)
        layout.addWidget(self._row_limit)
        layout.addWidget(self._row_limit_hint)
        layout.addWidget(self._reference_host)
        layout.addWidget(self._templates_panel)
        layout.addWidget(self._validation_template_host)
        layout.addWidget(self._schema_host)
        layout.addWidget(self._catalogs_panel)
        layout.addWidget(buttons)

        self._retranslate_ui()
        if initial_job_path is not None:
            self._load_job_path(initial_job_path.resolve())
        else:
            paths = list_job_paths()
            if paths:
                self._load_job_path(paths[0])

    def session(self) -> JobRunSession | None:
        return self._session

    def _retranslate_ui(self) -> None:
        self.setWindowTitle(tr("emr.action.run_job"))
        self._hint.setText(tr("emr.job_run.dialog_hint"))
        self._job_label.setText(tr("emr.job_run.job_label"))
        self._job_browse.setText(tr("emr.automation.browse"))
        self._docs_title.setText(tr("emr.job.metadata.description_label"))
        self._json_title.setText(tr("emr.automation.editor_title"))
        self._file_label.setText(tr("emr.automation.file_label"))
        self._file_browse.setText(tr("emr.automation.browse"))
        self._row_limit_label.setText(tr("emr.job.row_limit_label"))
        self._row_limit.setPlaceholderText(tr("emr.job.row_limit_ph"))
        self._row_limit_hint.setText(tr("emr.job.row_limit_hint"))
        self._reference_label.setText(tr("emr.automation.reference_label"))
        self._reference_browse.setText(tr("emr.automation.browse"))
        self._templates_label.setText(tr("emr.automation.templates_label"))
        self._templates_hint.setText(tr("emr.job_run.templates_session_hint"))
        self._add_template.setText(tr("emr.job_run.add_template"))
        self._validation_template_label.setText(tr("emr.job_run.validation_template"))
        self._validation_template_browse.setText(tr("emr.automation.browse"))
        self._schema_id_label.setText(tr("emr.job_run.schema_id"))
        self._catalogs_label.setText(tr("emr.automation.catalogs_session"))

    def _browse_job(self) -> None:
        path_str, _filter = QFileDialog.getOpenFileName(
            self,
            tr("emr.action.run_job"),
            self._job_path_edit.text().strip() or str(Path.home()),
            tr("emr.automation.dialog_filter"),
        )
        if path_str:
            self._load_job_path(Path(path_str))

    def _browse_file(self) -> None:
        path_str, _filter = QFileDialog.getOpenFileName(
            self,
            tr("emr.automation.file_label"),
            self._file.text().strip() or str(Path.home()),
            tr("emr.dialog.tabular_filter"),
        )
        if path_str:
            self._file.setText(path_str)

    def _browse_reference(self) -> None:
        path_str, _filter = QFileDialog.getOpenFileName(
            self,
            tr("emr.automation.reference_label"),
            self._reference.text().strip() or str(Path.home()),
            tr("emr.dialog.tabular_filter"),
        )
        if path_str:
            self._reference.setText(path_str)

    def _browse_validation_template(self) -> None:
        kb = self._loaded_job.knowledge_base_id if self._loaded_job else "default"
        start = str(templates_dir(kb))
        path_str, _filter = QFileDialog.getOpenFileName(
            self,
            tr("emr.job_run.validation_template"),
            start,
            tr("emr.job_run.template_filter"),
        )
        if not path_str:
            return
        path = Path(path_str)
        base = templates_dir(kb).resolve()
        try:
            self._validation_template.setText(path.resolve().relative_to(base).as_posix())
        except ValueError:
            self._validation_template.setText(path.name)

    def _load_job_path(self, path: Path) -> None:
        resolved = path.resolve()
        self._job_path = resolved
        self._job_path_edit.setText(str(resolved))
        try:
            job = load_job(resolved)
            raw = json.loads(resolved.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            self._loaded_job = None
            self._meta.setText(tr("emr.automation.job_load_fail", error=exc))
            self._docs.clear()
            self._json.clear()
            self._clear_session_fields()
            return
        self._loaded_job = job
        self._meta.setText(
            tr(
                "emr.automation.job_meta",
                name=job.name,
                mode=job.mode,
                path=str(resolved),
                columns=len(job.evaluated_columns or ()),
            )
        )
        docs = job.description.strip() or default_job_description(job.mode)
        self._docs.setPlainText(docs)
        self._json.setPlainText(json.dumps(raw, indent=2, ensure_ascii=False) + "\n")
        self._populate_session_fields(job)

    def _clear_session_fields(self) -> None:
        self._file.clear()
        self._row_limit.clear()
        self._reference.clear()
        self._clear_template_rows()
        self._clear_catalog_rows()
        self._validation_template.clear()
        self._reference_host.setVisible(False)
        self._templates_panel.setVisible(False)
        self._validation_template_host.setVisible(False)
        self._catalogs_panel.setVisible(False)

    def _clear_catalog_rows(self) -> None:
        while self._catalogs_layout.count():
            item = self._catalogs_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._catalog_rows.clear()

    def _clear_template_rows(self) -> None:
        while self._templates_layout.count():
            item = self._templates_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._template_rows.clear()

    def _add_template_row(self, *, initial: str = "") -> None:
        row = QWidget()
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        path_edit = QLineEdit(initial)
        path_edit.setPlaceholderText(tr("emr.job_run.template_ph"))
        remove = QPushButton("−")
        remove.setFixedWidth(28)
        remove.clicked.connect(lambda _checked=False, widget=row: self._remove_template_row(widget))
        browse = QPushButton("…")
        browse.setFixedWidth(32)
        browse.clicked.connect(lambda _checked=False, edit=path_edit: self._browse_template_path(edit))
        row_layout.addWidget(path_edit, stretch=1)
        row_layout.addWidget(browse)
        row_layout.addWidget(remove)
        self._templates_layout.addWidget(row)
        self._template_rows.append((path_edit, remove))

    def _remove_template_row(self, row: QWidget) -> None:
        for index, (edit, _remove) in enumerate(self._template_rows):
            if edit.parent() is row or edit.parentWidget() is row:
                self._template_rows.pop(index)
                break
        row.deleteLater()

    def _browse_template_path(self, target: QLineEdit) -> None:
        kb = self._loaded_job.knowledge_base_id if self._loaded_job else "default"
        path_str, _filter = QFileDialog.getOpenFileName(
            self,
            tr("emr.automation.templates_label"),
            str(templates_dir(kb)),
            tr("emr.job_run.template_filter"),
        )
        if not path_str:
            return
        path = Path(path_str)
        base = templates_dir(kb).resolve()
        try:
            target.setText(path.resolve().relative_to(base).as_posix())
        except ValueError:
            target.setText(path.name)

    def _rebuild_catalog_rows(self, specs: tuple[JobQaCatalogSpec, ...]) -> None:
        self._clear_catalog_rows()
        if not specs:
            self._catalogs_panel.setVisible(False)
            return
        self._catalogs_panel.setVisible(True)
        for spec in specs:
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            catalog_id = QLineEdit(spec.catalog_id)
            link_column = QLineEdit(spec.link_column)
            link_column.setPlaceholderText(tr("emr.automation.link_column_ph"))
            row_layout.addWidget(catalog_id, stretch=1)
            row_layout.addWidget(link_column, stretch=1)
            self._catalogs_layout.addWidget(row)
            self._catalog_rows.append((catalog_id, link_column))

    def _rebuild_template_rows(self, paths: tuple[str, ...]) -> None:
        self._clear_template_rows()
        if not paths:
            self._add_template_row()
            return
        for path in paths:
            self._add_template_row(initial=path)

    def _populate_session_fields(self, job: EmrQaJob) -> None:
        file_text = job.file or self._settings.value(_SETTINGS_LAST_FILE, "", str)
        self._file.setText(file_text)
        tag = job.row_limit or (str(job.max_rows) if job.max_rows is not None else "")
        self._row_limit.setText(tag)
        if job.reference_file:
            self._reference.setText(job.reference_file)
        else:
            self._reference.clear()
        self._reference_host.setVisible(job.mode == "reference")
        self._templates_panel.setVisible(job.mode == "qa")
        self._validation_template_host.setVisible(job.mode == "validation")
        self._schema_host.setVisible(job.mode == "schema")
        self._catalogs_panel.setVisible(job.mode == "qa")
        if job.mode == "qa":
            self._rebuild_template_rows(job.qa.template_paths)
        elif job.mode == "validation":
            self._validation_template.setText(job.validation.template_path)
        elif job.mode == "schema":
            self._schema_id.setText(job.schema.schema_id)
        self._rebuild_catalog_rows(job.qa.catalogs)

    def _catalog_specs_from_ui(self) -> tuple[JobQaCatalogSpec, ...]:
        specs: list[JobQaCatalogSpec] = []
        for catalog_id, link_column in self._catalog_rows:
            catalog = catalog_id.text().strip()
            if not catalog:
                continue
            specs.append(
                JobQaCatalogSpec(
                    catalog_id=catalog,
                    link_column=link_column.text().strip(),
                )
            )
        return tuple(specs)

    def _template_paths_from_ui(self) -> tuple[str, ...] | None:
        if self._loaded_job is None or self._loaded_job.mode != "qa":
            return None
        paths = tuple(
            edit.text().strip()
            for edit, _remove in self._template_rows
            if edit.text().strip()
        )
        return paths

    def _build_session(self) -> JobRunSession | None:
        if self._job_path is None or self._loaded_job is None:
            return None
        file_text = self._file.text().strip()
        if not file_text:
            return None
        reference_text = self._reference.text().strip()
        reference_path = Path(reference_text) if reference_text else None
        row_limit = self._row_limit.text().strip() or None
        validation_path = None
        schema_id = None
        if self._loaded_job.mode == "validation":
            text = self._validation_template.text().strip()
            validation_path = text or None
        if self._loaded_job.mode == "schema":
            schema_id = self._schema_id.text().strip() or None
        return JobRunSession(
            job_path=self._job_path,
            base_job=self._loaded_job,
            file_path=Path(file_text),
            reference_path=reference_path,
            catalog_specs=self._catalog_specs_from_ui(),
            template_paths=self._template_paths_from_ui(),
            validation_template_path=validation_path,
            schema_id=schema_id,
            row_limit=row_limit,
        )

    def _on_run(self) -> None:
        session = self._build_session()
        if session is None:
            QMessageBox.warning(
                self,
                tr("emr.app.title"),
                tr("emr.automation.run_need_file"),
            )
            return
        ready, missing = session_ready(session)
        if not ready:
            if missing == "reference":
                message = tr("emr.automation.run_need_reference")
            elif missing == "templates":
                message = tr("emr.automation.run_need_templates")
            else:
                message = tr("emr.automation.run_need_file")
            QMessageBox.warning(self, tr("emr.app.title"), message)
            return
        self._settings.setValue(_SETTINGS_LAST_FILE, str(session.file_path))
        self._session = session
        self.accept()


def show_job_run_dialog(
    parent=None,
    *,
    initial_job_path: Path | None = None,
) -> JobRunSession | None:
    dialog = JobRunDialog(parent, initial_job_path=initial_job_path)
    if dialog.exec() != QDialog.DialogCode.Accepted:
        return None
    return dialog.session()
