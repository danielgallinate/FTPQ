"""Panel resumen — validación estructural de columnas."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
)

from shell.schema_metrics import SchemaValidationReport
from ui.i18n import tr


class SchemaSummaryPanel(QFrame):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("panel")
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self._report: SchemaValidationReport | None = None

        self._title = QLabel()
        self._title.setObjectName("panelSubtitle")
        self._status = QLabel()
        self._status.setObjectName("panelTitle")
        self._status.setWordWrap(True)
        self._headline = QLabel()
        self._headline.setObjectName("configHint")
        self._headline.setWordWrap(True)

        self._kpi_cells = QLabel()
        self._kpi_coverage = QLabel()
        self._kpi_quality = QLabel()
        self._kpi_structural = QLabel()
        for label in (self._kpi_cells, self._kpi_coverage, self._kpi_quality, self._kpi_structural):
            label.setObjectName("configHint")
            label.setWordWrap(True)

        kpi_grid = QGridLayout()
        kpi_grid.setContentsMargins(0, 0, 0, 0)
        kpi_grid.setHorizontalSpacing(8)
        kpi_grid.setVerticalSpacing(2)
        kpi_grid.addWidget(self._kpi_cells, 0, 0)
        kpi_grid.addWidget(self._kpi_coverage, 0, 1)
        kpi_grid.addWidget(self._kpi_quality, 1, 0)
        kpi_grid.addWidget(self._kpi_structural, 1, 1)

        self._copy = QPushButton()
        self._copy.clicked.connect(self._copy_report)
        actions = QHBoxLayout()
        actions.setContentsMargins(0, 0, 0, 0)
        actions.addWidget(self._copy)
        actions.addStretch(1)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        layout.addWidget(self._title)
        layout.addWidget(self._status)
        layout.addWidget(self._headline)
        layout.addLayout(kpi_grid)
        layout.addLayout(actions)
        self.retranslate_ui()
        self.set_idle()

    def retranslate_ui(self) -> None:
        self._title.setText(tr("emr.schema.summary.title"))
        self._copy.setText(tr("emr.schema.summary.copy"))
        if self._report is None:
            self.set_idle()

    def set_idle(self) -> None:
        self._report = None
        self._status.setText(tr("emr.schema.summary.idle"))
        self._headline.clear()
        self._kpi_cells.clear()
        self._kpi_coverage.clear()
        self._kpi_quality.clear()
        self._kpi_structural.clear()

    def set_running(self) -> None:
        self._status.setText(tr("emr.schema.summary.running"))
        self._headline.clear()

    def set_error(self, message: str) -> None:
        self._report = None
        self._status.setText(tr("emr.schema.summary.error"))
        self._headline.setText(message)
        self._kpi_cells.clear()
        self._kpi_coverage.clear()
        self._kpi_quality.clear()
        self._kpi_structural.clear()

    def set_report(self, report: SchemaValidationReport) -> None:
        self._report = report
        self._status.setText(report.headline)
        self._headline.setText(
            tr(
                "emr.schema.summary.meta",
                schema=report.schema_name,
                strict=tr("emr.schema.strict.yes") if report.strict else tr("emr.schema.strict.no"),
                rows=f"{report.rows_total:,}",
            )
        )
        self._kpi_cells.setText(
            tr(
                "emr.schema.summary.kpi_cells",
                ok=f"{report.cells_ok:,}",
                nok=f"{report.cells_nok:,}",
            )
        )
        self._kpi_coverage.setText(
            tr("emr.schema.summary.kpi_coverage", pct=f"{report.coverage_pct:.2f}")
        )
        self._kpi_quality.setText(
            tr("emr.schema.summary.kpi_quality", pct=f"{report.quality_pct:.2f}")
        )
        structural = len(report.structural_errors)
        coverage_cols = len(report.coverage_columns)
        self._kpi_structural.setText(
            tr(
                "emr.schema.summary.kpi_gaps",
                structural=structural,
                coverage=coverage_cols,
            )
        )

    def _copy_report(self) -> None:
        if self._report is None:
            return
        QApplication.clipboard().setText(self._report.to_copyable_text())
