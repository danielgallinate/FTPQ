"""Progreso de validación — emisión limitada para no saturar la UI."""
from __future__ import annotations

from collections.abc import Callable

RowProgressCallback = Callable[[int, int], None]

PROGRESS_ROW_STEP = 2_000


def emit_row_progress(
    callback: RowProgressCallback | None,
    current: int,
    total: int,
    *,
    step: int = PROGRESS_ROW_STEP,
) -> None:
    if callback is None or total <= 0:
        return
    if current <= 1 or current >= total or current % step == 0:
        callback(current, total)
