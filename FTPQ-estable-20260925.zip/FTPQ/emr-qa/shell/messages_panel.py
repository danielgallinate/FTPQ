"""Panel inferior — alertas y mensajes de sesión."""
from __future__ import annotations

from PySide6.QtWidgets import QFrame, QLabel, QTextEdit, QVBoxLayout

from ui.i18n import tr


class MessagesPanel(QFrame):
    _COMPACT_MAX_HEIGHT = 64

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("panel")
        self.setFrameShape(QFrame.Shape.StyledPanel)

        self._title = QLabel()
        self._title.setObjectName("panelSubtitle")

        self._body = QTextEdit()
        self._body.setObjectName("panelBody")
        self._body.setReadOnly(True)
        self._body.setMaximumHeight(self._COMPACT_MAX_HEIGHT)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(2)
        layout.addWidget(self._title)
        layout.addWidget(self._body)
        self.retranslate_ui()

    def retranslate_ui(self) -> None:
        self._title.setText(tr("emr.panel.messages"))

    def set_messages(self, lines: list[str]) -> None:
        self._body.setPlainText("\n".join(lines) if lines else "—")

    def append(self, line: str) -> None:
        current = self._body.toPlainText()
        if current in ("", "—"):
            self._body.setPlainText(line)
        else:
            self._body.setPlainText(f"{current}\n{line}")

    def clear_messages(self) -> None:
        self.set_messages([])
