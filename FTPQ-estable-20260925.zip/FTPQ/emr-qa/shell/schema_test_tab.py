"""Tab Estructura — ejecutar validación de esquema columnar."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from core.schema_catalog_store import list_schema_catalog_summaries
from shell.schema_summary_panel import SchemaSummaryPanel
from ui.i18n import tr


class SchemaTestTab(QFrame):
    validate_requested = Signal()
    config_changed = Signal()
    export_schema_job_requested = Signal()
    user_message = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._hint = QLabel()
        self._hint.setObjectName("configHint")
        self._hint.setWordWrap(True)

        self._catalog = QComboBox()
        self._catalog.currentIndexChanged.connect(self._emit_config_changed)

        self._execute = QPushButton()
        self._execute.clicked.connect(self.validate_requested.emit)

        self._summary = SchemaSummaryPanel()

        self._export_job = QPushButton()
        self._export_job.clicked.connect(self.export_schema_job_requested.emit)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)
        layout.addWidget(self._export_job)
        layout.addWidget(self._hint)
        layout.addWidget(QLabel(tr("emr.schema.test.catalog_label")))
        layout.addWidget(self._catalog)
        row = QHBoxLayout()
        row.addWidget(self._execute)
        row.addStretch(1)
        layout.addLayout(row)
        layout.addWidget(self._summary, stretch=1)
        self.retranslate_ui()
        self.reload_catalogs()

    def retranslate_ui(self) -> None:
        self._hint.setText(tr("emr.schema.test.hint"))
        self._execute.setText(tr("emr.schema.test.execute"))
        self._export_job.setText(tr("emr.automation.export_schema"))
        self._summary.retranslate_ui()

    def reload_catalogs(self) -> None:
        current = self.selected_schema_id()
        self._catalog.blockSignals(True)
        self._catalog.clear()
        self._catalog.addItem(tr("emr.schema.test.pick_catalog"), "")
        for schema_id, name, strict in list_schema_catalog_summaries():
            label = name
            if strict:
                label += f" ({tr('emr.schema.strict.badge')})"
            self._catalog.addItem(label, schema_id)
            if schema_id == current:
                self._catalog.setCurrentIndex(self._catalog.count() - 1)
        self._catalog.blockSignals(False)
        self._emit_config_changed()

    def selected_schema_id(self) -> str:
        return str(self._catalog.currentData() or "").strip()

    def is_ready(self) -> bool:
        return bool(self.selected_schema_id())

    def set_summary_idle(self) -> None:
        self._summary.set_idle()

    def set_summary_running(self) -> None:
        self._summary.set_running()

    def set_summary_error(self, message: str) -> None:
        self._summary.set_error(message)

    def set_summary_report(self, report) -> None:
        self._summary.set_report(report)

    def _emit_config_changed(self) -> None:
        self.config_changed.emit()
