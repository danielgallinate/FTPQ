"""Métricas resumidas — comparación contra archivo de referencia."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from core.chart_format import floor_pct, format_pct
from core.reference_compare_types import ReferenceCompareConfig, ReferenceCompareResult
from ui.i18n import tr


@dataclass(frozen=True)
class ReferenceColumnMetrics:
    left_column: str
    right_column: str
    ok: int = 0
    nok: int = 0

    @property
    def judged(self) -> int:
        return self.ok + self.nok

    @property
    def ok_pct(self) -> float:
        return floor_pct(self.ok, self.judged)


@dataclass
class ReferenceCompareReport:
    file_name: str
    reference_name: str
    generated_at: str
    rows_compared: int = 0
    rows_matched_key: int = 0
    rows_without_match: int = 0
    rows_ambiguous_key: int = 0
    duplicate_reference_keys: int = 0
    reference_rows_loaded: int = 0
    reference_rows_total: int = 0
    cells_ok: int = 0
    cells_nok: int = 0
    cell_match_pct: float = 0.0
    row_match_pct: float = 0.0
    join_key_summary: str = ""
    pairs_compared: int = 0
    column_metrics: list[ReferenceColumnMetrics] = field(default_factory=list)
    status: str = "idle"
    headline: str = ""

    def column_items(self, *, nok_only: bool = False) -> list[ReferenceColumnMetrics]:
        items = list(self.column_metrics)
        if nok_only:
            items = [item for item in items if item.nok > 0]
        return items

    def to_copyable_text(self, *, nok_only: bool = False) -> str:
        lines = [
            tr("emr.ref.report.title"),
            tr("emr.ref.report.file", name=self.file_name),
            tr("emr.ref.report.reference", name=self.reference_name),
            tr("emr.ref.report.generated", at=self.generated_at),
            "",
            self.headline,
            "",
            tr(
                "emr.ref.report.rows",
                compared=f"{self.rows_compared:,}",
                matched=f"{self.rows_matched_key:,}",
                pct=format_pct(self.rows_matched_key, self.rows_compared),
            ),
            tr(
                "emr.ref.report.cells",
                ok=f"{self.cells_ok:,}",
                nok=f"{self.cells_nok:,}",
                pct=format_pct(self.cells_ok, self.cells_ok + self.cells_nok),
            ),
            tr("emr.ref.report.no_match", count=self.rows_without_match),
            tr("emr.ref.report.ambiguous", count=self.rows_ambiguous_key),
            tr("emr.ref.report.dup_keys", count=self.duplicate_reference_keys),
            tr("emr.ref.report.join", keys=self.join_key_summary),
            "",
            tr("emr.ref.report.columns_header"),
        ]
        for item in self.column_items(nok_only=nok_only):
            lines.append(
                tr(
                    "emr.ref.report.column_line",
                    left=item.left_column,
                    right=item.right_column,
                    ok=item.ok,
                    nok=item.nok,
                    pct=format_pct(item.ok, item.judged),
                )
            )
        if nok_only and not self.column_items(nok_only=True):
            lines.append(tr("emr.ref.metrics.nok_only_empty"))
        return "\n".join(lines)

    def to_csv(self, *, nok_only: bool = False) -> str:
        lines = [tr("emr.ref.metrics.csv.header")]
        for item in self.column_items(nok_only=nok_only):
            lines.append(
                f"{tr('emr.ref.metrics.csv.section_column')},{item.left_column},"
                f"{item.right_column},{item.ok},{item.nok},{item.ok_pct:.2f}"
            )
        lines.append(
            f"{tr('emr.ref.metrics.csv.section_summary')},,,"
            f"{self.cells_ok},{self.cells_nok},{self.cell_match_pct:.2f}"
        )
        return "\n".join(lines)


def _join_key_summary(config: ReferenceCompareConfig) -> str:
    keys = config.resolved_join_keys() or [
        item for item in config.join_keys if item.is_complete()
    ]
    parts: list[str] = []
    for mapping in keys:
        parts.append(f"{mapping.left_column}↔{mapping.right_column}")
    return " · ".join(parts) or "—"


def build_reference_compare_report(
    *,
    file_name: str,
    config: ReferenceCompareConfig,
    result: ReferenceCompareResult,
    rows_compared: int,
    reference_rows_loaded: int,
    reference_rows_total: int,
    name_to_index: dict[str, int],
) -> ReferenceCompareReport:
    pairs = [
        item for item in config.pairs if item.enabled and item.is_complete()
    ]
    column_metrics: list[ReferenceColumnMetrics] = []
    cells_ok = 0
    cells_nok = 0
    for pair in pairs:
        col_index = name_to_index.get(pair.left_column)
        if col_index is None:
            continue
        ok = sum(1 for _row, col in result.passed_cells if col == col_index)
        nok = sum(1 for _row, col in result.failed_cells if col == col_index)
        cells_ok += ok
        cells_nok += nok
        column_metrics.append(
            ReferenceColumnMetrics(
                left_column=pair.left_column,
                right_column=pair.right_column,
                ok=ok,
                nok=nok,
            )
        )

    rows_matched = max(
        0,
        rows_compared - result.rows_without_match - result.rows_ambiguous_key,
    )
    row_match_pct = floor_pct(rows_matched, rows_compared)
    judged_cells = cells_ok + cells_nok
    cell_match_pct = floor_pct(cells_ok, judged_cells)

    reference_name = config.reference_path.name if config.reference_path else "—"
    if rows_compared == 0:
        status = "empty"
        headline = tr("emr.ref.report.headline_empty")
    elif rows_matched == 0:
        status = "no_match"
        headline = tr("emr.ref.report.headline_no_match")
    elif cells_nok == 0 and result.rows_without_match == 0:
        status = "ok"
        headline = tr("emr.ref.report.headline_ok")
    elif cell_match_pct >= 95.0 and row_match_pct >= 95.0:
        status = "mostly_ok"
        headline = tr("emr.ref.report.headline_mostly_ok")
    else:
        status = "deltas"
        headline = tr(
            "emr.ref.report.headline_deltas",
            nok=f"{cells_nok:,}",
            rows=f"{result.rows_without_match:,}",
        )

    return ReferenceCompareReport(
        file_name=file_name,
        reference_name=reference_name,
        generated_at=datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z"),
        rows_compared=rows_compared,
        rows_matched_key=rows_matched,
        rows_without_match=result.rows_without_match,
        rows_ambiguous_key=result.rows_ambiguous_key,
        duplicate_reference_keys=result.duplicate_reference_keys,
        reference_rows_loaded=reference_rows_loaded,
        reference_rows_total=reference_rows_total,
        cells_ok=cells_ok,
        cells_nok=cells_nok,
        cell_match_pct=cell_match_pct,
        row_match_pct=row_match_pct,
        join_key_summary=_join_key_summary(config),
        pairs_compared=len(column_metrics),
        column_metrics=column_metrics,
        status=status,
        headline=headline,
    )
