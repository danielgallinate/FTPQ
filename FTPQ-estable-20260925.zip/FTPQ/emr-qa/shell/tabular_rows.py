"""Utilidades tabulares — filas dict para motor de validación."""
from __future__ import annotations

from typing import Any

from core.analysis_types import TabularDataset
from shell.validation_progress import RowProgressCallback, emit_row_progress


def dataset_to_row_dicts(
    dataset: TabularDataset,
    *,
    on_progress: RowProgressCallback | None = None,
) -> list[dict[str, Any]]:
    columns = [column.name for column in dataset.columns]
    rows: list[dict[str, Any]] = []
    total = len(dataset.rows)
    for row_index, record in enumerate(dataset.rows):
        row: dict[str, Any] = {}
        for index, name in enumerate(columns):
            row[name] = record[index] if index < len(record) else ""
        rows.append(row)
        emit_row_progress(on_progress, row_index + 1, total)
    return rows
