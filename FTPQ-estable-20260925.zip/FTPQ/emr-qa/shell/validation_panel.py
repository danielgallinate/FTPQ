"""Panel derecho modo Probar — tabs Vista / Validation."""
from __future__ import annotations

from collections.abc import Callable
from enum import Enum
from pathlib import Path

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from core.analysis_types import TabularDataset
from core.catalog_types import ColumnCatalogBinding
from emrqa.template_key_store import TemplateKeyStore
from emrqa.validation_models import DuplicateRecordError, RecordSource, ValidationTemplate
from emrqa.validation_storage import (
    TemplateKeyMismatchError,
    TemplateRequiresKeyError,
    TemplateSummary,
    encrypt_template_minibase,
    list_template_summaries,
    load_validation_template,
    save_validation_template,
    templates_dir,
)
from shell.minibase_rows import append_marked_rows
from shell.template_dialogs import CreateTemplateDialog
from shell.template_edit_tab import TemplateEditTab
from shell.reference_compare_tab import ReferenceCompareTab
from shell.automation_tab import AutomationTab
from shell.catalog_tab import CatalogTab
from shell.schema_edit_tab import SchemaEditTab
from shell.schema_test_tab import SchemaTestTab
from shell.qa_metrics_panel import QaMetricsPanel
from shell.qa_metrics import QaMetricsReport
from shell.template_factory import (
    build_empty_template,
    set_primary_key_fields,
    template_structure_locked,
)
from ui.i18n import tr


class ValidationTab(str, Enum):
    VIEW = "view"
    VALIDATION = "validation"
    REFERENCE = "reference"
    CATALOG = "catalog"
    TEMPLATE_EDIT = "template_edit"
    QA = "qa"
    SCHEMA_EDIT = "schema_edit"
    SCHEMA = "schema"
    AUTOMATION = "automation"


_TAB_STACK_ORDER = (
    ValidationTab.VIEW,
    ValidationTab.VALIDATION,
    ValidationTab.REFERENCE,
    ValidationTab.CATALOG,
    ValidationTab.TEMPLATE_EDIT,
    ValidationTab.SCHEMA_EDIT,
    ValidationTab.QA,
    ValidationTab.SCHEMA,
    ValidationTab.AUTOMATION,
)
_TAB_STACK_INDEX = {tab: index for index, tab in enumerate(_TAB_STACK_ORDER)}

_TAB_ROW_SETUP = (
    (
        ValidationTab.VIEW,
        ValidationTab.VALIDATION,
        ValidationTab.CATALOG,
        ValidationTab.TEMPLATE_EDIT,
        ValidationTab.SCHEMA_EDIT,
    ),
    (ValidationTab.REFERENCE, ValidationTab.QA, ValidationTab.SCHEMA),
    (ValidationTab.AUTOMATION,),
)


class ValidationPanel(QFrame):
    template_changed = Signal(object)
    qa_selection_changed = Signal()
    reference_config_changed = Signal()
    reference_compare_requested = Signal()
    export_reference_job_requested = Signal()
    export_qa_job_requested = Signal()
    export_schema_job_requested = Signal()
    schema_validate_requested = Signal()
    tab_changed = Signal()
    user_message = Signal(str)

    def __init__(self, parent=None, *, key_store: TemplateKeyStore | None = None) -> None:
        super().__init__(parent)
        self._key_store = key_store or TemplateKeyStore()
        self.setObjectName("panel")
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setMinimumWidth(300)
        self.setMaximumWidth(560)

        self._dataset: TabularDataset | None = None
        self._template: ValidationTemplate | None = None
        self._template_path: Path | None = None
        self._visible_columns_fn: Callable[[], list[str]] | None = None
        self._marked_rows_fn: Callable[[], set[int]] | None = None
        self._clear_marks_fn: Callable[[], None] | None = None
        self._dataset_path_fn: Callable[[], Path | None] | None = None
        self._field_edits: dict[str, QLineEdit] = {}
        self._key_checks: dict[str, QCheckBox] = {}
        self._qa_checks: dict[str, QCheckBox] = {}
        self._qa_paths: dict[str, Path] = {}
        self._qa_summaries: list[TemplateSummary] = []
        self._left_catalog_bindings: dict[str, ColumnCatalogBinding] = {}
        self._right_catalog_bindings: dict[str, ColumnCatalogBinding] = {}

        self._tabs = QStackedWidget()
        self._tab_buttons: dict[ValidationTab, QPushButton] = {}
        self._tab_group = QButtonGroup(self)
        self._tab_group.setExclusive(True)

        self._view_host = QWidget()
        self._view_layout = QVBoxLayout(self._view_host)
        self._view_layout.setContentsMargins(0, 0, 0, 0)
        self._view_layout.setSpacing(0)
        self._view_hint = QLabel()
        self._view_hint.setObjectName("configHint")
        self._view_hint.setWordWrap(True)
        view_page = QWidget()
        view_layout = QVBoxLayout(view_page)
        view_layout.setContentsMargins(8, 8, 8, 8)
        view_layout.setSpacing(8)
        view_layout.addWidget(self._view_hint)
        view_layout.addWidget(self._view_host, stretch=1)

        self._create_template = QPushButton()
        self._create_template.clicked.connect(self._on_create_template)
        self._load_template = QPushButton()
        self._load_template.clicked.connect(self._on_load_template)
        header_row = QHBoxLayout()
        header_row.addWidget(self._create_template)
        header_row.addWidget(self._load_template)

        self._title = QLabel()
        self._title.setObjectName("panelTitle")
        self._title.setWordWrap(True)

        self._meta = QLabel()
        self._meta.setObjectName("configHint")
        self._meta.setWordWrap(True)

        self._key_title = QLabel()
        self._key_title.setObjectName("panelSubtitle")

        self._compare_hint = QLabel()
        self._compare_hint.setObjectName("configHint")
        self._compare_hint.setWordWrap(True)

        self._key_host = QWidget()
        self._key_layout = QVBoxLayout(self._key_host)
        self._key_layout.setContentsMargins(4, 4, 4, 4)
        self._key_layout.setSpacing(4)

        self._apply_key = QPushButton()
        self._apply_key.clicked.connect(self._on_apply_key)

        self._fields_title = QLabel()
        self._fields_title.setObjectName("panelSubtitle")

        self._form_host = QWidget()
        self._form_layout = QVBoxLayout(self._form_host)
        self._form_layout.setContentsMargins(4, 4, 4, 4)
        self._form_layout.setSpacing(6)

        form_scroll = QScrollArea()
        form_scroll.setWidgetResizable(True)
        form_scroll.setWidget(self._form_host)
        form_scroll.setFrameShape(QFrame.Shape.NoFrame)

        self._save_record = QPushButton()
        self._save_record.clicked.connect(self._on_add_record)
        self._save_record.setEnabled(False)

        validation_page = QWidget()
        validation_layout = QVBoxLayout(validation_page)
        validation_layout.setContentsMargins(8, 8, 8, 8)
        validation_layout.setSpacing(6)
        validation_layout.addLayout(header_row)
        validation_layout.addWidget(self._title)
        validation_layout.addWidget(self._meta)
        validation_layout.addWidget(self._key_title)
        validation_layout.addWidget(self._compare_hint)
        validation_layout.addWidget(self._key_host)
        validation_layout.addWidget(self._apply_key)
        validation_layout.addWidget(self._fields_title)
        validation_layout.addWidget(form_scroll, stretch=1)
        validation_layout.addWidget(self._save_record)

        self._qa_hint = QLabel()
        self._qa_hint.setObjectName("configHint")
        self._qa_hint.setWordWrap(True)
        self._qa_metrics = QaMetricsPanel()
        self._qa_discrepancy = QCheckBox()
        self._qa_discrepancy.toggled.connect(self._emit_qa_selection_changed)
        self._qa_host = QWidget()
        self._qa_layout = QVBoxLayout(self._qa_host)
        self._qa_layout.setContentsMargins(4, 4, 4, 4)
        self._qa_layout.setSpacing(4)
        qa_scroll = QScrollArea()
        qa_scroll.setWidgetResizable(True)
        qa_scroll.setWidget(self._qa_host)
        qa_scroll.setFrameShape(QFrame.Shape.NoFrame)
        qa_page = QWidget()
        qa_layout = QVBoxLayout(qa_page)
        qa_layout.setContentsMargins(8, 8, 8, 8)
        self._export_qa_job = QPushButton()
        self._export_qa_job.clicked.connect(self.export_qa_job_requested.emit)
        qa_layout.addWidget(self._export_qa_job)
        qa_layout.addWidget(self._qa_hint)
        qa_layout.addWidget(self._qa_metrics)
        qa_layout.addWidget(self._qa_discrepancy)
        qa_layout.addWidget(qa_scroll, stretch=1)

        self._reference_compare = ReferenceCompareTab()
        self._reference_compare.config_changed.connect(self._emit_reference_config_changed)
        self._reference_compare.compare_requested.connect(self._emit_reference_compare_requested)
        self._reference_compare.user_message.connect(self.user_message.emit)

        reference_page = QWidget()
        reference_layout = QVBoxLayout(reference_page)
        reference_layout.setContentsMargins(0, 0, 0, 0)
        self._export_reference_job = QPushButton()
        self._export_reference_job.clicked.connect(self.export_reference_job_requested.emit)
        ref_toolbar = QHBoxLayout()
        ref_toolbar.setContentsMargins(8, 8, 8, 0)
        ref_toolbar.addWidget(self._export_reference_job)
        ref_toolbar.addStretch(1)
        reference_layout.addLayout(ref_toolbar)
        self._reference_hint = QLabel()
        self._reference_hint.setObjectName("configHint")
        self._reference_hint.setWordWrap(True)
        reference_layout.addWidget(self._reference_hint)
        reference_layout.addWidget(self._reference_compare, stretch=1)

        self._catalog_tab = CatalogTab()
        self._catalog_tab.catalogs_changed.connect(self._emit_reference_config_changed)

        self._schema_edit = SchemaEditTab()
        self._schema_edit.catalogs_changed.connect(self._on_schema_catalogs_changed)
        self._schema_edit.user_message.connect(self.user_message.emit)

        self._schema_test = SchemaTestTab()
        self._schema_test.validate_requested.connect(self.schema_validate_requested.emit)
        self._schema_test.config_changed.connect(self._on_schema_config_changed)
        self._schema_test.export_schema_job_requested.connect(
            self.export_schema_job_requested.emit
        )
        self._schema_test.user_message.connect(self.user_message.emit)

        self._automation = AutomationTab()

        self._template_edit = TemplateEditTab(key_store=self._key_store)
        self._template_edit.saved.connect(self._on_template_edit_saved)
        self._template_edit.cancelled.connect(self._on_template_edit_cancelled)
        self._template_edit.encrypt_requested.connect(self._on_template_edit_encrypt)

        self._tabs.addWidget(view_page)
        self._tabs.addWidget(validation_page)
        self._tabs.addWidget(reference_page)
        self._tabs.addWidget(self._catalog_tab)
        self._tabs.addWidget(self._template_edit)
        self._tabs.addWidget(self._schema_edit)
        self._tabs.addWidget(qa_page)
        self._tabs.addWidget(self._schema_test)
        self._tabs.addWidget(self._automation)

        nav_host = QWidget()
        nav_layout = QVBoxLayout(nav_host)
        nav_layout.setContentsMargins(4, 4, 4, 0)
        nav_layout.setSpacing(4)
        for row_tabs in _TAB_ROW_SETUP:
            row = QHBoxLayout()
            row.setSpacing(4)
            for tab in row_tabs:
                button = QPushButton()
                button.setCheckable(True)
                button.clicked.connect(lambda checked=False, t=tab: self._activate_tab(t))
                self._tab_group.addButton(button)
                self._tab_buttons[tab] = button
                row.addWidget(button)
            row.addStretch(1)
            nav_layout.addLayout(row)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(nav_host)
        layout.addWidget(self._tabs, stretch=1)

        self._activate_tab(ValidationTab.VIEW, emit_signal=False)
        self.retranslate_ui()
        self._reload_qa_templates()
        self._refresh_validation_ui()

    def retranslate_ui(self) -> None:
        self._tab_buttons[ValidationTab.VIEW].setText(tr("emr.tab.view"))
        self._view_hint.setText(tr("emr.tab.view.hint"))
        self._tab_buttons[ValidationTab.VALIDATION].setText(tr("emr.tab.validation"))
        self._tab_buttons[ValidationTab.REFERENCE].setText(tr("emr.tab.reference"))
        self._tab_buttons[ValidationTab.CATALOG].setText(tr("emr.tab.catalog"))
        self._tab_buttons[ValidationTab.TEMPLATE_EDIT].setText(tr("emr.tab.template_edit"))
        self._tab_buttons[ValidationTab.QA].setText(tr("emr.tab.qa"))
        self._tab_buttons[ValidationTab.SCHEMA_EDIT].setText(tr("emr.tab.schema_edit"))
        self._tab_buttons[ValidationTab.SCHEMA].setText(tr("emr.tab.schema"))
        self._tab_buttons[ValidationTab.AUTOMATION].setText(tr("emr.tab.automation"))
        self._export_reference_job.setText(tr("emr.automation.export_reference"))
        self._export_qa_job.setText(tr("emr.automation.export_qa"))
        self._reference_hint.setText(tr("emr.tab.reference.hint"))
        self._qa_hint.setText(tr("emr.tab.qa.hint"))
        self._qa_metrics.retranslate_ui()
        self._qa_discrepancy.setText(tr("emr.qa.discrepancy_mode"))
        self._create_template.setText(tr("emr.template.create"))
        self._load_template.setText(tr("emr.template.load"))
        self._apply_key.setText(tr("emr.template.apply_key"))
        self._fields_title.setText(tr("emr.template.active_fields"))
        self._save_record.setText(tr("emr.template.add_record"))
        self._key_title.setText(tr("emr.template.key_section"))
        self._compare_hint.setText(tr("emr.template.compare_fields_hint"))
        self._reference_compare.retranslate_ui()
        self._catalog_tab.retranslate_ui()
        self._schema_edit.retranslate_ui()
        self._schema_test.retranslate_ui()
        self._automation.retranslate_ui()
        self._template_edit.retranslate_ui()
        self._refresh_validation_ui()

    @property
    def template(self) -> ValidationTemplate | None:
        return self._template

    @property
    def template_path(self) -> Path | None:
        return self._template_path

    def set_visible_columns_provider(self, provider: Callable[[], list[str]]) -> None:
        self._visible_columns_fn = provider

    def set_marked_rows_provider(self, provider: Callable[[], set[int]]) -> None:
        self._marked_rows_fn = provider

    def set_clear_marks_callback(self, callback: Callable[[], None]) -> None:
        self._clear_marks_fn = callback

    def set_dataset_path_provider(self, provider: Callable[[], Path | None]) -> None:
        self._dataset_path_fn = provider

    def is_populate_mode(self) -> bool:
        """Template activo en Validation — UI de ADD permanece abierta."""
        return self._template is not None

    def is_minibase_empty(self) -> bool:
        return self._template is not None and len(self._template.minibase.records) == 0

    def is_build_mode(self) -> bool:
        return self.is_populate_mode()

    def primary_key_column_names(self) -> list[str]:
        if self._template is None:
            return []
        key = self._template.header.primary_key()
        if key is None:
            return []
        names: list[str] = []
        for field_id in key.field_ids:
            field = self._template.header.field_by_id(field_id)
            if field is not None:
                names.append(field.column)
        return names

    def active_tab(self) -> ValidationTab:
        index = self._tabs.currentIndex()
        if 0 <= index < len(_TAB_STACK_ORDER):
            return _TAB_STACK_ORDER[index]
        return ValidationTab.VIEW

    def _activate_tab(self, tab: ValidationTab, *, emit_signal: bool = True) -> None:
        button = self._tab_buttons.get(tab)
        if button is not None:
            button.setChecked(True)
        self._tabs.setCurrentIndex(_TAB_STACK_INDEX[tab])
        if tab == ValidationTab.AUTOMATION:
            self._automation.refresh_jobs()
        if emit_signal:
            if tab == ValidationTab.TEMPLATE_EDIT and self._template is not None:
                self._template_edit.set_template(self._template)
            self.tab_changed.emit()

    def select_automation_job(self, path: Path) -> None:
        self._automation.select_job_path(path)
        self._activate_tab(ValidationTab.AUTOMATION)

    def select_tab(self, tab: ValidationTab) -> None:
        self._activate_tab(tab)

    def _emit_tab_changed(self, _index: int) -> None:
        if self.active_tab() == ValidationTab.TEMPLATE_EDIT and self._template is not None:
            self._template_edit.set_template(self._template)
        self.tab_changed.emit()

    def set_qa_metrics(self, report: QaMetricsReport | None) -> None:
        self._qa_metrics.set_metrics(report)

    def clear_qa_metrics(self) -> None:
        self._qa_metrics.clear_metrics()

    def refresh_key_state(self) -> None:
        self._template_edit.refresh_key_state()
        if self._template is not None:
            self._refresh_validation_ui()

    def _persist_template(self) -> None:
        if self._template is None:
            return
        save_validation_template(self._template, key_store=self._key_store)

    def checked_qa_templates(self) -> list[ValidationTemplate]:
        templates: list[ValidationTemplate] = []
        for template_id, path in self.checked_qa_template_paths():
            try:
                templates.append(load_validation_template(path, key_store=self._key_store))
            except (TemplateKeyMismatchError, TemplateRequiresKeyError) as exc:
                self.user_message.emit(str(exc))
            except (OSError, ValueError):
                continue
        return templates

    def checked_qa_template_paths(self) -> list[tuple[str, Path]]:
        selected: list[tuple[str, Path]] = []
        for template_id, box in self._qa_checks.items():
            if not box.isChecked():
                continue
            path = self._qa_paths.get(template_id)
            if path is None:
                continue
            selected.append((template_id, path))
        return selected

    def qa_highlight_discrepancy(self) -> bool:
        return self._qa_discrepancy.isChecked()

    def ensure_template_selected(self) -> None:
        return None

    def _reload_qa_templates(self) -> None:
        checked_ids = {
            template_id
            for template_id, box in self._qa_checks.items()
            if box.isChecked()
        }
        active_id = self._template.template_id if self._template is not None else None
        while self._qa_layout.count():
            item = self._qa_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._qa_checks.clear()
        self._qa_paths.clear()
        self._qa_summaries = list_template_summaries("default")
        if not self._qa_summaries:
            empty = QLabel(tr("emr.qa.empty"))
            empty.setObjectName("configHint")
            empty.setWordWrap(True)
            self._qa_layout.addWidget(empty)
            self._qa_layout.addStretch(1)
            return
        for summary in self._qa_summaries:
            label = summary.name
            if summary.record_count:
                label = tr(
                    "emr.qa.template_item",
                    name=summary.name,
                    records=summary.record_count,
                )
            box = QCheckBox(label)
            should_check = summary.template_id in checked_ids
            if active_id and summary.template_id == active_id:
                should_check = True
            box.setChecked(should_check)
            box.toggled.connect(self._emit_qa_selection_changed)
            self._qa_checks[summary.template_id] = box
            self._qa_paths[summary.template_id] = summary.path
            self._qa_layout.addWidget(box)
        self._qa_layout.addStretch(1)

    def _emit_qa_selection_changed(self) -> None:
        self.qa_selection_changed.emit()

    def set_view_sidebar(self, sidebar: QWidget | None) -> None:
        while self._view_layout.count():
            item = self._view_layout.takeAt(0)
            widget = item.widget()
            if widget is not None and widget is not sidebar:
                widget.setParent(None)
        if sidebar is not None:
            self._view_layout.addWidget(sidebar)
            sidebar.show()

    def reference_compare_config(self):
        config = self._reference_compare.reference_compare_config()
        config.left_catalog_bindings = dict(self._left_catalog_bindings)
        config.right_catalog_bindings = dict(self._right_catalog_bindings)
        config.catalog_knowledge_base_id = "default"
        return config

    def left_catalog_binding(self, column_name: str) -> ColumnCatalogBinding | None:
        return self._left_catalog_bindings.get(column_name)

    def left_catalog_bindings(self) -> dict[str, ColumnCatalogBinding]:
        return dict(self._left_catalog_bindings)

    def set_left_catalog_binding(
        self,
        column_name: str,
        binding: ColumnCatalogBinding | None,
    ) -> None:
        if binding is None:
            self._left_catalog_bindings.pop(column_name, None)
        else:
            self._left_catalog_bindings[column_name] = binding
        self.reference_config_changed.emit()

    def clear_catalog_bindings(self) -> None:
        self._left_catalog_bindings.clear()
        self._right_catalog_bindings.clear()

    def _emit_reference_config_changed(self) -> None:
        self.reference_config_changed.emit()

    def _emit_reference_compare_requested(self) -> None:
        self.reference_compare_requested.emit()

    def set_reference_summary_running(self) -> None:
        self._reference_compare.set_summary_running()

    def set_reference_summary_error(self, message: str) -> None:
        self._reference_compare.set_summary_error(message)

    def set_reference_summary_report(self, report) -> None:
        self._reference_compare.set_summary_report(report)

    def clear_reference_summary(self) -> None:
        self._reference_compare.clear_summary()

    def set_reference_summary_idle_hint(self) -> None:
        self._reference_compare.set_summary_idle_hint()

    def set_dataset(self, dataset: TabularDataset | None) -> None:
        self._dataset = dataset
        source_file = ""
        if self._dataset_path_fn is not None:
            path = self._dataset_path_fn()
            if path is not None:
                source_file = path.name
        self._catalog_tab.set_dataset(dataset, source_file=source_file)
        self._schema_edit.set_dataset(dataset)
        if dataset is None:
            self._template = None
            self._template_path = None
            self._template_edit.set_template(None)
            self._reference_compare.set_left_columns([])
            self.clear_catalog_bindings()
        else:
            self._reference_compare.set_left_columns(
                [column.name for column in dataset.columns]
            )
        self._refresh_validation_ui()

    def sync_visible_columns(self) -> None:
        self._refresh_record_form()

    def _visible_columns(self) -> list[str]:
        if self._visible_columns_fn is not None:
            return list(self._visible_columns_fn())
        if self._dataset is None:
            return []
        return [column.name for column in self._dataset.columns]

    def _set_template(self, template: ValidationTemplate, path: Path) -> None:
        self._template = template
        self._template_path = path
        self._template_edit.set_template(template)
        self._reload_qa_templates()
        self._refresh_validation_ui()
        self.template_changed.emit(template)
        self.qa_selection_changed.emit()

    def _on_template_edit_saved(self) -> None:
        if self._template is None or self._template_path is None:
            return
        try:
            self._persist_template()
        except (OSError, ValueError, TemplateKeyMismatchError) as exc:
            self.user_message.emit(str(exc))
            return
        self._reload_qa_templates()
        self._refresh_validation_ui()
        self.template_changed.emit(self._template)
        self.qa_selection_changed.emit()
        self.user_message.emit(tr("emr.template_edit.saved"))

    def _on_template_edit_encrypt(self) -> None:
        if self._template is None or self._template_path is None:
            return
        try:
            encrypt_template_minibase(self._template, self._key_store)
            self._persist_template()
        except (OSError, ValueError, TemplateKeyMismatchError) as exc:
            QMessageBox.warning(self, tr("emr.app.title"), str(exc))
            return
        self._template_edit.set_template(self._template)
        self._reload_qa_templates()
        self._refresh_validation_ui()
        self.template_changed.emit(self._template)
        self.qa_selection_changed.emit()
        self.user_message.emit(tr("emr.template_edit.encrypted"))

    def _on_template_edit_cancelled(self) -> None:
        self._refresh_validation_ui()
        if self._template is not None:
            self.template_changed.emit(self._template)
            self.qa_selection_changed.emit()
        self.user_message.emit(tr("emr.template_edit.cancelled"))

    def _refresh_validation_ui(self) -> None:
        if self._template is None:
            self._title.setText(tr("emr.template.none"))
            self._meta.setText(tr("emr.template.empty_hint"))
            self._apply_key.setVisible(False)
            self._save_record.setEnabled(False)
            self._clear_key_editor()
            self._clear_record_form()
            self._template_edit.set_template(None)
            return

        locked = template_structure_locked(self._template)
        record_count = len(self._template.minibase.records)
        self._title.setText(self._template.header.name)
        encryption_hint = ""
        if self._template.is_encrypted and self._template.header.encryption is not None:
            encryption_hint = " · " + tr(
                "emr.template.encrypted_badge",
                key_id=self._template.header.encryption.key_id,
            )
        self._meta.setText(
            tr(
                "emr.template.meta",
                records=record_count,
                fields=len(self._template.header.fields),
                locked=tr("emr.template.structure_locked")
                if locked
                else tr("emr.template.structure_editable"),
            )
            + encryption_hint
        )
        self._apply_key.setVisible(not locked)
        self._save_record.setEnabled(True)
        self._save_record.setText(tr("emr.template.add_record"))
        self._refresh_key_editor(locked=locked)
        self._refresh_record_form()

    def _clear_key_editor(self) -> None:
        while self._key_layout.count():
            item = self._key_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._key_checks.clear()

    def _refresh_key_editor(self, *, locked: bool) -> None:
        self._clear_key_editor()
        if self._template is None:
            return
        primary = self._template.header.primary_key()
        selected = set(primary.field_ids) if primary is not None else set()
        for field in self._template.header.fields:
            box = QCheckBox(field.label)
            box.setChecked(field.field_id in selected)
            box.setEnabled(not locked)
            self._key_layout.addWidget(box)
            self._key_checks[field.field_id] = box
        self._key_layout.addStretch(1)

    def _clear_record_form(self) -> None:
        while self._form_layout.count():
            item = self._form_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._field_edits.clear()

    def _refresh_record_form(self) -> None:
        self._clear_record_form()
        if self._template is None:
            return
        visible = set(self._visible_columns())
        shown = 0
        for field in self._template.header.fields:
            if field.column not in visible:
                continue
            row = QHBoxLayout()
            label = QLabel(field.column)
            label.setMinimumWidth(120)
            edit = QLineEdit()
            edit.setPlaceholderText(tr("emr.template.value_ph"))
            row.addWidget(label, stretch=0)
            row.addWidget(edit, stretch=1)
            wrap = QWidget()
            wrap.setLayout(row)
            self._form_layout.addWidget(wrap)
            self._field_edits[field.column] = edit
            shown += 1
        if shown == 0:
            hint = QLabel(tr("emr.template.no_active_columns"))
            hint.setObjectName("configHint")
            hint.setWordWrap(True)
            self._form_layout.addWidget(hint)
        self._form_layout.addStretch(1)

    def _on_create_template(self) -> None:
        if self._dataset is None:
            self.user_message.emit(tr("emr.template.need_dataset"))
            return
        columns = self._visible_columns()
        if not columns:
            self.user_message.emit(tr("emr.template.need_visible_columns"))
            return
        dialog = CreateTemplateDialog(self, columns=columns)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            template = build_empty_template(
                name=dialog.template_name(),
                column_names=columns,
                key_column_names=dialog.key_columns(),
            )
            path = save_validation_template(template, key_store=self._key_store)
        except ValueError as exc:
            QMessageBox.warning(self, tr("emr.app.title"), str(exc))
            return
        self._set_template(template, path)
        self.user_message.emit(tr("emr.template.created", name=template.header.name))

    def _on_load_template(self) -> None:
        start = str(templates_dir("default"))
        path_str, _ = QFileDialog.getOpenFileName(
            self,
            tr("emr.template.load_dialog_title"),
            start,
            tr("emr.template.file_filter"),
        )
        if not path_str:
            return
        path = Path(path_str)
        try:
            template = load_validation_template(path, key_store=self._key_store)
        except (TemplateKeyMismatchError, TemplateRequiresKeyError) as exc:
            QMessageBox.warning(self, tr("emr.app.title"), str(exc))
            return
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, tr("emr.app.title"), str(exc))
            return
        self._set_template(template, path)
        self.user_message.emit(tr("emr.template.loaded", name=template.header.name))

    def _on_apply_key(self) -> None:
        if self._template is None or self._template_path is None:
            return
        if template_structure_locked(self._template):
            self.user_message.emit(tr("emr.template.key_locked"))
            return
        selected = [field_id for field_id, box in self._key_checks.items() if box.isChecked()]
        try:
            set_primary_key_fields(self._template, selected)
            self._persist_template()
        except ValueError as exc:
            QMessageBox.warning(self, tr("emr.app.title"), str(exc))
            return
        self._refresh_key_editor(locked=False)
        self.template_changed.emit(self._template)
        self.user_message.emit(tr("emr.template.key_applied"))

    def add_source_rows(self, source_rows: set[int]) -> int:
        if self._template is None or self._template_path is None or not source_rows:
            return 0
        if self._dataset is None:
            self.user_message.emit(tr("emr.template.need_dataset"))
            return 0
        file_path = self._dataset_path_fn() if self._dataset_path_fn is not None else None
        added, errors = append_marked_rows(
            self._template,
            self._dataset,
            source_rows,
            file_path=file_path,
        )
        if added == 0:
            self.user_message.emit(errors[0] if errors else tr("emr.msg.select_row"))
            return 0
        try:
            self._persist_template()
        except OSError as exc:
            self.user_message.emit(str(exc))
            return 0
        for edit in self._field_edits.values():
            edit.clear()
        if self._clear_marks_fn is not None:
            self._clear_marks_fn()
        self._refresh_validation_ui()
        self._reload_qa_templates()
        self.template_changed.emit(self._template)
        self.qa_selection_changed.emit()
        message = tr("emr.template.records_added", count=added)
        if errors:
            message = f"{message} · {errors[0]}"
        self.user_message.emit(message)
        return added

    def _on_add_record(self) -> None:
        if self._template is None or self._template_path is None:
            self.user_message.emit(tr("emr.template.need_template"))
            return
        marked: set[int] = set()
        if self._marked_rows_fn is not None:
            marked = set(self._marked_rows_fn())
        if marked:
            self.add_source_rows(marked)
            return

        visible = set(self._visible_columns())
        row: dict[str, str] = {}
        for field in self._template.header.fields:
            if field.column not in visible:
                continue
            edit = self._field_edits.get(field.column)
            if edit is None:
                continue
            row[field.column] = edit.text()
        if not any(value.strip() for value in row.values()):
            self.user_message.emit(tr("emr.template.need_values_or_mark"))
            return
        file_path = self._dataset_path_fn() if self._dataset_path_fn is not None else None
        file_name = file_path.name if file_path is not None else ""
        file_path_str = str(file_path) if file_path is not None else ""
        try:
            self._template.append_record(
                row,
                source=RecordSource(file_name=file_name, file_path=file_path_str),
            )
            self._persist_template()
        except DuplicateRecordError as exc:
            self.user_message.emit(tr("emr.msg.duplicate", key_id=exc.key_id))
            return
        except ValueError as exc:
            self.user_message.emit(str(exc))
            return
        for edit in self._field_edits.values():
            edit.clear()
        self._refresh_validation_ui()
        self._reload_qa_templates()
        self.template_changed.emit(self._template)
        self.qa_selection_changed.emit()
        self.user_message.emit(tr("emr.template.record_added"))

    def schema_test_config(self) -> str:
        return self._schema_test.selected_schema_id()

    def schema_test_ready(self) -> bool:
        return self._schema_test.is_ready()

    def set_schema_summary_idle(self) -> None:
        self._schema_test.set_summary_idle()

    def set_schema_summary_running(self) -> None:
        self._schema_test.set_summary_running()

    def set_schema_summary_error(self, message: str) -> None:
        self._schema_test.set_summary_error(message)

    def set_schema_summary_report(self, report) -> None:
        self._schema_test.set_summary_report(report)

    def reload_schema_catalogs(self) -> None:
        from core.schema_catalog_store import SchemaCatalogStore

        SchemaCatalogStore().invalidate()
        self._schema_edit._reload_catalog_list()
        self._schema_test.reload_catalogs()

    def _on_schema_config_changed(self) -> None:
        self._schema_test.set_summary_idle()

    def _on_schema_catalogs_changed(self) -> None:
        self._schema_test.reload_catalogs()
