"""Tab Template Edit — minibase como tabla editable."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from emrqa.template_key_store import NoActiveKeyError, TemplateKeyStore
from emrqa.validation_models import DuplicateRecordError, ValidationTemplate
from shell.template_edit import (
    apply_table_rows_to_template,
    restore_template,
    snapshot_template,
    table_rows_from_template,
)
from shell.template_edit_delegate import TemplateEditCellDelegate
from ui.i18n import tr
from ui.widgets.table_clipboard import install_table_copy_shortcut


class TemplateEditTab(QWidget):
    saved = Signal()
    cancelled = Signal()
    encrypt_requested = Signal()

    def __init__(self, parent=None, *, key_store: TemplateKeyStore | None = None) -> None:
        super().__init__(parent)
        self._key_store = key_store or TemplateKeyStore()
        self._template: ValidationTemplate | None = None
        self._baseline: ValidationTemplate | None = None
        self._fields: list = []
        self._dirty = False
        self._loading_table = False

        self._hint = QLabel()
        self._hint.setObjectName("configHint")
        self._hint.setWordWrap(True)

        self._table = QTableWidget()
        self._table.setObjectName("templateEditTable")
        self._table.setItemDelegate(
            TemplateEditCellDelegate(self._baseline_row_count, self._table)
        )
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.DoubleClicked
            | QAbstractItemView.EditTrigger.EditKeyPressed
        )
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectItems)
        self._table.setAlternatingRowColors(False)
        self._table.setShowGrid(True)
        self._table.setSortingEnabled(False)
        self._table.horizontalHeader().setSectionsClickable(False)
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.verticalHeader().setVisible(True)
        self._table.itemChanged.connect(self._on_item_changed)
        install_table_copy_shortcut(self._table)

        self._add_row = QPushButton()
        self._add_row.clicked.connect(self._on_add_row)
        self._remove_rows = QPushButton()
        self._remove_rows.clicked.connect(self._on_remove_rows)
        self._encrypt = QPushButton()
        self._encrypt.clicked.connect(self._on_encrypt)

        row_tools = QHBoxLayout()
        row_tools.addWidget(self._add_row)
        row_tools.addWidget(self._remove_rows)
        row_tools.addWidget(self._encrypt)
        row_tools.addStretch(1)

        self._save = QPushButton()
        self._save.clicked.connect(self._on_save)
        self._cancel = QPushButton()
        self._cancel.clicked.connect(self._on_cancel)

        actions = QHBoxLayout()
        actions.addStretch(1)
        actions.addWidget(self._cancel)
        actions.addWidget(self._save)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        layout.addWidget(self._hint)
        layout.addLayout(row_tools)
        layout.addWidget(self._table, stretch=1)
        layout.addLayout(actions)

        self.retranslate_ui()
        self._refresh_table()

    def set_key_store(self, key_store: TemplateKeyStore) -> None:
        self._key_store = key_store
        self._update_actions()

    def refresh_key_state(self) -> None:
        self._update_hint()
        self._update_actions()

    def retranslate_ui(self) -> None:
        self._add_row.setText(tr("emr.template_edit.add_row"))
        self._remove_rows.setText(tr("emr.template_edit.remove_rows"))
        self._encrypt.setText(tr("emr.template_edit.encrypt"))
        self._save.setText(tr("action.save"))
        self._cancel.setText(tr("emr.template_edit.cancel"))
        self._update_hint()
        self._update_actions()

    def set_template(self, template: ValidationTemplate | None) -> None:
        self._template = template
        self._baseline = snapshot_template(template) if template is not None else None
        self._dirty = False
        self._refresh_table()

    def _encryption_hint(self) -> str:
        if self._template is None:
            return ""
        if self._template.is_encrypted and self._template.header.encryption is not None:
            return tr(
                "emr.template_edit.encrypted_hint",
                key_id=self._template.header.encryption.key_id,
            )
        return tr("emr.template_edit.plaintext_hint")

    def _update_hint(self) -> None:
        if self._template is None:
            self._hint.setText(tr("emr.template_edit.no_template"))
            return
        self._hint.setText(
            tr(
                "emr.template_edit.hint_named",
                name=self._template.header.name,
                records=len(self._template.minibase.records),
            )
            + " "
            + self._encryption_hint()
            + " "
            + tr("emr.template_edit.pending_hint")
        )

    def _update_actions(self) -> None:
        enabled = self._template is not None
        self._add_row.setEnabled(enabled)
        self._remove_rows.setEnabled(enabled)
        can_encrypt = (
            enabled
            and self._key_store.has_active_key()
            and self._template is not None
            and not self._template.is_encrypted
        )
        self._encrypt.setEnabled(can_encrypt)
        self._save.setEnabled(enabled and self._dirty)
        self._cancel.setEnabled(enabled and self._dirty)

    def _repaint_pending(self) -> None:
        self._table.viewport().update()

    def _refresh_table(self) -> None:
        self._loading_table = True
        self._table.blockSignals(True)
        self._table.clear()
        self._fields = []

        if self._template is None:
            self._table.setRowCount(0)
            self._table.setColumnCount(0)
            self._table.blockSignals(False)
            self._loading_table = False
            self._update_hint()
            self._update_actions()
            return

        self._fields = list(self._template.header.fields)
        headers = [field.column for field in self._fields]
        rows = table_rows_from_template(self._template)

        self._table.setColumnCount(len(headers))
        self._table.setHorizontalHeaderLabels(headers)
        self._table.setRowCount(len(rows))

        for row_index, row_values in enumerate(rows):
            for col_index, field in enumerate(self._fields):
                value = row_values.get(field.field_id, "")
                item = QTableWidgetItem(value)
                item.setFlags(
                    Qt.ItemFlag.ItemIsEnabled
                    | Qt.ItemFlag.ItemIsSelectable
                    | Qt.ItemFlag.ItemIsEditable
                )
                item.setData(Qt.ItemDataRole.UserRole, value)
                self._table.setItem(row_index, col_index, item)

        self._table.resizeColumnsToContents()
        self._table.blockSignals(False)
        self._loading_table = False
        self._repaint_pending()
        self._update_hint()
        self._update_actions()

    def _baseline_row_count(self) -> int:
        if self._baseline is None:
            return 0
        return len(self._baseline.minibase.records)

    def _sync_dirty_state(self) -> None:
        if self._template is None or self._baseline is None:
            self._dirty = False
            return
        if self._table.rowCount() != self._baseline_row_count():
            self._dirty = True
            return
        for row_index in range(self._table.rowCount()):
            for col_index, _field in enumerate(self._fields):
                item = self._table.item(row_index, col_index)
                if item is None:
                    continue
                original = item.data(Qt.ItemDataRole.UserRole)
                if item.text() != str(original or ""):
                    self._dirty = True
                    return
        self._dirty = False

    def _on_item_changed(self, _item: QTableWidgetItem) -> None:
        if self._loading_table or self._template is None:
            return
        self._sync_dirty_state()
        self._repaint_pending()
        self._update_actions()

    def _on_add_row(self) -> None:
        if self._template is None or not self._fields:
            return
        row_index = self._table.rowCount()
        self._loading_table = True
        self._table.blockSignals(True)
        self._table.insertRow(row_index)
        for col_index, _field in enumerate(self._fields):
            item = QTableWidgetItem("")
            item.setFlags(
                Qt.ItemFlag.ItemIsEnabled
                | Qt.ItemFlag.ItemIsSelectable
                | Qt.ItemFlag.ItemIsEditable
            )
            item.setData(Qt.ItemDataRole.UserRole, "")
            self._table.setItem(row_index, col_index, item)
        self._table.blockSignals(False)
        self._loading_table = False
        self._sync_dirty_state()
        self._repaint_pending()
        self._update_actions()

    def _on_remove_rows(self) -> None:
        if self._template is None:
            return
        selected_rows = sorted(
            {index.row() for index in self._table.selectedIndexes()},
            reverse=True,
        )
        if not selected_rows:
            return
        self._loading_table = True
        self._table.blockSignals(True)
        for row_index in selected_rows:
            self._table.removeRow(row_index)
        self._table.blockSignals(False)
        self._loading_table = False
        self._sync_dirty_state()
        self._repaint_pending()
        self._update_actions()

    def _read_table_rows(self) -> list[dict[str, str]]:
        rows: list[dict[str, str]] = []
        for row_index in range(self._table.rowCount()):
            values: dict[str, str] = {}
            for col_index, field in enumerate(self._fields):
                item = self._table.item(row_index, col_index)
                values[field.field_id] = item.text() if item is not None else ""
            rows.append(values)
        return rows

    def _on_save(self) -> None:
        if self._template is None:
            return
        try:
            apply_table_rows_to_template(self._template, self._read_table_rows())
        except DuplicateRecordError as exc:
            self._hint.setText(tr("emr.msg.duplicate", key_id=exc.key_id))
            return
        except ValueError as exc:
            self._hint.setText(str(exc))
            return
        self._baseline = snapshot_template(self._template)
        self._dirty = False
        self._refresh_table()
        self.saved.emit()

    def _on_encrypt(self) -> None:
        if self._template is None:
            return
        if not self._key_store.has_active_key():
            QMessageBox.information(self, tr("emr.app.title"), tr("emr.key.export_none"))
            return
        if self._template.is_encrypted:
            return
        reply = QMessageBox.question(
            self,
            tr("emr.template_edit.encrypt_title"),
            tr("emr.template_edit.encrypt_confirm"),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return
        if self._dirty:
            try:
                apply_table_rows_to_template(self._template, self._read_table_rows())
            except (DuplicateRecordError, ValueError) as exc:
                self._hint.setText(str(exc))
                return
        try:
            self._key_store.active_key_bytes()
        except NoActiveKeyError:
            QMessageBox.information(self, tr("emr.app.title"), tr("emr.key.export_none"))
            return
        self.encrypt_requested.emit()

    def _on_cancel(self) -> None:
        if self._template is None or self._baseline is None:
            return
        restore_template(self._template, self._baseline)
        self._dirty = False
        self._refresh_table()
        self.cancelled.emit()
