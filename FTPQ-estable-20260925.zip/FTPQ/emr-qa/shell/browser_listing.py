"""Listado local EMR QA — filtro opcional solo archivos tabulares válidos."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from core.analysis_types import is_tabular_extension
from core.local_browser import (
    LocalEntry,
    LocalListing,
    is_storage_root,
    list_directory,
    navigate_up,
)


def list_emr_directory(path: Path | None, *, valid_files_only: bool) -> LocalListing:
    """Carpetas y unidades siempre visibles; archivos según filtro."""
    if path is None:
        return list_directory(None)
    if valid_files_only:
        listing = list_directory(path)
        filtered = tuple(
            entry
            for entry in listing.entries
            if entry.is_dir or is_tabular_extension(entry.name)
        )
        return LocalListing(
            current_path=listing.current_path,
            display_path=listing.display_path,
            entries=filtered,
        )
    return _list_all_entries(path.resolve())


def _list_all_entries(path: Path) -> LocalListing:
    rows: list[LocalEntry] = []
    rows.append(
        LocalEntry(
            name="..",
            absolute_path=navigate_up(path) or path,
            is_dir=True,
            ext="",
            size_bytes=0,
            modified=None,
        )
    )
    try:
        children = sorted(path.iterdir(), key=lambda item: item.name.casefold())
    except OSError:
        children = []

    for child in children:
        try:
            if child.is_dir():
                rows.append(_entry_from_path(child, is_dir=True))
            elif child.is_file():
                rows.append(_entry_from_path(child, is_dir=False))
        except OSError:
            continue

    return LocalListing(
        current_path=path,
        display_path=str(path),
        entries=tuple(rows),
    )


def _entry_from_path(path: Path, *, is_dir: bool) -> LocalEntry:
    name = path.name
    if is_dir and name != "..":
        name = f"{name}/"
    size = 0
    modified: datetime | None = None
    if not is_dir:
        try:
            stat = path.stat()
            size = stat.st_size
            modified = datetime.fromtimestamp(stat.st_mtime)
        except OSError:
            pass
    else:
        try:
            modified = datetime.fromtimestamp(path.stat().st_mtime)
        except OSError:
            pass
    ext = "" if is_dir else (path.suffix or "")
    return LocalEntry(
        name=name,
        absolute_path=path.resolve(),
        is_dir=is_dir,
        ext=ext,
        size_bytes=size,
        modified=modified,
    )
