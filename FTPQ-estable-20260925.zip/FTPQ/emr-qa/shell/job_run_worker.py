"""Worker — ejecutar EmrQaJob en hilo aparte (mismo motor que CLI)."""
from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCore import QObject, Signal, Slot

from core.app_log import log_event, log_exception
from job_runner import EmrQaJobRunResult, run_emr_qa_job
from shell.job_run_session import JobRunSession, build_effective_job, validation_tab_for_mode
from shell.validation_panel import ValidationTab


@dataclass(frozen=True)
class JobRunFinished:
    session: JobRunSession
    result: EmrQaJobRunResult
    tab: ValidationTab


@dataclass(frozen=True)
class JobRunError:
    message: str


class JobRunWorker(QObject):
    finished = Signal(object)
    run_requested = Signal(object)

    def __init__(self) -> None:
        super().__init__()
        self.run_requested.connect(self._do_run)

    @Slot(object)
    def _do_run(self, session: JobRunSession) -> None:
        try:
            job = build_effective_job(session)
            log_event(f"job run start mode={job.mode} file={session.file_path.name}")
            result = run_emr_qa_job(
                job,
                file_path=session.file_path,
                reference_path=session.reference_path,
            )
            tab = validation_tab_for_mode(result.mode)
            self.finished.emit(JobRunFinished(session=session, result=result, tab=tab))
            log_event(f"job run done ok={result.ok} mode={result.mode}")
        except Exception as exc:  # noqa: BLE001
            log_exception("job_run", exc)
            self.finished.emit(JobRunError(str(exc)))
