"""Menú superior EMR QA — Archivo / Ver / Ayuda + idioma."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from PySide6.QtGui import QAction, QActionGroup
from PySide6.QtWidgets import QMenu, QMenuBar, QWidget

from ui.i18n import current_language, tr


@dataclass
class EmrMenuState:
    file_menu: QMenu
    view_menu: QMenu
    key_menu: QMenu
    help_menu: QMenu
    language_menu: QMenu
    act_run_job: QAction
    act_edit_job: QAction
    act_close_file: QAction
    act_quit: QAction
    act_wallpaper: QAction
    act_icon: QAction
    act_key_status: QAction
    act_generate_key: QAction
    act_load_key: QAction
    act_export_key: QAction
    act_about: QAction
    act_lang_es: QAction
    act_lang_en: QAction


def populate_emr_menu_bar(
    bar: QMenuBar,
    *,
    on_run_job: Callable[[], None],
    on_edit_job: Callable[[], None],
    on_close_file: Callable[[], None],
    on_quit: Callable[[], None],
    on_pick_wallpaper: Callable[[], None],
    on_pick_icon: Callable[[], None],
    on_generate_key: Callable[[], None],
    on_load_key: Callable[[], None],
    on_export_key: Callable[[], None],
    key_status_text: Callable[[], str],
    on_about: Callable[[], None],
    on_language_picked: Callable[[str], None],
) -> EmrMenuState:
    bar.setNativeMenuBar(False)

    file_menu = bar.addMenu("")
    act_run_job = QAction("", bar)
    act_run_job.triggered.connect(on_run_job)
    file_menu.addAction(act_run_job)
    act_edit_job = QAction("", bar)
    act_edit_job.triggered.connect(on_edit_job)
    file_menu.addAction(act_edit_job)
    act_close_file = QAction("", bar)
    act_close_file.triggered.connect(on_close_file)
    file_menu.addAction(act_close_file)
    file_menu.addSeparator()
    act_quit = QAction("", bar)
    act_quit.triggered.connect(on_quit)
    file_menu.addAction(act_quit)

    view_menu = bar.addMenu("")
    act_wallpaper = QAction("", bar)
    act_wallpaper.triggered.connect(on_pick_wallpaper)
    view_menu.addAction(act_wallpaper)
    act_icon = QAction("", bar)
    act_icon.triggered.connect(on_pick_icon)
    view_menu.addAction(act_icon)

    key_menu = view_menu.addMenu("")
    act_key_status = QAction("", bar)
    act_key_status.setEnabled(False)
    act_generate_key = QAction("", bar)
    act_generate_key.triggered.connect(on_generate_key)
    act_load_key = QAction("", bar)
    act_load_key.triggered.connect(on_load_key)
    act_export_key = QAction("", bar)
    act_export_key.triggered.connect(on_export_key)
    key_menu.addAction(act_key_status)
    key_menu.addSeparator()
    key_menu.addAction(act_generate_key)
    key_menu.addAction(act_load_key)
    key_menu.addAction(act_export_key)

    help_menu = bar.addMenu("")
    act_about = QAction("", bar)
    act_about.triggered.connect(on_about)
    help_menu.addAction(act_about)

    language_menu = help_menu.addMenu("")
    lang_group = QActionGroup(bar)
    lang_group.setExclusive(True)

    act_lang_es = QAction("", bar)
    act_lang_es.setCheckable(True)
    lang_group.addAction(act_lang_es)
    act_lang_es.triggered.connect(lambda: on_language_picked("es"))
    language_menu.addAction(act_lang_es)

    act_lang_en = QAction("", bar)
    act_lang_en.setCheckable(True)
    lang_group.addAction(act_lang_en)
    act_lang_en.triggered.connect(lambda: on_language_picked("en"))
    language_menu.addAction(act_lang_en)

    state = EmrMenuState(
        file_menu=file_menu,
        view_menu=view_menu,
        key_menu=key_menu,
        help_menu=help_menu,
        language_menu=language_menu,
        act_run_job=act_run_job,
        act_edit_job=act_edit_job,
        act_close_file=act_close_file,
        act_quit=act_quit,
        act_wallpaper=act_wallpaper,
        act_icon=act_icon,
        act_key_status=act_key_status,
        act_generate_key=act_generate_key,
        act_load_key=act_load_key,
        act_export_key=act_export_key,
        act_about=act_about,
        act_lang_es=act_lang_es,
        act_lang_en=act_lang_en,
    )
    apply_emr_menu_translations(state, key_status_text=key_status_text)
    return state


def apply_emr_menu_translations(
    state: EmrMenuState,
    *,
    key_status_text: Callable[[], str] | None = None,
) -> None:
    state.file_menu.setTitle(tr("menu.file"))
    state.act_run_job.setText(tr("emr.action.run_job"))
    state.act_edit_job.setText(tr("emr.action.edit_job"))
    state.act_close_file.setText(tr("emr.action.close_file"))
    state.act_quit.setText(tr("emr.action.quit"))
    state.view_menu.setTitle(tr("menu.view"))
    state.act_wallpaper.setText(tr("action.wallpaper"))
    state.act_icon.setText(tr("action.icon"))
    state.key_menu.setTitle(tr("emr.menu.key"))
    if key_status_text is not None:
        state.act_key_status.setText(key_status_text())
    state.act_generate_key.setText(tr("emr.key.generate"))
    state.act_load_key.setText(tr("emr.key.load"))
    state.act_export_key.setText(tr("emr.key.export"))
    state.help_menu.setTitle(tr("menu.help"))
    state.act_about.setText(tr("emr.action.about"))
    state.language_menu.setTitle(tr("menu.language"))
    state.act_lang_es.setText(tr("language.spanish"))
    state.act_lang_en.setText(tr("language.english"))
    lang = current_language()
    state.act_lang_es.setChecked(lang == "es")
    state.act_lang_en.setChecked(lang == "en")
