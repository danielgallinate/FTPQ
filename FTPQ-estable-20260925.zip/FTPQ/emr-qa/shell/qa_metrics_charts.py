"""Gráficos QA — uno por fila, centrados, efectividad por plantilla."""
from __future__ import annotations

from PySide6.QtCharts import (
    QBarCategoryAxis,
    QBarSeries,
    QBarSet,
    QChart,
    QChartView,
    QPieSeries,
    QPieSlice,
    QValueAxis,
)
from PySide6.QtCore import QMargins, Qt
from PySide6.QtGui import QBrush, QColor, QFont, QPalette, QPainter
from PySide6.QtWidgets import QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout, QWidget

from core.chart_format import floor_pct, format_category_label, format_count
from shell.qa_chart_labels import flush_chart_tooltips, wire_bar_chart_labels, wire_bar_chart_tooltips

from shell.qa_metrics import QaMetricsReport, TemplateMetrics
from shell.qa_metrics_chart_layout import (
    MINI_BOARD_GAP,
    MINI_BOARD_ROW_GAP,
    MINI_PIES_PER_ROW,
    ChartStackLayout,
    compute_chart_stack_layout,
)
from ui.i18n import tr


def _centered_chart_row(view: QChartView, *, row_width: int, row_height: int) -> QWidget:
    row = QWidget()
    row.setFixedSize(row_width, row_height)
    layout = QHBoxLayout(row)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(0)
    layout.addStretch(1)
    layout.addWidget(view, 0, Qt.AlignmentFlag.AlignCenter)
    layout.addStretch(1)
    return row


class TemplateMiniPieCard(QWidget):
    """Tarjeta por template: título, pie grande y cifras legibles debajo."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("qaMetricsMiniPieCard")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 4, 6, 8)
        layout.setSpacing(6)
        self._title = QLabel()
        self._title.setObjectName("sectionLabel")
        self._title.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self._title.setWordWrap(True)
        title_font = QFont(self._title.font())
        title_font.setPointSize(11)
        title_font.setBold(True)
        self._title.setFont(title_font)
        self._view = QChartView()
        self._view.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self._stats = QLabel()
        self._stats.setObjectName("configHint")
        self._stats.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self._stats.setWordWrap(True)
        stats_font = QFont(self._stats.font())
        stats_font.setPointSize(10)
        self._stats.setFont(stats_font)
        layout.addWidget(self._title)
        layout.addWidget(self._view, 0, Qt.AlignmentFlag.AlignHCenter)
        layout.addWidget(self._stats)

    @property
    def view(self) -> QChartView:
        return self._view

    def set_content(self, *, title: str, stats: str, chart: QChart) -> None:
        self._title.setText(title)
        self._stats.setText(stats)
        self._view.setChart(chart)

    def set_pie_size(self, size: int) -> None:
        self._view.setFixedSize(size, size)


class QaMetricsChartsWidget(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("qaMetricsCharts")
        self._report: QaMetricsReport | None = None
        self._nok_only = False
        self._layout_spec: ChartStackLayout | None = None
        self._content_width = 640

        self._template_chart = QChartView()
        self._column_chart = QChartView()
        self._coverage_chart = QChartView()
        for view in (self._template_chart, self._column_chart, self._coverage_chart):
            view.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

        self._template_row = _centered_chart_row(self._template_chart, row_width=640, row_height=120)
        self._column_row = _centered_chart_row(self._column_chart, row_width=640, row_height=120)
        self._coverage_row = _centered_chart_row(self._coverage_chart, row_width=640, row_height=120)

        self._template_board_host = QWidget()
        self._template_board_host.setObjectName("qaMetricsTemplateBoard")
        self._template_board_outer = QHBoxLayout(self._template_board_host)
        self._template_board_outer.setContentsMargins(0, 0, 0, 0)
        self._template_board_outer.setSpacing(0)
        self._template_board_inner = QWidget()
        self._template_board_layout = QVBoxLayout(self._template_board_inner)
        self._template_board_layout.setContentsMargins(0, 0, 0, 0)
        self._template_board_layout.setSpacing(6)
        self._template_board_hint = QLabel()
        self._template_board_hint.setObjectName("configHint")
        self._template_board_hint.setWordWrap(True)
        self._template_board_hint.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self._template_board_pies = QWidget()
        self._template_board_pies_layout = QVBoxLayout(self._template_board_pies)
        self._template_board_pies_layout.setContentsMargins(0, 0, 0, 0)
        self._template_board_pies_layout.setSpacing(MINI_BOARD_ROW_GAP)
        self._template_board_layout.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self._template_board_layout.addWidget(self._template_board_hint)
        self._template_board_layout.addWidget(self._template_board_pies)
        self._template_board_outer.addStretch(1)
        self._template_board_outer.addWidget(self._template_board_inner)
        self._template_board_outer.addStretch(1)
        self._template_coverage_cards: list[TemplateMiniPieCard] = []

        self._stack = QVBoxLayout()
        self._stack.setContentsMargins(0, 8, 0, 0)
        self._stack.setSpacing(16)
        self._stack.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self._stack.addWidget(self._template_row)
        self._stack.addWidget(self._column_row)
        self._stack.addWidget(self._coverage_row)
        self._stack.addWidget(self._template_board_host)
        self._template_board_host.hide()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addLayout(self._stack)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

    def retranslate_ui(self) -> None:
        self._template_board_hint.setText(tr("emr.qa.metrics.chart_board_hint"))
        if self._report is not None:
            self.set_report(self._report, nok_only=self._nok_only)

    def set_report(self, report: QaMetricsReport | None, *, nok_only: bool = False) -> None:
        flush_chart_tooltips()
        self._report = report
        self._nok_only = nok_only
        if report is None:
            for view in (self._template_chart, self._column_chart, self._coverage_chart):
                view.setChart(QChart())
            self._clear_template_coverage_board()
            self._layout_spec = None
            self.update_content_size()
            return
        self._build_template_chart(report)
        self._build_column_chart(report)
        self._build_coverage_chart(report)
        self._build_template_coverage_board(report)
        self.update_content_size()

    def update_content_size(self, *, content_width: int | None = None) -> None:
        if self._report is None:
            self.setMinimumSize(0, 0)
            self.resize(0, 0)
            return
        self._content_width = max(content_width or self._content_width, 320)
        template_items = self._template_items(self._report)
        spec = compute_chart_stack_layout(
            content_width=self._content_width,
            template_count=len(template_items),
            column_count=len(self._column_items(self._report)),
        )
        self._layout_spec = spec
        self._apply_layout_spec(spec)
        self.setFixedSize(spec.stack_width, spec.stack_height + 8)
        self.updateGeometry()

    def refresh_display(self) -> None:
        if self._report is None:
            return
        self.set_report(self._report, nok_only=self._nok_only)

    def layout_spec(self) -> ChartStackLayout | None:
        return self._layout_spec

    def _apply_layout_spec(self, spec: ChartStackLayout) -> None:
        self._stack.setSpacing(spec.gap)
        main_rows = (
            (self._template_chart, self._template_row),
            (self._column_chart, self._column_row),
            (self._coverage_chart, self._coverage_row),
        )
        for index, (view, row_widget) in enumerate(main_rows):
            if index >= len(spec.rows):
                break
            chart_spec = spec.rows[index]
            view.setFixedSize(chart_spec.chart.width, chart_spec.chart.height)
            row_widget.setFixedSize(spec.stack_width, chart_spec.row_height)
        board = spec.template_board
        if board is None or not self._template_coverage_cards:
            self._template_board_host.hide()
            return
        self._template_board_host.show()
        self._template_board_host.setFixedSize(spec.stack_width, board.board_height)
        self._template_board_inner.setFixedSize(board.board_width, board.board_height)
        self._template_board_pies.setFixedSize(board.board_width, board.pies_height)
        for card in self._template_coverage_cards:
            card.setFixedSize(board.cell_width, board.cell_height)
            card.set_pie_size(board.pie_size)

    def _clear_template_coverage_board(self) -> None:
        while self._template_board_pies_layout.count():
            item = self._template_board_pies_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._template_coverage_cards.clear()
        self._template_board_host.hide()

    def _mini_stats_text(self, item: TemplateMetrics, *, nok_total: int) -> str:
        judged = item.judged
        return tr(
            "emr.qa.metrics.chart_mini_stats",
            eligible=format_count(item.eligible_cells),
            judged=format_count(judged),
            coverage_pct=f"{item.coverage_pct:.2f}",
            ok=format_count(item.ok),
            ok_pct=f"{self._slice_pct(item.ok, judged):.2f}",
            nok=format_count(nok_total),
            nok_pct=f"{self._slice_pct(nok_total, judged):.2f}",
            uncovered=format_count(item.unevaluated_cells),
        )

    def _make_template_mini_card(self, item: TemplateMetrics) -> TemplateMiniPieCard:
        nok_total = item.nok + item.conflict
        chart = self._build_quality_pie_chart(
            ok=item.ok,
            nok=nok_total,
            uncovered=item.unevaluated_cells,
            eligible=item.eligible_cells,
            pie_only=True,
        )
        card = TemplateMiniPieCard()
        self._apply_chart_theme(chart, card.view, compact=True)
        card.set_content(
            title=item.name,
            stats=self._mini_stats_text(item, nok_total=nok_total),
            chart=chart,
        )
        return card

    def _theme_colors(self) -> tuple[QColor, QColor, QColor, QColor, QColor]:
        palette = self.palette()
        fg = palette.color(QPalette.ColorRole.WindowText)
        hint = palette.color(QPalette.ColorRole.PlaceholderText)
        ok = QColor("#4CAF50") if fg.lightness() > 128 else QColor("#66BB6A")
        nok = QColor("#EF5350") if fg.lightness() > 128 else QColor("#E57373")
        pending = hint
        return fg, hint, ok, nok, pending

    def _apply_chart_theme(self, chart: QChart, view: QChartView, *, compact: bool = False) -> None:
        fg, hint, _ok, _nok, _pending = self._theme_colors()
        chart.setBackgroundVisible(False)
        chart.setPlotAreaBackgroundVisible(False)
        chart.setTitleBrush(QBrush(fg))
        chart.legend().setLabelColor(fg)
        if compact:
            chart.setMargins(QMargins(2, 0, 2, 0))
        else:
            chart.setMargins(QMargins(0, 0, 0, 0))
        view.setBackgroundBrush(QBrush(Qt.GlobalColor.transparent))
        view.setStyleSheet("background: transparent; border: none;")
        view.setRenderHint(QPainter.RenderHint.Antialiasing)
        for axis in chart.axes():
            axis.setLabelsColor(fg)
            axis.setTitleBrush(QBrush(fg))
            axis.setGridLineColor(QColor(hint.red(), hint.green(), hint.blue(), 80))

    def _template_items(self, report: QaMetricsReport) -> list[TemplateMetrics]:
        items: list[TemplateMetrics] = []
        for name in report.template_names:
            metrics = report.by_template.get(name)
            if metrics is None:
                continue
            if self._nok_only and metrics.nok <= 0:
                continue
            items.append(metrics)
        return sorted(items, key=lambda item: (-item.nok, item.name))

    def _column_items(self, report: QaMetricsReport) -> list:
        items = sorted(
            (m for m in report.by_column.values() if m.applicable),
            key=lambda item: (-item.nok, item.column),
        )
        if self._nok_only:
            items = [item for item in items if item.nok > 0]
        return items

    def _slice_pct(self, value: int, total: int) -> float:
        return floor_pct(value, total)

    def _append_pie_slice(
        self,
        series: QPieSeries,
        *,
        legend_label: str,
        value: int,
        total: int,
        color: QColor,
    ) -> None:
        if value <= 0:
            return
        pct = self._slice_pct(value, total)
        slice_item = QPieSlice(
            tr(
                "emr.qa.metrics.chart_slice_legend",
                name=legend_label,
                pct=f"{pct:.2f}",
                count=format_count(value),
            ),
            value,
        )
        slice_item.setColor(color)
        slice_item.setLabelVisible(False)
        series.append(slice_item)

    def _build_quality_pie_chart(
        self,
        *,
        ok: int,
        nok: int,
        uncovered: int,
        eligible: int,
        heading: str = "",
        pie_only: bool = False,
    ) -> QChart:
        chart = QChart()
        if not pie_only:
            chart.setTitle(
                tr(
                    "emr.qa.metrics.chart_quality_subtitle",
                    title=heading,
                    eligible=format_count(eligible),
                    ok=format_count(ok),
                    nok=format_count(nok),
                    uncovered=format_count(uncovered),
                )
            )
        series = QPieSeries()
        _fg, _hint, ok_color, nok_color, pending_color = self._theme_colors()
        total = max(eligible, ok + nok + uncovered)
        self._append_pie_slice(
            series,
            legend_label=tr("emr.qa.metrics.chart_ok"),
            value=ok,
            total=total,
            color=ok_color,
        )
        self._append_pie_slice(
            series,
            legend_label=tr("emr.qa.metrics.chart_nok"),
            value=nok,
            total=total,
            color=nok_color,
        )
        self._append_pie_slice(
            series,
            legend_label=tr("emr.qa.metrics.chart_uncovered"),
            value=uncovered,
            total=total,
            color=pending_color,
        )
        if total <= 0:
            return chart
        chart.addSeries(series)
        chart.legend().setVisible(not pie_only)
        if not pie_only:
            chart.legend().setAlignment(Qt.AlignmentFlag.AlignBottom)
        return chart

    def _build_ok_nok_bar_chart(
        self,
        *,
        view: QChartView,
        title: str,
        categories: list[str],
        ok_values: list[int],
        nok_values: list[int],
    ) -> None:
        chart = QChart()
        total_ok = sum(ok_values)
        total_nok = sum(nok_values)
        chart.setTitle(
            tr(
                "emr.qa.metrics.chart_bar_subtitle",
                title=title,
                ok=format_count(total_ok),
                nok=format_count(total_nok),
            )
        )
        chart.legend().setVisible(True)
        chart.legend().setAlignment(Qt.AlignmentFlag.AlignBottom)
        if not categories:
            self._apply_chart_theme(chart, view)
            view.setChart(chart)
            return
        fg, _hint, ok_color, nok_color, _pending = self._theme_colors()
        ok_set = QBarSet(tr("emr.qa.metrics.chart_ok"))
        nok_set = QBarSet(tr("emr.qa.metrics.chart_nok"))
        ok_set.setColor(ok_color)
        nok_set.setColor(nok_color)
        ok_set.setLabelColor(fg)
        nok_set.setLabelColor(fg)
        for ok_value, nok_value in zip(ok_values, nok_values, strict=True):
            ok_set.append(float(ok_value))
            nok_set.append(float(nok_value))
        series = QBarSeries()
        series.append(ok_set)
        series.append(nok_set)
        series.setLabelsVisible(False)
        chart.addSeries(series)
        display_categories = [format_category_label(name) for name in categories]
        axis_x = QBarCategoryAxis()
        axis_x.append(display_categories)
        axis_x.setLabelsAngle(-35 if any(len(name) > 14 for name in categories) else 0)
        chart.addAxis(axis_x, Qt.AlignmentFlag.AlignBottom)
        series.attachAxis(axis_x)
        axis_y = QValueAxis()
        axis_y.setLabelFormat("%d")
        axis_y.setMinorTickCount(0)
        max_value = max([0, *ok_values, *nok_values])
        axis_y.setRange(0, max(max_value, 1))
        if max_value <= 5:
            axis_y.setTickCount(max(max_value + 1, 2))
        elif max_value <= 50:
            axis_y.setTickCount(6)
        else:
            axis_y.setTickCount(5)
        chart.addAxis(axis_y, Qt.AlignmentFlag.AlignLeft)
        series.attachAxis(axis_y)
        self._apply_chart_theme(chart, view)
        chart.setMargins(QMargins(8, 24, 8, 28 if axis_x.labelsAngle() else 8))
        view.setChart(chart)
        wire_bar_chart_labels(chart, series, fg=fg)
        wire_bar_chart_tooltips(
            series,
            categories=categories,
            ok_label=tr("emr.qa.metrics.chart_ok"),
            nok_label=tr("emr.qa.metrics.chart_nok"),
        )

    def _build_template_chart(self, report: QaMetricsReport) -> None:
        items = self._template_items(report)
        self._build_ok_nok_bar_chart(
            view=self._template_chart,
            title=tr("emr.qa.metrics.chart_templates"),
            categories=[item.name for item in items],
            ok_values=[item.ok for item in items],
            nok_values=[item.nok + item.conflict for item in items],
        )

    def _build_column_chart(self, report: QaMetricsReport) -> None:
        items = self._column_items(report)
        self._build_ok_nok_bar_chart(
            view=self._column_chart,
            title=tr("emr.qa.metrics.chart_columns"),
            categories=[item.column for item in items],
            ok_values=[item.ok for item in items],
            nok_values=[item.nok for item in items],
        )

    def _build_coverage_chart(self, report: QaMetricsReport) -> None:
        nok_total = report.nok_cells + report.conflict_cells
        chart = self._build_quality_pie_chart(
            heading=tr("emr.qa.metrics.chart_quality"),
            ok=report.ok_cells,
            nok=nok_total,
            uncovered=report.unevaluated_cells,
            eligible=report.eligible_cells,
        )
        self._apply_chart_theme(chart, self._coverage_chart)
        self._coverage_chart.setChart(chart)

    def _build_template_coverage_board(self, report: QaMetricsReport) -> None:
        self._clear_template_coverage_board()
        items = self._template_items(report)
        if len(items) <= 1:
            return
        self._template_board_host.show()
        self._template_board_hint.setText(tr("emr.qa.metrics.chart_board_hint"))
        for row_start in range(0, len(items), MINI_PIES_PER_ROW):
            row_items = items[row_start : row_start + MINI_PIES_PER_ROW]
            row_widget = QWidget()
            row_layout = QHBoxLayout(row_widget)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(MINI_BOARD_GAP)
            row_layout.addStretch(1)
            for item in row_items:
                card = self._make_template_mini_card(item)
                self._template_coverage_cards.append(card)
                row_layout.addWidget(card, 0, Qt.AlignmentFlag.AlignTop)
            row_layout.addStretch(1)
            self._template_board_pies_layout.addWidget(row_widget)
