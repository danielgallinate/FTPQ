"""Tab Catálogos — crear tablas de referencia desde archivo abierto."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from core.analysis_types import TabularDataset
from core.catalog_store import (
    CatalogStore,
    create_catalog_from_dataset,
    list_catalog_metas,
)
from core.catalog_types import (
    CatalogKeyConflictError,
    CatalogTable,
    CatalogValidationError,
)
from shell.batch_match_editor import BatchMatchEditor
from shell.tabular_rows import dataset_to_row_dicts
from ui.i18n import tr


class CatalogTab(QFrame):
    catalogs_changed = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._dataset: TabularDataset | None = None
        self._source_file = ""
        self._column_checks: dict[str, QCheckBox] = {}

        self._list = QListWidget()
        self._list.setMaximumHeight(96)
        self._list.currentItemChanged.connect(self._on_catalog_selection_changed)
        self._refresh_btn = QPushButton()
        self._refresh_btn.clicked.connect(self._reload_catalog_list)
        self._delete_btn = QPushButton()
        self._delete_btn.clicked.connect(self._on_delete_catalog)

        self._name = QLineEdit()
        self._key_column = QComboBox()
        self._key_column.currentIndexChanged.connect(self._on_create_form_changed)
        self._unique_keys = QCheckBox()
        self._unique_keys.setChecked(True)
        self._unique_keys.stateChanged.connect(self._on_create_form_changed)
        self._create_btn = QPushButton()
        self._create_btn.clicked.connect(self._on_create_catalog)
        self._columns_host = QWidget()
        self._columns_layout = QVBoxLayout(self._columns_host)
        self._columns_layout.setContentsMargins(0, 0, 0, 0)
        self._columns_layout.setSpacing(4)
        columns_scroll = QScrollArea()
        columns_scroll.setWidgetResizable(True)
        columns_scroll.setWidget(self._columns_host)
        columns_scroll.setFrameShape(QFrame.Shape.NoFrame)

        self._hint = QLabel()
        self._hint.setObjectName("configHint")
        self._hint.setWordWrap(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)
        layout.addWidget(self._hint)
        layout.addWidget(QLabel(tr("emr.catalog.existing_title")))
        layout.addWidget(self._list)
        row = QHBoxLayout()
        row.addWidget(self._refresh_btn)
        row.addWidget(self._delete_btn)
        layout.addLayout(row)
        self._preview_title = QLabel()
        self._preview_title.setWordWrap(True)
        layout.addWidget(self._preview_title)
        self._preview_table = QTableWidget()
        self._preview_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._preview_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self._preview_table.setAlternatingRowColors(True)
        self._preview_table.verticalHeader().setVisible(False)
        self._preview_table.horizontalHeader().setStretchLastSection(True)
        self._preview_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.ResizeToContents
        )
        layout.addWidget(self._preview_table, stretch=2)
        self._batch_match = BatchMatchEditor()
        self._batch_save = QPushButton()
        self._batch_save.clicked.connect(self._on_save_batch_match)
        layout.addWidget(self._batch_match)
        layout.addWidget(self._batch_save)
        layout.addWidget(QLabel(tr("emr.catalog.create_title")))
        layout.addWidget(QLabel(tr("emr.catalog.name_label")))
        layout.addWidget(self._name)
        layout.addWidget(QLabel(tr("emr.catalog.key_column_label")))
        layout.addWidget(self._key_column)
        layout.addWidget(self._unique_keys)
        layout.addWidget(QLabel(tr("emr.catalog.columns_label")))
        layout.addWidget(columns_scroll, stretch=1)
        layout.addWidget(self._create_btn)
        self.retranslate_ui()
        self._reload_catalog_list()

    def retranslate_ui(self) -> None:
        self._refresh_btn.setText(tr("emr.catalog.refresh"))
        self._delete_btn.setText(tr("emr.catalog.delete"))
        self._create_btn.setText(tr("emr.catalog.create_btn"))
        self._unique_keys.setText(tr("emr.catalog.unique_keys"))
        self._hint.setText(tr("emr.catalog.tab_hint"))
        self._batch_save.setText(tr("emr.catalog.batch_save"))
        self._batch_match.retranslate_ui()
        self._refresh_preview_from_selection()

    def _selected_columns(self) -> list[str]:
        return [name for name, check in self._column_checks.items() if check.isChecked()]

    def _duplicate_policy(self) -> str:
        return "keep_first" if self._unique_keys.isChecked() else "error"

    def _on_create_form_changed(self) -> None:
        self._sync_key_column_choices()

    def _sync_key_column_choices(self) -> None:
        checked = self._selected_columns()
        current = str(self._key_column.currentData() or "")
        self._key_column.blockSignals(True)
        self._key_column.clear()
        for name in checked:
            self._key_column.addItem(name, name)
        if current in checked:
            index = checked.index(current)
            self._key_column.setCurrentIndex(index)
        elif checked:
            self._key_column.setCurrentIndex(0)
        self._key_column.blockSignals(False)

    def _refresh_preview_from_selection(self) -> None:
        catalog_id = self._selected_catalog_id()
        if not catalog_id:
            self._clear_preview()
            return
        try:
            table = CatalogStore().load(catalog_id)
        except CatalogValidationError:
            self._clear_preview()
            return
        self._show_preview(table)

    def _fill_preview_table(self, columns: list[str], rows: list[dict[str, str]]) -> None:
        self._preview_table.clear()
        self._preview_table.setColumnCount(len(columns))
        self._preview_table.setHorizontalHeaderLabels(columns)
        self._preview_table.setRowCount(len(rows))
        readonly = Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
        for row_index, row in enumerate(rows):
            for col_index, column in enumerate(columns):
                item = QTableWidgetItem(row.get(column, ""))
                item.setFlags(readonly)
                self._preview_table.setItem(row_index, col_index, item)
        self._preview_table.resizeColumnsToContents()

    def _clear_preview(self) -> None:
        self._preview_title.setText(tr("emr.catalog.preview_empty"))
        self._preview_table.clear()
        self._preview_table.setRowCount(0)
        self._preview_table.setColumnCount(0)
        self._batch_match.clear()
        self._batch_save.setEnabled(False)

    def _on_catalog_selection_changed(self) -> None:
        self._refresh_preview_from_selection()

    def _show_preview(self, table: CatalogTable) -> None:
        meta = table.meta
        self._preview_title.setText(
            tr(
                "emr.catalog.preview_title",
                name=meta.name,
                rows=len(table.rows),
                key_column=meta.key_column,
            )
        )
        columns = list(meta.columns)
        self._fill_preview_table(columns, table.rows)
        self._batch_match.set_spec(meta.batch_match)
        self._batch_save.setEnabled(True)

    def _select_catalog_in_list(self, catalog_id: str) -> None:
        for index in range(self._list.count()):
            item = self._list.item(index)
            if item is not None and item.data(256) == catalog_id:
                self._list.setCurrentItem(item)
                return

    def set_dataset(self, dataset: TabularDataset | None, *, source_file: str = "") -> None:
        self._dataset = dataset
        self._source_file = source_file
        self._batch_match.set_source_filename(
            source_file or (dataset.local_path.name if dataset is not None else "")
        )
        self._rebuild_column_checks()
        self._create_btn.setEnabled(dataset is not None)

    def _rebuild_column_checks(self) -> None:
        while self._columns_layout.count():
            item = self._columns_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self._column_checks.clear()
        self._key_column.clear()
        if self._dataset is None:
            return
        for column in self._dataset.columns:
            check = QCheckBox(column.name)
            check.setChecked(True)
            check.stateChanged.connect(self._on_create_form_changed)
            self._column_checks[column.name] = check
            self._columns_layout.addWidget(check)
        self._sync_key_column_choices()

    def _reload_catalog_list(self) -> None:
        selected_id = self._selected_catalog_id()
        self._list.clear()
        store = CatalogStore()
        for meta in list_catalog_metas():
            row_count = len(store.load(meta.catalog_id).rows)
            self._list.addItem(
                tr(
                    "emr.catalog.list_item",
                    name=meta.name,
                    rows=row_count,
                    key_column=meta.key_column,
                )
            )
            item = self._list.item(self._list.count() - 1)
            if item is not None:
                item.setData(256, meta.catalog_id)
        if selected_id:
            self._select_catalog_in_list(selected_id)
        elif self._list.count() > 0:
            self._list.setCurrentRow(0)
        else:
            self._clear_preview()

    def _selected_catalog_id(self) -> str | None:
        item = self._list.currentItem()
        if item is None:
            return None
        catalog_id = item.data(256)
        return str(catalog_id) if catalog_id else None

    def _on_delete_catalog(self) -> None:
        catalog_id = self._selected_catalog_id()
        if not catalog_id:
            return
        answer = QMessageBox.question(
            self,
            tr("emr.catalog.delete"),
            tr("emr.catalog.delete_confirm", catalog=catalog_id),
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        CatalogStore().delete(catalog_id)
        self._reload_catalog_list()
        self.catalogs_changed.emit()

    def _on_save_batch_match(self) -> None:
        catalog_id = self._selected_catalog_id()
        if not catalog_id:
            QMessageBox.information(
                self,
                tr("emr.catalog.batch_save"),
                tr("emr.catalog.batch_pick"),
            )
            return
        batch_error = self._batch_match.validate(catalog_id)
        if batch_error:
            QMessageBox.warning(
                self,
                tr("emr.batch_match.invalid_regex"),
                batch_error,
            )
            return
        try:
            CatalogStore().update_catalog_batch_match(catalog_id, self._batch_match.spec())
        except CatalogValidationError as exc:
            QMessageBox.warning(self, tr("emr.catalog.batch_save"), str(exc))
            return
        self.catalogs_changed.emit()
        QMessageBox.information(
            self,
            tr("emr.catalog.batch_save"),
            tr("emr.catalog.batch_saved"),
        )

    def _on_create_catalog(self) -> None:
        if self._dataset is None:
            return
        name = self._name.text().strip()
        key_column = str(self._key_column.currentData() or "")
        columns = self._selected_columns()
        if not name:
            QMessageBox.warning(self, tr("emr.catalog.create_btn"), tr("emr.catalog.err_name"))
            return
        if not key_column or key_column not in columns:
            QMessageBox.warning(self, tr("emr.catalog.create_btn"), tr("emr.catalog.err_key"))
            return
        if not columns:
            QMessageBox.warning(
                self, tr("emr.catalog.create_btn"), tr("emr.catalog.err_columns")
            )
            return
        try:
            rows = dataset_to_row_dicts(self._dataset)
            meta, skipped = create_catalog_from_dataset(
                name=name,
                columns=columns,
                key_column=key_column,
                dataset_rows=rows,
                source_file=self._source_file,
                on_duplicate=self._duplicate_policy(),
            )
            row_count = len(CatalogStore().load(meta.catalog_id).rows)
        except CatalogKeyConflictError as exc:
            QMessageBox.warning(
                self,
                tr("emr.catalog.create_btn"),
                tr("emr.catalog.err_conflict", key_value=exc.key_value),
            )
            return
        except CatalogValidationError as exc:
            QMessageBox.warning(self, tr("emr.catalog.create_btn"), str(exc))
            return
        self._name.clear()
        self._reload_catalog_list()
        self._select_catalog_in_list(meta.catalog_id)
        self.catalogs_changed.emit()
        QMessageBox.information(
            self,
            tr("emr.catalog.create_btn"),
            tr(
                "emr.catalog.created_skipped" if skipped else "emr.catalog.created",
                name=meta.name,
                rows=row_count,
                skipped=skipped,
            ),
        )
