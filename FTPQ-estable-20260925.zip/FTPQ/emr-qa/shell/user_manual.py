"""Rutas del manual de uso EMR QA por idioma."""
from __future__ import annotations

from pathlib import Path

DOCS_DIR = Path(__file__).resolve().parents[1] / "docs"


def user_manual_path(language: str | None = None) -> Path:
    from ui.i18n import current_language

    lang = (language or current_language()).casefold()
    if lang.startswith("en"):
        return DOCS_DIR / "manual-en.txt"
    return DOCS_DIR / "manual-es.txt"
