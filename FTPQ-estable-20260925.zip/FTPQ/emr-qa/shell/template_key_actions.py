"""Acciones de menú Ver → Llave para cifrado de minibase."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QFileDialog, QMessageBox, QWidget

from emrqa.template_key_store import InvalidKeyFileError, TemplateKeyStore
from ui.i18n import tr


def key_status_label(key_store: TemplateKeyStore) -> str:
    key_id = key_store.active_key_id()
    if key_id:
        return tr("emr.key.status_active", key_id=key_id)
    return tr("emr.key.status_none")


def confirm_generate_key(parent: QWidget) -> bool:
    reply = QMessageBox.warning(
        parent,
        tr("emr.key.generate_title"),
        tr("emr.key.generate_warning"),
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        QMessageBox.StandardButton.No,
    )
    return reply == QMessageBox.StandardButton.Yes


def generate_template_key(parent: QWidget, key_store: TemplateKeyStore) -> str | None:
    if not confirm_generate_key(parent):
        return None
    try:
        key_id = key_store.generate_and_save()
    except OSError as exc:
        QMessageBox.warning(parent, tr("emr.app.title"), str(exc))
        return None
    QMessageBox.information(
        parent,
        tr("emr.key.generate_title"),
        tr("emr.key.generate_ok", key_id=key_id),
    )
    return key_id


def load_template_key(parent: QWidget, key_store: TemplateKeyStore) -> str | None:
    path_str, _ = QFileDialog.getOpenFileName(
        parent,
        tr("emr.key.load_dialog_title"),
        str(Path.home()),
        tr("emr.key.file_filter"),
    )
    if not path_str:
        return None
    path = Path(path_str)
    try:
        key_id = key_store.load_from_file(path)
    except (OSError, InvalidKeyFileError, ValueError) as exc:
        QMessageBox.warning(parent, tr("emr.app.title"), str(exc))
        return None
    QMessageBox.information(
        parent,
        tr("emr.key.load_title"),
        tr("emr.key.load_ok", key_id=key_id),
    )
    return key_id


def export_template_key(parent: QWidget, key_store: TemplateKeyStore) -> bool:
    if not key_store.has_active_key():
        QMessageBox.information(parent, tr("emr.app.title"), tr("emr.key.export_none"))
        return False
    path_str, _ = QFileDialog.getSaveFileName(
        parent,
        tr("emr.key.export_dialog_title"),
        str(Path.home() / "template_encryption.key"),
        tr("emr.key.file_filter"),
    )
    if not path_str:
        return False
    try:
        key_store.export_to_file(Path(path_str))
    except OSError as exc:
        QMessageBox.warning(parent, tr("emr.app.title"), str(exc))
        return False
    QMessageBox.information(parent, tr("emr.app.title"), tr("emr.key.export_ok"))
    return True
