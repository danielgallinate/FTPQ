"""Diálogos — crear template EMR QA."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from ui.i18n import tr


class CreateTemplateDialog(QDialog):
    def __init__(self, parent=None, *, columns: list[str]) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("emr.template.create_dialog_title"))
        self.resize(420, 360)

        self._columns = list(columns)
        self._key_checks: list[QCheckBox] = []

        intro = QLabel(tr("emr.template.create_dialog_hint"))
        intro.setWordWrap(True)

        self._name = QLineEdit()
        self._name.setPlaceholderText(tr("emr.template.name_ph"))

        key_label = QLabel(tr("emr.template.key_columns"))
        key_label.setObjectName("panelSubtitle")

        key_host = QWidget()
        key_layout = QVBoxLayout(key_host)
        key_layout.setContentsMargins(4, 4, 4, 4)
        key_layout.setSpacing(4)
        for index, column in enumerate(self._columns):
            box = QCheckBox(column)
            box.setChecked(index == 0)
            key_layout.addWidget(box)
            self._key_checks.append(box)
        key_layout.addStretch(1)

        key_scroll = QScrollArea()
        key_scroll.setWidgetResizable(True)
        key_scroll.setWidget(key_host)
        key_scroll.setMaximumHeight(180)

        form = QFormLayout()
        form.addRow(tr("emr.template.name_label"), self._name)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(intro)
        layout.addLayout(form)
        layout.addWidget(key_label)
        layout.addWidget(key_scroll)
        layout.addWidget(buttons)

    def _on_accept(self) -> None:
        if not self._name.text().strip():
            QMessageBox.warning(self, tr("emr.app.title"), tr("emr.template.name_required"))
            return
        if not self.key_columns():
            QMessageBox.warning(self, tr("emr.app.title"), tr("emr.template.key_required"))
            return
        if len(self.key_columns()) >= len(self._columns):
            QMessageBox.warning(self, tr("emr.app.title"), tr("emr.template.key_leave_compare"))
            return
        self.accept()

    def template_name(self) -> str:
        return self._name.text().strip()

    def key_columns(self) -> list[str]:
        return [box.text() for box in self._key_checks if box.isChecked()]
