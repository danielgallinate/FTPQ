"""Filas del dataset → dict para minibase del template."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from core.analysis_types import TabularDataset
from emrqa.validation_models import RecordSource, ValidationTemplate


def row_dict_at_index(dataset: TabularDataset, source_row: int) -> dict[str, Any]:
    columns = [column.name for column in dataset.columns]
    record = dataset.rows[source_row]
    return {
        name: record[index] if index < len(record) else ""
        for index, name in enumerate(columns)
    }


def append_marked_rows(
    template: ValidationTemplate,
    dataset: TabularDataset,
    marked_rows: set[int],
    *,
    file_path: Path | None,
) -> tuple[int, list[str]]:
    if not marked_rows:
        return 0, []
    file_name = file_path.name if file_path is not None else ""
    file_path_str = str(file_path) if file_path is not None else ""
    added = 0
    errors: list[str] = []
    for source_row in sorted(marked_rows):
        row = row_dict_at_index(dataset, source_row)
        try:
            template.append_record(
                row,
                source=RecordSource(
                    file_name=file_name,
                    file_path=file_path_str,
                    row_index=source_row,
                ),
            )
            added += 1
        except Exception as exc:
            errors.append(str(exc))
    return added, errors
