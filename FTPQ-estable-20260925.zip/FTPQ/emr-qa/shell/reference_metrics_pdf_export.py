"""Exportación PDF — reporte comparación referencia."""
from __future__ import annotations

import re
from pathlib import Path

from PySide6.QtWidgets import QFileDialog, QWidget

from shell.qa_metrics_pdf_export import export_qa_metrics_pdf
from shell.reference_metrics_charts import ReferenceMetricsChartsWidget
from shell.reference_metrics_report_view import ReferenceMetricsReportView
from ui.i18n import tr


def default_pdf_filename(source_file_name: str) -> str:
    stem = Path(source_file_name).stem or "ref_compare"
    safe = re.sub(r"[^\w\-.]+", "_", stem).strip("_")
    return f"{safe or 'ref_compare'}_reference_report.pdf"


def pick_pdf_export_path(parent: QWidget, *, default_name: str) -> Path | None:
    downloads = Path.home() / "Downloads"
    start = downloads / default_name if downloads.is_dir() else Path(default_name)
    selected, _filter = QFileDialog.getSaveFileName(
        parent,
        tr("emr.ref.metrics.export_pdf_title"),
        str(start),
        tr("emr.ref.metrics.export_pdf_filter"),
    )
    if not selected:
        return None
    path = Path(selected)
    if path.suffix.lower() != ".pdf":
        path = path.with_suffix(".pdf")
    return path


def export_reference_metrics_pdf(
    path: Path | str,
    *,
    report_view: ReferenceMetricsReportView,
    charts: ReferenceMetricsChartsWidget,
) -> None:
    export_qa_metrics_pdf(path, report_view=report_view, charts=charts)
