"""Menú local EMR QA — Abrir vs Probar."""
from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import QPoint
from PySide6.QtWidgets import QMenu, QWidget

from ui.i18n import tr


def show_emr_file_menu(
    parent: QWidget,
    global_pos: QPoint,
    *,
    on_open: Callable[[], None],
    on_probe: Callable[[], None],
) -> None:
    menu = QMenu(parent)
    menu.setObjectName("emrFileActionsMenu")
    menu.addAction(tr("emr.action.open"), on_open)
    menu.addAction(tr("emr.action.probe"), on_probe)
    menu.exec(global_pos)
