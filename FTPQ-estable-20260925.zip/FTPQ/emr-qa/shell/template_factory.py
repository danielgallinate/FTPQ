"""Construcción y edición de templates v2.0 — EMR QA shell."""
from __future__ import annotations

from emrqa.validation_models import (
    DedupPolicy,
    EvaluationDefaults,
    MinibaseSection,
    RowField,
    TemplateHeader,
    TemplateKey,
    TemplateMeta,
    ValidationTemplate,
    _utc_now_iso,
    new_id,
)
from emrqa.validation_storage import slugify_template_name, templates_dir


def build_empty_template(
    *,
    name: str,
    column_names: list[str],
    key_column_names: list[str],
    knowledge_base_id: str = "default",
) -> ValidationTemplate:
    if not name.strip():
        raise ValueError("Nombre de template requerido")
    if not column_names:
        raise ValueError("Se requiere al menos una columna")
    if not key_column_names:
        raise ValueError("Se requiere al menos una columna en la llave")
    if len(key_column_names) >= len(column_names):
        raise ValueError("Debe quedar al menos un campo fuera de la llave para comparar")

    fields: list[RowField] = []
    column_to_field: dict[str, str] = {}
    for column in column_names:
        field_id = new_id("fld_")
        fields.append(
            RowField(
                field_id=field_id,
                label=column,
                column=column,
                required=False,
            )
        )
        column_to_field[column] = field_id

    missing_key = [column for column in key_column_names if column not in column_to_field]
    if missing_key:
        raise ValueError(f"Columnas de llave no presentes: {', '.join(missing_key)}")

    key_field_ids = [column_to_field[column] for column in key_column_names]
    key_label = _key_label_from_columns(key_column_names)
    key = TemplateKey(
        key_id=new_id("key_"),
        label=key_label,
        field_ids=key_field_ids,
        primary=True,
    )
    slug = slugify_template_name(name)
    target = templates_dir(knowledge_base_id) / f"{slug}.json"
    if target.exists():
        raise ValueError(f"Ya existe un template con el nombre «{name.strip()}»")
    now = _utc_now_iso()
    return ValidationTemplate(
        meta=TemplateMeta(
            schema_version="2.0",
            template_id=slug,
            knowledge_base_id=knowledge_base_id,
            created_at=now,
            updated_at=now,
        ),
        header=TemplateHeader(
            name=name.strip(),
            fields=fields,
            keys=[key],
            evaluation=EvaluationDefaults(columns=list(column_names)),
        ),
        minibase=MinibaseSection(
            dedup=DedupPolicy(key_id=key.key_id),
            records=[],
        ),
    )


def set_primary_key_fields(template: ValidationTemplate, field_ids: list[str]) -> None:
    if template.minibase.records:
        raise ValueError("No se puede cambiar la llave con registros guardados")
    allowed = {field.field_id for field in template.header.fields}
    selected = [field_id for field_id in field_ids if field_id in allowed]
    if not selected:
        raise ValueError("Seleccione al menos un campo para la llave")
    if len(selected) >= len(template.header.fields):
        raise ValueError("Debe quedar al menos un campo fuera de la llave para comparar")

    key = template.header.primary_key()
    labels = []
    for field_id in selected:
        field = template.header.field_by_id(field_id)
        if field is not None:
            labels.append(field.label)
    label = _key_label_from_columns(labels)

    if key is None:
        key = TemplateKey(
            key_id=new_id("key_"),
            label=label,
            field_ids=selected,
            primary=True,
        )
        template.header.keys = [key]
    else:
        key.field_ids = selected
        key.label = label
        key.primary = True

    template.minibase.dedup.key_id = key.key_id
    template.meta.updated_at = _utc_now_iso()


def template_structure_locked(template: ValidationTemplate) -> bool:
    return bool(template.minibase.records)


def _key_label_from_columns(columns: list[str]) -> str:
    if len(columns) == 1:
        return f"PK {columns[0]}"
    return " + ".join(columns)
