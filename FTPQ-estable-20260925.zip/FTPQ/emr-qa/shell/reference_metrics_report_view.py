"""Vista tabular del reporte de comparación contra referencia."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHeaderView,
    QLabel,
    QSizePolicy,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from shell.reference_metrics import ReferenceCompareReport
from ui.i18n import tr


def _readonly_item(text: str) -> QTableWidgetItem:
    item = QTableWidgetItem(text)
    item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
    return item


def _configure_table(table: QTableWidget) -> None:
    table.setObjectName("qaMetricsTable")
    table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
    table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
    table.setAlternatingRowColors(True)
    table.setShowGrid(True)
    table.verticalHeader().setVisible(False)
    header = table.horizontalHeader()
    header.setStretchLastSection(False)
    header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
    table.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
    table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)


def _finalize_table_size(table: QTableWidget) -> None:
    table.resizeColumnsToContents()
    table.resizeRowsToContents()
    width = table.frameWidth() * 2
    if table.verticalHeader().isVisible():
        width += table.verticalHeader().width()
    for column in range(table.columnCount()):
        width += table.columnWidth(column)
    height = table.frameWidth() * 2 + table.horizontalHeader().height()
    for row in range(table.rowCount()):
        height += table.rowHeight(row)
    w = max(width, 120)
    h = max(height, table.horizontalHeader().height() + 8)
    table.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
    table.setFixedSize(w, h)


def _section_height(widget: QWidget) -> int:
    if isinstance(widget, QTableWidget):
        return widget.height()
    return max(widget.minimumHeight(), widget.sizeHint().height(), widget.height())


def _section_width(widget: QWidget) -> int:
    if isinstance(widget, QTableWidget):
        return widget.width()
    return max(widget.minimumWidth(), widget.sizeHint().width(), widget.width())


class ReferenceMetricsReportView(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("referenceMetricsReportView")
        self._report: ReferenceCompareReport | None = None
        self._nok_only = False

        self._meta = QLabel()
        self._meta.setObjectName("configHint")
        self._meta.setWordWrap(True)
        self._meta.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self._summary_title = QLabel()
        self._summary_title.setObjectName("panelSubtitle")
        self._summary_table = QTableWidget()
        _configure_table(self._summary_table)
        self._summary_table.setColumnCount(2)

        self._columns_title = QLabel()
        self._columns_title.setObjectName("panelSubtitle")
        self._columns_table = QTableWidget()
        _configure_table(self._columns_table)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.addWidget(self._meta)
        layout.addWidget(self._summary_title)
        layout.addWidget(self._summary_table)
        layout.addWidget(self._columns_title)
        layout.addWidget(self._columns_table)
        layout.addStretch(0)
        self.setSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Minimum)
        self.retranslate_ui()

    def retranslate_ui(self) -> None:
        self._summary_title.setText(tr("emr.ref.report.summary_section"))
        self._columns_title.setText(tr("emr.ref.report.columns_section"))
        self._summary_table.setHorizontalHeaderLabels(
            [
                tr("emr.qa.metrics.table.metric"),
                tr("emr.qa.metrics.table.value"),
            ]
        )
        if self._report is not None:
            self.set_report(self._report, nok_only=self._nok_only)

    def set_report(self, report: ReferenceCompareReport | None, *, nok_only: bool = False) -> None:
        self._report = report
        self._nok_only = nok_only
        if report is None:
            self._meta.clear()
            self._summary_table.setRowCount(0)
            self._columns_table.setRowCount(0)
            self._columns_title.hide()
            self._columns_table.hide()
            self.update_content_size()
            return

        self._meta.setText(
            tr(
                "emr.ref.report.meta_block",
                file=report.file_name,
                reference=report.reference_name,
                generated=report.generated_at,
                headline=report.headline,
            )
        )
        self._fill_summary(report)
        self._fill_columns(report, nok_only=nok_only)
        self.update_content_size()

    def _fill_summary(self, report: ReferenceCompareReport) -> None:
        summary_rows = [
            (
                tr("emr.ref.report.rows_label"),
                tr(
                    "emr.ref.report.rows",
                    compared=f"{report.rows_compared:,}",
                    matched=f"{report.rows_matched_key:,}",
                    pct=f"{report.row_match_pct:.2f}",
                ),
            ),
            (
                tr("emr.ref.report.cells_label"),
                tr(
                    "emr.ref.report.cells",
                    ok=f"{report.cells_ok:,}",
                    nok=f"{report.cells_nok:,}",
                    pct=f"{report.cell_match_pct:.2f}",
                ),
            ),
            (tr("emr.ref.report.no_match"), str(report.rows_without_match)),
            (tr("emr.ref.report.ambiguous"), str(report.rows_ambiguous_key)),
            (tr("emr.ref.report.dup_keys"), str(report.duplicate_reference_keys)),
            (tr("emr.ref.report.join"), report.join_key_summary),
            (
                tr("emr.ref.report.ref_rows"),
                tr(
                    "emr.ref.report.ref_rows_value",
                    loaded=f"{report.reference_rows_loaded:,}",
                    total=f"{report.reference_rows_total:,}",
                ),
            ),
            (
                tr("emr.ref.report.pairs_compared"),
                str(report.pairs_compared),
            ),
        ]
        self._summary_table.setRowCount(len(summary_rows))
        for row_index, (label, value) in enumerate(summary_rows):
            self._summary_table.setItem(row_index, 0, _readonly_item(label))
            self._summary_table.setItem(row_index, 1, _readonly_item(value))
        _finalize_table_size(self._summary_table)

    def _fill_columns(self, report: ReferenceCompareReport, *, nok_only: bool) -> None:
        headers = [
            tr("emr.ref.report.table.column"),
            tr("emr.ref.report.table.reference"),
            tr("emr.ref.report.table.ok"),
            tr("emr.ref.report.table.nok"),
            tr("emr.ref.report.table.ok_pct"),
        ]
        self._columns_table.setColumnCount(len(headers))
        self._columns_table.setHorizontalHeaderLabels(headers)
        items = report.column_items(nok_only=nok_only)
        if not items:
            self._columns_title.hide()
            self._columns_table.hide()
            return
        self._columns_title.show()
        self._columns_table.show()
        self._columns_table.setRowCount(len(items))
        for row_index, item in enumerate(items):
            self._columns_table.setItem(row_index, 0, _readonly_item(item.left_column))
            self._columns_table.setItem(row_index, 1, _readonly_item(item.right_column))
            self._columns_table.setItem(row_index, 2, _readonly_item(f"{item.ok:,}"))
            self._columns_table.setItem(row_index, 3, _readonly_item(f"{item.nok:,}"))
            self._columns_table.setItem(row_index, 4, _readonly_item(f"{item.ok_pct:.2f}%"))
        _finalize_table_size(self._columns_table)

    def update_content_size(self) -> None:
        if self._report is None:
            self.setMinimumSize(0, 0)
            return
        width = 0
        height = 0
        visible_count = 0
        for widget in (
            self._meta,
            self._summary_title,
            self._summary_table,
            self._columns_title,
            self._columns_table,
        ):
            if not widget.isVisible():
                continue
            visible_count += 1
            width = max(width, _section_width(widget))
            height += _section_height(widget)
        layout = self.layout()
        if layout is not None:
            height += layout.spacing() * max(0, visible_count - 1)
            height += layout.contentsMargins().top() + layout.contentsMargins().bottom()
            width += layout.contentsMargins().left() + layout.contentsMargins().right()
        self.setMinimumSize(max(width, 320), max(height, 120))
        self.resize(self.minimumWidth(), self.minimumHeight())
        self.updateGeometry()
