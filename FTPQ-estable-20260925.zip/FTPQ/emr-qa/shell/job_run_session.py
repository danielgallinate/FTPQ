"""Sesión Run job — overrides efímeros sobre EmrQaJob (sin persistir rutas)."""
from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path

from core.emr_qa_job import EmrQaJob, JobQaCatalogSpec, JobQaSection, JobValidationSection, load_job


@dataclass(frozen=True)
class JobRunSession:
    job_path: Path
    base_job: EmrQaJob
    file_path: Path
    reference_path: Path | None = None
    catalog_specs: tuple[JobQaCatalogSpec, ...] = ()
    template_paths: tuple[str, ...] | None = None
    validation_template_path: str | None = None
    schema_id: str | None = None
    row_limit: str | None = None


def load_job_session(path: Path) -> JobRunSession:
    resolved = path.resolve()
    job = load_job(resolved)
    file_path = Path(job.file).resolve() if job.file else Path()
    reference_path = Path(job.reference_file).resolve() if job.reference_file else None
    catalogs = job.qa.catalogs
    return JobRunSession(
        job_path=resolved,
        base_job=job,
        file_path=file_path,
        reference_path=reference_path,
        catalog_specs=catalogs,
    )


def build_effective_job(session: JobRunSession) -> EmrQaJob:
    qa_section = session.base_job.qa
    if session.catalog_specs:
        qa_section = replace(qa_section, catalogs=session.catalog_specs)
    if session.template_paths is not None:
        qa_section = replace(qa_section, template_paths=session.template_paths)
    job = replace(session.base_job, qa=qa_section)
    if session.validation_template_path is not None:
        validation = replace(
            job.validation,
            template_path=session.validation_template_path,
        )
        job = replace(job, validation=validation)
    if session.schema_id is not None:
        schema = replace(job.schema, schema_id=session.schema_id.strip())
        job = replace(job, schema=schema)
    if session.row_limit is not None:
        job = replace(job, row_limit=session.row_limit.strip() or None)
    return job


def effective_row_limit_tag(session: JobRunSession) -> str | None:
    if session.row_limit is not None:
        tag = session.row_limit.strip()
        if tag:
            return tag
    return session.base_job.effective_row_limit_tag()


def validation_tab_for_mode(mode: str):
    from shell.validation_panel import ValidationTab

    if mode == "reference":
        return ValidationTab.REFERENCE
    if mode == "validation":
        return ValidationTab.VALIDATION
    if mode == "schema":
        return ValidationTab.SCHEMA
    return ValidationTab.QA


def session_ready(session: JobRunSession) -> tuple[bool, str]:
    if not session.file_path.is_file():
        return False, "file"
    if session.base_job.mode == "reference":
        ref = session.reference_path
        if ref is None or not ref.is_file():
            return False, "reference"
    if session.base_job.mode == "qa":
        effective = build_effective_job(session)
        if not effective.qa.template_paths and not effective.qa.catalogs:
            return False, "templates"
    if session.base_job.mode == "schema" and not session.base_job.schema.schema_id:
        return False, "schema"
    return True, ""
