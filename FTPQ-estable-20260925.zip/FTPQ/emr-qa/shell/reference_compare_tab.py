"""Tab Referencia — archivo fuente fiable y mapeo unificado de columnas/llaves."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
    QFileDialog,
)

from adapters.pandas_analyzer import analyze_tabular_file
from core.analysis_types import is_tabular_extension
from core.reference_compare import suggest_initial_pairs
from core.reference_compare_types import ComparePairMapping, ReferenceCompareConfig
from core.result import Err, Ok
from shell.reference_summary_panel import ReferenceSummaryPanel
from ui.i18n import tr


class _MappingRow(QFrame):
    removed = Signal(object)

    def __init__(
        self,
        *,
        left_columns: list[str],
        right_columns: list[str],
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._left = QComboBox()
        self._right = QComboBox()
        self._left.addItem("", "")
        self._right.addItem("", "")
        for name in left_columns:
            self._left.addItem(name, name)
        for name in right_columns:
            self._right.addItem(name, name)
        self._regex_left = QLineEdit()
        self._regex_left.setPlaceholderText(tr("emr.ref.regex_left_ph"))
        self._regex_right = QLineEdit()
        self._regex_right.setPlaceholderText(tr("emr.ref.regex_right_ph"))
        self._replace_left = QLineEdit()
        self._replace_left.setPlaceholderText(tr("emr.ref.replace_ph"))
        self._replace_right = QLineEdit()
        self._replace_right.setPlaceholderText(tr("emr.ref.replace_ph"))
        self._is_key = QCheckBox()
        self._enabled = QCheckBox()
        self._enabled.setChecked(True)
        self._is_key.toggled.connect(self._on_key_toggled)
        self._enabled.toggled.connect(self._on_enabled_toggled)
        self._remove = QPushButton("×")
        self._remove.setFixedWidth(28)
        self._remove.clicked.connect(lambda: self.removed.emit(self))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(4)
        top = QHBoxLayout()
        top.addWidget(QLabel(tr("emr.ref.col_file")))
        top.addWidget(self._left, stretch=1)
        top.addWidget(QLabel("↔"))
        top.addWidget(QLabel(tr("emr.ref.col_ref")))
        top.addWidget(self._right, stretch=1)
        top.addWidget(self._is_key)
        top.addWidget(self._enabled)
        top.addWidget(self._remove)
        layout.addLayout(top)
        regex_row = QHBoxLayout()
        regex_row.addWidget(self._regex_left, stretch=1)
        regex_row.addWidget(self._replace_left, stretch=1)
        regex_row.addWidget(self._regex_right, stretch=1)
        regex_row.addWidget(self._replace_right, stretch=1)
        layout.addLayout(regex_row)
        self.retranslate_ui()

    def retranslate_ui(self) -> None:
        self._is_key.setText(tr("emr.ref.is_key"))
        self._enabled.setText(tr("emr.ref.enabled"))

    def _on_key_toggled(self, checked: bool) -> None:
        if checked and not self._enabled.isChecked():
            self._enabled.setChecked(True)

    def _on_enabled_toggled(self, checked: bool) -> None:
        if not checked and self._is_key.isChecked():
            self._is_key.setChecked(False)

    def set_columns(self, left_columns: list[str], right_columns: list[str]) -> None:
        left_value = self._left.currentData()
        right_value = self._right.currentData()
        self._left.clear()
        self._right.clear()
        self._left.addItem("", "")
        self._right.addItem("", "")
        for name in left_columns:
            self._left.addItem(name, name)
        for name in right_columns:
            self._right.addItem(name, name)
        self._restore_combo(self._left, left_value)
        self._restore_combo(self._right, right_value)

    @staticmethod
    def _restore_combo(combo: QComboBox, value: object) -> None:
        if not value:
            return
        index = combo.findData(value)
        if index >= 0:
            combo.setCurrentIndex(index)

    def set_pair_mapping(self, mapping: ComparePairMapping) -> None:
        self._restore_combo(self._left, mapping.left_column)
        self._restore_combo(self._right, mapping.right_column)
        self._regex_left.setText(mapping.left_transform.pattern)
        self._replace_left.setText(mapping.left_transform.replacement)
        self._regex_right.setText(mapping.right_transform.pattern)
        self._replace_right.setText(mapping.right_transform.replacement)
        self._enabled.setChecked(mapping.enabled)
        self._is_key.setChecked(mapping.is_join_key)

    @staticmethod
    def _cell_transform(pattern_edit: QLineEdit, replace_edit: QLineEdit):
        from core.cell_transform import CellTransform

        pattern = pattern_edit.text().strip()
        if not pattern:
            return CellTransform()
        raw_replace = replace_edit.text()
        if raw_replace == "~":
            return CellTransform(pattern=pattern, replacement="")
        if raw_replace:
            return CellTransform(pattern=pattern, replacement=raw_replace)
        return CellTransform(pattern=pattern)

    def pair_mapping(self) -> ComparePairMapping:
        is_key = self._is_key.isChecked()
        enabled = self._enabled.isChecked()
        if is_key and not enabled:
            enabled = True
        return ComparePairMapping(
            left_column=str(self._left.currentData() or ""),
            right_column=str(self._right.currentData() or ""),
            left_transform=self._cell_transform(self._regex_left, self._replace_left),
            right_transform=self._cell_transform(self._regex_right, self._replace_right),
            enabled=enabled,
            is_join_key=is_key,
        )

    def wire_changes(self, callback) -> None:
        widgets = [
            self._left,
            self._right,
            self._regex_left,
            self._regex_right,
            self._replace_left,
            self._replace_right,
            self._is_key,
            self._enabled,
        ]
        for widget in widgets:
            if isinstance(widget, QComboBox):
                widget.currentIndexChanged.connect(callback)
            elif isinstance(widget, QCheckBox):
                widget.toggled.connect(callback)
            else:
                widget.textChanged.connect(callback)


class ReferenceCompareTab(QWidget):
    config_changed = Signal()
    compare_requested = Signal()
    user_message = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._left_columns: list[str] = []
        self._reference_path: Path | None = None
        self._reference_columns: list[str] = []
        self._reference_total_rows = 0
        self._pair_rows: list[_MappingRow] = []
        self._building = False

        self._summary = ReferenceSummaryPanel()

        self._hint = QLabel()
        self._hint.setObjectName("configHint")
        self._hint.setWordWrap(True)

        self._pick = QPushButton()
        self._pick.clicked.connect(self._on_pick_reference)

        self._meta = QLabel()
        self._meta.setObjectName("configHint")
        self._meta.setWordWrap(True)

        self._dup_label = QLabel()
        self._duplicate_policy = QComboBox()
        self._duplicate_policy.addItem("", "first")
        self._duplicate_policy.addItem("", "ambiguous")
        self._duplicate_policy.currentIndexChanged.connect(self._emit_config_changed)

        self._execute = QPushButton()
        self._execute.setObjectName("saveAction")
        self._execute.setMinimumHeight(40)
        self._execute.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Fixed,
        )
        self._execute.clicked.connect(self._on_execute)

        self._add_pair = QPushButton()
        self._add_pair.clicked.connect(lambda: self._add_pair_row())
        self._auto_map = QPushButton()
        self._auto_map.clicked.connect(self._on_auto_map)

        self._pair_title = QLabel()
        self._pair_title.setObjectName("panelSubtitle")
        self._pair_host = QWidget()
        self._pair_layout = QVBoxLayout(self._pair_host)
        self._pair_layout.setContentsMargins(0, 0, 0, 0)
        self._pair_layout.setSpacing(4)

        scroll_inner = QWidget()
        inner_layout = QVBoxLayout(scroll_inner)
        inner_layout.setContentsMargins(8, 8, 8, 8)
        inner_layout.setSpacing(8)
        inner_layout.addWidget(self._hint)
        inner_layout.addWidget(self._pick)
        inner_layout.addWidget(self._meta)
        dup_row = QHBoxLayout()
        dup_row.addWidget(self._dup_label)
        dup_row.addWidget(self._duplicate_policy, stretch=1)
        inner_layout.addLayout(dup_row)
        execute_row = QHBoxLayout()
        execute_row.addWidget(self._execute, stretch=1)
        inner_layout.addLayout(execute_row)
        inner_layout.addWidget(self._pair_title)
        inner_layout.addWidget(self._add_pair)
        inner_layout.addWidget(self._auto_map)
        inner_layout.addWidget(self._pair_host)
        inner_layout.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(scroll_inner)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._summary)
        layout.addWidget(scroll, stretch=1)

        self.retranslate_ui()

    def set_summary_running(self) -> None:
        self._summary.set_running()

    def set_summary_error(self, message: str) -> None:
        self._summary.set_error(message)

    def set_summary_report(self, report) -> None:
        self._summary.set_report(report)

    def clear_summary(self) -> None:
        self._summary.set_idle()

    def set_summary_idle_hint(self) -> None:
        self._summary.set_idle_preserve_report()

    def retranslate_ui(self) -> None:
        self._hint.setText(tr("emr.ref.hint"))
        self._pick.setText(tr("emr.ref.pick_file"))
        self._duplicate_policy.setItemText(0, tr("emr.ref.dup_first"))
        self._duplicate_policy.setItemText(1, tr("emr.ref.dup_ambiguous"))
        self._dup_label.setText(tr("emr.ref.dup_policy"))
        self._pair_title.setText(tr("emr.ref.pairs_section"))
        self._add_pair.setText(tr("emr.ref.add_pair"))
        self._auto_map.setText(tr("emr.ref.auto_map"))
        self._execute.setText(tr("emr.ref.execute"))
        self._summary.retranslate_ui()
        for row in self._pair_rows:
            row.retranslate_ui()
        self._refresh_meta()

    def set_left_columns(self, columns: list[str]) -> None:
        self._left_columns = list(columns)
        for row in self._pair_rows:
            row.set_columns(self._left_columns, self._reference_columns)

    def reference_compare_config(self) -> ReferenceCompareConfig:
        policy = self._duplicate_policy.currentData()
        if policy not in ("first", "ambiguous"):
            policy = "first"
        pairs = [row.pair_mapping() for row in self._pair_rows]
        return ReferenceCompareConfig(
            reference_path=self._reference_path,
            reference_columns=tuple(self._reference_columns),
            reference_total_rows=self._reference_total_rows,
            join_keys=[pair.as_join_key() for pair in pairs if pair.is_join_key and pair.enabled],
            pairs=pairs,
            duplicate_policy=policy,
            enabled=True,
        )

    def _refresh_meta(self) -> None:
        if self._reference_path is None:
            self._meta.setText(tr("emr.ref.no_file"))
            return
        extra = ""
        if self._reference_total_rows > 500_000:
            extra = " · " + tr("emr.ref.truncated")
        self._meta.setText(
            tr(
                "emr.ref.meta",
                name=self._reference_path.name,
                rows=f"{self._reference_total_rows:,}",
                cols=len(self._reference_columns),
            )
            + extra
        )

    def _emit_config_changed(self) -> None:
        if self._building:
            return
        self.config_changed.emit()

    def _on_execute(self) -> None:
        config = self.reference_compare_config()
        if config.reference_path is None:
            QMessageBox.information(self, tr("emr.app.title"), tr("emr.ref.need_file"))
            return
        if not any(p.is_join_key and p.enabled and p.is_complete() for p in config.pairs):
            QMessageBox.information(self, tr("emr.app.title"), tr("emr.ref.need_key"))
            return
        if not any(p.enabled and p.is_complete() for p in config.pairs):
            QMessageBox.information(self, tr("emr.app.title"), tr("emr.ref.need_pair"))
            return
        self.compare_requested.emit()

    def _on_pick_reference(self) -> None:
        start = str(Path.home() / "Downloads")
        path_str, _ = QFileDialog.getOpenFileName(
            self,
            tr("emr.ref.pick_dialog_title"),
            start,
            tr("emr.ref.file_filter"),
        )
        if not path_str:
            return
        path = Path(path_str)
        if not is_tabular_extension(path.name):
            QMessageBox.warning(self, tr("emr.app.title"), tr("emr.ref.not_tabular"))
            return
        result = analyze_tabular_file(path, max_display_rows=1)
        if isinstance(result, Err):
            QMessageBox.warning(self, tr("emr.app.title"), str(result.error))
            return
        if not isinstance(result, Ok):
            return
        dataset = result.value
        self._reference_path = path
        self._reference_columns = [column.name for column in dataset.columns]
        self._reference_total_rows = dataset.total_rows
        self._refresh_meta()
        self._rebuild_defaults()
        self.user_message.emit(tr("emr.ref.loaded", name=path.name))
        self._emit_config_changed()

    def _rebuild_defaults(self) -> None:
        self._building = True
        self._clear_pair_rows()
        for pair in suggest_initial_pairs(self._left_columns, self._reference_columns):
            self._add_pair_row(pair, emit=False)
        if not self._pair_rows:
            self._add_pair_row(emit=False)
        self._building = False
        self._emit_config_changed()

    def _clear_pair_rows(self) -> None:
        for row in self._pair_rows:
            row.setParent(None)
            row.deleteLater()
        self._pair_rows.clear()

    def _add_pair_row(
        self,
        mapping: ComparePairMapping | None = None,
        *,
        emit: bool = True,
    ) -> None:
        row = _MappingRow(
            left_columns=self._left_columns,
            right_columns=self._reference_columns,
        )
        if mapping is not None:
            row.set_pair_mapping(mapping)
        row.removed.connect(self._remove_pair_row)
        row.wire_changes(self._emit_config_changed)
        self._pair_rows.append(row)
        self._pair_layout.addWidget(row)
        if emit:
            self._emit_config_changed()

    def _remove_pair_row(self, row: _MappingRow) -> None:
        if row not in self._pair_rows:
            return
        self._pair_rows.remove(row)
        row.setParent(None)
        row.deleteLater()
        self._emit_config_changed()

    def _on_auto_map(self) -> None:
        if not self._reference_columns:
            self.user_message.emit(tr("emr.ref.need_file"))
            return
        self._building = True
        self._clear_pair_rows()
        for pair in suggest_initial_pairs(self._left_columns, self._reference_columns):
            self._add_pair_row(pair, emit=False)
        if not self._pair_rows:
            self._add_pair_row(emit=False)
        self._building = False
        self.user_message.emit(tr("emr.ref.auto_mapped"))
        self._emit_config_changed()
