"""Diálogo metadatos de job — nombre, documentación y rutas opcionales."""
from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path

from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QTextEdit,
    QVBoxLayout,
)

from core.emr_qa_job import EmrQaJob, JobMode, load_job, save_job
from ui.i18n import tr


@dataclass(frozen=True)
class JobMetadataResult:
    name: str
    description: str
    include_file: bool
    include_reference: bool


def default_job_description(mode: JobMode) -> str:
    if mode == "reference":
        return tr("emr.job.default_description.reference")
    if mode == "validation":
        return tr("emr.job.default_description.validation")
    if mode == "schema":
        return tr("emr.job.default_description.schema")
    return tr("emr.job.default_description.qa")


class JobMetadataDialog(QDialog):
    def __init__(
        self,
        parent=None,
        *,
        mode: JobMode,
        job_name: str,
        description: str = "",
        can_include_file: bool = False,
        can_include_reference: bool = False,
        file_hint: str = "",
        reference_hint: str = "",
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("emr.job.metadata.title"))
        self.setMinimumWidth(520)

        intro = QLabel(tr("emr.job.metadata.intro"))
        intro.setWordWrap(True)
        intro.setObjectName("configHint")

        self._name = QLineEdit(job_name)
        self._description = QTextEdit()
        self._description.setPlaceholderText(tr("emr.job.metadata.description_ph"))
        text = description.strip() or default_job_description(mode)
        self._description.setPlainText(text)

        self._include_file = QCheckBox(tr("emr.job.metadata.include_file"))
        self._include_file.setVisible(can_include_file)
        if file_hint:
            self._include_file.setToolTip(file_hint)

        self._include_reference = QCheckBox(tr("emr.job.metadata.include_reference"))
        self._include_reference.setVisible(can_include_reference)
        if reference_hint:
            self._include_reference.setToolTip(reference_hint)

        form = QFormLayout()
        form.addRow(tr("emr.job.metadata.name_label"), self._name)
        form.addRow(tr("emr.job.metadata.description_label"), self._description)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(intro)
        layout.addLayout(form)
        if can_include_file:
            layout.addWidget(self._include_file)
        if can_include_reference:
            layout.addWidget(self._include_reference)
        layout.addWidget(buttons)

    def _on_accept(self) -> None:
        if not self._name.text().strip():
            self._name.setFocus()
            return
        self.accept()

    def result_data(self) -> JobMetadataResult:
        return JobMetadataResult(
            name=self._name.text().strip(),
            description=self._description.toPlainText().strip(),
            include_file=self._include_file.isChecked(),
            include_reference=self._include_reference.isChecked(),
        )


def prompt_job_metadata(
    parent,
    *,
    mode: JobMode,
    job_name: str,
    description: str = "",
    current_file: Path | None = None,
    current_reference: Path | None = None,
) -> JobMetadataResult | None:
    file_hint = str(current_file) if current_file is not None else ""
    reference_hint = str(current_reference) if current_reference is not None else ""
    dialog = JobMetadataDialog(
        parent,
        mode=mode,
        job_name=job_name,
        description=description,
        can_include_file=current_file is not None,
        can_include_reference=mode == "reference" and current_reference is not None,
        file_hint=file_hint,
        reference_hint=reference_hint,
    )
    if dialog.exec() != QDialog.DialogCode.Accepted:
        return None
    return dialog.result_data()


class JobEditDialog(QDialog):
    def __init__(self, parent=None, *, job: EmrQaJob, job_path: Path) -> None:
        super().__init__(parent)
        self._job = job
        self._job_path = job_path
        self.setWindowTitle(tr("emr.action.edit_job"))
        self.setMinimumWidth(520)

        path_label = QLabel(str(job_path))
        path_label.setWordWrap(True)
        path_label.setObjectName("configHint")

        self._name = QLineEdit(job.name)
        self._description = QTextEdit()
        self._description.setPlainText(job.description or default_job_description(job.mode))

        form = QFormLayout()
        form.addRow(tr("emr.job.metadata.name_label"), self._name)
        form.addRow(tr("emr.job.metadata.description_label"), self._description)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Save).setText(tr("emr.automation.save_job"))
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(path_label)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def _on_save(self) -> None:
        name = self._name.text().strip()
        if not name:
            self._name.setFocus()
            return
        updated = replace(
            self._job,
            name=name,
            description=self._description.toPlainText().strip(),
        )
        try:
            save_job(self._job_path, updated)
        except OSError:
            return
        self.accept()


def edit_job_metadata(parent, job_path: Path) -> bool:
    try:
        job = load_job(job_path)
    except (OSError, ValueError):
        return False
    dialog = JobEditDialog(parent, job=job, job_path=job_path)
    return dialog.exec() == QDialog.DialogCode.Accepted
