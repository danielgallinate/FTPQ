"""Ventana principal EMR QA iteración 2 — local, Abrir/Probar."""
from __future__ import annotations

import re
from dataclasses import replace
from enum import Enum
from pathlib import Path

from PySide6.QtCore import Qt, QThread, QTimer
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFrame,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMenuBar,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSplitter,
    QStackedWidget,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

from core.analysis_types import TabularDataset, is_tabular_extension
from core.analysis_limits import DEFAULT_MAX_DISPLAY_ROWS, resolve_job_display_rows
from core.catalog_store import build_catalog_displays
from core.emr_qa_job import JobMode, JobTimezone, save_job
from core.local_browser import LocalListing, resolve_folder_open, sanitize_browser_path
from core.result import Err, Ok
from core.reference_compare import expand_evaluated_columns_for_reference
from core.timezone_transform import apply_timezone_transform, guess_datetime_columns
from emrqa.template_key_store import TemplateKeyStore
from emrqa.validation_models import ValidationTemplate
from emrqa.validation_storage import knowledge_base_dir
from shell.about_dialog import show_about_dialog
from shell.browser_listing import list_emr_directory
from shell.job_export import build_job_from_session
from shell.job_metadata_dialog import edit_job_metadata, prompt_job_metadata
from shell.job_run_dialog import show_job_run_dialog
from shell.job_run_session import JobRunSession, effective_row_limit_tag
from shell.job_run_worker import JobRunError, JobRunFinished, JobRunWorker
from shell.local_actions_menu import show_emr_file_menu
from shell.messages_panel import MessagesPanel
from shell.menu_bar import apply_emr_menu_translations, populate_emr_menu_bar
from shell.template_key_actions import (
    export_template_key,
    generate_template_key,
    key_status_label,
    load_template_key,
)
from shell.validation_panel import ValidationTab, ValidationPanel
from shell.overlay_snapshot import GridOverlaySnapshot
from shell.qa_metrics import QaMetricsReport, metrics_snapshot_key
from shell.validation_runner import QaHighlightMode
from shell.validation_worker import (
    ValidationJob,
    ValidationJobError,
    ValidationJobResult,
    ValidationPhase,
    ValidationWorker,
)
from ui.app_controller import AppController
from ui.chrome.color_button import ColorButton
from ui.i18n import language_changed, tr
from ui.panels.local_file_panel import LocalFilePanel
from ui.panels.local_file_sort import local_entry_to_row
from ui.shell.analysis_worker import AnalysisWorker
from ui.theme.theme_engine import ThemeEngine, WallpaperHost
from ui.theme.app_icon import apply_app_icon
from ui.theme.icon_store import install_icon, pick_icon_source
from ui.theme.wallpaper_store import install_wallpaper, pick_wallpaper_source, resolve_wallpaper_path
from ui.widgets.data_viewer import DataViewerWidget


class _Screen(str, Enum):
    BROWSER = "browser"
    OPEN = "open"
    PROBAR = "probar"


def _downloads_path() -> Path:
    downloads = Path.home() / "Downloads"
    if downloads.is_dir():
        return downloads.resolve()
    return Path.home().resolve()


def _home_path() -> Path:
    return Path.home().resolve()


def _sanitize_browser_path(path: Path | None) -> Path | None:
    return sanitize_browser_path(path)


def _local_entries_for_ui(listing: LocalListing) -> list[dict]:
    return [local_entry_to_row(entry) for entry in listing.entries]


def _sampled_notice(dataset: TabularDataset) -> str:
    estimated = dataset.estimated_total_rows
    total = (
        tr("emr.msg.sampled_total_estimate", total=f"{estimated:,}")
        if estimated
        else tr("emr.msg.sampled_total_unknown")
    )
    return tr("emr.msg.sampled_file", rows=f"{dataset.total_rows:,}", total=total)


class MainWindow(QMainWindow):
    def __init__(self, *, theme: ThemeEngine) -> None:
        super().__init__()
        self._theme = theme
        self._controller = AppController()
        self._screen = _Screen.BROWSER
        self._browser_path: Path | None = _downloads_path()
        self._pending_file: dict | None = None
        self._pending_mode: _Screen = _Screen.OPEN
        self._dataset: TabularDataset | None = None
        self._raw_dataset: TabularDataset | None = None
        self._current_path: Path | None = None
        self._template: ValidationTemplate | None = None
        self._overlay_passed: set[tuple[int, int]] = set()
        self._overlay_failed: set[tuple[int, int]] = set()
        self._overlay_conflict: set[tuple[int, int]] = set()
        self._overlay_gray: set[tuple[int, int]] = set()
        self._overlay_reference_values: dict[tuple[int, int], str] = {}
        self._overlay_cells_without_reference: set[tuple[int, int]] = set()
        self._overlay_catalog_displays: dict[tuple[int, int], str] = {}
        self._overlay_snapshots: dict[ValidationTab, GridOverlaySnapshot | None] = {
            ValidationTab.REFERENCE: None,
            ValidationTab.QA: None,
            ValidationTab.VALIDATION: None,
            ValidationTab.SCHEMA: None,
        }
        self._metrics_snapshots: dict[str, QaMetricsReport] = {}
        self._analysis_busy = False
        self._max_display_rows = DEFAULT_MAX_DISPLAY_ROWS
        self._validation_busy = False
        self._validation_job_id = 0
        self._job_run_busy = False
        self._pending_job_session: JobRunSession | None = None
        self._pending_row_limit_tag: str | None = None
        self._last_exportable_tab: ValidationTab | None = None
        self._row_dicts_cache_key: tuple[object, ...] | None = None
        self._row_dicts_cache: list[dict[str, object]] | None = None
        self._template_key_store = TemplateKeyStore()

        self.setWindowTitle(tr("emr.app.title"))
        self.resize(1280, 820)

        self._messages = MessagesPanel()
        self._browser = LocalFilePanel(title_key="panel.local_files")
        self._filter_valid_only = QCheckBox()
        self._filter_valid_only.setChecked(True)
        self._filter_valid_only.toggled.connect(lambda _checked: self._refresh_browser())

        self._browser_nav_hint = QLabel()
        self._browser_nav_hint.setObjectName("configHint")
        self._browser_nav_hint.setWordWrap(True)

        self._browser_home_btn = QPushButton()
        self._browser_home_btn.clicked.connect(self._go_browser_home)
        self._browser_downloads_btn = QPushButton()
        self._browser_downloads_btn.clicked.connect(self._go_browser_downloads)

        self._browser_page = QWidget()
        browser_layout = QVBoxLayout(self._browser_page)
        browser_layout.setContentsMargins(0, 0, 0, 0)
        browser_layout.setSpacing(6)
        filter_row = QHBoxLayout()
        filter_row.setContentsMargins(8, 4, 8, 0)
        filter_row.addWidget(self._filter_valid_only)
        filter_row.addWidget(self._browser_home_btn)
        filter_row.addWidget(self._browser_downloads_btn)
        filter_row.addStretch(1)
        browser_layout.addLayout(filter_row)
        browser_layout.addWidget(self._browser_nav_hint)
        browser_layout.addWidget(self._browser, stretch=1)

        self._viewer = DataViewerWidget()
        self._viewer.close_requested.connect(self._close_viewer)
        self._viewer.columns_visibility_changed.connect(self._on_viewer_columns_changed)
        self._viewer.row_add_requested.connect(self._on_viewer_row_add)
        self._viewer.add_all_requested.connect(self._on_viewer_add_all)
        self._viewer.reload_requested.connect(self._reload_with_display_rows)
        self._viewer.timezone_apply_requested.connect(self._apply_timezone_transform)
        self._viewer.catalog_column_requested.connect(self._on_catalog_column_requested)
        self._validation = ValidationPanel(key_store=self._template_key_store)
        self._validation.set_visible_columns_provider(self._visible_column_names_list)
        self._validation.set_marked_rows_provider(self._viewer.marked_source_rows)
        self._validation.set_clear_marks_callback(self._viewer.clear_marked_rows)
        self._validation.set_dataset_path_provider(lambda: self._current_path)
        self._validation.template_changed.connect(self._on_template_changed)
        self._validation.qa_selection_changed.connect(self._schedule_validation)
        self._validation.reference_config_changed.connect(self._on_reference_config_changed)
        self._validation.reference_compare_requested.connect(self._run_reference_compare)
        self._validation.export_reference_job_requested.connect(
            lambda: self._export_automation_job(mode="reference")
        )
        self._validation.export_qa_job_requested.connect(
            lambda: self._export_automation_job(mode="qa")
        )
        self._validation.export_schema_job_requested.connect(
            lambda: self._export_automation_job(mode="schema")
        )
        self._validation.schema_validate_requested.connect(self._run_schema_validation)
        self._validation.tab_changed.connect(self._on_validation_tab_changed)
        self._validation.user_message.connect(self._on_validation_message)

        self._progress_label = QLabel("")
        self._progress_label.setObjectName("panelSubtitle")

        self._open_page = QWidget()
        self._open_layout = QVBoxLayout(self._open_page)
        self._open_layout.setContentsMargins(0, 0, 0, 0)

        self._probar_left = QWidget()
        self._probar_left_layout = QVBoxLayout(self._probar_left)
        self._probar_left_layout.setContentsMargins(0, 0, 0, 0)
        self._probar_left_layout.setSpacing(0)

        self._probar_split = QSplitter(Qt.Orientation.Horizontal)
        self._probar_split.addWidget(self._probar_left)
        self._probar_split.addWidget(self._validation)
        self._probar_split.setStretchFactor(0, 3)
        self._probar_split.setStretchFactor(1, 1)
        self._probar_page = QWidget()
        probar_layout = QVBoxLayout(self._probar_page)
        probar_layout.setContentsMargins(0, 0, 0, 0)
        probar_layout.addWidget(self._probar_split)

        self._stack = QStackedWidget()
        self._stack.addWidget(self._browser_page)
        self._stack.addWidget(self._open_page)
        self._stack.addWidget(self._probar_page)

        self._progress_row = QFrame()
        progress_layout = QHBoxLayout(self._progress_row)
        progress_layout.setContentsMargins(8, 2, 8, 2)
        progress_layout.setSpacing(8)
        progress_layout.addWidget(self._progress_label, stretch=1)
        self._progress_bar = QProgressBar()
        self._progress_bar.setObjectName("emrProgressBar")
        self._progress_bar.setTextVisible(True)
        self._progress_bar.setMinimumWidth(180)
        self._progress_bar.hide()
        progress_layout.addWidget(self._progress_bar)

        self._footer_host = QWidget()
        self._footer_layout = QVBoxLayout(self._footer_host)
        self._footer_layout.setContentsMargins(0, 0, 0, 0)
        self._footer_layout.setSpacing(0)
        self._footer_layout.addWidget(self._progress_row)
        self._footer_layout.addWidget(self._messages)

        self._content = QWidget()
        self._content_layout = QVBoxLayout(self._content)
        self._content_layout.setContentsMargins(0, 0, 0, 0)
        self._content_layout.setSpacing(0)
        self._content_layout.addWidget(self._stack, stretch=1)
        self._content_layout.addWidget(self._footer_host, stretch=0)

        self._host = WallpaperHost(theme, wallpaper_path=resolve_wallpaper_path())
        host_layout = QVBoxLayout(self._host)
        host_layout.setContentsMargins(0, 0, 0, 0)
        host_layout.setSpacing(ThemeEngine.SECTION_GAP)
        host_layout.addWidget(self._content, stretch=1)

        self._shell = QWidget()
        shell_layout = QVBoxLayout(self._shell)
        shell_layout.setContentsMargins(
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
        )
        shell_layout.setSpacing(ThemeEngine.SECTION_GAP)
        self._menu_header = self._build_menu_header()
        shell_layout.addWidget(self._menu_header)
        shell_layout.addWidget(self._host, stretch=1)
        self.setCentralWidget(self._shell)
        self.menuBar().hide()

        self.setStatusBar(QStatusBar())

        self._analysis_thread = QThread(self)
        self._analysis_worker = AnalysisWorker()
        self._analysis_worker.moveToThread(self._analysis_thread)
        self._analysis_worker.analyze_requested.connect(
            self._analysis_worker._do_analyze,
            Qt.ConnectionType.QueuedConnection,
        )
        self._analysis_worker.finished.connect(
            self._on_analysis_finished,
            Qt.ConnectionType.QueuedConnection,
        )
        self._analysis_thread.start()

        self._validation_thread = QThread(self)
        self._validation_worker = ValidationWorker()
        self._validation_worker.moveToThread(self._validation_thread)
        self._validation_worker.validate_requested.connect(
            self._validation_worker._do_validate,
            Qt.ConnectionType.QueuedConnection,
        )
        self._validation_worker.progress.connect(
            self._on_validation_progress,
            Qt.ConnectionType.QueuedConnection,
        )
        self._validation_worker.finished.connect(
            self._on_validation_finished,
            Qt.ConnectionType.QueuedConnection,
        )
        self._validation_thread.start()

        self._job_run_thread = QThread(self)
        self._job_run_worker = JobRunWorker()
        self._job_run_worker.moveToThread(self._job_run_thread)
        self._job_run_worker.run_requested.connect(
            self._job_run_worker._do_run,
            Qt.ConnectionType.QueuedConnection,
        )
        self._job_run_worker.finished.connect(
            self._on_job_run_finished,
            Qt.ConnectionType.QueuedConnection,
        )
        self._job_run_thread.start()

        self._validation_debounce = QTimer(self)
        self._validation_debounce.setSingleShot(True)
        self._validation_debounce.setInterval(350)
        self._validation_debounce.timeout.connect(self._run_validation)

        self._browser.folder_open_requested.connect(self._open_local_folder)
        self._browser.file_actions_requested.connect(self._on_file_actions)

        language_changed().connect(self._retranslate_ui)
        self._retranslate_ui()
        self._refresh_browser()
        self._show_browser()

    def shutdown_workers(self) -> None:
        self._analysis_thread.quit()
        self._analysis_thread.wait(3000)
        self._validation_thread.quit()
        self._validation_thread.wait(3000)
        self._job_run_thread.quit()
        self._job_run_thread.wait(3000)

    def _run_job_from_menu(self) -> None:
        if self._analysis_busy or self._validation_busy or self._job_run_busy:
            self._messages.set_messages([tr("emr.automation.run_busy")])
            return
        session = show_job_run_dialog(self)
        if session is not None:
            self._on_run_job_requested(session)

    def _edit_job_from_menu(self) -> None:
        path_str, _filter = QFileDialog.getOpenFileName(
            self,
            tr("emr.action.edit_job"),
            str(knowledge_base_dir("default") / "jobs"),
            tr("emr.automation.dialog_filter"),
        )
        if not path_str:
            return
        if edit_job_metadata(self, Path(path_str)):
            self._messages.set_messages([tr("emr.job.metadata.saved", path=path_str)])

    def _on_run_job_requested(self, session: JobRunSession) -> None:
        if self._analysis_busy or self._validation_busy or self._job_run_busy:
            self._messages.set_messages([tr("emr.automation.run_busy")])
            return
        if not is_tabular_extension(session.file_path.name):
            self._messages.set_messages(
                [tr("emr.msg.not_tabular", name=session.file_path.name)]
            )
            return
        self._pending_job_session = session
        tag = effective_row_limit_tag(session)
        self._pending_row_limit_tag = tag
        if tag and "%" not in tag:
            cleaned = re.sub(r"[^\d]", "", tag)
            self._max_display_rows = int(cleaned) if cleaned else DEFAULT_MAX_DISPLAY_ROWS
        elif tag:
            self._max_display_rows = 10_000_000
        else:
            self._max_display_rows = DEFAULT_MAX_DISPLAY_ROWS
        resolved_file = session.file_path.resolve()
        need_load = (
            self._current_path != resolved_file
            or self._dataset is None
            or self._screen is not _Screen.PROBAR
        )
        if need_load:
            self._pending_mode = _Screen.PROBAR
            self._current_path = resolved_file
            self._analysis_busy = True
            self.statusBar().showMessage(
                tr("emr.status.loading", name=resolved_file.name)
            )
            self._analysis_worker.analyze_requested.emit(
                str(resolved_file),
                self._max_display_rows,
            )
            return
        self._pending_job_session = None
        self._execute_job_run(session)

    def _execute_job_run(self, session: JobRunSession) -> None:
        self._job_run_busy = True
        self._progress_bar.setRange(0, 0)
        self._progress_bar.show()
        self._progress_label.setText(tr("emr.status.job_running"))
        self.statusBar().showMessage(tr("emr.status.job_running"))
        self._job_run_worker.run_requested.emit(session)

    def _on_job_run_finished(self, payload: object) -> None:
        self._job_run_busy = False
        self._progress_bar.hide()
        self._progress_label.setText("")
        if isinstance(payload, JobRunError):
            self._messages.set_messages(
                [tr("emr.msg.job_run_fail", error=payload.message)]
            )
            self.statusBar().showMessage(tr("emr.status.validation_error"), 5000)
            return
        if not isinstance(payload, JobRunFinished):
            return
        self._apply_job_run_result(payload)

    def _apply_job_run_result(self, finished: JobRunFinished) -> None:
        result = finished.result
        tab = finished.tab
        overlay = result.overlay
        if overlay is None:
            self._messages.set_messages(
                [tr("emr.msg.job_run_fail", error=tr("emr.msg.no_overlay"))]
            )
            return

        if tab == ValidationTab.VALIDATION:
            self._apply_overlay_state(overlay, tab=tab)
            messages = result.messages or [tr("emr.msg.minibase_overlay")]
            self._messages.set_messages(messages)
        elif tab == ValidationTab.REFERENCE:
            report = result.reference_report
            if report is not None:
                self._validation.set_reference_summary_report(report)
            progress = report.headline if report is not None else tr("emr.ref.done")
            self._apply_overlay_state(overlay, tab=tab, progress_label=progress)
            alerts: list[str] = []
            if report is not None:
                alerts.append(report.headline)
                alerts.append(
                    tr(
                        "emr.ref.summary.progress_line",
                        rows=f"{report.rows_matched_key:,}",
                        total=f"{report.rows_compared:,}",
                        ok=f"{report.cells_ok:,}",
                        nok=f"{report.cells_nok:,}",
                    )
                )
            alerts.extend(list(getattr(overlay, "alerts", [])[:15]))
            self._messages.set_messages(alerts or [tr("emr.ref.done")])
        elif tab == ValidationTab.SCHEMA:
            report = result.schema_report
            if report is not None:
                self._validation.set_schema_summary_report(report)
            progress = report.headline if report is not None else tr("emr.schema.done")
            self._apply_overlay_state(overlay, tab=tab, progress_label=progress)
            alerts = list(getattr(overlay, "alerts", [])[:20])
            if report is not None:
                alerts.insert(0, report.headline)
            self._messages.set_messages(alerts or [tr("emr.schema.done")])
        else:
            metrics = result.qa_metrics_report
            if metrics is not None:
                self._validation.set_qa_metrics(metrics)
            progress = tr(
                "emr.progress.validated",
                percent=overlay.percent,
                passed=overlay.passed_count,
                total=overlay.total_count,
            )
            self._apply_overlay_state(overlay, tab=ValidationTab.QA, progress_label=progress)
            alerts = list(getattr(overlay, "alerts", [])[:30])
            if overlay.conflict_cells:
                alerts.insert(0, tr("emr.qa.conflicts", count=len(overlay.conflict_cells)))
            if overlay.rows_with_key_errors:
                alerts.insert(
                    0,
                    tr("emr.msg.key_errors", count=overlay.rows_with_key_errors),
                )
            qa_result = result.qa_validation_result
            if qa_result is not None and len(qa_result.template_overlays) > 1:
                alerts.insert(
                    0,
                    tr(
                        "emr.qa.templates_active",
                        count=len(qa_result.template_overlays),
                    ),
                )
            self._messages.set_messages(alerts or [tr("emr.msg.no_alerts")])

        self._validation.select_tab(tab)
        self._sync_grid_header_sort()
        self._restore_tab_overlay(tab)
        status = tr("emr.msg.job_run_ok") if result.ok else tr("emr.msg.job_run_fail", error="FAIL")
        self.statusBar().showMessage(status, 5000)

    def _build_menu_header(self) -> QWidget:
        bar = QWidget()
        bar.setObjectName("headerBar")

        menu = QMenuBar(bar)
        self._menu_state = populate_emr_menu_bar(
            menu,
            on_run_job=self._run_job_from_menu,
            on_edit_job=self._edit_job_from_menu,
            on_close_file=self._close_viewer,
            on_quit=self.close,
            on_pick_wallpaper=self._pick_wallpaper,
            on_pick_icon=self._pick_icon,
            on_generate_key=self._generate_template_key,
            on_load_key=self._load_template_key,
            on_export_key=self._export_template_key,
            key_status_text=self._template_key_status_text,
            on_about=self._show_about,
            on_language_picked=self._on_language_picked,
        )

        self._color_button = ColorButton(self._toggle_chrome, bar)

        layout = QHBoxLayout(bar)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.addWidget(menu, stretch=1)
        layout.addWidget(self._color_button, stretch=0, alignment=Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        return bar

    def _on_language_picked(self, code: str) -> None:
        self._controller.set_ui_language(code)
        self._retranslate_ui()

    def _template_key_status_text(self) -> str:
        return key_status_label(self._template_key_store)

    def _refresh_key_menu(self) -> None:
        apply_emr_menu_translations(
            self._menu_state,
            key_status_text=self._template_key_status_text,
        )

    def _generate_template_key(self) -> None:
        key_id = generate_template_key(self, self._template_key_store)
        if key_id is None:
            return
        self._refresh_key_menu()
        self._validation.refresh_key_state()
        self._messages.append(tr("emr.key.generate_ok", key_id=key_id))

    def _load_template_key(self) -> None:
        key_id = load_template_key(self, self._template_key_store)
        if key_id is None:
            return
        self._refresh_key_menu()
        self._validation.refresh_key_state()
        self._messages.append(tr("emr.key.load_ok", key_id=key_id))

    def _export_template_key(self) -> None:
        if export_template_key(self, self._template_key_store):
            self._messages.append(tr("emr.key.export_ok"))

    def _resolve_automation_job_mode(self) -> JobMode | None:
        tab = self._validation.active_tab()
        if tab == ValidationTab.REFERENCE:
            return "reference"
        if tab == ValidationTab.QA:
            return "qa"
        if tab == ValidationTab.VALIDATION:
            return "validation"
        if tab == ValidationTab.SCHEMA:
            return "schema"

        if self._last_exportable_tab == ValidationTab.REFERENCE:
            return "reference"
        if self._last_exportable_tab == ValidationTab.QA:
            return "qa"
        if self._last_exportable_tab == ValidationTab.VALIDATION:
            return "validation"
        if self._last_exportable_tab == ValidationTab.SCHEMA:
            return "schema"

        if self._validation.reference_compare_config().is_ready():
            return "reference"
        if self._validation.checked_qa_template_paths():
            return "qa"
        if self._validation.schema_test_ready():
            return "schema"
        if self._validation.template_path is not None:
            return "validation"
        return None

    def _build_automation_job(self, *, mode: JobMode | None = None):
        if self._screen is not _Screen.PROBAR or self._dataset is None:
            raise ValueError(tr("emr.automation.need_probar"))

        resolved_mode = mode or self._resolve_automation_job_mode()
        if resolved_mode is None:
            raise ValueError(tr("emr.automation.need_mode"))

        reference_config = None
        validation_template_path = None
        schema_id = ""
        qa_paths: list[tuple[str, Path]] = []
        job_name = "emr-qa-job"

        if resolved_mode == "reference":
            reference_config = self._validation.reference_compare_config()
            if not reference_config.is_ready():
                raise ValueError(tr("emr.automation.need_reference_config"))
            job_name = "reference-compare"
        elif resolved_mode == "qa":
            qa_paths = self._validation.checked_qa_template_paths()
            if not qa_paths:
                raise ValueError(tr("emr.automation.need_qa_templates"))
            job_name = "qa-run"
        elif resolved_mode == "schema":
            schema_id = self._validation.schema_test_config()
            if not schema_id:
                raise ValueError(tr("emr.automation.need_schema_catalog"))
            job_name = schema_id
        else:
            validation_template_path = self._validation.template_path
            if validation_template_path is None:
                raise ValueError(tr("emr.automation.need_validation_template"))
            active = self._validation.template
            if active is not None:
                job_name = active.header.name or validation_template_path.stem

        tz_config = self._viewer.timezone_config()
        job_timezone = None
        if tz_config.is_active:
            job_timezone = JobTimezone(
                source_tz=tz_config.source_tz,
                target_tz=tz_config.target_tz,
                columns=tuple(sorted(tz_config.columns)),
            )

        return build_job_from_session(
            name=job_name,
            mode=resolved_mode,
            evaluated_columns=self._visible_column_names_list(),
            max_rows=self._max_display_rows,
            reference_config=reference_config,
            left_catalog_bindings=self._validation.left_catalog_bindings(),
            qa_template_paths=qa_paths,
            highlight_discrepancy=self._validation.qa_highlight_discrepancy(),
            validation_template_path=validation_template_path,
            schema_id=schema_id,
            timezone=job_timezone,
        )

    def _export_automation_job(self, *, mode: JobMode) -> None:
        try:
            job = self._build_automation_job(mode=mode)
        except ValueError as exc:
            self._messages.set_messages([str(exc)])
            return

        reference_path = None
        if mode == "reference":
            config = self._validation.reference_compare_config()
            if config.is_ready():
                reference_path = config.reference_path

        metadata = prompt_job_metadata(
            self,
            mode=mode,
            job_name=job.name,
            current_file=self._current_path,
            current_reference=reference_path,
        )
        if metadata is None:
            self._messages.set_messages([tr("emr.automation.export_cancelled")])
            return

        job = replace(job, name=metadata.name, description=metadata.description)
        if metadata.include_file and self._current_path is not None:
            job = replace(job, file=str(self._current_path.resolve()))
        if metadata.include_reference and reference_path is not None:
            job = replace(job, reference_file=str(reference_path.resolve()))

        jobs_dir = knowledge_base_dir("default") / "jobs"
        jobs_dir.mkdir(parents=True, exist_ok=True)
        default_name = f"{job.name}.job.json".replace("/", "-")
        path_str, _filter = QFileDialog.getSaveFileName(
            self,
            tr("emr.automation.dialog_title"),
            str(jobs_dir / default_name),
            tr("emr.automation.dialog_filter"),
        )
        if not path_str:
            self._messages.set_messages([tr("emr.automation.export_cancelled")])
            return
        job_path = Path(path_str)
        try:
            save_job(job_path, job)
        except OSError as exc:
            self._messages.set_messages([tr("emr.automation.export_fail", error=exc)])
            return

        self._messages.set_messages(
            [
                tr("emr.automation.export_ok", path=job_path),
                tr("emr.automation.export_saved_hint", path=job_path.parent),
            ]
        )
        self._validation.select_automation_job(job_path)

    def _retranslate_ui(self) -> None:
        apply_emr_menu_translations(
            self._menu_state,
            key_status_text=self._template_key_status_text,
        )
        self.setWindowTitle(tr("emr.app.title"))
        self._color_button.retranslate_ui()
        self._filter_valid_only.setText(tr("emr.filter.valid_only"))
        self._browser_nav_hint.setText(tr("emr.browser.nav_hint"))
        self._browser_home_btn.setText(tr("emr.browser.go_home"))
        self._browser_downloads_btn.setText(tr("emr.browser.go_downloads"))
        self._browser.retranslate_ui()
        self._viewer.retranslate_ui()
        self._validation.retranslate_ui()
        self._messages.retranslate_ui()
        if self._screen is _Screen.PROBAR:
            self._run_validation()

    def _toggle_chrome(self) -> None:
        self._theme.toggle_chrome()
        self._host.refresh_scrim()
        self.statusBar().showMessage(self._theme.mode_label(), 2500)

    def _show_about(self) -> None:
        show_about_dialog(self)

    def _pick_wallpaper(self) -> None:
        source = pick_wallpaper_source(self)
        if source is None:
            return
        try:
            installed = install_wallpaper(source)
        except OSError as exc:
            self._messages.append(tr("emr.msg.wallpaper_fail", error=exc))
            return
        self._host.set_wallpaper(installed)
        self._host.refresh_scrim()
        self._messages.append(tr("emr.msg.wallpaper_ok", name=installed.name))

    def _pick_icon(self) -> None:
        source = pick_icon_source(self)
        if source is None:
            return
        try:
            installed = install_icon(source)
        except (OSError, ValueError) as exc:
            self._messages.append(tr("emr.msg.icon_fail", error=exc))
            return
        app = QApplication.instance()
        if app is not None:
            apply_app_icon(app)
        self._messages.append(tr("emr.msg.icon_ok", name=installed.name))

    def _attach_footer_global(self) -> None:
        if self._footer_host.parentWidget() is self._content:
            return
        if self._footer_host.parentWidget() is self._probar_left:
            self._probar_left_layout.removeWidget(self._footer_host)
        self._footer_host.setParent(None)
        self._content_layout.addWidget(self._footer_host, stretch=0)

    def _attach_footer_probar(self) -> None:
        if self._footer_host.parentWidget() is self._probar_left:
            return
        if self._footer_host.parentWidget() is self._content:
            self._content_layout.removeWidget(self._footer_host)
        self._footer_host.setParent(None)
        self._probar_left_layout.addWidget(self._footer_host, stretch=0)

    def _detach_viewer(self) -> None:
        self._validation.set_view_sidebar(None)
        self._viewer.set_sidebar_embedded(True)
        if self._viewer.parentWidget() is self._open_page:
            self._open_layout.removeWidget(self._viewer)
        if self._probar_left_layout.indexOf(self._viewer) >= 0:
            self._probar_left_layout.removeWidget(self._viewer)
        self._viewer.setParent(None)
        self._viewer.hide()
        self._attach_footer_global()

    def _mount_viewer_open(self) -> None:
        self._detach_viewer()
        self._open_layout.addWidget(self._viewer)
        self._viewer.show()

    def _mount_viewer_probar(self) -> None:
        self._detach_viewer()
        self._viewer.set_sidebar_embedded(False)
        self._validation.set_view_sidebar(self._viewer.sidebar_widget())
        self._probar_left_layout.insertWidget(0, self._viewer, stretch=1)
        self._attach_footer_probar()
        self._sync_catalog_column_menu()
        self._viewer.show()

    def _show_browser(self) -> None:
        self._screen = _Screen.BROWSER
        self._detach_viewer()
        self._stack.setCurrentWidget(self._browser_page)
        self._progress_label.setText("")
        self._viewer.clear_validation_overlay()

    def _refresh_browser(self) -> None:
        self._browser_path = _sanitize_browser_path(self._browser_path)
        listing = list_emr_directory(
            self._browser_path,
            valid_files_only=self._filter_valid_only.isChecked(),
        )
        self._browser.set_path(listing.display_path)
        self._browser.set_entries(_local_entries_for_ui(listing))

    def _go_browser_home(self) -> None:
        self._browser_path = _home_path()
        self._refresh_browser()

    def _go_browser_downloads(self) -> None:
        self._browser_path = _downloads_path()
        self._refresh_browser()

    def _open_local_folder(self, folder_name: str) -> None:
        token = folder_name.rstrip("/") or ".."
        if self._browser_path is None and token == "..":
            self._refresh_browser()
            return
        next_path = resolve_folder_open(self._browser_path, token)
        if next_path is None and token != "..":
            return
        self._browser_path = _sanitize_browser_path(next_path)
        self._refresh_browser()

    def _on_file_actions(self, payload: dict) -> None:
        self._pending_file = payload
        show_emr_file_menu(
            self,
            payload["global_pos"],
            on_open=lambda: self._open_file(_Screen.OPEN),
            on_probe=lambda: self._open_file(_Screen.PROBAR),
        )

    def _open_file(self, mode: _Screen) -> None:
        if self._pending_file is None or self._analysis_busy:
            return
        raw = self._pending_file.get("absolute_path", "")
        if not raw:
            return
        path = Path(raw)
        if not path.is_file():
            return
        if not is_tabular_extension(path.name):
            self._messages.set_messages([tr("emr.msg.not_tabular", name=path.name)])
            return
        self._pending_mode = mode
        self._current_path = path
        self._max_display_rows = DEFAULT_MAX_DISPLAY_ROWS
        self._analysis_busy = True
        self.statusBar().showMessage(tr("emr.status.loading", name=path.name))
        self._analysis_worker.analyze_requested.emit(str(path), self._max_display_rows)

    def _reload_with_display_rows(self, limit: int) -> None:
        if self._current_path is None or self._analysis_busy:
            return
        self._max_display_rows = limit
        self._analysis_busy = True
        self.statusBar().showMessage(
            tr("emr.status.loading", name=self._current_path.name)
        )
        self._analysis_worker.analyze_requested.emit(
            str(self._current_path),
            self._max_display_rows,
        )

    def _on_analysis_finished(self, result) -> None:
        self._analysis_busy = False
        self.statusBar().clearMessage()
        if isinstance(result, Err):
            message = str(result.error)
            self._messages.set_messages([tr("emr.msg.open_error", error=message)])
            self._pending_job_session = None
            self._pending_row_limit_tag = None
            return
        if not isinstance(result, Ok):
            self._pending_job_session = None
            self._pending_row_limit_tag = None
            return
        dataset = result.value
        if self._pending_row_limit_tag and self._pending_job_session is not None:
            limit = resolve_job_display_rows(
                row_limit=self._pending_row_limit_tag,
                max_rows=self._pending_job_session.base_job.max_rows,
                total_rows=dataset.total_rows,
            )
            if limit < len(dataset.rows):
                from core.analysis_types import TabularDataset

                dataset = TabularDataset(
                    local_path=dataset.local_path,
                    columns=dataset.columns,
                    rows=dataset.rows[:limit],
                    total_rows=dataset.total_rows,
                    display_truncated=True,
                    sampled=dataset.sampled,
                    estimated_total_rows=dataset.estimated_total_rows,
                )
        self._present_dataset(dataset)
        pending_job = self._pending_job_session
        if pending_job is not None:
            self._pending_job_session = None
            self._pending_row_limit_tag = None
            self._execute_job_run(pending_job)

    def _effective_dataset(self) -> TabularDataset | None:
        if self._raw_dataset is None:
            return None
        config = self._viewer.timezone_config()
        if not config.is_active:
            return self._raw_dataset
        return apply_timezone_transform(self._raw_dataset, config)

    def _apply_timezone_transform(self) -> None:
        if self._raw_dataset is None:
            return
        display = self._effective_dataset()
        if display is None:
            return
        self._dataset = display
        self._row_dicts_cache_key = None
        self._row_dicts_cache = None
        self._viewer.refresh_dataset_values(display)
        self._validation.set_dataset(display)
        config = self._viewer.timezone_config()
        if config.is_active:
            self._messages.append(
                tr(
                    "viewer.timezone.applied",
                    source=config.source_tz,
                    target=config.target_tz,
                    count=len(config.columns),
                )
            )
        else:
            self._messages.append(tr("viewer.timezone.cleared"))
        self._run_validation()

    def _present_dataset(self, dataset: TabularDataset) -> None:
        previous = self._viewer.timezone_config()
        had_dataset = self._raw_dataset is not None
        self._raw_dataset = dataset
        path = dataset.local_path
        self._row_dicts_cache_key = None
        self._row_dicts_cache = None
        self._viewer.load(dataset, filename=path.name)
        column_names = [column.name for column in dataset.columns]
        suggested = guess_datetime_columns(dataset)
        if had_dataset and previous.columns:
            selected = {name for name in previous.columns if name in column_names}
        else:
            selected = set()
        self._viewer.setup_timezone_columns(
            column_names,
            suggested=suggested,
            selected=selected,
        )
        display = self._effective_dataset() or dataset
        self._dataset = display
        if display is not dataset:
            self._viewer.refresh_dataset_values(display)
        self._viewer.configure_load_limits(
            total_rows=dataset.estimated_total_rows or dataset.total_rows,
            column_count=len(dataset.columns),
            current_limit=self._max_display_rows,
        )
        self._validation.set_dataset(display)
        self._messages.clear_messages()
        if dataset.sampled:
            self._messages.append(_sampled_notice(dataset))

        if self._pending_mode is _Screen.PROBAR:
            self._screen = _Screen.PROBAR
            self._mount_viewer_probar()
            self._stack.setCurrentWidget(self._probar_page)
            self._validation.ensure_template_selected()
            self._sync_grid_header_sort()
            self._sync_catalog_column_menu()
            self._refresh_catalog_displays()
            self._run_validation()
        else:
            self._screen = _Screen.OPEN
            self._viewer.clear_validation_overlay()
            self._mount_viewer_open()
            self._stack.setCurrentWidget(self._open_page)
            self._progress_label.setText("")

    def _on_template_changed(self, template: ValidationTemplate | None) -> None:
        self._template = template
        if template is not None and self._dataset is not None:
            selected = set(template.header.evaluation.columns)
            if not selected:
                selected = {column.name for column in self._dataset.columns}
            self._viewer.sync_column_selection_by_name(selected)
            self._validation.sync_visible_columns()
        self._sync_build_mode()
        self._run_validation()

    def _sync_grid_header_sort(self) -> None:
        tab = self._validation.active_tab()
        self._viewer.set_qa_header_sort(
            tab in (ValidationTab.QA, ValidationTab.REFERENCE, ValidationTab.SCHEMA)
        )

    def _on_reference_config_changed(self) -> None:
        if self._screen is not _Screen.PROBAR:
            return
        if self._validation.active_tab() != ValidationTab.REFERENCE:
            return
        config = self._validation.reference_compare_config()
        if config.is_ready():
            self._validation.set_reference_summary_idle_hint()
        else:
            self._validation.set_reference_summary_idle_hint()
            if self._dataset is not None:
                self._messages.set_messages([tr("emr.ref.config_pending")])

    def _on_validation_tab_changed(self) -> None:
        self._sync_build_mode()
        self._sync_grid_header_sort()
        tab = self._validation.active_tab()
        if tab in (ValidationTab.REFERENCE, ValidationTab.QA, ValidationTab.VALIDATION, ValidationTab.SCHEMA):
            self._last_exportable_tab = tab

        if tab == ValidationTab.REFERENCE:
            config = self._validation.reference_compare_config()
            if not config.is_ready():
                self._clear_grid_overlay_only()
                self._messages.set_messages([tr("emr.ref.need_config")])
            elif self._overlay_snapshots.get(ValidationTab.REFERENCE) is not None:
                self._restore_tab_overlay(ValidationTab.REFERENCE)
            else:
                self._run_reference_compare()
            return

        if tab == ValidationTab.QA:
            snapshot = self._overlay_snapshots.get(ValidationTab.QA)
            if snapshot is not None:
                self._restore_tab_overlay(ValidationTab.QA)
            else:
                self._run_validation()
            return

        if tab == ValidationTab.VALIDATION:
            snapshot = self._overlay_snapshots.get(ValidationTab.VALIDATION)
            if snapshot is not None:
                self._restore_tab_overlay(ValidationTab.VALIDATION)
            else:
                self._run_validation()
            return

        if tab == ValidationTab.SCHEMA:
            self._validation.reload_schema_catalogs()
            if not self._validation.schema_test_ready():
                self._clear_grid_overlay_only()
                self._validation.set_schema_summary_idle()
                self._messages.set_messages([tr("emr.schema.need_config")])
            elif self._overlay_snapshots.get(ValidationTab.SCHEMA) is not None:
                self._restore_tab_overlay(ValidationTab.SCHEMA)
            else:
                self._validation.set_schema_summary_idle()
            return

        if tab == ValidationTab.AUTOMATION:
            self._clear_grid_overlay_only()
            return

        self._clear_grid_overlay_only()
        if tab in (ValidationTab.VIEW, ValidationTab.TEMPLATE_EDIT, ValidationTab.CATALOG, ValidationTab.SCHEMA_EDIT):
            if tab == ValidationTab.SCHEMA_EDIT:
                self._validation.reload_schema_catalogs()
            self._validation.clear_qa_metrics()
            self._messages.set_messages([tr("emr.msg.no_validation_tab")])

    def _run_schema_validation(self) -> None:
        if self._screen is not _Screen.PROBAR or self._dataset is None:
            return
        if self._validation.active_tab() != ValidationTab.SCHEMA:
            return
        schema_id = self._validation.schema_test_config()
        if not schema_id:
            self._validation.set_schema_summary_idle()
            self._clear_validation_ui(tr("emr.schema.need_config"))
            return
        evaluated = self._evaluated_column_names()
        # La prueba juzga el archivo: nunca los valores convertidos de zona horaria.
        source = self._raw_dataset or self._dataset
        name_to_index = {column.name: idx for idx, column in enumerate(source.columns)}
        file_name = self._current_path.name if self._current_path else tr("emr.qa.metrics.unknown_file")
        job = ValidationJob(
            job_id=self._next_validation_job_id(),
            tab=ValidationTab.SCHEMA,
            dataset=source,
            evaluated_columns=evaluated,
            name_to_index=name_to_index,
            schema_id=schema_id,
            file_name=file_name,
            cached_rows=self._cached_row_dicts() if source is self._dataset else None,
        )
        self._validation.set_schema_summary_running()
        self._start_validation_job(job)

    def _run_reference_compare(self) -> None:
        if self._screen is not _Screen.PROBAR or self._dataset is None:
            return
        if self._validation.active_tab() != ValidationTab.REFERENCE:
            return
        config = self._validation.reference_compare_config()
        if not config.is_ready():
            self._validation.set_reference_summary_idle_hint()
            self._clear_validation_ui(tr("emr.ref.need_config"))
            return
        evaluated = self._evaluated_column_names()
        evaluated = expand_evaluated_columns_for_reference(evaluated, config)
        name_to_index = {column.name: idx for idx, column in enumerate(self._dataset.columns)}
        file_name = self._current_path.name if self._current_path else tr("emr.qa.metrics.unknown_file")
        job = ValidationJob(
            job_id=self._next_validation_job_id(),
            tab=ValidationTab.REFERENCE,
            dataset=self._dataset,
            evaluated_columns=evaluated,
            name_to_index=name_to_index,
            reference_config=config,
            file_name=file_name,
            cached_rows=self._cached_row_dicts(),
        )
        self._validation.set_reference_summary_running()
        self._start_validation_job(job)

    def _sync_build_mode(self) -> None:
        if self._screen is not _Screen.PROBAR:
            self._viewer.set_build_mode(False)
            return
        populate = (
            self._validation.is_populate_mode()
            and self._validation.active_tab() == ValidationTab.VALIDATION
        )
        key_columns = self._validation.primary_key_column_names() if populate else None
        self._viewer.set_build_mode(populate, key_column_names=key_columns)

    def _visible_column_names_list(self) -> list[str]:
        if self._dataset is None:
            return []
        return [
            self._dataset.columns[index].name
            for index in self._viewer.visible_column_indices()
            if index < len(self._dataset.columns)
        ]

    def _on_validation_message(self, message: str) -> None:
        self._messages.set_messages([message])

    def _on_viewer_columns_changed(self) -> None:
        if self._screen is not _Screen.PROBAR:
            return
        self._validation.sync_visible_columns()
        tab = self._validation.active_tab()
        if tab == ValidationTab.REFERENCE:
            self._run_reference_compare()
        elif tab in (ValidationTab.QA, ValidationTab.VALIDATION):
            self._run_validation()
        elif tab == ValidationTab.SCHEMA and self._validation.schema_test_ready():
            self._run_schema_validation()

    def _evaluated_column_names(self) -> set[str]:
        if self._dataset is None:
            return set()
        return {
            self._dataset.columns[index].name
            for index in self._viewer.visible_column_indices()
            if index < len(self._dataset.columns)
        }

    def _on_viewer_row_add(self, view_row: int) -> None:
        source_row = self._viewer.source_row_at_view_row(view_row)
        if source_row is None:
            return
        self._validation.add_source_rows({source_row})

    def _on_viewer_add_all(self) -> None:
        marked = self._viewer.marked_source_rows()
        if marked:
            self._validation.add_source_rows(marked)
            return
        self._validation.add_source_rows(self._viewer.all_visible_source_rows())

    def _reference_cell_tooltips(self) -> dict[tuple[int, int], str]:
        if self._dataset is None:
            return {}
        tooltips: dict[tuple[int, int], str] = {}
        for coord in self._overlay_cells_without_reference:
            row_index, col_index = coord
            if row_index >= len(self._dataset.rows):
                continue
            row = self._dataset.rows[row_index]
            file_value = row[col_index] if col_index < len(row) else ""
            tooltips[coord] = tr(
                "emr.ref.cell_tooltip_no_match",
                file=file_value or "—",
            )
        for coord, reference_value in self._overlay_reference_values.items():
            row_index, col_index = coord
            if row_index >= len(self._dataset.rows):
                continue
            row = self._dataset.rows[row_index]
            file_value = row[col_index] if col_index < len(row) else ""
            catalog_value = self._overlay_catalog_displays.get(coord, "")
            if catalog_value:
                tooltips[coord] = tr(
                    "emr.catalog.cell_tooltip_diff",
                    file=file_value or "—",
                    catalog=catalog_value,
                    reference=reference_value or "—",
                )
            else:
                tooltips[coord] = tr(
                    "emr.ref.cell_tooltip_diff",
                    file=file_value or "—",
                    reference=reference_value or "—",
                )
        for coord, catalog_value in self._overlay_catalog_displays.items():
            if coord in tooltips:
                continue
            row_index, col_index = coord
            if row_index >= len(self._dataset.rows):
                continue
            row = self._dataset.rows[row_index]
            file_value = row[col_index] if col_index < len(row) else ""
            tooltips[coord] = tr(
                "emr.catalog.cell_tooltip",
                file=file_value or "—",
                catalog=catalog_value or "—",
            )
        return tooltips

    def _on_catalog_column_requested(self, column_name: str) -> None:
        if self._screen is not _Screen.PROBAR:
            return
        from shell.catalog_column_dialog import CatalogColumnDialog

        dialog = CatalogColumnDialog(
            column_name=column_name,
            binding=self._validation.left_catalog_binding(column_name),
            parent=self,
        )
        result = dialog.exec()
        if result == 0:
            return
        binding = dialog.result_binding()
        if result == 2 or binding is None:
            self._validation.set_left_catalog_binding(column_name, None)
            self._messages.set_messages([tr("emr.catalog.binding_cleared", column=column_name)])
        else:
            self._validation.set_left_catalog_binding(column_name, binding)
            self._messages.set_messages(
                [tr("emr.catalog.binding_saved", column=column_name, catalog=binding.catalog_id)]
            )
        if self._validation.active_tab() == ValidationTab.REFERENCE:
            config = self._validation.reference_compare_config()
            if config.is_ready():
                self._run_reference_compare()
        self._refresh_catalog_displays()

    def _refresh_catalog_displays(self) -> None:
        if self._screen is not _Screen.PROBAR or self._dataset is None:
            self._viewer.clear_catalog_displays()
            return
        bindings = self._validation.left_catalog_bindings()
        if not bindings:
            self._viewer.clear_catalog_displays()
            return
        name_to_index = {
            column.name: index for index, column in enumerate(self._dataset.columns)
        }
        displays, misses = build_catalog_displays(
            self._dataset.rows,
            bindings,
            name_to_index,
            miss_label=tr("emr.catalog.miss_marker"),
        )
        bound_columns = {
            name_to_index[name] for name in bindings if name in name_to_index
        }
        self._viewer.apply_catalog_displays(displays, misses, bound_columns)

    def _sync_catalog_column_menu(self) -> None:
        enabled = self._screen is _Screen.PROBAR and self._dataset is not None
        self._viewer.set_catalog_column_menu_enabled(enabled)

    def _apply_evaluation_ui(self) -> None:
        if self._screen is not _Screen.PROBAR or self._dataset is None:
            return
        tab = self._validation.active_tab()
        evaluated = self._evaluated_column_names()
        if tab == ValidationTab.REFERENCE:
            config = self._validation.reference_compare_config()
            if config.is_ready():
                evaluated = expand_evaluated_columns_for_reference(evaluated, config)
        tooltips = (
            self._reference_cell_tooltips()
            if tab == ValidationTab.REFERENCE
            else {}
        )
        self._viewer.apply_validation_overlay(
            evaluated_columns=evaluated,
            passed_cells=self._overlay_passed,
            failed_cells=self._overlay_failed,
            conflict_cells=self._overlay_conflict,
            gray_cells=self._overlay_gray,
            gray_unevaluated=False,
            cell_tooltips=tooltips,
        )

    def _clear_grid_overlay_only(self) -> None:
        self._overlay_passed = set()
        self._overlay_failed = set()
        self._overlay_conflict = set()
        self._overlay_gray = set()
        self._overlay_reference_values = {}
        self._overlay_cells_without_reference = set()
        self._viewer.clear_validation_overlay()

    def _save_overlay_snapshot(
        self,
        tab: ValidationTab,
        overlay,
        *,
        progress_label: str = "",
    ) -> None:
        self._overlay_snapshots[tab] = GridOverlaySnapshot.from_overlay(
            overlay,
            progress_label=progress_label,
        )

    def _restore_tab_overlay(self, tab: ValidationTab) -> None:
        snapshot = self._overlay_snapshots.get(tab)
        if snapshot is None or snapshot.is_empty():
            self._clear_grid_overlay_only()
            return
        self._overlay_passed = set(snapshot.passed)
        self._overlay_failed = set(snapshot.failed)
        self._overlay_conflict = set(snapshot.conflict)
        self._overlay_gray = set(snapshot.gray)
        self._overlay_reference_values = dict(snapshot.reference_values)
        self._overlay_cells_without_reference = set(snapshot.cells_without_reference)
        self._overlay_catalog_displays = dict(snapshot.catalog_displays)
        self._apply_evaluation_ui()
        if snapshot.progress_label:
            self._progress_label.setText(snapshot.progress_label)

    def _clear_validation_ui(self, message: str) -> None:
        self._clear_grid_overlay_only()
        self._progress_bar.hide()
        self._progress_label.setText("")
        self._messages.set_messages([message])

    def _apply_overlay_state(
        self,
        overlay,
        *,
        tab: ValidationTab,
        progress_label: str = "",
    ) -> None:
        label = progress_label or tr(
            "emr.progress.validated",
            percent=overlay.percent,
            passed=overlay.passed_count,
            total=overlay.total_count,
        )
        self._overlay_passed = overlay.passed_cells
        self._overlay_failed = overlay.failed_cells
        self._overlay_conflict = getattr(overlay, "conflict_cells", set()) or set()
        self._overlay_gray = getattr(overlay, "gray_cells", set()) or set()
        self._overlay_reference_values = dict(
            getattr(overlay, "cell_reference_values", {}) or {}
        )
        self._overlay_cells_without_reference = set(
            getattr(overlay, "cells_without_reference", set()) or set()
        )
        self._overlay_catalog_displays = dict(
            getattr(overlay, "cell_catalog_displays", {}) or {}
        )
        self._save_overlay_snapshot(tab, overlay, progress_label=label)
        if self._validation.active_tab() == tab:
            self._apply_evaluation_ui()
            self._progress_label.setText(label)

    def _schedule_validation(self) -> None:
        self._validation_debounce.start()

    def _row_dicts_cache_token(self) -> tuple[object, ...] | None:
        if self._dataset is None or self._current_path is None:
            return None
        return (
            str(self._current_path),
            len(self._dataset.rows),
            len(self._dataset.columns),
            self._max_display_rows,
        )

    def _cached_row_dicts(self) -> list[dict[str, object]] | None:
        token = self._row_dicts_cache_token()
        if token is None or token != self._row_dicts_cache_key:
            return None
        return self._row_dicts_cache

    def _store_row_dicts_cache(self, rows: list[dict[str, object]] | None) -> None:
        if rows is None:
            return
        token = self._row_dicts_cache_token()
        if token is None:
            return
        self._row_dicts_cache_key = token
        self._row_dicts_cache = rows

    def _run_validation(self) -> None:
        if self._screen is not _Screen.PROBAR or self._dataset is None:
            return

        tab = self._validation.active_tab()
        evaluated = self._evaluated_column_names()
        name_to_index = {column.name: idx for idx, column in enumerate(self._dataset.columns)}

        if tab == ValidationTab.AUTOMATION:
            return

        if tab in (
            ValidationTab.VIEW,
            ValidationTab.TEMPLATE_EDIT,
            ValidationTab.CATALOG,
            ValidationTab.SCHEMA_EDIT,
        ):
            self._clear_validation_ui(tr("emr.msg.no_validation_tab"))
            self._validation.clear_qa_metrics()
            return

        if tab in (ValidationTab.REFERENCE, ValidationTab.SCHEMA):
            return

        if tab == ValidationTab.VALIDATION:
            self._validation.clear_qa_metrics()
            active = self._validation.template
            if active is None:
                self._clear_validation_ui(tr("emr.msg.pick_template"))
                return
            if self._validation.is_minibase_empty():
                self._clear_validation_ui(tr("emr.msg.build_mode"))
                return
            job = ValidationJob(
                job_id=self._next_validation_job_id(),
                tab=tab,
                dataset=self._dataset,
                evaluated_columns=evaluated,
                name_to_index=name_to_index,
                template=active,
                cached_rows=self._cached_row_dicts(),
                key_store=self._template_key_store,
            )
            self._start_validation_job(job)
            return

        templates_paths = self._validation.checked_qa_template_paths()
        if not templates_paths:
            self._clear_validation_ui(tr("emr.msg.qa_pick_templates"))
            self._validation.clear_qa_metrics()
            return

        highlight_mode = (
            QaHighlightMode.DISCREPANCY
            if self._validation.qa_highlight_discrepancy()
            else QaHighlightMode.FAIL_ANY
        )
        file_name = self._current_path.name if self._current_path else tr("emr.qa.metrics.unknown_file")
        visible = self._visible_column_names_list()
        snapshot_key = metrics_snapshot_key(
            file_name,
            [template_id for template_id, _path in templates_paths],
        )
        job = ValidationJob(
            job_id=self._next_validation_job_id(),
            tab=tab,
            dataset=self._dataset,
            evaluated_columns=evaluated,
            name_to_index=name_to_index,
            qa_template_paths=templates_paths,
            highlight_mode=highlight_mode,
            file_name=file_name,
            visible_columns=visible,
            snapshot_key=snapshot_key,
            previous_metrics=self._metrics_snapshots.get(snapshot_key),
            cached_rows=self._cached_row_dicts(),
            key_store=self._template_key_store,
        )
        self._start_validation_job(job)

    def _next_validation_job_id(self) -> int:
        self._validation_job_id += 1
        return self._validation_job_id

    def _start_validation_job(self, job: ValidationJob) -> None:
        self._validation_busy = True
        row_count = len(job.dataset.rows)
        total_rows = max(row_count, 1)
        self._progress_bar.setRange(0, total_rows)
        self._progress_bar.setValue(0)
        self._progress_bar.show()
        self._progress_label.setText(
            tr(
                "emr.progress.validating_start",
                rows=f"{row_count:,}",
            )
        )
        self.statusBar().showMessage(
            tr("emr.status.validating", rows=f"{row_count:,}")
        )
        self._validation_worker.validate_requested.emit(job)

    def _on_validation_progress(
        self,
        phase: str,
        current: int,
        total: int,
        detail: str,
    ) -> None:
        if not self._validation_busy:
            return

        if phase == ValidationPhase.PREPARE.value and total > 0:
            self._progress_bar.setRange(0, total)
            self._progress_bar.setValue(current)
            pct = int((100 * current) / total)
            label = tr(
                "emr.progress.validating_prepare_rows",
                current=f"{current:,}",
                total=f"{total:,}",
                pct=pct,
            )
            self._progress_label.setText(label)
            self.statusBar().showMessage(label)
            return

        if phase == ValidationPhase.LOAD_TEMPLATES.value and total > 0:
            self._progress_bar.setRange(0, total)
            self._progress_bar.setValue(current)
            label = tr(
                "emr.progress.validating_load_template",
                current=current,
                total=total,
                name=detail or "—",
            )
            self._progress_label.setText(label)
            self.statusBar().showMessage(label)
            return

        if phase == ValidationPhase.TEMPLATE.value and total > 0:
            self._progress_bar.setRange(0, total)
            self._progress_bar.setValue(current)
            label = tr(
                "emr.progress.validating_template",
                current=current,
                total=total,
                name=detail or "—",
            )
            self._progress_label.setText(label)
            self.statusBar().showMessage(label)
            return

        if phase == ValidationPhase.ROWS.value and total > 0:
            self._progress_bar.setRange(0, total)
            self._progress_bar.setValue(current)
            pct = int((100 * current) / total)
            if detail:
                label = tr(
                    "emr.progress.validating_rows_named",
                    current=f"{current:,}",
                    total=f"{total:,}",
                    pct=pct,
                    name=detail,
                )
            else:
                label = tr(
                    "emr.progress.validating_rows",
                    current=f"{current:,}",
                    total=f"{total:,}",
                    pct=pct,
                )
            self._progress_label.setText(label)
            self.statusBar().showMessage(label)
            return

        if phase == ValidationPhase.METRICS.value:
            self._progress_bar.setRange(0, 1)
            self._progress_bar.setValue(current)
            label = tr("emr.progress.validating_metrics")
            self._progress_label.setText(label)
            self.statusBar().showMessage(label)

    def _on_validation_finished(self, payload: object) -> None:
        if isinstance(payload, ValidationJobError):
            if payload.job_id != self._validation_job_id:
                return
            self._validation_busy = False
            self._progress_bar.hide()
            self._progress_label.setText("")
            self.statusBar().showMessage(tr("emr.status.validation_error"), 5000)
            if self._validation.active_tab() == ValidationTab.REFERENCE:
                self._validation.set_reference_summary_error(payload.message)
            elif self._validation.active_tab() == ValidationTab.SCHEMA:
                self._validation.set_schema_summary_error(payload.message)
            self._messages.set_messages(
                [tr("emr.msg.validation_error", error=payload.message)]
            )
            return

        if not isinstance(payload, ValidationJobResult):
            return
        if payload.job_id != self._validation_job_id:
            return

        self._validation_busy = False
        self._progress_bar.hide()
        self._store_row_dicts_cache(payload.row_dicts)
        overlay = payload.overlay

        if payload.tab == ValidationTab.VALIDATION:
            self._apply_overlay_state(overlay, tab=payload.tab)
            messages = payload.messages or [tr("emr.msg.minibase_overlay")]
            self._messages.set_messages(messages)
            self.statusBar().showMessage(tr("emr.status.validation_done"), 4000)
            return

        if payload.tab == ValidationTab.REFERENCE:
            report = payload.reference_report
            if report is not None:
                self._validation.set_reference_summary_report(report)
            progress = report.headline if report is not None else tr("emr.ref.done")
            self._apply_overlay_state(overlay, tab=payload.tab, progress_label=progress)
            alerts: list[str] = []
            if report is not None:
                alerts.append(report.headline)
                alerts.append(
                    tr(
                        "emr.ref.summary.progress_line",
                        rows=f"{report.rows_matched_key:,}",
                        total=f"{report.rows_compared:,}",
                        ok=f"{report.cells_ok:,}",
                        nok=f"{report.cells_nok:,}",
                    )
                )
            alerts.extend(list(getattr(overlay, "alerts", [])[:15]))
            self._messages.set_messages(alerts or [tr("emr.ref.done")])
            self.statusBar().showMessage(tr("emr.status.validation_done"), 4000)
            return

        if payload.tab == ValidationTab.SCHEMA:
            report = payload.schema_report
            if report is not None:
                self._validation.set_schema_summary_report(report)
            progress = report.headline if report is not None else tr("emr.schema.done")
            self._apply_overlay_state(overlay, tab=payload.tab, progress_label=progress)
            alerts = list(getattr(overlay, "alerts", [])[:20])
            if report is not None:
                alerts.insert(0, report.headline)
            self._messages.set_messages(alerts or [tr("emr.schema.done")])
            self.statusBar().showMessage(tr("emr.status.validation_done"), 4000)
            return

        if payload.metrics is not None:
            self._metrics_snapshots[payload.snapshot_key] = payload.metrics
            self._validation.set_qa_metrics(payload.metrics)

        progress = tr(
            "emr.progress.validated",
            percent=overlay.percent,
            passed=overlay.passed_count,
            total=overlay.total_count,
        )
        self._apply_overlay_state(overlay, tab=ValidationTab.QA, progress_label=progress)
        alerts = list(getattr(overlay, "alerts", [])[:30])
        if overlay.conflict_cells:
            alerts.insert(0, tr("emr.qa.conflicts", count=len(overlay.conflict_cells)))
        if overlay.rows_with_key_errors:
            alerts.insert(
                0,
                tr("emr.msg.key_errors", count=overlay.rows_with_key_errors),
            )
        if payload.qa_result is not None and len(payload.qa_result.template_overlays) > 1:
            alerts.insert(
                0,
                tr(
                    "emr.qa.templates_active",
                    count=len(payload.qa_result.template_overlays),
                ),
            )
        self._messages.set_messages(alerts or [tr("emr.msg.no_alerts")])
        self.statusBar().showMessage(tr("emr.status.validation_done"), 4000)

    def _close_viewer(self) -> None:
        self._dataset = None
        self._raw_dataset = None
        self._current_path = None
        self._template = None
        self._overlay_passed = set()
        self._overlay_failed = set()
        self._overlay_conflict = set()
        self._overlay_gray = set()
        self._overlay_snapshots = {
            ValidationTab.REFERENCE: None,
            ValidationTab.QA: None,
            ValidationTab.VALIDATION: None,
            ValidationTab.SCHEMA: None,
        }
        self._metrics_snapshots.clear()
        self._row_dicts_cache_key = None
        self._row_dicts_cache = None
        self._viewer.clear_validation_overlay()
        self._viewer.set_build_mode(False)
        self._validation.set_dataset(None)
        self._validation.clear_qa_metrics()
        self._sync_catalog_column_menu()
        self._viewer.clear_catalog_displays()
        self._show_browser()
        self._messages.clear_messages()
