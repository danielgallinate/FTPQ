"""Delegate sutil para celdas pendientes en Template Edit."""
from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import QModelIndex, Qt
from PySide6.QtGui import QColor, QPainter, QBrush
from PySide6.QtWidgets import QStyledItemDelegate, QStyleOptionViewItem, QStyle


PENDING_TINT = QColor(255, 236, 160, 36)
PENDING_ACCENT = QColor(201, 162, 39)


class TemplateEditCellDelegate(QStyledItemDelegate):
    def __init__(
        self,
        baseline_row_count: Callable[[], int],
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._baseline_row_count = baseline_row_count

    def _is_pending(self, index: QModelIndex) -> bool:
        if not index.isValid():
            return False
        row = index.row()
        if row >= self._baseline_row_count():
            return True
        original = index.data(Qt.ItemDataRole.UserRole)
        current = index.data(Qt.ItemDataRole.DisplayRole)
        if original is None:
            original = ""
        if current is None:
            current = ""
        return str(current) != str(original)

    def paint(
        self,
        painter: QPainter,
        option: QStyleOptionViewItem,
        index: QModelIndex,
    ) -> None:
        pending = self._is_pending(index)
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        if pending:
            painter.save()
            painter.fillRect(option.rect, PENDING_TINT)
            accent = option.rect.adjusted(0, 1, 0, -1)
            painter.fillRect(accent.left(), accent.top(), 2, accent.height(), PENDING_ACCENT)
            painter.restore()
            opt.state &= ~QStyle.StateFlag.State_Selected
            opt.backgroundBrush = QBrush()
        super().paint(painter, opt, index)
