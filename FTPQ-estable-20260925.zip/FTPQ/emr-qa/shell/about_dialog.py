"""Diálogo Acerca de — descripción del sistema y manual de uso."""
from __future__ import annotations

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from shell.user_manual import user_manual_path
from ui.i18n import tr


class AboutDialog(QDialog):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("emr.action.about"))

        self._description = QLabel()
        self._description.setWordWrap(True)
        self._description.setText(tr("emr.about.description"))

        self._open_manual = QPushButton(tr("emr.about.open_manual"))
        self._open_manual.clicked.connect(self._on_open_manual)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.reject)

        manual_row = QHBoxLayout()
        manual_row.addWidget(self._open_manual)
        manual_row.addStretch(1)

        layout = QVBoxLayout(self)
        layout.addWidget(self._description)
        layout.addLayout(manual_row)
        layout.addWidget(buttons)

        self.setMinimumWidth(420)

    def retranslate_ui(self) -> None:
        self.setWindowTitle(tr("emr.action.about"))
        self._description.setText(tr("emr.about.description"))
        self._open_manual.setText(tr("emr.about.open_manual"))

    def _on_open_manual(self) -> None:
        path = user_manual_path()
        if not path.is_file():
            QMessageBox.warning(
                self,
                tr("emr.app.title"),
                tr("emr.about.manual_missing", path=str(path)),
            )
            return
        opened = QDesktopServices.openUrl(QUrl.fromLocalFile(str(path.resolve())))
        if not opened:
            QMessageBox.warning(
                self,
                tr("emr.app.title"),
                tr("emr.about.manual_open_failed", path=str(path)),
            )


def show_about_dialog(parent: QWidget | None = None) -> None:
    dialog = AboutDialog(parent)
    dialog.exec()
