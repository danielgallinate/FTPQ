"""Tema claro para exportación PDF — texto oscuro, fondo neutro, gráficos con borde."""
from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCharts import QBarSeries, QChartView, QPieSeries
from PySide6.QtGui import QBrush, QColor, QPalette, QPen
from PySide6.QtWidgets import QSizePolicy, QWidget

_PDF_BG = QColor("#FFFFFF")
_PDF_FG = QColor("#1A1A1A")
_PDF_HINT = QColor("#666666")
_PDF_GRID = QColor("#CCCCCC")
_PDF_LINE = QColor("#333333")
_CHART_BORDER = QPen(QColor("#000000"), 1)
_OK_COLOR = QColor("#4CAF50")
_NOK_COLOR = QColor("#E53935")

_PDF_QSS = """
QWidget {
    background-color: #FFFFFF;
    color: #1A1A1A;
}
QLabel#configHint, QLabel#panelSubtitle {
    color: #1A1A1A;
    background: transparent;
}
QTableWidget#qaMetricsTable {
    background-color: #FFFFFF;
    alternate-background-color: #F4F4F4;
    color: #1A1A1A;
    gridline-color: #CFCFCF;
    selection-background-color: #D6E4F5;
    selection-color: #1A1A1A;
    border: 1px solid #333333;
}
QTableWidget#qaMetricsTable::item {
    padding: 4px 8px;
}
QHeaderView::section {
    background-color: #EEEEEE;
    color: #1A1A1A;
    border: 1px solid #CFCFCF;
    padding: 4px 8px;
}
QChartView {
    background-color: #FFFFFF;
    border: 1px solid #000000;
}
"""


@dataclass
class _WidgetSnapshot:
    stylesheet: str
    palette: QPalette
    size_policy: QSizePolicy
    minimum_size: tuple[int, int]
    maximum_size: tuple[int, int]
    fixed: bool


def _light_palette() -> QPalette:
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, _PDF_BG)
    palette.setColor(QPalette.ColorRole.WindowText, _PDF_FG)
    palette.setColor(QPalette.ColorRole.Base, _PDF_BG)
    palette.setColor(QPalette.ColorRole.Text, _PDF_FG)
    palette.setColor(QPalette.ColorRole.Button, _PDF_BG)
    palette.setColor(QPalette.ColorRole.ButtonText, _PDF_FG)
    palette.setColor(QPalette.ColorRole.PlaceholderText, _PDF_HINT)
    palette.setColor(QPalette.ColorRole.Mid, _PDF_GRID)
    palette.setColor(QPalette.ColorRole.Dark, _PDF_LINE)
    return palette


def snapshot_widget(widget: QWidget) -> _WidgetSnapshot:
    max_size = widget.maximumSize()
    return _WidgetSnapshot(
        stylesheet=widget.styleSheet(),
        palette=widget.palette(),
        size_policy=widget.sizePolicy(),
        minimum_size=(widget.minimumWidth(), widget.minimumHeight()),
        maximum_size=(max_size.width(), max_size.height()),
        fixed=widget.sizePolicy().horizontalPolicy() == QSizePolicy.Policy.Fixed
        and widget.sizePolicy().verticalPolicy() == QSizePolicy.Policy.Fixed,
    )


def apply_pdf_light_theme(widget: QWidget) -> _WidgetSnapshot:
    snapshot = snapshot_widget(widget)
    widget.setPalette(_light_palette())
    widget.setAutoFillBackground(True)
    widget.setStyleSheet(_PDF_QSS)
    return snapshot


def restore_pdf_theme(widget: QWidget, snapshot: _WidgetSnapshot) -> None:
    widget.setStyleSheet(snapshot.stylesheet)
    widget.setPalette(snapshot.palette)
    widget.setAutoFillBackground(False)
    widget.setSizePolicy(snapshot.size_policy)
    widget.setMinimumSize(*snapshot.minimum_size)
    widget.setMaximumSize(*snapshot.maximum_size)
    if snapshot.fixed:
        widget.setFixedSize(snapshot.minimum_size[0], snapshot.minimum_size[1])
    else:
        widget.resize(snapshot.minimum_size[0], snapshot.minimum_size[1])
    widget.updateGeometry()


def pin_widget_to_content(widget: QWidget) -> None:
    width = max(widget.minimumWidth(), 1)
    height = max(widget.minimumHeight(), 1)
    widget.setFixedSize(width, height)


def style_charts_for_pdf(root: QWidget) -> None:
    for view in root.findChildren(QChartView):
        view.setStyleSheet("background-color: #FFFFFF; border: 1px solid #000000;")
        chart = view.chart()
        if chart is None:
            continue
        chart.setBackgroundVisible(True)
        chart.setBackgroundBrush(QBrush(_PDF_BG))
        chart.setTitleBrush(QBrush(_PDF_FG))
        chart.legend().setLabelColor(_PDF_FG)
        for series in chart.series():
            if isinstance(series, QPieSeries):
                for index in range(series.count()):
                    slice_item = series.slices()[index]
                    slice_item.setPen(_CHART_BORDER)
                    label = slice_item.label().upper()
                    if "NOK" in label or "NO OK" in label:
                        slice_item.setBrush(QBrush(_NOK_COLOR))
                    elif "OK" in label:
                        slice_item.setBrush(QBrush(_OK_COLOR))
            elif isinstance(series, QBarSeries):
                for bar_set in series.barSets():
                    bar_set.setPen(_CHART_BORDER)
                    bar_set.setBorderColor(QColor("#000000"))
                    title = bar_set.label().upper()
                    if "NOK" in title or "NO OK" in title:
                        bar_set.setColor(_NOK_COLOR)
                    elif "OK" in title:
                        bar_set.setColor(_OK_COLOR)
        for axis in chart.axes():
            axis.setLabelsColor(_PDF_FG)
            axis.setTitleBrush(QBrush(_PDF_FG))
            axis.setGridLineColor(_PDF_GRID)
