"""Utilidades de layout compartidas para reporte QA."""
from __future__ import annotations

from pathlib import Path
from typing import Protocol

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QScrollArea, QVBoxLayout, QWidget

from ui.theme.theme_engine import ThemeEngine
from ui.theme.wallpaper_store import resolve_wallpaper_path


class _MetricsReportView(Protocol):
    def update_content_size(self) -> None: ...


class _MetricsCharts(Protocol):
    def update_content_size(self, *, content_width: int = ...) -> None: ...

    @property
    def width(self) -> int: ...

    @property
    def height(self) -> int: ...


def resolve_wallpaper_context(main_window: QWidget | None) -> tuple[ThemeEngine, Path]:
    if main_window is not None:
        theme = getattr(main_window, "_theme", None)
        if isinstance(theme, ThemeEngine):
            host = getattr(main_window, "_host", None)
            path = getattr(host, "_wallpaper_path", None) if host is not None else None
            return theme, path or resolve_wallpaper_path()
    app = QApplication.instance()
    if app is not None:
        for widget in app.topLevelWidgets():
            theme = getattr(widget, "_theme", None)
            if isinstance(theme, ThemeEngine):
                host = getattr(widget, "_host", None)
                path = getattr(host, "_wallpaper_path", None) if host is not None else None
                return theme, path or resolve_wallpaper_path()
    raise RuntimeError("ThemeEngine no disponible para el reporte QA")


def configure_metrics_scroll(scroll: QScrollArea) -> None:
    scroll.setWidgetResizable(False)
    scroll.setFrameShape(QScrollArea.Shape.NoFrame)
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
    scroll.viewport().setStyleSheet("background: transparent;")


def sync_metrics_scroll_content(
    scroll: QScrollArea,
    content: QWidget,
    report_view: _MetricsReportView,
    charts: _MetricsCharts,
) -> None:
    report_view.update_content_size()
    layout = content.layout()
    spacing = layout.spacing() if isinstance(layout, QVBoxLayout) else 0
    viewport_width = max(scroll.viewport().width(), 640)
    base_width = max(report_view.minimumWidth(), viewport_width)
    charts.update_content_size(content_width=base_width)
    content_width = max(report_view.minimumWidth(), charts.width(), viewport_width)
    content_height = report_view.minimumHeight() + charts.height() + spacing
    content.setMinimumSize(content_width, content_height)
    content.resize(content_width, content_height)
