"""Panel de métricas QA — KPIs, tablas, gráficos y pantalla completa."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from shell.qa_metrics import QaMetricsReport
from shell.qa_metrics_charts import QaMetricsChartsWidget
from shell.qa_metrics_fullscreen_dialog import QaMetricsReportDialog
from shell.qa_metrics_layout import configure_metrics_scroll, sync_metrics_scroll_content
from shell.qa_metrics_pdf_export import (
    default_pdf_filename,
    export_qa_metrics_pdf,
    pick_pdf_export_path,
)
from shell.qa_metrics_report_view import QaMetricsReportView
from ui.i18n import tr


class QaMetricsPanel(QFrame):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("panel")
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self._report: QaMetricsReport | None = None
        self._nok_only = False
        self._fullscreen_dialog: QaMetricsReportDialog | None = None

        self._title = QLabel()
        self._title.setObjectName("panelSubtitle")

        self._kpi_coverage = QLabel()
        self._kpi_quality = QLabel()
        self._kpi_localization = QLabel()
        self._kpi_conflict = QLabel()
        for label in (
            self._kpi_coverage,
            self._kpi_quality,
            self._kpi_localization,
            self._kpi_conflict,
        ):
            label.setObjectName("configHint")
            label.setWordWrap(True)

        kpi_grid = QGridLayout()
        kpi_grid.setContentsMargins(0, 0, 0, 0)
        kpi_grid.setHorizontalSpacing(8)
        kpi_grid.setVerticalSpacing(2)
        kpi_grid.addWidget(self._kpi_coverage, 0, 0)
        kpi_grid.addWidget(self._kpi_quality, 0, 1)
        kpi_grid.addWidget(self._kpi_localization, 1, 0)
        kpi_grid.addWidget(self._kpi_conflict, 1, 1)

        self._empty = QLabel()
        self._empty.setObjectName("configHint")
        self._empty.setWordWrap(True)

        self._nok_filter = QCheckBox()
        self._nok_filter.toggled.connect(self._on_nok_filter_toggled)

        self._fullscreen = QPushButton()
        self._fullscreen.clicked.connect(self._open_fullscreen)

        self._copy_report = QPushButton()
        self._copy_report.clicked.connect(self._copy_report_text)

        self._copy_csv = QPushButton()
        self._copy_csv.clicked.connect(self._copy_csv_text)

        self._export_pdf = QPushButton()
        self._export_pdf.clicked.connect(self._export_pdf_file)

        actions = QHBoxLayout()
        actions.setContentsMargins(0, 0, 0, 0)
        actions.addWidget(self._nok_filter)
        actions.addStretch(1)
        actions.addWidget(self._fullscreen)
        actions.addWidget(self._copy_report)
        actions.addWidget(self._copy_csv)
        actions.addWidget(self._export_pdf)

        self._report_view = QaMetricsReportView()
        self._charts = QaMetricsChartsWidget()

        self._report_scroll_content = QWidget()
        self._report_scroll_content.setObjectName("qaMetricsScrollHost")
        report_body = QVBoxLayout(self._report_scroll_content)
        report_body.setContentsMargins(0, 0, 0, 0)
        report_body.setSpacing(16)
        report_body.addWidget(self._report_view)
        report_body.addWidget(self._charts)

        self._report_scroll = QScrollArea()
        self._report_scroll.setObjectName("qaMetricsScroll")
        configure_metrics_scroll(self._report_scroll)
        self._report_scroll.setWidget(self._report_scroll_content)

        self._content = QWidget()
        content_layout = QVBoxLayout(self._content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(6)
        content_layout.addLayout(kpi_grid)
        content_layout.addLayout(actions)
        content_layout.addWidget(self._report_scroll, stretch=1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(self._content)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        layout.addWidget(self._title)
        layout.addWidget(self._empty)
        layout.addWidget(scroll, stretch=1)
        self._show_empty()
        self.retranslate_ui()

    def retranslate_ui(self) -> None:
        self._title.setText(tr("emr.qa.metrics.title"))
        self._empty.setText(tr("emr.qa.metrics.empty"))
        self._nok_filter.setText(tr("emr.qa.metrics.nok_only"))
        self._fullscreen.setText(tr("emr.qa.metrics.fullscreen"))
        self._copy_report.setText(tr("emr.qa.metrics.copy_report"))
        self._copy_csv.setText(tr("emr.qa.metrics.copy_csv"))
        self._export_pdf.setText(tr("emr.qa.metrics.export_pdf"))
        if self._report is not None:
            self._refresh_kpis(self._report)
            self._refresh_report_view()
            self._charts.set_report(self._report, nok_only=self._nok_only)
        else:
            self._report_view.retranslate_ui()
            self._charts.retranslate_ui()
        if self._fullscreen_dialog is not None and self._fullscreen_dialog.isVisible():
            self._fullscreen_dialog.retranslate_ui()

    def clear_metrics(self) -> None:
        self._report = None
        self._show_empty()

    def set_metrics(self, report: QaMetricsReport | None) -> None:
        self._report = report
        if report is None:
            self._show_empty()
            return
        self._empty.hide()
        self._content.show()
        self._refresh_kpis(report)
        self._refresh_report_view()
        self._charts.set_report(report, nok_only=self._nok_only)
        self._sync_report_scroll_size()

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._sync_report_scroll_size()

    def _sync_report_scroll_size(self) -> None:
        if self._report is None:
            return
        sync_metrics_scroll_content(
            self._report_scroll,
            self._report_scroll_content,
            self._report_view,
            self._charts,
        )

    def _show_empty(self) -> None:
        self._empty.show()
        self._content.hide()
        self._kpi_coverage.clear()
        self._kpi_quality.clear()
        self._kpi_localization.clear()
        self._kpi_conflict.clear()
        self._report_view.set_report(None)
        self._charts.set_report(None)

    def _refresh_report_view(self) -> None:
        if self._report is None:
            return
        self._report_view.set_report(self._report, nok_only=self._nok_only)
        self._sync_report_scroll_size()

    def _refresh_kpis(self, report: QaMetricsReport) -> None:
        self._kpi_coverage.setText(
            tr(
                "emr.qa.metrics.kpi_coverage",
                pct=f"{report.coverage_pct:.2f}",
                judged=report.judged_cells,
                eligible=report.eligible_cells,
            )
        )
        self._kpi_quality.setText(
            tr(
                "emr.qa.metrics.kpi_quality",
                pct=f"{report.quality_pct:.2f}",
                ok=report.ok_cells,
                judged=report.judged_cells,
            )
        )
        self._kpi_localization.setText(
            tr(
                "emr.qa.metrics.kpi_localization",
                pct=f"{report.localization_pct:.2f}",
                located=report.rows_located,
                complete=report.rows_key_complete,
            )
        )
        self._kpi_conflict.setText(
            tr(
                "emr.qa.metrics.kpi_conflict",
                pct=f"{report.conflict_pct:.2f}",
                count=report.conflict_cells,
                judged=report.judged_cells,
            )
        )

    def _on_nok_filter_toggled(self, checked: bool) -> None:
        self._nok_only = checked
        if self._report is not None:
            self._refresh_report_view()
            self._charts.set_report(self._report, nok_only=self._nok_only)
            self._sync_report_scroll_size()

    def _open_fullscreen(self) -> None:
        if self._report is None:
            return
        dialog = QaMetricsReportDialog(
            self._report,
            nok_only=self._nok_only,
            parent=self.window(),
        )
        self._fullscreen_dialog = dialog
        dialog.finished.connect(lambda _result: setattr(self, "_fullscreen_dialog", None))
        dialog.exec()

    def _copy_report_text(self) -> None:
        if self._report is None:
            return
        QApplication.clipboard().setText(
            self._report.to_copyable_text(nok_only=self._nok_only)
        )

    def _copy_csv_text(self) -> None:
        if self._report is None:
            return
        QApplication.clipboard().setText(self._report.to_csv(nok_only=self._nok_only))

    def _export_pdf_file(self) -> None:
        if self._report is None:
            return
        default_name = default_pdf_filename(self._report.file_name)
        path = pick_pdf_export_path(self.window(), default_name=default_name)
        if path is None:
            return
        try:
            export_qa_metrics_pdf(
                path,
                report_view=self._report_view,
                charts=self._charts,
            )
        except OSError as exc:
            QMessageBox.warning(
                self.window(),
                tr("emr.qa.metrics.export_pdf"),
                tr("emr.qa.metrics.export_pdf_fail", error=exc),
            )
            return
        QMessageBox.information(
            self.window(),
            tr("emr.qa.metrics.export_pdf"),
            tr("emr.qa.metrics.export_pdf_done", path=str(path)),
        )
