"""Métricas QA — cobertura, calidad, localización, desglose por columna/template."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from core.chart_format import floor_pct, format_pct
from emrqa.minibase_lookup import MinibaseLookup
from emrqa.validation_models import ValidationTemplate, normalize_cell_value
from shell.validation_runner import OverlayState, QaHighlightMode, TemplateOverlay
from ui.i18n import tr


@dataclass(frozen=True)
class ColumnMetrics:
    column: str
    eligible: int = 0
    judged: int = 0
    ok: int = 0
    nok: int = 0
    conflict: int = 0
    unevaluated: int = 0
    applicable: bool = True

    @property
    def ok_pct(self) -> float:
        return floor_pct(self.ok, self.judged)


@dataclass(frozen=True)
class TemplateMetrics:
    name: str
    judged: int = 0
    ok: int = 0
    nok: int = 0
    conflict: int = 0
    eligible_cells: int = 0
    unevaluated_cells: int = 0
    rows_key_complete: int = 0
    rows_located: int = 0
    rows_partial: int = 0
    rows_orphan: int = 0
    rows_key_conflict: int = 0

    @property
    def localization_pct(self) -> float:
        if not self.rows_key_complete:
            return 0.0
        return floor_pct(self.rows_located, self.rows_key_complete)

    @property
    def coverage_pct(self) -> float:
        if not self.eligible_cells:
            return 0.0
        return floor_pct(self.judged, self.eligible_cells)


@dataclass(frozen=True)
class TemplateProfile:
    name: str
    column_names: tuple[str, ...]
    compare_columns: tuple[str, ...]
    minibase_records: int
    key_kind: str
    key_columns: tuple[str, ...]

    def key_summary(self) -> str:
        if self.key_kind == "none":
            return tr("emr.qa.metrics.report.template_profile.no_key")
        columns = ", ".join(self.key_columns) or "—"
        if self.key_kind == "composite":
            return tr(
                "emr.qa.metrics.report.template_profile.composite_key",
                columns=columns,
            )
        return tr(
            "emr.qa.metrics.report.template_profile.simple_key",
            columns=columns,
        )

    def to_line(self) -> str:
        columns = ", ".join(self.column_names) or "—"
        compare = ", ".join(self.compare_columns) or "—"
        return tr(
            "emr.qa.metrics.report.template_profile_line",
            name=self.name,
            key_summary=self.key_summary(),
            columns=columns,
            compare=compare,
            records=self.minibase_records,
        )


@dataclass(frozen=True)
class MetricsDelta:
    ok_cells: int = 0
    nok_cells: int = 0
    conflict_cells: int = 0
    judged_cells: int = 0
    coverage_pct: float = 0.0
    quality_pct: float = 0.0
    localization_pct: float = 0.0


@dataclass
class QaMetricsReport:
    file_name: str
    generated_at: str
    visible_columns: list[str] = field(default_factory=list)
    not_applicable_columns: list[str] = field(default_factory=list)
    evaluable_columns: list[str] = field(default_factory=list)
    template_names: list[str] = field(default_factory=list)
    template_profiles: list[TemplateProfile] = field(default_factory=list)
    highlight_mode: str = "fail_any"

    eligible_cells: int = 0
    judged_cells: int = 0
    ok_cells: int = 0
    nok_cells: int = 0
    conflict_cells: int = 0
    unevaluated_cells: int = 0

    rows_total: int = 0
    rows_key_complete: int = 0
    rows_located: int = 0
    rows_partial: int = 0
    rows_orphan: int = 0
    rows_key_conflict: int = 0

    by_column: dict[str, ColumnMetrics] = field(default_factory=dict)
    by_template: dict[str, TemplateMetrics] = field(default_factory=dict)
    delta: MetricsDelta | None = None

    @property
    def coverage_pct(self) -> float:
        return floor_pct(self.judged_cells, self.eligible_cells)

    @property
    def quality_pct(self) -> float:
        return floor_pct(self.ok_cells, self.judged_cells)

    @property
    def conflict_pct(self) -> float:
        return floor_pct(self.conflict_cells, self.judged_cells)

    @property
    def localization_pct(self) -> float:
        if not self.rows_key_complete:
            return 0.0
        return floor_pct(self.rows_located, self.rows_key_complete)

    def columns_with_nok(self) -> list[ColumnMetrics]:
        return [
            metrics
            for metrics in self.by_column.values()
            if metrics.applicable and metrics.nok > 0
        ]

    def top_nok_columns(self, limit: int = 5) -> list[ColumnMetrics]:
        items = sorted(
            self.columns_with_nok(),
            key=lambda item: (-item.nok, item.column),
        )
        return items[:limit]

    def template_profiles_block(self) -> str:
        if not self.template_profiles:
            return ""
        lines = [tr("emr.qa.metrics.report.template_profiles_title")]
        lines.extend(profile.to_line() for profile in self.template_profiles)
        return "\n".join(lines)

    def meta_block_text(self) -> str:
        mode_label = tr(f"emr.qa.metrics.mode.{self.highlight_mode}")
        base = tr(
            "emr.qa.metrics.report.meta_block",
            file=self.file_name,
            when=self.generated_at,
            templates=", ".join(self.template_names) or "—",
            mode=mode_label,
            visible=len(self.visible_columns),
            evaluable=len(self.evaluable_columns),
            not_applicable=len(self.not_applicable_columns),
        )
        profiles = self.template_profiles_block()
        if profiles:
            return f"{base}\n\n{profiles}"
        return base

    def to_copyable_text(self, *, nok_only: bool = False) -> str:
        lines: list[str] = [
            tr("emr.qa.metrics.report.title", file=self.file_name),
            tr("emr.qa.metrics.report.generated", when=self.generated_at),
            self.meta_block_text(),
            "",
            tr("emr.qa.metrics.report.section_kpis"),
            tr(
                "emr.qa.metrics.report.coverage",
                pct=f"{self.coverage_pct:5.2f}",
                judged=self.judged_cells,
                eligible=self.eligible_cells,
            ),
            tr(
                "emr.qa.metrics.report.quality",
                pct=f"{self.quality_pct:5.2f}",
                ok=self.ok_cells,
                judged=self.judged_cells,
            ),
            tr(
                "emr.qa.metrics.report.localization",
                pct=f"{self.localization_pct:5.2f}",
                located=self.rows_located,
                complete=self.rows_key_complete,
            ),
            tr(
                "emr.qa.metrics.report.conflict",
                pct=f"{self.conflict_pct:5.2f}",
                count=self.conflict_cells,
                judged=self.judged_cells,
            ),
            "",
            tr("emr.qa.metrics.report.section_keys"),
            tr("emr.qa.metrics.report.rows_total", count=self.rows_total),
            tr("emr.qa.metrics.report.rows_key_complete", count=self.rows_key_complete),
            tr("emr.qa.metrics.report.rows_located", count=self.rows_located),
            tr("emr.qa.metrics.report.rows_partial", count=self.rows_partial),
            tr("emr.qa.metrics.report.rows_orphan", count=self.rows_orphan),
            tr("emr.qa.metrics.report.rows_key_conflict", count=self.rows_key_conflict),
        ]
        if self.delta is not None:
            delta = self.delta
            lines.extend(
                [
                    "",
                    tr("emr.qa.metrics.report.section_delta"),
                    tr("emr.qa.metrics.report.delta_ok", value=f"{delta.ok_cells:+d}"),
                    tr("emr.qa.metrics.report.delta_nok", value=f"{delta.nok_cells:+d}"),
                    tr(
                        "emr.qa.metrics.report.delta_conflict",
                        value=f"{delta.conflict_cells:+d}",
                    ),
                    tr(
                        "emr.qa.metrics.report.delta_coverage",
                        value=f"{delta.coverage_pct:+.1f}",
                    ),
                    tr(
                        "emr.qa.metrics.report.delta_quality",
                        value=f"{delta.quality_pct:+.1f}",
                    ),
                    tr(
                        "emr.qa.metrics.report.delta_localization",
                        value=f"{delta.localization_pct:+.1f}",
                    ),
                ]
            )
        lines.extend(["", tr("emr.qa.metrics.report.section_columns")])
        header = tr("emr.qa.metrics.report.columns_header")
        lines.append(header)
        lines.append("-" * len(header))
        column_items = sorted(self.by_column.values(), key=lambda item: item.column)
        if nok_only:
            column_items = [item for item in column_items if item.applicable and item.nok > 0]
        for metrics in column_items:
            if not metrics.applicable:
                lines.append(
                    tr(
                        "emr.qa.metrics.report.column_not_applicable",
                        column=f"{metrics.column:<16}",
                    )
                )
                continue
            lines.append(
                f"{metrics.column:<16}| {metrics.eligible:5d} | {metrics.judged:5d} | "
                f"{metrics.ok:5d} | {metrics.nok:5d} | {metrics.conflict:5d} | "
                f"{metrics.unevaluated:5d} | {metrics.ok_pct:6.2f}%"
            )
        if self.not_applicable_columns:
            lines.extend(
                [
                    "",
                    tr("emr.qa.metrics.report.not_applicable_list"),
                    ", ".join(self.not_applicable_columns),
                ]
            )
        if self.by_template:
            lines.extend(["", tr("emr.qa.metrics.report.section_templates")])
            for name in self.template_names:
                metrics = self.by_template.get(name)
                if metrics is None:
                    continue
                lines.append(
                    tr(
                        "emr.qa.metrics.report.template_line",
                        name=name,
                        judged=metrics.judged,
                        ok=metrics.ok,
                        nok=metrics.nok,
                        conflict=metrics.conflict,
                        loc_pct=f"{metrics.localization_pct:.0f}",
                        located=metrics.rows_located,
                        complete=metrics.rows_key_complete,
                    )
                )
        top = self.top_nok_columns()
        if top:
            lines.extend(["", tr("emr.qa.metrics.report.section_top_nok")])
            for metrics in top:
                lines.append(
                    tr(
                        "emr.qa.metrics.report.top_nok_line",
                        column=metrics.column,
                        nok=metrics.nok,
                        ok_pct=f"{metrics.ok_pct:.2f}",
                    )
                )
        return "\n".join(lines)

    def to_csv(self, *, nok_only: bool = False) -> str:
        lines = [tr("emr.qa.metrics.csv.header")]
        for metrics in sorted(self.by_column.values(), key=lambda item: item.column):
            if not metrics.applicable:
                continue
            if nok_only and metrics.nok <= 0:
                continue
            lines.append(
                f"{tr('emr.qa.metrics.csv.section_column')},{metrics.column},"
                f"{metrics.eligible},{metrics.judged},"
                f"{metrics.ok},{metrics.nok},{metrics.conflict},{metrics.unevaluated},"
                f"{metrics.ok_pct:.2f}"
            )
        for name in self.template_names:
            metrics = self.by_template.get(name)
            if metrics is None:
                continue
            lines.append(
                f"{tr('emr.qa.metrics.csv.section_template')},{name},,,"
                f"{metrics.ok},{metrics.nok},{metrics.conflict},,"
            )
        lines.append(
            f"{tr('emr.qa.metrics.csv.section_summary')},,{self.eligible_cells},"
            f"{self.judged_cells},{self.ok_cells},{self.nok_cells},"
            f"{self.conflict_cells},{self.unevaluated_cells},{self.quality_pct:.2f}"
        )
        return "\n".join(lines)


def _evaluable_columns(
    visible_columns: list[str],
    templates: list[ValidationTemplate],
) -> tuple[list[str], list[str]]:
    mapped: set[str] = set()
    for template in templates:
        for field in template.header.fields:
            if field.column:
                mapped.add(field.column)
    evaluable = [column for column in visible_columns if column in mapped]
    not_applicable = [column for column in visible_columns if column not in mapped]
    return evaluable, not_applicable


def _row_locate_state(
    template: ValidationTemplate,
    row: dict[str, object],
    *,
    lookup: MinibaseLookup | None = None,
) -> str:
    dedup_key = template.dedup_key()
    if dedup_key is None or not template.minibase.records:
        return "no_minibase"
    key_values: list[str] = []
    for field_id in dedup_key.field_ids:
        field = template.header.field_by_id(field_id)
        if field is None:
            continue
        key_values.append(normalize_cell_value(row.get(field.column)))
    if not any(key_values) or not all(key_values):
        return "no_key"
    if lookup is None:
        lookup = MinibaseLookup.from_template(template)
    fingerprint = template.fingerprint_for_row(dedup_key, row)
    if fingerprint in lookup.by_fingerprint:
        return "located"
    for record in lookup.candidate_records(template, dedup_key, row):
        partial = 0
        mismatch = False
        for field_id in dedup_key.field_ids:
            field = template.header.field_by_id(field_id)
            if field is None:
                continue
            row_value = normalize_cell_value(row.get(field.column))
            saved = record.values.get(field_id, "")
            if row_value and saved and row_value == saved:
                partial += 1
            elif row_value != saved:
                mismatch = True
        if partial > 0 and mismatch:
            return "conflict" if fingerprint != record.key_fingerprint else "partial"
    return "orphan"


def _count_column_cells(
    *,
    rows_count: int,
    column: str,
    name_to_index: dict[str, int],
    passed: set[tuple[int, int]],
    failed: set[tuple[int, int]],
    conflict: set[tuple[int, int]],
) -> ColumnMetrics:
    col_index = name_to_index.get(column)
    if col_index is None:
        return ColumnMetrics(column=column, applicable=False)
    ok = nok = disc = 0
    for row_index in range(rows_count):
        coord = (row_index, col_index)
        if coord in failed:
            nok += 1
        elif coord in conflict:
            disc += 1
        elif coord in passed:
            ok += 1
    judged = ok + nok + disc
    return ColumnMetrics(
        column=column,
        eligible=rows_count,
        judged=judged,
        ok=ok,
        nok=nok,
        conflict=disc,
        unevaluated=max(0, rows_count - judged),
        applicable=True,
    )


def _template_cell_metrics(overlay: TemplateOverlay) -> TemplateMetrics:
    ok = len(overlay.passed)
    nok = len(overlay.failed)
    judged = ok + nok
    unevaluated = len(overlay.gray)
    eligible = judged + unevaluated
    return TemplateMetrics(
        name=overlay.name,
        judged=judged,
        ok=ok,
        nok=nok,
        eligible_cells=eligible,
        unevaluated_cells=unevaluated,
    )


def _template_row_metrics(
    template: ValidationTemplate,
    rows: list[dict[str, object]],
    *,
    lookup: MinibaseLookup | None = None,
) -> TemplateMetrics:
    rows_key_complete = 0
    rows_located = 0
    rows_partial = 0
    rows_orphan = 0
    rows_key_conflict = 0
    for row in rows:
        state = _row_locate_state(template, row, lookup=lookup)
        if state in ("no_key", "no_minibase"):
            continue
        rows_key_complete += 1
        if state == "located":
            rows_located += 1
        elif state == "partial":
            rows_partial += 1
        elif state == "conflict":
            rows_key_conflict += 1
        elif state == "orphan":
            rows_orphan += 1
    return TemplateMetrics(
        name=template.header.name,
        rows_key_complete=rows_key_complete,
        rows_located=rows_located,
        rows_partial=rows_partial,
        rows_orphan=rows_orphan,
        rows_key_conflict=rows_key_conflict,
    )


def _compute_delta(current: QaMetricsReport, previous: QaMetricsReport) -> MetricsDelta:
    return MetricsDelta(
        ok_cells=current.ok_cells - previous.ok_cells,
        nok_cells=current.nok_cells - previous.nok_cells,
        conflict_cells=current.conflict_cells - previous.conflict_cells,
        judged_cells=current.judged_cells - previous.judged_cells,
        coverage_pct=round(current.coverage_pct - previous.coverage_pct, 2),
        quality_pct=round(current.quality_pct - previous.quality_pct, 2),
        localization_pct=round(current.localization_pct - previous.localization_pct, 2),
    )


def summarize_template_profile(template: ValidationTemplate) -> TemplateProfile:
    header = template.header
    key = template.dedup_key()
    if key is None:
        key_kind = "none"
        key_columns: tuple[str, ...] = ()
    else:
        columns: list[str] = []
        for field_id in key.field_ids:
            field = header.field_by_id(field_id)
            if field is not None and field.column:
                columns.append(field.column)
        key_columns = tuple(columns)
        key_kind = "composite" if key.is_composite else "simple"
    column_names = tuple(field.column for field in header.fields if field.column)
    key_col_set = set(key_columns)
    compare_columns = tuple(column for column in column_names if column not in key_col_set)
    return TemplateProfile(
        name=header.name,
        column_names=column_names,
        compare_columns=compare_columns,
        minibase_records=len(template.minibase.records),
        key_kind=key_kind,
        key_columns=key_columns,
    )


def build_qa_metrics(
    *,
    file_name: str,
    visible_columns: list[str],
    rows: list[dict[str, object]],
    templates: list[ValidationTemplate],
    template_overlays: list[TemplateOverlay],
    merged: OverlayState,
    name_to_index: dict[str, int],
    highlight_mode: QaHighlightMode,
    previous: QaMetricsReport | None = None,
) -> QaMetricsReport:
    evaluable, not_applicable = _evaluable_columns(visible_columns, templates)
    rows_count = len(rows)
    eligible_cells = rows_count * len(evaluable)

    by_column: dict[str, ColumnMetrics] = {}
    for column in visible_columns:
        if column not in evaluable:
            by_column[column] = ColumnMetrics(column=column, applicable=False)
            continue
        by_column[column] = _count_column_cells(
            rows_count=rows_count,
            column=column,
            name_to_index=name_to_index,
            passed=merged.passed_cells,
            failed=merged.failed_cells,
            conflict=merged.conflict_cells,
        )

    ok_cells = len(merged.passed_cells)
    nok_cells = len(merged.failed_cells)
    conflict_cells = len(merged.conflict_cells)
    judged_cells = ok_cells + nok_cells + conflict_cells

    by_template: dict[str, TemplateMetrics] = {}
    template_names: list[str] = []
    template_profiles: list[TemplateProfile] = []
    global_key_complete: set[int] = set()
    global_located: set[int] = set()
    global_partial: set[int] = set()
    global_orphan: set[int] = set()
    global_conflict: set[int] = set()

    for template, overlay in zip(templates, template_overlays, strict=True):
        name = template.header.name
        template_names.append(name)
        template_profiles.append(summarize_template_profile(template))
        cell_part = _template_cell_metrics(overlay)
        lookup = MinibaseLookup.from_template(template) if template.minibase.records else None
        row_part = _template_row_metrics(template, rows, lookup=lookup)
        by_template[name] = TemplateMetrics(
            name=name,
            judged=cell_part.judged,
            ok=cell_part.ok,
            nok=cell_part.nok,
            conflict=cell_part.conflict,
            eligible_cells=cell_part.eligible_cells,
            unevaluated_cells=cell_part.unevaluated_cells,
            rows_key_complete=row_part.rows_key_complete,
            rows_located=row_part.rows_located,
            rows_partial=row_part.rows_partial,
            rows_orphan=row_part.rows_orphan,
            rows_key_conflict=row_part.rows_key_conflict,
        )
        for row_index, row in enumerate(rows):
            state = _row_locate_state(template, row, lookup=lookup)
            if state in ("no_key", "no_minibase"):
                continue
            global_key_complete.add(row_index)
            if state == "located":
                global_located.add(row_index)
            elif state == "partial":
                global_partial.add(row_index)
            elif state == "conflict":
                global_conflict.add(row_index)
            elif state == "orphan":
                global_orphan.add(row_index)

    report = QaMetricsReport(
        file_name=file_name,
        generated_at=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        visible_columns=list(visible_columns),
        not_applicable_columns=not_applicable,
        evaluable_columns=evaluable,
        template_names=template_names,
        template_profiles=template_profiles,
        highlight_mode=highlight_mode.value,
        eligible_cells=eligible_cells,
        judged_cells=judged_cells,
        ok_cells=ok_cells,
        nok_cells=nok_cells,
        conflict_cells=conflict_cells,
        unevaluated_cells=max(0, eligible_cells - judged_cells),
        rows_total=rows_count,
        rows_key_complete=len(global_key_complete),
        rows_located=len(global_located),
        rows_partial=len(global_partial),
        rows_orphan=len(global_orphan),
        rows_key_conflict=len(global_conflict),
        by_column=by_column,
        by_template=by_template,
    )
    if previous is not None:
        report.delta = _compute_delta(report, previous)
    return report


def metrics_snapshot_key(file_name: str, template_ids: list[str]) -> str:
    return f"{file_name}::{','.join(sorted(template_ids))}"
