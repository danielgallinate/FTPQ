"""Métricas resumidas — validación estructural de columnas."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from core.schema_catalog_types import SchemaCatalog
from core.schema_validation import SchemaValidationResult
from ui.i18n import tr


@dataclass(frozen=True)
class SchemaColumnMetrics:
    column: str
    data_type: str
    allows_null: bool
    enabled: bool
    judged: int = 0
    ok: int = 0
    nok: int = 0
    unevaluated: int = 0

    @property
    def ok_pct(self) -> float:
        if self.judged <= 0:
            return 0.0
        return round(100.0 * self.ok / self.judged, 2)


@dataclass
class SchemaValidationReport:
    file_name: str
    schema_name: str
    schema_id: str
    strict: bool
    generated_at: str
    rows_total: int = 0
    columns_defined: int = 0
    columns_evaluated: int = 0
    coverage_columns: list[str] = field(default_factory=list)
    structural_errors: list[str] = field(default_factory=list)
    cells_ok: int = 0
    cells_nok: int = 0
    cells_unevaluated: int = 0
    coverage_pct: float = 0.0
    quality_pct: float = 0.0
    headline: str = ""
    no_data: bool = False
    by_column: list[SchemaColumnMetrics] = field(default_factory=list)

    def to_copyable_text(self) -> str:
        lines = [
            tr("emr.schema.report.title"),
            tr("emr.schema.report.file", name=self.file_name),
            tr("emr.schema.report.schema", name=self.schema_name, schema_id=self.schema_id),
            tr("emr.schema.report.strict", value=tr("emr.schema.strict.yes") if self.strict else tr("emr.schema.strict.no")),
            tr("emr.schema.report.generated", at=self.generated_at),
            "",
            self.headline,
            "",
            tr(
                "emr.schema.report.cells",
                ok=f"{self.cells_ok:,}",
                nok=f"{self.cells_nok:,}",
                unevaluated=f"{self.cells_unevaluated:,}",
            ),
            tr("emr.schema.report.coverage_pct", pct=f"{self.coverage_pct:.2f}"),
            tr("emr.schema.report.quality_pct", pct=f"{self.quality_pct:.2f}"),
        ]
        if self.structural_errors:
            lines.append("")
            lines.append(tr("emr.schema.report.structural"))
            lines.extend(f"  · {item}" for item in self.structural_errors)
        if self.coverage_columns:
            lines.append("")
            lines.append(tr("emr.schema.report.coverage_columns"))
            lines.append("  " + ", ".join(self.coverage_columns))
        if self.by_column:
            lines.append("")
            lines.append(tr("emr.schema.report.by_column"))
            for item in self.by_column:
                if not item.enabled:
                    lines.append(
                        tr(
                            "emr.schema.report.column_unevaluated",
                            column=item.column,
                        )
                    )
                    continue
                lines.append(
                    tr(
                        "emr.schema.report.column_line",
                        column=item.column,
                        type=item.data_type,
                        ok=f"{item.ok:,}",
                        nok=f"{item.nok:,}",
                        pct=f"{item.ok_pct:.2f}",
                    )
                )
        return "\n".join(lines)


def build_schema_validation_report(
    *,
    file_name: str,
    catalog: SchemaCatalog,
    result: SchemaValidationResult,
    rows_total: int,
    name_to_index: dict[str, int],
) -> SchemaValidationReport:
    judged = len(result.passed_cells) + len(result.failed_cells)
    unevaluated = len(result.gray_cells)
    eligible = judged + unevaluated
    coverage_pct = round(100.0 * judged / eligible, 2) if eligible else 0.0
    quality_pct = round(100.0 * len(result.passed_cells) / judged, 2) if judged else 0.0

    by_column: list[SchemaColumnMetrics] = []
    for spec in catalog.columns:
        if not spec.name.strip():
            continue
        col_index = name_to_index.get(spec.name)
        ok = nok = uneval = 0
        if col_index is not None:
            for row_index in range(rows_total):
                coord = (row_index, col_index)
                if coord in result.passed_cells:
                    ok += 1
                elif coord in result.failed_cells:
                    nok += 1
                elif coord in result.gray_cells:
                    uneval += 1
        judged_col = ok + nok
        by_column.append(
            SchemaColumnMetrics(
                column=spec.name,
                data_type=spec.data_type,
                allows_null=spec.allows_null,
                enabled=spec.enabled,
                judged=judged_col,
                ok=ok,
                nok=nok,
                unevaluated=uneval,
            )
        )

    structural = list(result.structural_errors)
    # Sin filas no hay tipos ni patrones que juzgar: se alerta, no se aprueba ni reprueba.
    no_data = rows_total == 0
    if no_data:
        headline = tr("emr.schema.headline.no_data")
    elif result.failed_cells and not structural:
        headline = tr(
            "emr.schema.headline.nok",
            nok=f"{len(result.failed_cells):,}",
            judged=f"{judged:,}",
        )
    elif structural and not result.failed_cells:
        headline = tr("emr.schema.headline.structural", count=len(structural))
    elif structural and result.failed_cells:
        headline = tr(
            "emr.schema.headline.mixed",
            structural=len(structural),
            nok=f"{len(result.failed_cells):,}",
        )
    elif judged == 0 and unevaluated > 0:
        headline = tr("emr.schema.headline.coverage_only")
    else:
        headline = tr(
            "emr.schema.headline.ok",
            ok=f"{len(result.passed_cells):,}",
            judged=f"{judged:,}",
        )

    return SchemaValidationReport(
        file_name=file_name,
        schema_name=catalog.name,
        schema_id=catalog.schema_id,
        strict=catalog.strict,
        generated_at=datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z"),
        rows_total=rows_total,
        columns_defined=len([spec for spec in catalog.columns if spec.name.strip()]),
        columns_evaluated=len(result.evaluated_columns),
        coverage_columns=list(result.coverage_columns),
        structural_errors=structural,
        cells_ok=len(result.passed_cells),
        cells_nok=len(result.failed_cells),
        cells_unevaluated=unevaluated,
        coverage_pct=coverage_pct,
        quality_pct=quality_pct,
        headline=headline,
        no_data=no_data,
        by_column=by_column,
    )
