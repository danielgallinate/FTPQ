"""Worker de validación QA — hilo aparte para no bloquear la UI."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

from PySide6.QtCore import QObject, Signal, Slot

from core.analysis_types import TabularDataset
from core.app_log import log_event, log_exception
from core.reference_compare import load_reference_row_dicts, validate_reference_overlay
from core.schema_catalog_store import SchemaCatalogStore
from core.schema_validation import validate_schema_catalog
from core.reference_compare_types import ReferenceCompareConfig
from emrqa.template_key_store import TemplateKeyStore
from emrqa.validation_engine import validate_minibase_overlay
from emrqa.validation_models import ValidationTemplate
from emrqa.validation_storage import (
    TemplateKeyMismatchError,
    TemplateRequiresKeyError,
    load_validation_template,
)
from shell.qa_metrics import QaMetricsReport, build_qa_metrics
from shell.tabular_rows import dataset_to_row_dicts
from shell.reference_metrics import ReferenceCompareReport, build_reference_compare_report
from shell.schema_metrics import SchemaValidationReport, build_schema_validation_report
from shell.validation_panel import ValidationTab
from shell.validation_runner import QaHighlightMode, QaValidationResult, run_multi_template_validation


class ValidationPhase(str, Enum):
    PREPARE = "prepare"
    LOAD_TEMPLATES = "load_templates"
    TEMPLATE = "template"
    ROWS = "rows"
    METRICS = "metrics"
    APPLY = "apply"


@dataclass
class ValidationJob:
    job_id: int
    tab: ValidationTab
    dataset: TabularDataset
    evaluated_columns: set[str]
    name_to_index: dict[str, int]
    template: ValidationTemplate | None = None
    qa_template_paths: list[tuple[str, Path]] = field(default_factory=list)
    highlight_mode: QaHighlightMode = QaHighlightMode.FAIL_ANY
    file_name: str = ""
    visible_columns: list[str] = field(default_factory=list)
    snapshot_key: str = ""
    previous_metrics: QaMetricsReport | None = None
    cached_rows: list[dict[str, object]] | None = None
    key_store: TemplateKeyStore | None = None
    reference_config: ReferenceCompareConfig | None = None
    schema_id: str = ""


@dataclass
class ValidationJobResult:
    job_id: int
    tab: ValidationTab
    overlay: object
    qa_result: QaValidationResult | None = None
    metrics: QaMetricsReport | None = None
    messages: list[str] = field(default_factory=list)
    snapshot_key: str = ""
    row_dicts: list[dict[str, object]] | None = None
    reference_report: ReferenceCompareReport | None = None
    schema_report: SchemaValidationReport | None = None


@dataclass
class ValidationJobError:
    job_id: int
    message: str


class ValidationWorker(QObject):
    progress = Signal(str, int, int, str)
    finished = Signal(object)

    validate_requested = Signal(object)

    def __init__(self) -> None:
        super().__init__()

    @Slot(object)
    def _do_validate(self, job: ValidationJob) -> None:
        try:
            row_count = len(job.dataset.rows)
            log_event(
                f"validation start job={job.job_id} tab={job.tab.value} rows={row_count:,}"
            )

            if job.cached_rows is not None:
                rows = job.cached_rows
                self.progress.emit(
                    ValidationPhase.PREPARE.value,
                    row_count,
                    row_count,
                    "",
                )
            else:
                self.progress.emit(ValidationPhase.PREPARE.value, 0, row_count, "")

                def on_prepare(current: int, total: int) -> None:
                    self.progress.emit(
                        ValidationPhase.PREPARE.value,
                        current,
                        total,
                        "",
                    )

                rows = dataset_to_row_dicts(job.dataset, on_progress=on_prepare)

            if job.tab == ValidationTab.REFERENCE:
                config = job.reference_config
                if config is None or not config.is_ready() or config.reference_path is None:
                    raise ValueError("missing reference compare config")
                self.progress.emit(ValidationPhase.LOAD_TEMPLATES.value, 0, 1, "reference")
                _columns, reference_rows, total_ref = load_reference_row_dicts(
                    config.reference_path
                )
                if total_ref > len(reference_rows):
                    log_event(
                        f"reference truncated rows={len(reference_rows):,} total={total_ref:,}"
                    )
                overlay = validate_reference_overlay(
                    rows,
                    reference_rows,
                    config,
                    evaluated_columns=job.evaluated_columns,
                    name_to_index=job.name_to_index,
                    on_progress=lambda current, total: self.progress.emit(
                        ValidationPhase.ROWS.value,
                        current,
                        total,
                        config.reference_path.name if config.reference_path else "",
                    ),
                )
                report = build_reference_compare_report(
                    file_name=job.file_name or "—",
                    config=config,
                    result=overlay,
                    rows_compared=len(rows),
                    reference_rows_loaded=len(reference_rows),
                    reference_rows_total=total_ref,
                    name_to_index=job.name_to_index,
                )
                result = ValidationJobResult(
                    job_id=job.job_id,
                    tab=job.tab,
                    overlay=overlay,
                    messages=list(overlay.alerts or []),
                    row_dicts=rows,
                    reference_report=report,
                )
                self.finished.emit(result)
                log_event(f"validation done job={job.job_id}")
                return

            if job.tab == ValidationTab.SCHEMA:
                if not job.schema_id:
                    raise ValueError("missing schema catalog")
                catalog_store = SchemaCatalogStore()
                catalog = catalog_store.load(job.schema_id)
                file_columns = list(job.name_to_index.keys())
                self.progress.emit(
                    ValidationPhase.LOAD_TEMPLATES.value,
                    0,
                    1,
                    catalog.name,
                )

                def on_schema_progress(current: int, total: int) -> None:
                    self.progress.emit(
                        ValidationPhase.ROWS.value,
                        current,
                        total,
                        catalog.name,
                    )

                overlay = validate_schema_catalog(
                    catalog,
                    rows,
                    file_columns=file_columns,
                    name_to_index=job.name_to_index,
                    on_progress=on_schema_progress,
                )
                report = build_schema_validation_report(
                    file_name=job.file_name or "—",
                    catalog=catalog,
                    result=overlay,
                    rows_total=len(rows),
                    name_to_index=job.name_to_index,
                )
                result = ValidationJobResult(
                    job_id=job.job_id,
                    tab=job.tab,
                    overlay=overlay,
                    messages=list(overlay.alerts or []),
                    row_dicts=rows,
                    schema_report=report,
                )
                self.finished.emit(result)
                log_event(f"validation done job={job.job_id}")
                return

            if job.tab == ValidationTab.VALIDATION:
                template = job.template
                if template is None:
                    raise ValueError("missing template")
                overlay = validate_minibase_overlay(
                    template,
                    rows,
                    evaluated_columns=job.evaluated_columns,
                    name_to_index=job.name_to_index,
                    on_progress=lambda current, total: self.progress.emit(
                        ValidationPhase.ROWS.value,
                        current,
                        total,
                        template.header.name,
                    ),
                )
                result = ValidationJobResult(
                    job_id=job.job_id,
                    tab=job.tab,
                    overlay=overlay,
                    messages=list(overlay.alerts or []),
                    row_dicts=rows,
                )
                self.finished.emit(result)
                log_event(f"validation done job={job.job_id}")
                return

            templates: list[ValidationTemplate] = []
            skipped_messages: list[str] = []
            total_templates = len(job.qa_template_paths)
            for index, (template_id, path) in enumerate(job.qa_template_paths, start=1):
                self.progress.emit(
                    ValidationPhase.LOAD_TEMPLATES.value,
                    index,
                    total_templates,
                    template_id,
                )
                try:
                    templates.append(
                        load_validation_template(path, key_store=job.key_store)
                    )
                except (TemplateKeyMismatchError, TemplateRequiresKeyError) as exc:
                    skipped_messages.append(str(exc))
                    continue

            if not templates:
                detail = skipped_messages[0] if skipped_messages else "missing QA templates"
                raise ValueError(detail)

            def on_template_start(index: int, total: int, name: str) -> None:
                self.progress.emit(
                    ValidationPhase.TEMPLATE.value,
                    index,
                    total,
                    name,
                )

            def on_row_progress(current: int, total: int) -> None:
                self.progress.emit(
                    ValidationPhase.ROWS.value,
                    current,
                    total,
                    templates[0].header.name if len(templates) == 1 else "",
                )

            qa_result = run_multi_template_validation(
                templates,
                rows,
                evaluated_columns=job.evaluated_columns,
                name_to_index=job.name_to_index,
                highlight_mode=job.highlight_mode,
                on_row_progress=on_row_progress,
                on_template_start=on_template_start,
            )
            overlay = qa_result.overlay

            self.progress.emit(ValidationPhase.METRICS.value, 0, 1, "")
            metrics = build_qa_metrics(
                file_name=job.file_name,
                visible_columns=job.visible_columns,
                rows=rows,
                templates=templates,
                template_overlays=qa_result.template_overlays,
                merged=overlay,
                name_to_index=job.name_to_index,
                highlight_mode=job.highlight_mode,
                previous=job.previous_metrics,
            )
            self.progress.emit(ValidationPhase.METRICS.value, 1, 1, "")

            result = ValidationJobResult(
                job_id=job.job_id,
                tab=job.tab,
                overlay=overlay,
                qa_result=qa_result,
                metrics=metrics,
                snapshot_key=job.snapshot_key,
                row_dicts=rows,
                messages=skipped_messages,
            )
            self.finished.emit(result)
            log_event(f"validation done job={job.job_id}")
        except Exception as exc:  # noqa: BLE001
            log_exception("validation", exc)
            self.finished.emit(ValidationJobError(job_id=job.job_id, message=str(exc)))
