"""Tab Automatización — referencia de jobs guardados (solo lectura)."""
from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSplitter,
    QTextEdit,
    QVBoxLayout,
)

from core.emr_qa_job import load_job
from emrqa.validation_storage import knowledge_base_dir
from shell.job_metadata_dialog import default_job_description
from shell.job_export import job_cli_command
from ui.i18n import tr


def jobs_dir() -> Path:
    path = knowledge_base_dir("default") / "jobs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def list_job_paths() -> list[Path]:
    folder = jobs_dir()
    return sorted(folder.glob("*.job.json"), key=lambda item: item.name.casefold())


class AutomationTab(QFrame):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._selected_path: Path | None = None

        self._hint = QLabel()
        self._hint.setWordWrap(True)
        self._hint.setObjectName("configHint")

        self._refresh = QPushButton()
        self._refresh.clicked.connect(self.refresh_jobs)

        self._jobs = QListWidget()
        self._jobs.currentItemChanged.connect(self._on_job_selected)

        self._meta = QLabel()
        self._meta.setObjectName("configHint")
        self._meta.setWordWrap(True)

        self._docs_title = QLabel()
        self._docs_title.setObjectName("panelSubtitle")
        self._docs = QTextEdit()
        self._docs.setReadOnly(True)
        self._docs.setMaximumHeight(88)

        self._command_title = QLabel()
        self._command_title.setObjectName("panelSubtitle")
        self._command = QTextEdit()
        self._command.setReadOnly(True)
        self._command.setMaximumHeight(72)

        self._editor_title = QLabel()
        self._editor_title.setObjectName("panelSubtitle")
        self._editor = QTextEdit()
        self._editor.setReadOnly(True)
        self._editor.setPlaceholderText("{}")

        list_panel = QFrame()
        list_layout = QVBoxLayout(list_panel)
        list_layout.setContentsMargins(0, 0, 0, 0)
        list_layout.addWidget(self._refresh)
        list_layout.addWidget(self._jobs, stretch=1)

        detail_panel = QFrame()
        detail_layout = QVBoxLayout(detail_panel)
        detail_layout.setContentsMargins(0, 0, 0, 0)
        detail_layout.addWidget(self._meta)
        detail_layout.addWidget(self._docs_title)
        detail_layout.addWidget(self._docs)
        detail_layout.addWidget(self._command_title)
        detail_layout.addWidget(self._command)
        detail_layout.addWidget(self._editor_title)
        detail_layout.addWidget(self._editor, stretch=1)

        split = QSplitter(Qt.Orientation.Horizontal)
        split.addWidget(list_panel)
        split.addWidget(detail_panel)
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)
        layout.addWidget(self._hint)
        layout.addWidget(split, stretch=1)
        self.retranslate_ui()
        self.refresh_jobs()

    def retranslate_ui(self) -> None:
        self._hint.setText(tr("emr.automation.hint"))
        self._refresh.setText(tr("emr.automation.refresh_jobs"))
        self._command_title.setText(tr("emr.automation.command_title"))
        self._editor_title.setText(tr("emr.automation.editor_title"))
        self._docs_title.setText(tr("emr.job.metadata.description_label"))
        if self._selected_path is None:
            self._meta.setText(tr("emr.automation.pick_job"))
            self._docs.clear()
            self._command.clear()
            self._editor.clear()

    def refresh_jobs(self) -> None:
        current = self._selected_path
        self._jobs.blockSignals(True)
        self._jobs.clear()
        paths = list_job_paths()
        for path in paths:
            item = QListWidgetItem(path.name)
            item.setData(Qt.ItemDataRole.UserRole, str(path))
            self._jobs.addItem(item)
        self._jobs.blockSignals(False)
        if not paths:
            self._selected_path = None
            self.retranslate_ui()
            return
        restore_index = 0
        if current is not None:
            for index in range(self._jobs.count()):
                item = self._jobs.item(index)
                if item is not None and Path(str(item.data(Qt.ItemDataRole.UserRole))) == current:
                    restore_index = index
                    break
        self._jobs.setCurrentRow(restore_index)

    def select_job_path(self, path: Path) -> None:
        target = str(path.resolve())
        for index in range(self._jobs.count()):
            item = self._jobs.item(index)
            if item is not None and str(item.data(Qt.ItemDataRole.UserRole)) == target:
                self._jobs.setCurrentRow(index)
                return
        self.refresh_jobs()
        for index in range(self._jobs.count()):
            item = self._jobs.item(index)
            if item is not None and str(item.data(Qt.ItemDataRole.UserRole)) == target:
                self._jobs.setCurrentRow(index)
                return

    def _load_job_path(self, path: Path) -> None:
        self._selected_path = path
        try:
            job = load_job(path)
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            self._meta.setText(tr("emr.automation.job_load_fail", error=exc))
            self._docs.clear()
            self._command.clear()
            self._editor.clear()
            return
        self._meta.setText(
            tr(
                "emr.automation.job_meta",
                name=job.name,
                mode=job.mode,
                path=str(path),
                columns=len(job.evaluated_columns or ()),
            )
        )
        docs = job.description.strip() or default_job_description(job.mode)
        self._docs.setPlainText(docs)
        self._command.setPlainText(job_cli_command(path))
        self._editor.setPlainText(json.dumps(raw, indent=2, ensure_ascii=False) + "\n")

    def _on_job_selected(self, current: QListWidgetItem | None, _previous) -> None:
        if current is None:
            self._selected_path = None
            self.retranslate_ui()
            return
        path = Path(str(current.data(Qt.ItemDataRole.UserRole)))
        self._load_job_path(path)
