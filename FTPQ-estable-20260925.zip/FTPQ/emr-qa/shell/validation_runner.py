"""Validación multi-template — overlay verde/rojo/naranja sobre el grid."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from collections.abc import Callable

from emrqa.validation_engine import validate_minibase_overlay, validate_rows
from emrqa.validation_models import ValidationTemplate
from shell.validation_progress import RowProgressCallback

CellOutcome = str  # "passed" | "failed" | "neutral"


class QaHighlightMode(str, Enum):
    FAIL_ANY = "fail_any"
    DISCREPANCY = "discrepancy"


@dataclass
class OverlayState:
    passed_cells: set[tuple[int, int]] = field(default_factory=set)
    failed_cells: set[tuple[int, int]] = field(default_factory=set)
    conflict_cells: set[tuple[int, int]] = field(default_factory=set)
    gray_cells: set[tuple[int, int]] = field(default_factory=set)
    evaluated_columns: set[str] = field(default_factory=set)
    percent: float = 0.0
    passed_count: int = 0
    total_count: int = 0
    rows_with_key_errors: int = 0
    alerts: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class TemplateOverlay:
    name: str
    passed: set[tuple[int, int]]
    failed: set[tuple[int, int]]
    gray: set[tuple[int, int]]
    alerts: list[str]


@dataclass
class QaValidationResult:
    overlay: OverlayState
    template_overlays: list[TemplateOverlay] = field(default_factory=list)


def _cell_outcome(coord: tuple[int, int], overlay: TemplateOverlay) -> CellOutcome:
    if coord in overlay.failed:
        return "failed"
    if coord in overlay.passed:
        return "passed"
    return "neutral"


def _merge_outcomes(outcomes: list[CellOutcome], mode: QaHighlightMode) -> CellOutcome:
    if not outcomes:
        return "neutral"
    if mode == QaHighlightMode.DISCREPANCY:
        judged = [item for item in outcomes if item != "neutral"]
        if len(judged) >= 2 and len(set(judged)) > 1:
            return "conflict"
        if "failed" in judged:
            return "failed"
        if "passed" in judged:
            return "passed"
        return "neutral"
    if "failed" in outcomes:
        return "failed"
    if "passed" in outcomes:
        return "passed"
    return "neutral"


def _template_overlay(
    template: ValidationTemplate,
    rows: list[dict[str, object]],
    *,
    evaluated_columns: set[str],
    name_to_index: dict[str, int],
    on_progress: RowProgressCallback | None = None,
) -> TemplateOverlay:
    prefix = template.header.name
    if template.minibase.records:
        overlay = validate_minibase_overlay(
            template,
            rows,
            evaluated_columns=evaluated_columns,
            name_to_index=name_to_index,
            on_progress=on_progress,
        )
        return TemplateOverlay(
            name=prefix,
            passed=set(overlay.passed_cells),
            failed=set(overlay.failed_cells),
            gray=set(overlay.gray_cells),
            alerts=[f"{prefix}: {alert}" for alert in overlay.alerts[:20]],
        )

    result = validate_rows(template, rows, evaluated_columns=evaluated_columns, on_progress=on_progress)
    passed: set[tuple[int, int]] = set()
    failed: set[tuple[int, int]] = set()
    for cell in result.cells:
        if not cell.evaluated:
            continue
        col_index = name_to_index.get(cell.column)
        if col_index is None:
            continue
        coord = (cell.row_index, col_index)
        if cell.passed:
            passed.add(coord)
        else:
            failed.add(coord)
    return TemplateOverlay(
        name=prefix,
        passed=passed,
        failed=failed,
        gray=set(),
        alerts=[f"{prefix}: {alert}" for alert in result.summary.alerts[:20]],
    )


TemplateProgressCallback = Callable[[int, int, str], None]


def run_multi_template_validation(
    templates: list[ValidationTemplate],
    rows: list[dict[str, object]],
    *,
    evaluated_columns: set[str],
    name_to_index: dict[str, int],
    highlight_mode: QaHighlightMode = QaHighlightMode.FAIL_ANY,
    on_row_progress: RowProgressCallback | None = None,
    on_template_start: TemplateProgressCallback | None = None,
) -> QaValidationResult:
    if not templates or not rows:
        return QaValidationResult(
            overlay=OverlayState(evaluated_columns=set(evaluated_columns)),
        )

    overlays = []
    for index, template in enumerate(templates):
        if on_template_start is not None:
            on_template_start(index + 1, len(templates), template.header.name)
        overlays.append(
            _template_overlay(
                template,
                rows,
                evaluated_columns=evaluated_columns,
                name_to_index=name_to_index,
                on_progress=on_row_progress,
            )
        )

    all_coords: set[tuple[int, int]] = set()
    for overlay in overlays:
        all_coords |= overlay.passed | overlay.failed | overlay.gray

    passed: set[tuple[int, int]] = set()
    failed: set[tuple[int, int]] = set()
    conflict: set[tuple[int, int]] = set()
    gray: set[tuple[int, int]] = set()
    key_error_rows: set[int] = set()
    alerts: list[str] = []
    for overlay in overlays:
        alerts.extend(overlay.alerts)

    for coord in all_coords:
        outcomes = [_cell_outcome(coord, overlay) for overlay in overlays]
        merged = _merge_outcomes(outcomes, highlight_mode)
        if merged == "failed":
            failed.add(coord)
            key_error_rows.add(coord[0])
        elif merged == "conflict":
            conflict.add(coord)
            key_error_rows.add(coord[0])
        elif merged == "passed":
            passed.add(coord)
        elif any(item == "neutral" and coord in overlay.gray for item, overlay in zip(outcomes, overlays)):
            gray.add(coord)

    for coord in failed:
        passed.discard(coord)
        conflict.discard(coord)
    for coord in conflict:
        passed.discard(coord)

    total = len(passed) + len(failed) + len(conflict)
    percent = (100.0 * len(passed) / total) if total else 0.0
    overlay = OverlayState(
        passed_cells=passed,
        failed_cells=failed,
        conflict_cells=conflict,
        gray_cells=gray,
        evaluated_columns=set(evaluated_columns),
        percent=round(percent, 2),
        passed_count=len(passed),
        total_count=total,
        rows_with_key_errors=len(key_error_rows),
        alerts=alerts,
    )
    return QaValidationResult(overlay=overlay, template_overlays=overlays)
