"""Diálogo pantalla completa — reporte comparación referencia."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from shell.qa_metrics_layout import (
    configure_metrics_scroll,
    resolve_wallpaper_context,
    sync_metrics_scroll_content,
)
from shell.reference_metrics import ReferenceCompareReport
from shell.reference_metrics_charts import ReferenceMetricsChartsWidget
from shell.reference_metrics_pdf_export import (
    default_pdf_filename,
    export_reference_metrics_pdf,
    pick_pdf_export_path,
)
from shell.reference_metrics_report_view import ReferenceMetricsReportView
from ui.i18n import tr
from ui.theme.theme_engine import ThemeEngine, WallpaperHost


class ReferenceMetricsReportDialog(QDialog):
    def __init__(
        self,
        report: ReferenceCompareReport,
        *,
        nok_only: bool = False,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("referenceMetricsDialog")
        self._report = report
        self._nok_only = nok_only
        self._main_window = parent

        self.setWindowTitle(
            tr("emr.ref.fullscreen.title", file=report.file_name, reference=report.reference_name)
        )
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.resize(1180, 820)

        theme, wallpaper_path = resolve_wallpaper_context(parent)
        self._host = WallpaperHost(theme, wallpaper_path=wallpaper_path)

        self._kpi_rows = QLabel()
        self._kpi_cells = QLabel()
        self._kpi_no_match = QLabel()
        self._kpi_deltas = QLabel()
        for label in (self._kpi_rows, self._kpi_cells, self._kpi_no_match, self._kpi_deltas):
            label.setObjectName("configHint")
            label.setWordWrap(True)

        kpi_grid = QGridLayout()
        kpi_grid.setContentsMargins(0, 0, 0, 0)
        kpi_grid.setHorizontalSpacing(12)
        kpi_grid.setVerticalSpacing(4)
        kpi_grid.addWidget(self._kpi_rows, 0, 0)
        kpi_grid.addWidget(self._kpi_cells, 0, 1)
        kpi_grid.addWidget(self._kpi_no_match, 1, 0)
        kpi_grid.addWidget(self._kpi_deltas, 1, 1)

        self._nok_filter = QCheckBox()
        self._nok_filter.setChecked(nok_only)
        self._nok_filter.toggled.connect(self._on_nok_filter)

        self._copy = QPushButton()
        self._copy.clicked.connect(self._copy_report)
        self._copy_csv = QPushButton()
        self._copy_csv.clicked.connect(self._copy_csv_text)
        self._export_pdf = QPushButton()
        self._export_pdf.clicked.connect(self._export_pdf_file)
        self._close = QPushButton()
        self._close.clicked.connect(self.accept)

        actions = QHBoxLayout()
        actions.addWidget(self._nok_filter)
        actions.addStretch(1)
        actions.addWidget(self._copy)
        actions.addWidget(self._copy_csv)
        actions.addWidget(self._export_pdf)
        actions.addWidget(self._close)

        self._report_view = ReferenceMetricsReportView()
        self._report_view.set_report(report, nok_only=nok_only)
        self._charts = ReferenceMetricsChartsWidget()
        self._charts.set_report(report, nok_only=nok_only)

        self._scroll_content = QWidget()
        self._scroll_content.setObjectName("referenceMetricsScrollHost")
        content_layout = QVBoxLayout(self._scroll_content)
        content_layout.setContentsMargins(0, 0, 8, 0)
        content_layout.setSpacing(16)
        content_layout.addWidget(self._report_view)
        content_layout.addWidget(self._charts, 0, Qt.AlignmentFlag.AlignHCenter)

        self._scroll = QScrollArea()
        self._scroll.setObjectName("referenceMetricsScroll")
        configure_metrics_scroll(self._scroll)
        self._scroll.setWidget(self._scroll_content)

        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(8)
        body_layout.addLayout(kpi_grid)
        body_layout.addLayout(actions)
        body_layout.addWidget(self._scroll, stretch=1)

        host_layout = QVBoxLayout(self._host)
        host_layout.setContentsMargins(
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
        )
        host_layout.addWidget(body)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(self._host)

        self._apply_kpis(report)
        self.retranslate_ui()
        self._update_scroll_content_size()

    def retranslate_ui(self) -> None:
        self._nok_filter.setText(tr("emr.qa.metrics.nok_only"))
        self._copy.setText(tr("emr.qa.metrics.copy_report"))
        self._copy_csv.setText(tr("emr.qa.metrics.copy_csv"))
        self._export_pdf.setText(tr("emr.qa.metrics.export_pdf"))
        self._close.setText(tr("emr.ref.fullscreen.close"))
        self.setWindowTitle(
            tr("emr.ref.fullscreen.title", file=self._report.file_name, reference=self._report.reference_name)
        )
        self._apply_kpis(self._report)
        self._report_view.retranslate_ui()
        self._charts.retranslate_ui()
        self._update_scroll_content_size()

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        self._sync_wallpaper_from_parent()
        self.showMaximized()
        self._update_scroll_content_size()

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._update_scroll_content_size()

    def _sync_wallpaper_from_parent(self) -> None:
        main_host = getattr(self._main_window, "_host", None)
        if main_host is not None:
            self._host.set_wallpaper(main_host._wallpaper_path)
        self._host.refresh_scrim()

    def _apply_kpis(self, report: ReferenceCompareReport) -> None:
        self._kpi_rows.setText(
            tr(
                "emr.ref.summary.kpi_rows",
                matched=f"{report.rows_matched_key:,}",
                total=f"{report.rows_compared:,}",
                pct=f"{report.row_match_pct:.2f}",
            )
        )
        self._kpi_cells.setText(
            tr(
                "emr.ref.summary.kpi_cells",
                ok=f"{report.cells_ok:,}",
                total=f"{report.cells_ok + report.cells_nok:,}",
                pct=f"{report.cell_match_pct:.2f}",
            )
        )
        self._kpi_no_match.setText(
            tr(
                "emr.ref.summary.kpi_no_match",
                count=report.rows_without_match,
                ambiguous=report.rows_ambiguous_key,
            )
        )
        self._kpi_deltas.setText(
            tr(
                "emr.ref.summary.kpi_deltas",
                count=report.cells_nok,
                pairs=report.pairs_compared,
            )
        )

    def _update_scroll_content_size(self) -> None:
        sync_metrics_scroll_content(
            self._scroll,
            self._scroll_content,
            self._report_view,
            self._charts,
        )

    def _on_nok_filter(self, checked: bool) -> None:
        self._nok_only = checked
        self._report_view.set_report(self._report, nok_only=checked)
        self._charts.set_report(self._report, nok_only=checked)
        self._update_scroll_content_size()

    def _copy_report(self) -> None:
        QApplication.clipboard().setText(
            self._report.to_copyable_text(nok_only=self._nok_only)
        )

    def _copy_csv_text(self) -> None:
        QApplication.clipboard().setText(self._report.to_csv(nok_only=self._nok_only))

    def _export_pdf_file(self) -> None:
        default_name = default_pdf_filename(self._report.file_name)
        path = pick_pdf_export_path(self, default_name=default_name)
        if path is None:
            return
        try:
            export_reference_metrics_pdf(
                path,
                report_view=self._report_view,
                charts=self._charts,
            )
        except OSError as exc:
            QMessageBox.warning(
                self,
                tr("emr.qa.metrics.export_pdf"),
                tr("emr.qa.metrics.export_pdf_fail", error=exc),
            )
            return
        QMessageBox.information(
            self,
            tr("emr.qa.metrics.export_pdf"),
            tr("emr.qa.metrics.export_pdf_done", path=str(path)),
        )
