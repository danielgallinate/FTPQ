"""Vista tabular del reporte QA — tablas Qt en lugar de texto ASCII."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHeaderView,
    QLabel,
    QSizePolicy,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from shell.qa_metrics import QaMetricsReport, TemplateMetrics
from ui.i18n import tr


def _readonly_item(text: str) -> QTableWidgetItem:
    item = QTableWidgetItem(text)
    item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)
    return item


def _configure_table(table: QTableWidget) -> None:
    table.setObjectName("qaMetricsTable")
    table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
    table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
    table.setAlternatingRowColors(True)
    table.setShowGrid(True)
    table.verticalHeader().setVisible(False)
    header = table.horizontalHeader()
    header.setStretchLastSection(False)
    header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
    table.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
    table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)


def _finalize_table_size(table: QTableWidget) -> None:
    table.resizeColumnsToContents()
    table.resizeRowsToContents()
    width = table.frameWidth() * 2
    if table.verticalHeader().isVisible():
        width += table.verticalHeader().width()
    for column in range(table.columnCount()):
        width += table.columnWidth(column)
    height = table.frameWidth() * 2 + table.horizontalHeader().height()
    for row in range(table.rowCount()):
        height += table.rowHeight(row)
    w = max(width, 120)
    h = max(height, table.horizontalHeader().height() + 8)
    table.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
    table.setFixedSize(w, h)


def _section_height(widget: QWidget) -> int:
    if isinstance(widget, QTableWidget):
        return widget.height()
    return max(widget.minimumHeight(), widget.sizeHint().height(), widget.height())


def _section_width(widget: QWidget) -> int:
    if isinstance(widget, QTableWidget):
        return widget.width()
    return max(widget.minimumWidth(), widget.sizeHint().width(), widget.width())


class QaMetricsReportView(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("qaMetricsReportView")
        self._report: QaMetricsReport | None = None
        self._nok_only = False

        self._meta = QLabel()
        self._meta.setObjectName("configHint")
        self._meta.setWordWrap(True)
        self._meta.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self._summary_title = QLabel()
        self._summary_title.setObjectName("panelSubtitle")
        self._summary_table = QTableWidget()
        _configure_table(self._summary_table)
        self._summary_table.setColumnCount(2)

        self._columns_title = QLabel()
        self._columns_title.setObjectName("panelSubtitle")
        self._columns_table = QTableWidget()
        _configure_table(self._columns_table)

        self._templates_title = QLabel()
        self._templates_title.setObjectName("panelSubtitle")
        self._templates_table = QTableWidget()
        _configure_table(self._templates_table)

        self._not_applicable_title = QLabel()
        self._not_applicable_title.setObjectName("panelSubtitle")
        self._not_applicable = QLabel()
        self._not_applicable.setObjectName("configHint")
        self._not_applicable.setWordWrap(True)
        self._not_applicable.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.addWidget(self._meta)
        layout.addWidget(self._summary_title)
        layout.addWidget(self._summary_table)
        layout.addWidget(self._columns_title)
        layout.addWidget(self._columns_table)
        layout.addWidget(self._templates_title)
        layout.addWidget(self._templates_table)
        layout.addWidget(self._not_applicable_title)
        layout.addWidget(self._not_applicable)
        layout.addStretch(0)
        self.setSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Minimum)
        self.retranslate_ui()

    def update_content_size(self) -> None:
        if self._report is None:
            self.setMinimumSize(0, 0)
            return
        width = 0
        height = 0
        visible_count = 0
        for widget in (
            self._meta,
            self._summary_title,
            self._summary_table,
            self._columns_title,
            self._columns_table,
            self._templates_title,
            self._templates_table,
            self._not_applicable_title,
            self._not_applicable,
        ):
            if not widget.isVisible():
                continue
            visible_count += 1
            width = max(width, _section_width(widget))
            height += _section_height(widget)
        layout = self.layout()
        if layout is not None:
            height += layout.spacing() * max(0, visible_count - 1)
            height += layout.contentsMargins().top() + layout.contentsMargins().bottom()
            width += layout.contentsMargins().left() + layout.contentsMargins().right()
        self.setMinimumSize(max(width, 320), max(height, 120))
        self.resize(self.minimumWidth(), self.minimumHeight())
        self.updateGeometry()

    def retranslate_ui(self) -> None:
        self._summary_title.setText(tr("emr.qa.metrics.table.section_summary"))
        self._columns_title.setText(tr("emr.qa.metrics.report.section_columns"))
        self._templates_title.setText(tr("emr.qa.metrics.report.section_templates"))
        self._not_applicable_title.setText(tr("emr.qa.metrics.report.not_applicable_list"))
        self._summary_table.setHorizontalHeaderLabels(
            [
                tr("emr.qa.metrics.table.metric"),
                tr("emr.qa.metrics.table.value"),
            ]
        )
        if self._report is not None:
            self.set_report(self._report, nok_only=self._nok_only)

    def set_report(self, report: QaMetricsReport | None, *, nok_only: bool = False) -> None:
        self._report = report
        self._nok_only = nok_only
        if report is None:
            self._meta.clear()
            self._summary_table.setRowCount(0)
            self._columns_table.setRowCount(0)
            self._templates_table.setRowCount(0)
            self._not_applicable.clear()
            self._not_applicable_title.hide()
            self._not_applicable.hide()
            return

        self._meta.setText(report.meta_block_text())
        self._fill_summary(report)
        self._fill_columns(report)
        self._fill_templates(report)
        if report.not_applicable_columns:
            self._not_applicable_title.show()
            self._not_applicable.show()
            self._not_applicable.setText(", ".join(report.not_applicable_columns))
        else:
            self._not_applicable_title.hide()
            self._not_applicable.hide()
        self.update_content_size()

    def _fill_summary(self, report: QaMetricsReport) -> None:
        rows: list[tuple[str, str]] = [
            (
                tr("emr.qa.metrics.table.coverage"),
                tr(
                    "emr.qa.metrics.table.coverage_value",
                    pct=f"{report.coverage_pct:.2f}",
                    judged=report.judged_cells,
                    eligible=report.eligible_cells,
                ),
            ),
            (
                tr("emr.qa.metrics.table.quality"),
                tr(
                    "emr.qa.metrics.table.quality_value",
                    pct=f"{report.quality_pct:.2f}",
                    ok=report.ok_cells,
                    judged=report.judged_cells,
                ),
            ),
            (
                tr("emr.qa.metrics.table.localization"),
                tr(
                    "emr.qa.metrics.table.localization_value",
                    pct=f"{report.localization_pct:.2f}",
                    located=report.rows_located,
                    complete=report.rows_key_complete,
                ),
            ),
            (
                tr("emr.qa.metrics.table.conflict"),
                tr(
                    "emr.qa.metrics.table.conflict_value",
                    pct=f"{report.conflict_pct:.2f}",
                    count=report.conflict_cells,
                    judged=report.judged_cells,
                ),
            ),
            (tr("emr.qa.metrics.report.rows_total"), str(report.rows_total)),
            (tr("emr.qa.metrics.report.rows_key_complete"), str(report.rows_key_complete)),
            (tr("emr.qa.metrics.report.rows_located"), str(report.rows_located)),
            (tr("emr.qa.metrics.report.rows_partial"), str(report.rows_partial)),
            (tr("emr.qa.metrics.report.rows_orphan"), str(report.rows_orphan)),
            (tr("emr.qa.metrics.report.rows_key_conflict"), str(report.rows_key_conflict)),
            (tr("emr.qa.metrics.table.unevaluated"), str(report.unevaluated_cells)),
        ]
        if report.delta is not None:
            delta = report.delta
            rows.extend(
                [
                    (tr("emr.qa.metrics.table.delta_ok"), f"{delta.ok_cells:+d}"),
                    (tr("emr.qa.metrics.table.delta_nok"), f"{delta.nok_cells:+d}"),
                    (tr("emr.qa.metrics.table.delta_conflict"), f"{delta.conflict_cells:+d}"),
                    (
                        tr("emr.qa.metrics.table.delta_coverage"),
                        f"{delta.coverage_pct:+.1f} pp",
                    ),
                    (
                        tr("emr.qa.metrics.table.delta_quality"),
                        f"{delta.quality_pct:+.1f} pp",
                    ),
                    (
                        tr("emr.qa.metrics.table.delta_localization"),
                        f"{delta.localization_pct:+.1f} pp",
                    ),
                ]
            )
        self._summary_table.setRowCount(len(rows))
        for row_index, (label, value) in enumerate(rows):
            self._summary_table.setItem(row_index, 0, _readonly_item(label))
            self._summary_table.setItem(row_index, 1, _readonly_item(value))
        _finalize_table_size(self._summary_table)

    def _fill_columns(self, report: QaMetricsReport) -> None:
        headers = [
            tr("emr.qa.metrics.table.col_name"),
            tr("emr.qa.metrics.table.col_eligible"),
            tr("emr.qa.metrics.table.col_judged"),
            tr("emr.qa.metrics.table.col_ok"),
            tr("emr.qa.metrics.table.col_nok"),
            tr("emr.qa.metrics.table.col_conflict"),
            tr("emr.qa.metrics.table.col_unevaluated"),
            tr("emr.qa.metrics.table.col_ok_pct"),
            tr("emr.qa.metrics.table.col_status"),
        ]
        self._columns_table.setColumnCount(len(headers))
        self._columns_table.setHorizontalHeaderLabels(headers)
        items = sorted(report.by_column.values(), key=lambda item: item.column)
        if self._nok_only:
            items = [item for item in items if item.applicable and item.nok > 0]
        self._columns_table.setRowCount(len(items))
        for row_index, metrics in enumerate(items):
            if not metrics.applicable:
                values = [
                    metrics.column,
                    "—",
                    "—",
                    "—",
                    "—",
                    "—",
                    "—",
                    "—",
                    tr("emr.qa.metrics.table.not_applicable"),
                ]
            else:
                values = [
                    metrics.column,
                    str(metrics.eligible),
                    str(metrics.judged),
                    str(metrics.ok),
                    str(metrics.nok),
                    str(metrics.conflict),
                    str(metrics.unevaluated),
                    f"{metrics.ok_pct:.2f}%",
                    "",
                ]
            for col_index, value in enumerate(values):
                self._columns_table.setItem(row_index, col_index, _readonly_item(value))
        _finalize_table_size(self._columns_table)

    def _fill_templates(self, report: QaMetricsReport) -> None:
        headers = [
            tr("emr.qa.metrics.table.tpl_name"),
            tr("emr.qa.metrics.table.col_judged"),
            tr("emr.qa.metrics.table.col_ok"),
            tr("emr.qa.metrics.table.col_nok"),
            tr("emr.qa.metrics.table.col_conflict"),
            tr("emr.qa.metrics.table.tpl_loc_pct"),
            tr("emr.qa.metrics.table.tpl_located"),
            tr("emr.qa.metrics.table.tpl_key_complete"),
            tr("emr.qa.metrics.table.tpl_partial"),
            tr("emr.qa.metrics.table.tpl_orphan"),
            tr("emr.qa.metrics.table.tpl_key_conflict"),
        ]
        self._templates_table.setColumnCount(len(headers))
        self._templates_table.setHorizontalHeaderLabels(headers)
        rows: list[TemplateMetrics] = []
        for name in report.template_names:
            metrics = report.by_template.get(name)
            if metrics is not None:
                rows.append(metrics)
        self._templates_table.setRowCount(len(rows))
        for row_index, metrics in enumerate(rows):
            values = [
                metrics.name,
                str(metrics.judged),
                str(metrics.ok),
                str(metrics.nok),
                str(metrics.conflict),
                f"{metrics.localization_pct:.2f}%",
                str(metrics.rows_located),
                str(metrics.rows_key_complete),
                str(metrics.rows_partial),
                str(metrics.rows_orphan),
                str(metrics.rows_key_conflict),
            ]
            for col_index, value in enumerate(values):
                self._templates_table.setItem(row_index, col_index, _readonly_item(value))
        _finalize_table_size(self._templates_table)
        self._templates_title.setVisible(bool(rows))
        self._templates_table.setVisible(bool(rows))
