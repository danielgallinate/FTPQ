"""Exportar job de automatización desde el estado actual de Probar."""
from __future__ import annotations

from pathlib import Path

from core.emr_qa_job import (
    EmrQaJob,
    JobQaSection,
    JobReferenceSection,
    JobSchemaSection,
    JobThresholds,
    JobTimezone,
    JobValidationSection,
    JobMode,
    load_job,
)
from core.reference_compare_types import ComparePairMapping, ReferenceCompareConfig
from core.catalog_types import ColumnCatalogBinding
from emrqa.validation_storage import templates_dir


def _relative_template_path(path: Path, knowledge_base_id: str) -> str:
    resolved = path.resolve()
    base = templates_dir(knowledge_base_id).resolve()
    try:
        return resolved.relative_to(base).as_posix()
    except ValueError:
        return resolved.name


def build_job_from_session(
    *,
    name: str,
    mode: JobMode,
    description: str = "",
    evaluated_columns: list[str],
    max_rows: int | None,
    reference_config: ReferenceCompareConfig | None,
    left_catalog_bindings: dict[str, ColumnCatalogBinding],
    qa_template_paths: list[tuple[str, Path]],
    highlight_discrepancy: bool,
    validation_template_path: Path | None,
    schema_id: str = "",
    timezone: JobTimezone | None,
    knowledge_base_id: str = "default",
    thresholds: JobThresholds | None = None,
    row_limit: str | None = None,
    file_path: Path | None = None,
    reference_file_path: Path | None = None,
) -> EmrQaJob:
    reference_section = JobReferenceSection()
    if reference_config is not None:
        reference_section = JobReferenceSection(
            duplicate_policy=reference_config.duplicate_policy,
            pairs=list(reference_config.pairs),
            left_catalog_bindings=dict(left_catalog_bindings),
        )

    qa_section = JobQaSection(
        template_paths=tuple(
            _relative_template_path(path, knowledge_base_id)
            for _template_id, path in qa_template_paths
        ),
        highlight_mode="discrepancy" if highlight_discrepancy else "fail_any",
    )

    validation_section = JobValidationSection()
    if validation_template_path is not None:
        validation_section = JobValidationSection(
            template_path=_relative_template_path(validation_template_path, knowledge_base_id),
        )

    schema_section = JobSchemaSection(schema_id=schema_id.strip()) if schema_id.strip() else JobSchemaSection()

    file_text = str(file_path.resolve()) if file_path is not None else None
    reference_text = (
        str(reference_file_path.resolve()) if reference_file_path is not None else None
    )
    resolved_row_limit = (row_limit.strip() if row_limit else None) or (
        str(max_rows) if max_rows is not None else None
    )
    return EmrQaJob(
        name=name,
        mode=mode,
        description=description.strip(),
        max_rows=None,
        row_limit=resolved_row_limit,
        evaluated_columns=tuple(evaluated_columns),
        knowledge_base_id=knowledge_base_id,
        reference=reference_section,
        qa=qa_section,
        validation=validation_section,
        schema=schema_section,
        timezone=timezone,
        thresholds=thresholds or JobThresholds(),
        file=file_text,
        reference_file=reference_text,
    )


def job_cli_command(job_path: Path, *, repo_root: Path | None = None) -> str:
    root = repo_root or Path(__file__).resolve().parents[2]
    script = root / "scripts" / "run_emr_qa_job.sh"
    job = load_job(job_path.resolve())
    base = f'{script} "{job_path}" --file "/ruta/export.csv"'
    if job.mode == "reference":
        return f'{base} --reference "/ruta/referencia.csv"'
    return base
