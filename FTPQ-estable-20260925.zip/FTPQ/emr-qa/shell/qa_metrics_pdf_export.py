"""Exportación PDF del reporte QA — tablas Qt + gráficos."""
from __future__ import annotations

import re
from pathlib import Path

from PySide6.QtCore import Qt, QSize, QSizeF
from PySide6.QtGui import QColor, QPageSize, QPainter, QPdfWriter, QPixmap
from PySide6.QtWidgets import QApplication, QFileDialog, QWidget

from shell.metrics_pdf_export_theme import (
    apply_pdf_light_theme,
    pin_widget_to_content,
    restore_pdf_theme,
    style_charts_for_pdf,
)
from shell.qa_metrics_charts import QaMetricsChartsWidget
from shell.qa_metrics_report_view import QaMetricsReportView
from ui.i18n import tr

_PDF_DPI = 150
_PAGE_MARGIN_PT = 36
_A4 = QPageSize(QPageSize.PageSizeId.A4)
_PDF_BACKGROUND = QColor("#FFFFFF")


def default_pdf_filename(source_file_name: str) -> str:
    stem = Path(source_file_name).stem or "qa_report"
    safe = re.sub(r"[^\w\-.]+", "_", stem).strip("_")
    return f"{safe or 'qa_report'}_qa_report.pdf"


def pick_pdf_export_path(parent: QWidget, *, default_name: str) -> Path | None:
    downloads = Path.home() / "Downloads"
    start = downloads / default_name if downloads.is_dir() else Path(default_name)
    selected, _filter = QFileDialog.getSaveFileName(
        parent,
        tr("emr.qa.metrics.export_pdf_title"),
        str(start),
        tr("emr.qa.metrics.export_pdf_filter"),
    )
    if not selected:
        return None
    path = Path(selected)
    if path.suffix.lower() != ".pdf":
        path = path.with_suffix(".pdf")
    return path


def export_qa_metrics_pdf(
    path: Path | str,
    *,
    report_view: QaMetricsReportView,
    charts: QaMetricsChartsWidget,
) -> None:
    report_view.update_content_size()
    charts.update_content_size(content_width=max(report_view.minimumWidth(), 640))
    QApplication.processEvents()

    report_snapshot = apply_pdf_light_theme(report_view)
    charts_snapshot = apply_pdf_light_theme(charts)
    try:
        charts.refresh_display()
        style_charts_for_pdf(charts)
        QApplication.processEvents()
        report_pixmap = _render_widget(report_view)
        charts_pixmap = _render_widget(charts)
    finally:
        restore_pdf_theme(report_view, report_snapshot)
        restore_pdf_theme(charts, charts_snapshot)
        charts.refresh_display()
        QApplication.processEvents()

    _write_sectioned_pdf(Path(path), report_pixmap, charts_pixmap)


def _render_widget(widget: QWidget) -> QPixmap:
    pin_widget_to_content(widget)
    widget.ensurePolished()
    width = widget.width()
    height = widget.height()

    pixmap = QPixmap(QSize(width, height))
    pixmap.fill(_PDF_BACKGROUND)
    widget.render(pixmap)
    return pixmap


def _a4_content_size(writer: QPdfWriter) -> tuple[int, int]:
    return (
        writer.width() - 2 * _PAGE_MARGIN_PT,
        writer.height() - 2 * _PAGE_MARGIN_PT,
    )


def _page_size_for_pixmap(
    pixmap: QPixmap,
    *,
    fallback: QPageSize = _A4,
) -> QPageSize:
    content_w = pixmap.width() + 2 * _PAGE_MARGIN_PT
    content_h = pixmap.height() + 2 * _PAGE_MARGIN_PT
    a4_w = fallback.size(QPageSize.Unit.Point).width()
    a4_h = fallback.size(QPageSize.Unit.Point).height()
    page_w = max(a4_w, float(content_w))
    page_h = max(a4_h, float(content_h))
    return QPageSize(QSizeF(page_w, page_h), QPageSize.Unit.Point)


def _write_sectioned_pdf(path: Path, report: QPixmap, charts: QPixmap) -> None:
    writer = QPdfWriter(str(path))
    writer.setPageSize(_A4)
    writer.setResolution(_PDF_DPI)
    writer.setTitle(path.stem)

    painter = QPainter(writer)
    try:
        _paginate_pixmap_vertical(writer, painter, report, fit_width=True)
        if not charts.isNull() and charts.height() > 0 and charts.width() > 0:
            chart_page = _page_size_for_pixmap(charts)
            writer.setPageSize(chart_page)
            writer.newPage()
            _draw_pixmap_fit_page(writer, painter, charts)
    finally:
        painter.end()


def _paginate_pixmap_vertical(
    writer: QPdfWriter,
    painter: QPainter,
    pixmap: QPixmap,
    *,
    fit_width: bool,
) -> None:
    content_width, content_height = _a4_content_size(writer)
    scale = content_width / max(pixmap.width(), 1) if fit_width else 1.0
    slice_height = max(int(content_height / scale), 1)

    y_source = 0
    first_page = True
    while y_source < pixmap.height():
        if not first_page:
            writer.newPage()
            writer.setPageSize(_A4)
        first_page = False

        remaining = pixmap.height() - y_source
        chunk_height = min(slice_height, remaining)
        chunk = pixmap.copy(0, y_source, pixmap.width(), chunk_height)

        painter.save()
        painter.fillRect(0, 0, writer.width(), writer.height(), _PDF_BACKGROUND)
        painter.translate(_PAGE_MARGIN_PT, _PAGE_MARGIN_PT)
        painter.scale(scale, scale)
        painter.drawPixmap(0, 0, chunk)
        painter.restore()

        y_source += chunk_height


def _draw_pixmap_fit_page(writer: QPdfWriter, painter: QPainter, pixmap: QPixmap) -> None:
    content_width, content_height = _a4_content_size(writer)
    page_w = writer.width()
    page_h = writer.height()
    scale = min(
        content_width / max(pixmap.width(), 1),
        content_height / max(pixmap.height(), 1),
        1.0,
    )
    target_w = int(pixmap.width() * scale)
    target_h = int(pixmap.height() * scale)
    x = _PAGE_MARGIN_PT
    y = _PAGE_MARGIN_PT

    painter.fillRect(0, 0, page_w, page_h, _PDF_BACKGROUND)
    painter.save()
    painter.translate(x, y)
    painter.scale(scale, scale)
    painter.drawPixmap(0, 0, pixmap)
    painter.restore()
