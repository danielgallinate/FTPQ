"""Snapshot de overlay del grid — uno por tab de validación."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class GridOverlaySnapshot:
    passed: set[tuple[int, int]] = field(default_factory=set)
    failed: set[tuple[int, int]] = field(default_factory=set)
    conflict: set[tuple[int, int]] = field(default_factory=set)
    gray: set[tuple[int, int]] = field(default_factory=set)
    reference_values: dict[tuple[int, int], str] = field(default_factory=dict)
    cells_without_reference: set[tuple[int, int]] = field(default_factory=set)
    catalog_displays: dict[tuple[int, int], str] = field(default_factory=dict)
    progress_label: str = ""
    percent: float = 0.0
    passed_count: int = 0
    total_count: int = 0

    @classmethod
    def from_overlay(cls, overlay, *, progress_label: str = "") -> GridOverlaySnapshot:
        return cls(
            passed=set(overlay.passed_cells),
            failed=set(overlay.failed_cells),
            conflict=set(getattr(overlay, "conflict_cells", set()) or set()),
            gray=set(getattr(overlay, "gray_cells", set()) or set()),
            reference_values=dict(getattr(overlay, "cell_reference_values", {}) or {}),
            cells_without_reference=set(
                getattr(overlay, "cells_without_reference", set()) or set()
            ),
            catalog_displays=dict(getattr(overlay, "cell_catalog_displays", {}) or {}),
            progress_label=progress_label,
            percent=float(getattr(overlay, "percent", 0.0) or 0.0),
            passed_count=int(getattr(overlay, "passed_count", 0) or 0),
            total_count=int(getattr(overlay, "total_count", 0) or 0),
        )

    def is_empty(self) -> bool:
        return (
            not self.passed
            and not self.failed
            and not self.conflict
            and not self.gray
        )
