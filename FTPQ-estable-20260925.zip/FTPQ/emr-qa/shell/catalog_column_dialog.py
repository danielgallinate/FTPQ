"""Diálogo — asociar catálogo a una columna del archivo."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QVBoxLayout,
)

from core.catalog_store import CatalogStore, list_catalog_metas
from core.catalog_types import CatalogMeta, ColumnCatalogBinding
from ui.i18n import tr


class CatalogColumnDialog(QDialog):
    def __init__(
        self,
        *,
        column_name: str,
        binding: ColumnCatalogBinding | None = None,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._column_name = column_name
        self._binding = binding
        self._metas: list[CatalogMeta] = list_catalog_metas()
        self._store = CatalogStore()

        self.setWindowTitle(tr("emr.catalog.use_title"))
        layout = QVBoxLayout(self)

        self._hint = QLabel()
        self._hint.setWordWrap(True)
        layout.addWidget(self._hint)

        self._catalog = QComboBox()
        self._catalog.addItem(tr("emr.catalog.none"), "")
        for meta in self._metas:
            self._catalog.addItem(meta.name, meta.catalog_id)
        layout.addWidget(QLabel(tr("emr.catalog.pick_catalog")))
        layout.addWidget(self._catalog)

        self._match = QComboBox()
        layout.addWidget(QLabel(tr("emr.catalog.match_column")))
        layout.addWidget(self._match)

        self._display = QListWidget()
        self._display.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        layout.addWidget(QLabel(tr("emr.catalog.display_columns")))
        layout.addWidget(self._display)

        self._compare = QComboBox()
        layout.addWidget(QLabel(tr("emr.catalog.compare_column")))
        layout.addWidget(self._compare)

        self._multi_comma = QCheckBox()
        layout.addWidget(self._multi_comma)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        clear_btn = buttons.addButton(tr("emr.catalog.clear_binding"), QDialogButtonBox.ButtonRole.ResetRole)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        clear_btn.clicked.connect(self._on_clear)
        layout.addWidget(buttons)

        self._catalog.currentIndexChanged.connect(self._reload_catalog_columns)
        self._display.itemSelectionChanged.connect(self._sync_compare_default)
        self.retranslate_ui()
        self._restore_binding()

    def retranslate_ui(self) -> None:
        self._hint.setText(tr("emr.catalog.use_hint", column=self._column_name))
        self._multi_comma.setText(tr("emr.catalog.multi_comma"))

    def _restore_binding(self) -> None:
        if self._binding is None:
            return
        index = self._catalog.findData(self._binding.catalog_id)
        if index >= 0:
            self._catalog.setCurrentIndex(index)
        self._select_combo(self._match, self._binding.match_column)
        self._select_combo(self._compare, self._binding.compare_column)
        self._multi_comma.setChecked(self._binding.multi_value_separator == ",")
        for row in range(self._display.count()):
            item = self._display.item(row)
            if item is not None and item.text() in self._binding.display_columns:
                item.setSelected(True)

    def _on_clear(self) -> None:
        self._binding = None
        self.done(2)

    def _reload_catalog_columns(self) -> None:
        catalog_id = str(self._catalog.currentData() or "")
        self._match.clear()
        self._compare.clear()
        self._display.clear()
        if not catalog_id:
            return
        try:
            table = self._store.load(catalog_id)
        except Exception:  # noqa: BLE001
            return
        for column in table.meta.columns:
            self._match.addItem(column, column)
            self._compare.addItem(column, column)
            item = QListWidgetItem(column)
            self._display.addItem(item)
        if self._match.count():
            self._match.setCurrentIndex(0)
        if self._compare.count():
            self._compare.setCurrentIndex(min(1, self._compare.count() - 1))

    def _sync_compare_default(self) -> None:
        selected = self._selected_display_columns()
        if selected and not self._compare.currentData():
            self._select_combo(self._compare, selected[0])

    @staticmethod
    def _select_combo(combo: QComboBox, value: str) -> None:
        index = combo.findData(value)
        if index >= 0:
            combo.setCurrentIndex(index)

    def _selected_display_columns(self) -> list[str]:
        columns: list[str] = []
        for item in self._display.selectedItems():
            columns.append(item.text())
        return columns

    def result_binding(self) -> ColumnCatalogBinding | None:
        if self.result() == 2:
            return None
        if self.result() != QDialog.DialogCode.Accepted:
            return self._binding
        catalog_id = str(self._catalog.currentData() or "")
        if not catalog_id:
            return None
        match_column = str(self._match.currentData() or "")
        compare_column = str(self._compare.currentData() or "")
        display_columns = tuple(self._selected_display_columns())
        if not match_column or not compare_column:
            return None
        if not display_columns:
            display_columns = (compare_column,)
        multi_value_separator = "," if self._multi_comma.isChecked() else ""
        return ColumnCatalogBinding(
            catalog_id=catalog_id,
            match_column=match_column,
            display_columns=display_columns,
            compare_column=compare_column,
            multi_value_separator=multi_value_separator,
        )
