"""Entry point — EMR QA iteración 2 (local, Abrir/Probar)."""
from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
EMR_QA_ROOT = Path(__file__).resolve().parents[1]

if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
if str(EMR_QA_ROOT) not in sys.path:
    sys.path.append(str(EMR_QA_ROOT))

from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication

from shell.main_window import MainWindow
from ui.app_controller import bootstrap_profile
from ui.i18n import init_locale
from ui.theme.app_icon import apply_app_icon
from ui.theme.theme_engine import ThemeEngine


def _platform_font() -> QFont:
    if sys.platform == "darwin":
        return QFont(".AppleSystemUIFont", 13)
    if sys.platform == "win32":
        return QFont("Segoe UI", 13)
    font = QFont()
    font.setPointSize(13)
    return font


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("EMR QA")
    app.setStyle("Fusion")
    app.setFont(_platform_font())
    init_locale(bootstrap_profile().language)

    theme = ThemeEngine(app)
    theme.apply()
    apply_app_icon(app)

    window = MainWindow(theme=theme)
    app.aboutToQuit.connect(window.shutdown_workers)
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
