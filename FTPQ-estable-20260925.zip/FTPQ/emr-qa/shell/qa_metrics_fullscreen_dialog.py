"""Diálogo pantalla completa — reporte QA tabular + gráficos con scroll."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QHBoxLayout,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from shell.qa_metrics import QaMetricsReport
from shell.qa_metrics_charts import QaMetricsChartsWidget
from shell.qa_metrics_layout import (
    configure_metrics_scroll,
    resolve_wallpaper_context,
    sync_metrics_scroll_content,
)
from shell.qa_metrics_pdf_export import (
    default_pdf_filename,
    export_qa_metrics_pdf,
    pick_pdf_export_path,
)
from shell.qa_metrics_report_view import QaMetricsReportView
from ui.i18n import tr
from ui.theme.theme_engine import ThemeEngine, WallpaperHost


class QaMetricsReportDialog(QDialog):
    def __init__(self, report: QaMetricsReport, *, nok_only: bool = False, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("qaMetricsDialog")
        self._report = report
        self._nok_only = nok_only
        self._main_window = parent

        self.setWindowTitle(tr("emr.qa.metrics.fullscreen_title", file=report.file_name))
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.resize(1280, 860)

        theme, wallpaper_path = resolve_wallpaper_context(parent)
        self._host = WallpaperHost(theme, wallpaper_path=wallpaper_path)

        self._nok_filter = QCheckBox()
        self._nok_filter.setChecked(nok_only)
        self._nok_filter.toggled.connect(self._on_nok_filter)

        self._copy_report = QPushButton()
        self._copy_report.clicked.connect(self._copy_report_text)

        self._copy_csv = QPushButton()
        self._copy_csv.clicked.connect(self._copy_csv_text)

        self._export_pdf = QPushButton()
        self._export_pdf.clicked.connect(self._export_pdf_file)

        self._close = QPushButton()
        self._close.clicked.connect(self.accept)

        actions = QHBoxLayout()
        actions.addWidget(self._nok_filter)
        actions.addStretch(1)
        actions.addWidget(self._copy_report)
        actions.addWidget(self._copy_csv)
        actions.addWidget(self._export_pdf)
        actions.addWidget(self._close)

        self._report_view = QaMetricsReportView()
        self._report_view.set_report(report, nok_only=nok_only)

        self._charts = QaMetricsChartsWidget()

        self._scroll_content = QWidget()
        self._scroll_content.setObjectName("qaMetricsScrollHost")
        content_layout = QVBoxLayout(self._scroll_content)
        content_layout.setContentsMargins(0, 0, 8, 0)
        content_layout.setSpacing(16)
        content_layout.addWidget(self._report_view)
        content_layout.addWidget(self._charts)

        self._scroll = QScrollArea()
        self._scroll.setObjectName("qaMetricsScroll")
        configure_metrics_scroll(self._scroll)
        self._scroll.setWidget(self._scroll_content)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(8)
        body_layout.addLayout(actions)
        body_layout.addWidget(self._scroll, stretch=1)

        host_layout = QVBoxLayout(self._host)
        host_layout.setContentsMargins(
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
            ThemeEngine.OUTER_MARGIN,
        )
        host_layout.addWidget(body)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self._host)

        self.retranslate_ui()
        self._refresh_charts()
        self._update_scroll_content_size()

    def retranslate_ui(self) -> None:
        self._nok_filter.setText(tr("emr.qa.metrics.nok_only"))
        self._copy_report.setText(tr("emr.qa.metrics.copy_report"))
        self._copy_csv.setText(tr("emr.qa.metrics.copy_csv"))
        self._export_pdf.setText(tr("emr.qa.metrics.export_pdf"))
        self._close.setText(tr("action.close"))
        self.setWindowTitle(tr("emr.qa.metrics.fullscreen_title", file=self._report.file_name))
        self._report_view.retranslate_ui()
        self._charts.retranslate_ui()
        self._update_scroll_content_size()

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        self._sync_wallpaper_from_parent()
        self.showMaximized()
        self._update_scroll_content_size()

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._update_scroll_content_size()

    def _sync_wallpaper_from_parent(self) -> None:
        main_host = getattr(self._main_window, "_host", None)
        if main_host is not None:
            self._host.set_wallpaper(main_host._wallpaper_path)
        self._host.refresh_scrim()

    def _update_scroll_content_size(self) -> None:
        sync_metrics_scroll_content(
            self._scroll,
            self._scroll_content,
            self._report_view,
            self._charts,
        )

    def _on_nok_filter(self, checked: bool) -> None:
        self._nok_only = checked
        self._report_view.set_report(self._report, nok_only=checked)
        self._refresh_charts()
        self._update_scroll_content_size()

    def _refresh_charts(self) -> None:
        self._charts.set_report(self._report, nok_only=self._nok_only)
        self._update_scroll_content_size()

    def _copy_report_text(self) -> None:
        QApplication.clipboard().setText(
            self._report.to_copyable_text(nok_only=self._nok_only)
        )

    def _copy_csv_text(self) -> None:
        QApplication.clipboard().setText(self._report.to_csv(nok_only=self._nok_only))

    def _export_pdf_file(self) -> None:
        default_name = default_pdf_filename(self._report.file_name)
        path = pick_pdf_export_path(self, default_name=default_name)
        if path is None:
            return
        try:
            export_qa_metrics_pdf(
                path,
                report_view=self._report_view,
                charts=self._charts,
            )
        except OSError as exc:
            from PySide6.QtWidgets import QMessageBox

            QMessageBox.warning(
                self,
                tr("emr.qa.metrics.export_pdf"),
                tr("emr.qa.metrics.export_pdf_fail", error=exc),
            )
            return
        from PySide6.QtWidgets import QMessageBox

        QMessageBox.information(
            self,
            tr("emr.qa.metrics.export_pdf"),
            tr("emr.qa.metrics.export_pdf_done", path=str(path)),
        )
