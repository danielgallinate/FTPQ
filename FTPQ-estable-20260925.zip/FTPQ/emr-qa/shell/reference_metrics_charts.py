"""Gráficos simples — comparación contra referencia."""
from __future__ import annotations

from PySide6.QtCharts import (
    QBarCategoryAxis,
    QBarSeries,
    QBarSet,
    QChart,
    QChartView,
    QPieSeries,
    QValueAxis,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QBrush, QColor, QFont, QPalette, QPainter
from PySide6.QtWidgets import QLabel, QSizePolicy, QVBoxLayout, QWidget

from core.chart_format import format_category_label, format_count
from shell.qa_chart_labels import flush_chart_tooltips, wire_bar_chart_labels, wire_bar_chart_tooltips
from shell.reference_metrics import ReferenceCompareReport
from ui.i18n import tr

_MAX_COLUMN_BARS = 15


def _chart_colors(widget: QWidget) -> tuple[QColor, QColor, QColor]:
    palette = widget.palette()
    ok = palette.color(QPalette.ColorRole.Text)
    ok.setAlpha(180)
    nok = QColor("#e74c3c")
    fg = palette.color(QPalette.ColorRole.WindowText)
    return ok, nok, fg


class ReferenceMetricsChartsWidget(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("referenceMetricsCharts")
        self._report: ReferenceCompareReport | None = None
        self._nok_only = False
        self._content_width = 520

        self._cells_title = QLabel()
        self._cells_title.setObjectName("panelSubtitle")
        self._cells_chart = QChartView()
        self._cells_chart.setRenderHint(QPainter.RenderHint.Antialiasing)

        self._columns_title = QLabel()
        self._columns_title.setObjectName("panelSubtitle")
        self._columns_chart = QChartView()
        self._columns_chart.setRenderHint(QPainter.RenderHint.Antialiasing)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)
        layout.addWidget(self._cells_title)
        layout.addWidget(self._cells_chart, 0, Qt.AlignmentFlag.AlignHCenter)
        layout.addWidget(self._columns_title)
        layout.addWidget(self._columns_chart, 0, Qt.AlignmentFlag.AlignHCenter)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.retranslate_ui()

    def retranslate_ui(self) -> None:
        self._cells_title.setText(tr("emr.ref.charts.cells_title"))
        self._columns_title.setText(tr("emr.ref.charts.columns_title"))
        if self._report is not None:
            self.set_report(self._report, nok_only=self._nok_only)

    def set_report(self, report: ReferenceCompareReport | None, *, nok_only: bool = False) -> None:
        flush_chart_tooltips()
        self._report = report
        self._nok_only = nok_only
        if report is None:
            self._cells_chart.setChart(QChart())
            self._columns_chart.setChart(QChart())
            self._cells_chart.setFixedSize(320, 240)
            self._columns_chart.setFixedSize(320, 280)
            self.update_content_size()
            return
        ok_color, nok_color, fg = _chart_colors(self)
        cells_chart = self._build_cells_pie(report, ok_color=ok_color, nok_color=nok_color, fg=fg)
        self._apply_chart_theme(cells_chart, self._cells_chart)
        self._cells_chart.setChart(cells_chart)
        self._cells_chart.setFixedSize(340, 260)
        column_chart, series = self._build_columns_bar(
            report, ok_color=ok_color, nok_color=nok_color, fg=fg, nok_only=nok_only
        )
        self._apply_chart_theme(column_chart, self._columns_chart)
        self._columns_chart.setChart(column_chart)
        items = report.column_items(nok_only=nok_only)
        bar_height = 220 + min(len(items), _MAX_COLUMN_BARS) * 8
        self._columns_chart.setFixedSize(min(max(self._content_width - 40, 520), 900), bar_height)
        if series is not None:
            categories = [
                format_category_label(item.left_column, max_len=14)
                for item in items[:_MAX_COLUMN_BARS]
            ]
            wire_bar_chart_labels(column_chart, series, fg=fg)
            wire_bar_chart_tooltips(
                series,
                categories=categories,
                ok_label=tr("emr.ref.charts.ok"),
                nok_label=tr("emr.ref.charts.nok"),
            )
        self._columns_title.setVisible(bool(items))
        self._columns_chart.setVisible(bool(items))
        self.update_content_size()

    def _apply_chart_theme(self, chart: QChart, view: QChartView) -> None:
        chart.setBackgroundVisible(False)
        chart.setPlotAreaBackgroundVisible(False)
        view.setBackgroundBrush(QBrush(Qt.GlobalColor.transparent))
        view.setStyleSheet("background: transparent; border: none;")

    @staticmethod
    def _build_cells_pie(report: ReferenceCompareReport, *, ok_color, nok_color, fg) -> QChart:
        chart = QChart()
        chart.setBackgroundVisible(False)
        chart.legend().setVisible(True)
        chart.setTitle(tr("emr.ref.charts.cells_pie_title"))
        title_font = QFont(chart.titleFont())
        title_font.setPointSize(10)
        chart.setTitleFont(title_font)
        series = QPieSeries()
        ok = report.cells_ok
        nok = report.cells_nok
        if ok == 0 and nok == 0:
            chart.setTitle(tr("emr.ref.charts.no_data"))
            return chart
        if ok:
            slice_ok = series.append(tr("emr.ref.charts.ok"), ok)
            slice_ok.setBrush(QBrush(ok_color))
            slice_ok.setLabel(f"{tr('emr.ref.charts.ok')} {format_count(ok)}")
        if nok:
            slice_nok = series.append(tr("emr.ref.charts.nok"), nok)
            slice_nok.setBrush(QBrush(nok_color))
            slice_nok.setLabel(f"{tr('emr.ref.charts.nok')} {format_count(nok)}")
        chart.addSeries(series)
        chart.legend().setLabelColor(fg)
        return chart

    @staticmethod
    def _build_columns_bar(report: ReferenceCompareReport, *, ok_color, nok_color, fg, nok_only: bool = False):
        chart = QChart()
        chart.setBackgroundVisible(False)
        chart.legend().setVisible(True)
        chart.setTitle(tr("emr.ref.charts.columns_bar_title"))
        title_font = QFont(chart.titleFont())
        title_font.setPointSize(10)
        chart.setTitleFont(title_font)
        items = report.column_items(nok_only=nok_only)[:_MAX_COLUMN_BARS]
        if not items:
            chart.setTitle(tr("emr.ref.charts.no_data"))
            return chart, None
        ok_set = QBarSet(tr("emr.ref.charts.ok"))
        nok_set = QBarSet(tr("emr.ref.charts.nok"))
        ok_set.setColor(ok_color)
        nok_set.setColor(nok_color)
        categories: list[str] = []
        for item in items:
            categories.append(format_category_label(item.left_column, max_len=14))
            ok_set.append(item.ok)
            nok_set.append(item.nok)
        series = QBarSeries()
        series.append(ok_set)
        series.append(nok_set)
        series.setLabelsVisible(False)
        chart.addSeries(series)
        axis_x = QBarCategoryAxis()
        axis_x.append(categories)
        axis_x.setLabelsAngle(-35 if any(len(name) > 10 for name in categories) else 0)
        axis_x.setLabelsColor(fg)
        chart.addAxis(axis_x, Qt.AlignmentFlag.AlignBottom)
        series.attachAxis(axis_x)
        axis_y = QValueAxis()
        axis_y.setLabelFormat("%d")
        axis_y.setLabelsColor(fg)
        max_value = max([0, *[item.ok for item in items], *[item.nok for item in items]])
        axis_y.setRange(0, max(max_value, 1))
        chart.addAxis(axis_y, Qt.AlignmentFlag.AlignLeft)
        series.attachAxis(axis_y)
        chart.legend().setLabelColor(fg)
        return chart, series

    def update_content_size(self, *, content_width: int | None = None) -> None:
        if content_width is not None:
            self._content_width = max(content_width, 320)
        if self._report is None:
            self.setMinimumSize(0, 0)
            self.resize(0, 0)
            return
        stack_width = self._content_width
        height = 0
        for widget in (self._cells_title, self._cells_chart, self._columns_title, self._columns_chart):
            if not widget.isVisible():
                continue
            height += widget.height() if widget.height() > 0 else widget.sizeHint().height()
        height += 12
        self.setFixedSize(stack_width, max(height, 280))
        self.updateGeometry()

    def refresh_display(self) -> None:
        if self._report is None:
            return
        self.set_report(self._report, nok_only=self._nok_only)
