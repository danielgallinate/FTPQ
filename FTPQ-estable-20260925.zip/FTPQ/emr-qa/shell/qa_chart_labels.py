"""Etiquetas numéricas legibles sobre barras QA (evita 1e+04 en Qt Charts)."""
from __future__ import annotations

from PySide6.QtCharts import QBarSeries, QChart
from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor, QCursor, QFont, QGuiApplication
from PySide6.QtWidgets import QGraphicsSimpleTextItem, QToolTip

from core.chart_format import format_count

_QA_BAR_LABEL_TAG = 9001


def _remove_bar_label_items(chart: QChart) -> None:
    scene = chart.scene()
    if scene is None:
        return
    for item in list(scene.items()):
        if item.data(0) == _QA_BAR_LABEL_TAG:
            scene.removeItem(item)


def place_bar_value_labels(chart: QChart, series: QBarSeries, *, fg: QColor) -> None:
    _remove_bar_label_items(chart)
    scene = chart.scene()
    if scene is None:
        return
    bar_sets = series.barSets()
    if not bar_sets:
        return
    set_count = len(bar_sets)
    for set_index, bar_set in enumerate(bar_sets):
        for cat_index in range(bar_set.count()):
            value = bar_set.at(cat_index)
            if value <= 0:
                continue
            x = cat_index + (set_index - (set_count - 1) / 2.0) * 0.35
            point = chart.mapToPosition(QPointF(x, value), series)
            label = QGraphicsSimpleTextItem(format_count(value))
            label.setBrush(fg)
            font = QFont(label.font())
            font.setPointSize(9)
            font.setBold(True)
            label.setFont(font)
            rect = label.boundingRect()
            label.setPos(point.x() - rect.width() / 2, point.y() - rect.height() - 3)
            label.setData(0, _QA_BAR_LABEL_TAG)
            label.setZValue(10)
            scene.addItem(label)


def wire_bar_chart_labels(chart: QChart, series: QBarSeries, *, fg: QColor) -> None:
    def refresh() -> None:
        place_bar_value_labels(chart, series, fg=fg)

    chart.plotAreaChanged.connect(refresh)
    refresh()


def wire_bar_chart_tooltips(
    series: QBarSeries,
    *,
    categories: list[str],
    ok_label: str,
    nok_label: str,
) -> None:
    bar_sets = series.barSets()
    if len(bar_sets) < 2:
        return
    ok_set, nok_set = bar_sets[0], bar_sets[1]

    def on_hovered(status: bool, index: int, bar_set) -> None:
        if not status or index < 0 or index >= len(categories):
            QToolTip.hideText()
            return
        value = int(bar_set.at(index))
        if bar_set is ok_set:
            kind = ok_label
        elif bar_set is nok_set:
            kind = nok_label
        else:
            kind = ""
        category = categories[index]
        QToolTip.showText(
            QCursor.pos(),
            f"{category}\n{kind}: {format_count(value)}",
        )

    series.hovered.connect(on_hovered)


def flush_chart_tooltips() -> None:
    QToolTip.hideText()
    QGuiApplication.processEvents()
