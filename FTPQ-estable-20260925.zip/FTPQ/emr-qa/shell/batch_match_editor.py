"""Editor UI — regex batch_match (patrones y exclusiones por línea)."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from core.batch_match import (
    EXAMPLE_FILENAME_PATTERN,
    compile_batch_match,
    suggest_filename_pattern,
)
from core.batch_match_types import BatchMatchSpec
from ui.i18n import tr


def _lines_from_text(text: str) -> tuple[str, ...]:
    return tuple(line.strip() for line in text.splitlines() if line.strip())


def _text_from_lines(lines: tuple[str, ...]) -> str:
    return "\n".join(lines)


class BatchMatchEditor(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._title = QLabel()
        self._title.setObjectName("panelSubtitle")
        self._hint = QLabel()
        self._hint.setObjectName("configHint")
        self._hint.setWordWrap(True)
        self._patterns_label = QLabel()
        self._patterns = QPlainTextEdit()
        self._patterns.setPlaceholderText(EXAMPLE_FILENAME_PATTERN)
        self._patterns.setMaximumHeight(72)

        self._source_filename = ""
        self._example = QLabel(EXAMPLE_FILENAME_PATTERN)
        self._example.setObjectName("configHint")
        self._example.setWordWrap(True)
        self._example.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
            | Qt.TextInteractionFlag.TextSelectableByKeyboard
        )
        self._use_example = QPushButton()
        self._use_example.clicked.connect(self._on_use_example)
        self._from_file = QPushButton()
        self._from_file.clicked.connect(self._on_use_current_file)
        self._from_file.setEnabled(False)

        example_row = QHBoxLayout()
        example_row.setContentsMargins(0, 0, 0, 0)
        example_row.addWidget(self._use_example)
        example_row.addWidget(self._from_file)
        example_row.addStretch(1)

        self._excludes_label = QLabel()
        self._excludes = QPlainTextEdit()
        self._excludes.setMaximumHeight(56)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        layout.addWidget(self._title)
        layout.addWidget(self._hint)
        layout.addWidget(self._patterns_label)
        layout.addWidget(self._patterns)
        layout.addWidget(self._example)
        layout.addLayout(example_row)
        layout.addWidget(self._excludes_label)
        layout.addWidget(self._excludes)
        self.retranslate_ui()

    def retranslate_ui(self) -> None:
        self._title.setText(tr("emr.batch_match.title"))
        self._hint.setText(tr("emr.batch_match.hint"))
        self._patterns_label.setText(tr("emr.batch_match.patterns_label"))
        self._excludes_label.setText(tr("emr.batch_match.excludes_label"))
        self._use_example.setText(tr("emr.batch_match.use_example"))
        self._from_file.setText(tr("emr.batch_match.from_file"))
        self._refresh_example()

    def set_source_filename(self, filename: str) -> None:
        """Archivo de muestra que alimenta el patrón sugerido."""
        self._source_filename = (filename or "").strip()
        self._from_file.setEnabled(bool(self._source_filename))
        self._refresh_example()

    def _refresh_example(self) -> None:
        if self._source_filename:
            suggestion = suggest_filename_pattern(self._source_filename)
            self._from_file.setToolTip(suggestion)
        else:
            suggestion = EXAMPLE_FILENAME_PATTERN
            self._from_file.setToolTip(tr("emr.batch_match.from_file_empty"))
        self._example.setText(tr("emr.batch_match.example", pattern=suggestion))

    def _append_pattern(self, pattern: str) -> None:
        existing = _lines_from_text(self._patterns.toPlainText())
        if pattern in existing:
            return
        self._patterns.setPlainText(_text_from_lines(existing + (pattern,)))

    def _on_use_example(self) -> None:
        self._append_pattern(EXAMPLE_FILENAME_PATTERN)

    def _on_use_current_file(self) -> None:
        if not self._source_filename:
            return
        self._append_pattern(suggest_filename_pattern(self._source_filename))

    def clear(self) -> None:
        self._patterns.clear()
        self._excludes.clear()

    def set_spec(self, spec: BatchMatchSpec | None) -> None:
        if spec is None:
            self.clear()
            return
        self._patterns.setPlainText(_text_from_lines(spec.filename_patterns))
        self._excludes.setPlainText(_text_from_lines(spec.filename_excludes))

    def spec(self) -> BatchMatchSpec | None:
        patterns = _lines_from_text(self._patterns.toPlainText())
        excludes = _lines_from_text(self._excludes.toPlainText())
        if not patterns and not excludes:
            return None
        return BatchMatchSpec(filename_patterns=patterns, filename_excludes=excludes)

    def validate(self, source: str = "batch_match") -> str | None:
        spec = self.spec()
        if spec is None or not spec.is_configured():
            return None
        try:
            compile_batch_match(spec, source)
        except Exception as exc:
            return str(exc)
        return None
