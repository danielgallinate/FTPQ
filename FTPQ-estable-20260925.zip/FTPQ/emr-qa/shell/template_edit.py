"""Edición tabular de registros en minibase del template."""
from __future__ import annotations

import copy

from emrqa.validation_models import (
    DuplicateRecordError,
    MinibaseRecord,
    RecordSource,
    RecordValidationSnapshot,
    ValidationTemplate,
    _utc_now_iso,
    new_id,
    normalize_cell_value,
)


def snapshot_template(template: ValidationTemplate) -> ValidationTemplate:
    return copy.deepcopy(template)


def restore_template(target: ValidationTemplate, source: ValidationTemplate) -> None:
    restored = snapshot_template(source)
    target.meta = restored.meta
    target.header = restored.header
    target.minibase = restored.minibase


def table_rows_from_template(template: ValidationTemplate) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for record in template.minibase.records:
        row = {
            field.field_id: record.values.get(field.field_id, "")
            for field in template.header.fields
        }
        rows.append(row)
    return rows


def apply_table_rows_to_template(
    template: ValidationTemplate,
    table_rows: list[dict[str, str]],
) -> None:
    key = template.dedup_key()
    if key is None:
        raise ValueError("Template sin llave de deduplicación")

    new_records: list[MinibaseRecord] = []
    seen_fingerprints: set[str] = set()
    for index, values in enumerate(table_rows):
        previous = (
            template.minibase.records[index]
            if index < len(template.minibase.records)
            else None
        )
        normalized = {
            field.field_id: normalize_cell_value(values.get(field.field_id, ""))
            for field in template.header.fields
        }
        row_by_column = {
            field.column: normalized[field.field_id] for field in template.header.fields
        }
        fingerprint = template.fingerprint_for_row(key, row_by_column)
        if fingerprint in seen_fingerprints:
            raise DuplicateRecordError(fingerprint=fingerprint, key_id=key.key_id)
        seen_fingerprints.add(fingerprint)
        new_records.append(
            MinibaseRecord(
                record_id=previous.record_id if previous else new_id("rec_"),
                key_fingerprint=fingerprint,
                key_id=key.key_id,
                saved_at=previous.saved_at if previous else _utc_now_iso(),
                values=normalized,
                source=previous.source if previous else RecordSource(),
                validation=previous.validation if previous else RecordValidationSnapshot(),
            )
        )

    template.minibase.records = new_records
    template.meta.updated_at = _utc_now_iso()
