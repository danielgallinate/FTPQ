"""Cálculo de layout vertical para gráficos QA (30% ancho, uno por fila)."""
from __future__ import annotations

from dataclasses import dataclass
import math

CHART_GAP = 16
CHART_SIZE_RATIO = 0.30
_MIN_CHART = 112
_PER_SLOT = 44
MINI_PIES_PER_ROW = 3
MINI_BOARD_GAP = 14
MINI_BOARD_ROW_GAP = 16
MINI_BOARD_HINT_EXTRA = 32
MINI_PIE_MIN = 160
MINI_PIE_MAX = 280
MINI_HEADER_EXTRA = 38
MINI_FOOTER_EXTRA = 98
MINI_CARD_PADDING = 14


@dataclass(frozen=True)
class ChartSize:
    width: int
    height: int


@dataclass(frozen=True)
class ChartRowSpec:
    chart: ChartSize
    row_height: int


@dataclass(frozen=True)
class TemplateBoardSpec:
    cell_width: int
    cell_height: int
    pie_size: int
    board_width: int
    pies_height: int
    board_height: int
    count: int
    columns_per_row: int
    grid_rows: int


@dataclass(frozen=True)
class ChartStackLayout:
    rows: tuple[ChartRowSpec, ...]
    template_board: TemplateBoardSpec | None
    stack_width: int
    stack_height: int
    gap: int = CHART_GAP


def _base_size(content_width: int) -> int:
    return max(int(content_width * CHART_SIZE_RATIO), _MIN_CHART)


def _bar_chart_size(content_width: int, slot_count: int) -> ChartSize:
    base = _base_size(content_width)
    slots = max(slot_count, 1)
    if slots <= 4:
        width = base
    else:
        width = max(base, min(slots * _PER_SLOT + 56, content_width))
    return ChartSize(width=width, height=base + 44)


def _pie_chart_size(content_width: int) -> ChartSize:
    side = _base_size(content_width)
    return ChartSize(width=side, height=side + 56)


def _template_board_spec(content_width: int, template_count: int) -> TemplateBoardSpec | None:
    if template_count <= 1:
        return None
    columns = min(MINI_PIES_PER_ROW, template_count)
    gaps = max(0, columns - 1) * MINI_BOARD_GAP
    available = max(content_width - gaps, MINI_PIE_MIN * columns)
    cell = min(MINI_PIE_MAX, max(MINI_PIE_MIN, available // columns))
    pie_size = max(120, cell - MINI_CARD_PADDING)
    cell_height = MINI_HEADER_EXTRA + pie_size + MINI_FOOTER_EXTRA + MINI_CARD_PADDING
    grid_rows = math.ceil(template_count / MINI_PIES_PER_ROW)
    board_width = columns * cell + gaps
    pies_height = grid_rows * cell_height + max(0, grid_rows - 1) * MINI_BOARD_ROW_GAP
    board_height = MINI_BOARD_HINT_EXTRA + pies_height
    return TemplateBoardSpec(
        cell_width=cell,
        cell_height=cell_height,
        pie_size=pie_size,
        board_width=board_width,
        pies_height=pies_height,
        board_height=board_height,
        count=template_count,
        columns_per_row=columns,
        grid_rows=grid_rows,
    )


def compute_chart_stack_layout(
    *,
    content_width: int,
    template_count: int,
    column_count: int,
) -> ChartStackLayout:
    """Barras + pie unificado por fila; mini-pies por template en grilla 3×N."""
    gap = CHART_GAP
    main_rows = (
        ChartRowSpec(chart=_bar_chart_size(content_width, template_count), row_height=0),
        ChartRowSpec(chart=_bar_chart_size(content_width, column_count), row_height=0),
        ChartRowSpec(chart=_pie_chart_size(content_width), row_height=0),
    )
    rows = tuple(
        ChartRowSpec(chart=row.chart, row_height=row.chart.height)
        for row in main_rows
    )
    board = _template_board_spec(content_width, template_count)
    stack_width = max(
        content_width,
        max(row.chart.width for row in rows),
        board.board_width if board is not None else 0,
    )
    stack_height = sum(row.row_height for row in rows) + gap * max(0, len(rows) - 1)
    if board is not None:
        stack_height += gap + board.board_height
    return ChartStackLayout(
        rows=rows,
        template_board=board,
        stack_width=stack_width,
        stack_height=stack_height,
        gap=gap,
    )
