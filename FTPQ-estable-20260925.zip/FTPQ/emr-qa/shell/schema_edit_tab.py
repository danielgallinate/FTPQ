"""Tab Esquema — crear y editar catálogos de estructura columnar."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from core.analysis_types import TabularDataset
from core.schema_catalog_store import SchemaCatalogStore, list_schema_catalog_summaries
from core.schema_catalog_types import DATA_TYPES, SchemaCatalog, SchemaColumnSpec, SchemaCatalogValidationError
from shell.batch_match_editor import BatchMatchEditor
from ui.i18n import tr
from ui.widgets.table_clipboard import install_table_copy_shortcut

_COL_ENABLED = 0
_COL_NAME = 1
_COL_TYPE = 2
_COL_NULL = 3
_COL_UNIQUE = 4
_COL_DATE_FMT = 5


class SchemaEditTab(QWidget):
    catalogs_changed = Signal()
    user_message = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._store = SchemaCatalogStore()
        self._dataset: TabularDataset | None = None
        self._catalog: SchemaCatalog | None = None
        self._loading = False

        self._hint = QLabel()
        self._hint.setObjectName("configHint")
        self._hint.setWordWrap(True)

        self._list = QListWidget()
        self._list.setMaximumHeight(96)
        self._list.currentItemChanged.connect(self._on_catalog_selected)

        self._refresh_btn = QPushButton()
        self._refresh_btn.clicked.connect(self._reload_catalog_list)
        self._new_btn = QPushButton()
        self._new_btn.clicked.connect(self._on_new_catalog)
        self._delete_btn = QPushButton()
        self._delete_btn.clicked.connect(self._on_delete_catalog)

        list_row = QHBoxLayout()
        list_row.addWidget(self._refresh_btn)
        list_row.addWidget(self._new_btn)
        list_row.addWidget(self._delete_btn)

        self._name = QLineEdit()
        self._strict = QCheckBox()
        self._strict.toggled.connect(self._mark_dirty)

        self._batch_match = BatchMatchEditor()

        self._table = QTableWidget(0, 6)
        self._table.setHorizontalHeaderLabels(["", "", "", "", ""])
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self._table.verticalHeader().setVisible(True)
        header = self._table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(_COL_NAME, QHeaderView.ResizeMode.Stretch)
        for column in (_COL_ENABLED, _COL_TYPE, _COL_NULL, _COL_UNIQUE):
            header.setSectionResizeMode(column, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(_COL_DATE_FMT, QHeaderView.ResizeMode.Interactive)
        self._table.itemChanged.connect(self._on_item_changed)
        install_table_copy_shortcut(self._table)

        self._import_cols = QPushButton()
        self._import_cols.clicked.connect(self._on_import_columns)
        self._add_row = QPushButton()
        self._add_row.clicked.connect(self._on_add_row)
        self._remove_rows = QPushButton()
        self._remove_rows.clicked.connect(self._on_remove_rows)
        self._save = QPushButton()
        self._save.clicked.connect(self._on_save)

        tools = QHBoxLayout()
        tools.addWidget(self._import_cols)
        tools.addWidget(self._add_row)
        tools.addWidget(self._remove_rows)
        tools.addStretch(1)
        tools.addWidget(self._save)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)
        layout.addWidget(self._hint)
        layout.addWidget(QLabel(tr("emr.schema.edit.existing")))
        layout.addWidget(self._list)
        layout.addLayout(list_row)
        layout.addWidget(QLabel(tr("emr.schema.edit.name_label")))
        layout.addWidget(self._name)
        layout.addWidget(self._strict)
        layout.addWidget(self._batch_match)
        layout.addWidget(self._table, stretch=1)
        layout.addLayout(tools)
        self.retranslate_ui()
        self._reload_catalog_list()

    def retranslate_ui(self) -> None:
        self._hint.setText(tr("emr.schema.edit.hint"))
        self._refresh_btn.setText(tr("emr.schema.edit.refresh"))
        self._new_btn.setText(tr("emr.schema.edit.new"))
        self._delete_btn.setText(tr("emr.schema.edit.delete"))
        self._strict.setText(tr("emr.schema.edit.strict"))
        self._import_cols.setText(tr("emr.schema.edit.import_columns"))
        self._add_row.setText(tr("emr.schema.edit.add_row"))
        self._remove_rows.setText(tr("emr.schema.edit.remove_rows"))
        self._save.setText(tr("emr.schema.edit.save"))
        self._batch_match.retranslate_ui()
        headers = [
            tr("emr.schema.col.enabled"),
            tr("emr.schema.col.name"),
            tr("emr.schema.col.type"),
            tr("emr.schema.col.null"),
            tr("emr.schema.col.unique"),
            tr("emr.schema.col.date_format"),
        ]
        self._table.setHorizontalHeaderLabels(headers)

    def set_dataset(self, dataset: TabularDataset | None) -> None:
        self._dataset = dataset
        self._batch_match.set_source_filename(
            dataset.local_path.name if dataset is not None else ""
        )

    def selected_schema_id(self) -> str:
        item = self._list.currentItem()
        if item is None:
            return ""
        return str(item.data(Qt.ItemDataRole.UserRole) or "")

    def _reload_catalog_list(self) -> None:
        current = self.selected_schema_id()
        self._list.blockSignals(True)
        self._list.clear()
        for schema_id, name, strict in list_schema_catalog_summaries():
            label = name
            if strict:
                label += f" ({tr('emr.schema.strict.badge')})"
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, schema_id)
            self._list.addItem(item)
            if schema_id == current:
                self._list.setCurrentItem(item)
        self._list.blockSignals(False)
        if self._list.currentItem() is None and self._list.count():
            self._list.setCurrentRow(0)

    def _on_catalog_selected(self) -> None:
        schema_id = self.selected_schema_id()
        if not schema_id:
            self._catalog = None
            self._clear_form()
            return
        try:
            self._catalog = self._store.load(schema_id)
        except SchemaCatalogValidationError as exc:
            self.user_message.emit(str(exc))
            self._catalog = None
            self._clear_form()
            return
        self._fill_form(self._catalog)

    def _clear_form(self) -> None:
        self._loading = True
        self._name.clear()
        self._strict.setChecked(False)
        self._batch_match.clear()
        self._table.setRowCount(0)
        self._loading = False

    def _fill_form(self, catalog: SchemaCatalog) -> None:
        self._loading = True
        self._name.setText(catalog.name)
        self._strict.setChecked(catalog.strict)
        self._batch_match.set_spec(catalog.batch_match)
        self._table.setRowCount(0)
        for spec in catalog.columns:
            self._append_row(spec)
        self._loading = False

    def _append_row(self, spec: SchemaColumnSpec | None = None) -> None:
        row = self._table.rowCount()
        self._table.insertRow(row)
        spec = spec or SchemaColumnSpec(name="", enabled=True)
        enabled = QTableWidgetItem()
        enabled.setFlags(
            Qt.ItemFlag.ItemIsUserCheckable
            | Qt.ItemFlag.ItemIsEnabled
            | Qt.ItemFlag.ItemIsSelectable
        )
        enabled.setCheckState(
            Qt.CheckState.Checked if spec.enabled else Qt.CheckState.Unchecked
        )
        self._table.setItem(row, _COL_ENABLED, enabled)

        name_item = QTableWidgetItem(spec.name)
        self._table.setItem(row, _COL_NAME, name_item)

        type_combo = QComboBox()
        for data_type in DATA_TYPES:
            type_combo.addItem(data_type, data_type)
        index = type_combo.findData(spec.data_type)
        type_combo.setCurrentIndex(index if index >= 0 else 0)
        type_combo.currentIndexChanged.connect(self._mark_dirty)
        self._table.setCellWidget(row, _COL_TYPE, type_combo)

        null_item = QTableWidgetItem()
        null_item.setFlags(
            Qt.ItemFlag.ItemIsUserCheckable
            | Qt.ItemFlag.ItemIsEnabled
            | Qt.ItemFlag.ItemIsSelectable
        )
        null_item.setCheckState(
            Qt.CheckState.Checked if spec.allows_null else Qt.CheckState.Unchecked
        )
        self._table.setItem(row, _COL_NULL, null_item)

        unique_item = QTableWidgetItem()
        unique_item.setFlags(
            Qt.ItemFlag.ItemIsUserCheckable
            | Qt.ItemFlag.ItemIsEnabled
            | Qt.ItemFlag.ItemIsSelectable
        )
        unique_item.setCheckState(
            Qt.CheckState.Checked if spec.unique else Qt.CheckState.Unchecked
        )
        self._table.setItem(row, _COL_UNIQUE, unique_item)

        fmt_item = QTableWidgetItem(spec.date_format)
        self._table.setItem(row, _COL_DATE_FMT, fmt_item)

    def _row_spec(self, row: int) -> SchemaColumnSpec | None:
        name_item = self._table.item(row, _COL_NAME)
        if name_item is None:
            return None
        name = name_item.text().strip()
        enabled_item = self._table.item(row, _COL_ENABLED)
        enabled = (
            enabled_item.checkState() == Qt.CheckState.Checked
            if enabled_item is not None
            else True
        )
        null_item = self._table.item(row, _COL_NULL)
        allows_null = (
            null_item.checkState() == Qt.CheckState.Checked
            if null_item is not None
            else True
        )
        unique_item = self._table.item(row, _COL_UNIQUE)
        unique = (
            unique_item.checkState() == Qt.CheckState.Checked
            if unique_item is not None
            else False
        )
        type_combo = self._table.cellWidget(row, _COL_TYPE)
        data_type = "string"
        if isinstance(type_combo, QComboBox):
            data_type = str(type_combo.currentData() or "string")
        fmt_item = self._table.item(row, _COL_DATE_FMT)
        date_format = fmt_item.text().strip() if fmt_item is not None else ""
        return SchemaColumnSpec(
            name=name,
            data_type=data_type,  # type: ignore[arg-type]
            allows_null=allows_null,
            unique=unique,
            date_format=date_format,
            enabled=enabled,
        )

    def _collect_columns(self) -> list[SchemaColumnSpec]:
        specs: list[SchemaColumnSpec] = []
        for row in range(self._table.rowCount()):
            spec = self._row_spec(row)
            if spec is not None and spec.name:
                specs.append(spec)
        return specs

    def _on_item_changed(self, _item: QTableWidgetItem) -> None:
        if self._loading:
            return
        self._mark_dirty()

    def _mark_dirty(self, *_args) -> None:
        return

    def _on_new_catalog(self) -> None:
        name, ok = QInputDialog.getText(
            self,
            tr("emr.schema.edit.new"),
            tr("emr.schema.edit.name_prompt"),
        )
        if not ok or not name.strip():
            return
        catalog = self._store.new_catalog(name.strip())
        self._catalog = catalog
        self._fill_form(catalog)
        self._reload_catalog_list()
        for index in range(self._list.count()):
            item = self._list.item(index)
            if item and item.data(Qt.ItemDataRole.UserRole) == catalog.schema_id:
                self._list.setCurrentItem(item)
                break

    def _on_delete_catalog(self) -> None:
        schema_id = self.selected_schema_id()
        if not schema_id:
            return
        answer = QMessageBox.question(
            self,
            tr("emr.schema.edit.delete"),
            tr("emr.schema.edit.delete_confirm", schema_id=schema_id),
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self._store.delete(schema_id)
        self._catalog = None
        self._clear_form()
        self._reload_catalog_list()
        self.catalogs_changed.emit()
        self.user_message.emit(tr("emr.schema.edit.deleted"))

    def _on_import_columns(self) -> None:
        if self._dataset is None:
            self.user_message.emit(tr("emr.schema.edit.need_dataset"))
            return
        existing = {spec.name.casefold() for spec in self._collect_columns()}
        for column in self._dataset.columns:
            if column.name.casefold() in existing:
                continue
            dtype = "string"
            lowered = column.dtype.casefold()
            if "int" in lowered:
                dtype = "integer"
            elif "float" in lowered or "decimal" in lowered:
                dtype = "decimal"
            elif "bool" in lowered:
                dtype = "boolean"
            elif "date" in lowered and "time" in lowered:
                dtype = "datetime"
            elif "date" in lowered:
                dtype = "date"
            self._append_row(
                SchemaColumnSpec(
                    name=column.name,
                    data_type=dtype,  # type: ignore[arg-type]
                    allows_null=column.null_count > 0,
                    enabled=True,
                )
            )
            existing.add(column.name.casefold())

    def _on_add_row(self) -> None:
        self._append_row()

    def _on_remove_rows(self) -> None:
        rows = sorted({index.row() for index in self._table.selectedIndexes()}, reverse=True)
        if not rows:
            return
        for row in rows:
            self._table.removeRow(row)

    def _on_save(self) -> None:
        if self._catalog is None:
            self.user_message.emit(tr("emr.schema.edit.need_catalog"))
            return
        name = self._name.text().strip()
        if not name:
            self.user_message.emit(tr("emr.schema.edit.need_name"))
            return
        columns = self._collect_columns()
        if not columns:
            self.user_message.emit(tr("emr.schema.edit.need_columns"))
            return
        batch_error = self._batch_match.validate(self._catalog.schema_id)
        if batch_error:
            QMessageBox.warning(
                self,
                tr("emr.batch_match.invalid_regex"),
                batch_error,
            )
            return
        batch_match = self._batch_match.spec()
        payload = SchemaCatalog(
            schema_id=self._catalog.schema_id,
            name=name,
            strict=self._strict.isChecked(),
            columns=columns,
            created_at=self._catalog.created_at,
            updated_at=self._catalog.updated_at,
            batch_match=batch_match,
        )
        try:
            saved = self._store.save(payload)
        except SchemaCatalogValidationError as exc:
            QMessageBox.warning(self, tr("emr.app.title"), str(exc))
            return
        self._catalog = saved
        self._reload_catalog_list()
        self.catalogs_changed.emit()
        self.user_message.emit(tr("emr.schema.edit.saved"))
