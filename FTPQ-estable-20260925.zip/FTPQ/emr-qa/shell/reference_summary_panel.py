"""Panel resumen — comparación contra referencia (estilo KPI QA)."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from shell.qa_metrics_layout import configure_metrics_scroll, sync_metrics_scroll_content
from shell.reference_metrics import ReferenceCompareReport
from shell.reference_metrics_charts import ReferenceMetricsChartsWidget
from shell.reference_metrics_fullscreen_dialog import ReferenceMetricsReportDialog
from shell.reference_metrics_pdf_export import (
    default_pdf_filename,
    export_reference_metrics_pdf,
    pick_pdf_export_path,
)
from shell.reference_metrics_report_view import ReferenceMetricsReportView
from ui.i18n import tr


class ReferenceSummaryPanel(QFrame):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("panel")
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self._fullscreen_dialog: ReferenceMetricsReportDialog | None = None
        self._nok_only = False

        self._title = QLabel()
        self._title.setObjectName("panelSubtitle")
        self._status = QLabel()
        self._status.setObjectName("panelTitle")
        self._status.setWordWrap(True)
        self._headline = QLabel()
        self._headline.setObjectName("configHint")
        self._headline.setWordWrap(True)

        self._kpi_rows = QLabel()
        self._kpi_cells = QLabel()
        self._kpi_no_match = QLabel()
        self._kpi_deltas = QLabel()
        for label in (self._kpi_rows, self._kpi_cells, self._kpi_no_match, self._kpi_deltas):
            label.setObjectName("configHint")
            label.setWordWrap(True)

        kpi_grid = QGridLayout()
        kpi_grid.setContentsMargins(0, 0, 0, 0)
        kpi_grid.setHorizontalSpacing(8)
        kpi_grid.setVerticalSpacing(2)
        kpi_grid.addWidget(self._kpi_rows, 0, 0)
        kpi_grid.addWidget(self._kpi_cells, 0, 1)
        kpi_grid.addWidget(self._kpi_no_match, 1, 0)
        kpi_grid.addWidget(self._kpi_deltas, 1, 1)

        self._nok_filter = QCheckBox()
        self._nok_filter.toggled.connect(self._on_nok_filter)

        self._fullscreen = QPushButton()
        self._fullscreen.clicked.connect(self._open_fullscreen)
        self._copy = QPushButton()
        self._copy.clicked.connect(self._copy_report)
        self._copy_csv = QPushButton()
        self._copy_csv.clicked.connect(self._copy_csv_text)
        self._export_pdf = QPushButton()
        self._export_pdf.clicked.connect(self._export_pdf_file)

        actions = QHBoxLayout()
        actions.setContentsMargins(0, 0, 0, 0)
        actions.addWidget(self._nok_filter)
        actions.addWidget(self._fullscreen)
        actions.addStretch(1)
        actions.addWidget(self._copy)
        actions.addWidget(self._copy_csv)
        actions.addWidget(self._export_pdf)

        self._report_view = ReferenceMetricsReportView()
        self._charts = ReferenceMetricsChartsWidget()
        self._details_host = QWidget()
        self._details_host.setObjectName("referenceMetricsScrollHost")
        details_layout = QVBoxLayout(self._details_host)
        details_layout.setContentsMargins(0, 0, 0, 0)
        details_layout.setSpacing(12)
        details_layout.addWidget(self._report_view)
        details_layout.addWidget(self._charts)

        self._details_scroll = QScrollArea()
        configure_metrics_scroll(self._details_scroll)
        self._details_scroll.setWidget(self._details_host)
        self._details_scroll.setMaximumHeight(420)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        layout.addWidget(self._title)
        layout.addWidget(self._status)
        layout.addWidget(self._headline)
        layout.addLayout(kpi_grid)
        layout.addLayout(actions)
        layout.addWidget(self._details_scroll, stretch=1)

        self._report: ReferenceCompareReport | None = None
        self.retranslate_ui()
        self.set_idle()

    def retranslate_ui(self) -> None:
        self._title.setText(tr("emr.ref.summary.title"))
        self._nok_filter.setText(tr("emr.qa.metrics.nok_only"))
        self._fullscreen.setText(tr("emr.ref.fullscreen.open"))
        self._copy.setText(tr("emr.qa.metrics.copy_report"))
        self._copy_csv.setText(tr("emr.qa.metrics.copy_csv"))
        self._export_pdf.setText(tr("emr.qa.metrics.export_pdf"))
        self._report_view.retranslate_ui()
        self._charts.retranslate_ui()
        if self._report is not None:
            self._apply_report(self._report)
        elif self._status.text() == "" or self._status.text() == tr("emr.ref.summary.idle"):
            self.set_idle()

    def set_idle(self) -> None:
        self._report = None
        self._status.setText(tr("emr.ref.summary.idle"))
        self._headline.setText(tr("emr.ref.summary.idle_hint"))
        self._clear_kpis()
        self._report_view.set_report(None)
        self._charts.set_report(None)
        self._copy.setEnabled(False)
        self._copy_csv.setEnabled(False)
        self._export_pdf.setEnabled(False)
        self._fullscreen.setEnabled(False)
        self._details_scroll.hide()

    def set_idle_preserve_report(self) -> None:
        if self._report is not None:
            self._apply_report(self._report)
            self._headline.setText(
                f"{self._report.headline}\n{tr('emr.ref.config_pending')}"
            )
            return
        self.set_idle()

    def set_running(self) -> None:
        self._status.setText(tr("emr.ref.summary.running"))
        self._headline.setText(tr("emr.ref.summary.running_hint"))
        self._clear_kpis()
        self._copy.setEnabled(False)
        self._copy_csv.setEnabled(False)
        self._export_pdf.setEnabled(False)
        self._fullscreen.setEnabled(False)
        self._details_scroll.hide()

    def set_error(self, message: str) -> None:
        self._report = None
        self._status.setText(tr("emr.ref.summary.error"))
        self._headline.setText(message)
        self._clear_kpis()
        self._report_view.set_report(None)
        self._charts.set_report(None)
        self._copy.setEnabled(False)
        self._copy_csv.setEnabled(False)
        self._export_pdf.setEnabled(False)
        self._fullscreen.setEnabled(False)
        self._details_scroll.hide()

    def set_report(self, report: ReferenceCompareReport | None) -> None:
        self._report = report
        if report is None:
            self.set_idle()
            return
        self._apply_report(report)
        self._copy.setEnabled(True)
        self._copy_csv.setEnabled(True)
        self._export_pdf.setEnabled(True)
        self._fullscreen.setEnabled(True)

    def _apply_report(self, report: ReferenceCompareReport) -> None:
        self._status.setText(tr("emr.ref.summary.done"))
        self._headline.setText(report.headline)
        self._kpi_rows.setText(
            tr(
                "emr.ref.summary.kpi_rows",
                matched=f"{report.rows_matched_key:,}",
                total=f"{report.rows_compared:,}",
                pct=f"{report.row_match_pct:.2f}",
            )
        )
        self._kpi_cells.setText(
            tr(
                "emr.ref.summary.kpi_cells",
                ok=f"{report.cells_ok:,}",
                total=f"{report.cells_ok + report.cells_nok:,}",
                pct=f"{report.cell_match_pct:.2f}",
            )
        )
        self._kpi_no_match.setText(
            tr(
                "emr.ref.summary.kpi_no_match",
                count=report.rows_without_match,
                ambiguous=report.rows_ambiguous_key,
            )
        )
        self._kpi_deltas.setText(
            tr(
                "emr.ref.summary.kpi_deltas",
                count=report.cells_nok,
                pairs=report.pairs_compared,
            )
        )
        self._report_view.set_report(report, nok_only=self._nok_only)
        self._charts.set_report(report, nok_only=self._nok_only)
        self._details_scroll.show()
        self._sync_details_size()

    def _on_nok_filter(self, checked: bool) -> None:
        self._nok_only = checked
        if self._report is not None:
            self._report_view.set_report(self._report, nok_only=checked)
            self._charts.set_report(self._report, nok_only=checked)
            self._sync_details_size()

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        if self._report is not None:
            self._sync_details_size()

    def _sync_details_size(self) -> None:
        sync_metrics_scroll_content(
            self._details_scroll,
            self._details_host,
            self._report_view,
            self._charts,
        )

    def _clear_kpis(self) -> None:
        self._kpi_rows.clear()
        self._kpi_cells.clear()
        self._kpi_no_match.clear()
        self._kpi_deltas.clear()

    def _copy_report(self) -> None:
        if self._report is None:
            return
        QApplication.clipboard().setText(
            self._report.to_copyable_text(nok_only=self._nok_only)
        )

    def _copy_csv_text(self) -> None:
        if self._report is None:
            return
        QApplication.clipboard().setText(self._report.to_csv(nok_only=self._nok_only))

    def _export_pdf_file(self) -> None:
        if self._report is None:
            return
        default_name = default_pdf_filename(self._report.file_name)
        path = pick_pdf_export_path(self.window(), default_name=default_name)
        if path is None:
            return
        try:
            export_reference_metrics_pdf(
                path,
                report_view=self._report_view,
                charts=self._charts,
            )
        except OSError as exc:
            QMessageBox.warning(
                self.window(),
                tr("emr.qa.metrics.export_pdf"),
                tr("emr.qa.metrics.export_pdf_fail", error=exc),
            )
            return
        QMessageBox.information(
            self.window(),
            tr("emr.qa.metrics.export_pdf"),
            tr("emr.qa.metrics.export_pdf_done", path=str(path)),
        )

    def _open_fullscreen(self) -> None:
        if self._report is None:
            return
        dialog = ReferenceMetricsReportDialog(
            self._report,
            nok_only=self._nok_only,
            parent=self.window(),
        )
        self._fullscreen_dialog = dialog
        dialog.finished.connect(lambda _result: setattr(self, "_fullscreen_dialog", None))
        dialog.exec()
