# Módulo EMR QA — reconciliación local

**Estado:** iteración 1 (extracción HTML → base local)  
**ADR:** [`adr/0001-alcance-local-only.md`](./adr/0001-alcance-local-only.md)

Herramienta para **recordar pantallas EMR**: el operador decide **cuándo** sacar un snap del estado visible, etiqueta lo que importa y persiste en una **base de conocimiento local** (no compartible).

PDE Desktop (SFTP/UI) **no se modifica** en comportamiento baseline; EMR QA vive en `emr-qa/` en la raíz del repo.

---

## Qué es y qué no es

EMR QA **no es un navegador** ni un robot que recorre el EMR por cuenta propia. Es un **cuaderno de memoria** sobre instantáneas que tú eliges guardar.

| | EMR QA (este módulo) | Navegador / Selenium / Playwright |
|---|----------------------|-----------------------------------|
| **Quién decide** | Tú: cuándo hacer snap, qué pantalla, si crear plantilla | El script: URLs, clicks, timing |
| **Qué se guarda** | Snap estático (HTML/texto pegado) + tags sobre fragmentos | Lectura repetida del DOM en vivo |
| **Plantillas** | Opcionales: las creas si hace falta reutilizar tags en pantallas similares | Selectores CSS/XPath que hay que mantener |
| **Rol de la app** | Editor local para marcar y recordar | Automatización del browser |
| **Cuándo encaja** | Memorizar “así se ve esta pantalla y estos campos importan” | Repetir la misma extracción muchas veces sin intervención |

### Flujo mental

1. En el EMR real (Chrome, Edge, lo que uses) navegas hasta la pantalla que te interesa.
2. **Cuando tú quieras**, sacas un snap: copiar HTML, “Guardar como”, snippet en consola F12, etc.
3. Pegas ese snap en el editor EMR QA (o lo abres desde archivo).
4. Seleccionas trozos de texto y los **recuerdas** con tags (nombre, clasificación, identificación…).
5. Si la pantalla se repite con otro layout, **opcionalmente** guardas o cargas una **plantilla** de tags y mapeas de nuevo.

No hay polling, no hay “leer la página cada N segundos”, no hay login automatizado. El snap es **discreto y bajo tu control**.

### Ambientes (dev / stage / prd)

Tienes **tres ambientes** EMR. Al sacar un snap, pegas la **URL de la barra del browser** en el editor; el módulo infiere el ambiente (`dev`, `stage`, `prd`) según patrones configurados.

- **UI:** menú **Configuración → Ambientes (URLs dev / stage / prd)…** en el editor EMR QA.
- **Archivo:** [`emr-qa/config/environments.json`](../../emr-qa/config/environments.json) (misma fuente que el diálogo).

- La URL y el ambiente se guardan en `_meta` de cada captura (y opcionalmente en plantillas).
- Si la URL no coincide con ningún patrón → `unknown`; puedes corregirlo manualmente en el combo.
- **Edita los patrones** con tus hosts reales (orden: dev → stage → prd; gana la primera coincidencia).

Ejemplo de patrones (ajústalos a tu org):

```json
{ "id": "dev", "url_patterns": ["dev.emr.midominio.com"] },
{ "id": "stage", "url_patterns": ["stage.emr.midominio.com"] },
{ "id": "prd", "url_patterns": ["app.emr.midominio.com"] }
```

### Por qué no Selenium en v1

Selenium y similares resuelven **automatizar el browser**. Este módulo resuelve **decidir qué vale la pena recordar** de una pantalla concreta. Son problemas distintos; en una fase posterior podría existir un helper que *obtenga* el HTML, pero no sustituye el editor ni las plantillas.

---

## Principios acordados

| Tema | Decisión |
|------|----------|
| Ubicación | Dentro de `FTPQ/` |
| PDE existente | Intacto; se **agregan** funcionalidades |
| Conectores BD | **No** — solo archivos locales |
| Golden dataset | **Evolutivo**; PK definido por el usuario en cada iteración de base |
| Catálogos / config | Estables; datos transaccionales muy volátiles → **omitir** en v1 |
| Multi-ventana | Posible; forma de interacción **manual**, no automática |
| QA online | **No** — datos estáticos simulados; asumimos deltas |
| Extracción | HTML de página + mapa de campos; **no** tabla/listado masivo |
| Tipo captura | Simulador de carga (estado de pantalla), no scrape de grid |
| Fechas | Deben llevar **UTC explícito** para cuadrar vs TXT/backend |
| PII | Sin enmascarado; herramienta personal; protección = gestión local, no export |
| Ejecución | Manual: yo decido el snap → pegar URL + contenido en editor → guardar en mi base |
| Ambientes | **dev / stage / prd** — reconocidos por URL (`config/environments.json`) |
| Navegador integrado | **No** — el EMR se usa fuera; EMR QA solo recibe el snap |
| Plantillas | **Opcionales** — crear solo si la pantalla se repite o conviene reutilizar tags |
| Consolidator / Validator | **Postergados** — spec e implementación incremental |

---

## Estructura prevista (repo)

```text
emr-qa/
  browser_extractor.js      # iteración 1
  knowledge_bases/          # una carpeta por base de conocimiento (usuario)
  captures/                 # JSON crudos por captura (nombre TBD en implementación)
  reports/                  # fase validator (futuro)

documentacion/emr-qa/       # spec (este árbol)
```

Nombres finales de carpetas (`captures` vs `capturas`) se fijan al implementar.

---

## Documentos

| Archivo | Contenido |
|---------|-----------|
| [adr/0001-alcance-local-only.md](./adr/0001-alcance-local-only.md) | Alcance, permitido/prohibido |
| [iteracion-01-extraccion.md](./iteracion-01-extraccion.md) | Primera entrega: JS + mapa HTML + persistencia local |

---

## Relación con otros módulos FTPQ

| Módulo | Relación |
|--------|----------|
| SFTP | Ninguna en v1 |
| Pandas | Futuro validator local sobre TXT |
| UI PySide6 | Opcional más adelante; no bloquea v1 |

---

## Pendiente (no bloquea iteración 1)

- Definición de `clinic_id` / IDs sintéticos de filtro
- Reglas consolidator: dedup, historial, schema CSV master
- Spec validator: formato TXT, join, reportes — **más simple** que el prompt original; no generador de diagnósticos masivos
