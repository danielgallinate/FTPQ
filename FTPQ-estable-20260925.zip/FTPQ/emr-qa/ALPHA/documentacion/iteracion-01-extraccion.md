# Iteración 1 — Editor de marcado manual

## Objetivo

Herramienta local para **recordar pantallas EMR**. El operador controla el ritmo: **no hay navegador integrado** ni extracción automática; el snap lo dispara el usuario cuando la pantalla está en el estado que quiere memorizar.

Ver también la tabla **Qué es y qué no es** en [`README.md`](./README.md) (contraste explícito vs Selenium/navegador automatizado).

1. Sacar snap de la página **cuando decidas** (fuera del editor: copiar HTML, consola, archivo…).
2. Pegar HTML/texto del snap en el editor.
3. Seleccionar porciones y **taggear** (clasificación, subclasificación, identificación, nombre).
4. Guardar **capturas** (texto + marcadores + valores seleccionados).
5. **(Opcional)** Definir **plantillas** de tags reutilizables — solo si la pantalla se repite o conviene estandarizar.
6. En otra pantalla, **mapear** tags existentes a nuevos fragmentos o crear tags nuevos.

**No incluye:** navegador embebido, Selenium/Playwright, DOM en vivo, polling, consolidator, validator (fases posteriores).

Implementación: `./scripts/run_emr_qa_editor.sh` → `emr-qa/editor/`.

---

## Modelo de datos

### Tag (definición)

| Campo | Uso |
|-------|-----|
| `name` | Clave lógica del campo |
| `classification` | Categoría principal |
| `subclassification` | Subtipo |
| `identification` | Rol del identificador |
| `notes` | Notas libres |

### Plantilla (`templates/*.json`)

Conjunto de tags esperados para un **tipo de pantalla**. Misma pantalla distinta layout → otra plantilla.

### Captura (`captures/*.json`)

```json
{
  "_meta": {
    "capture_id": "cap_…",
    "knowledge_base_id": "default",
    "template_id": "tpl_…",
    "record_pk": "opcional",
    "source_url": "https://dev.emr.example.com/patient/123",
    "environment": "dev",
    "captured_at": "…Z",
    "source": "manual_tag_editor"
  },
  "source_text": "… HTML pegado …",
  "markers": [
    {
      "tag_id": "tag_…",
      "name": "mrn",
      "classification": "identificacion",
      "start": 120,
      "end": 126,
      "text": "001234"
    }
  ]
}
```

Los offsets permiten resaltar en el editor; **no** implican selectores DOM.

### Ambiente en plantilla

Campo opcional `"environment": "dev|stage|prd"` en el JSON de plantilla — útil para no mezclar tags de distintos ambientes.

---

## Fechas (fase posterior)

Al marcar fechas, en una iteración siguiente el editor ofrecerá objeto `{ raw, iso_utc, source_tz }`. v1 guarda el texto seleccionado tal cual.

---

## Entregables iteración 1

- [x] Editor PySide6 (`emr-qa/editor/`)
- [x] Modelos + storage JSON
- [x] `./scripts/run_emr_qa_editor.sh`
- [x] Fixture `fixtures/sample_page.html`
- [x] Menú **Configuración → Ambientes** (URLs dev / stage / prd)
- [x] Búsqueda in-text en el panel central (`Ctrl+F`, Siguiente/Anterior)
- [x] `browser_extractor.js` — URL → plantilla → `emrQaCapture()`

---

## Uso rápido

Ver [`../../emr-qa/README.md`](../../emr-qa/README.md).
