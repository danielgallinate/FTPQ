# ADR-0001: Módulo EMR QA local dentro de FTPQ

## Estado
Aceptado (2026-07-22)

## Contexto

FTPQ hereda PDE Desktop 1.0.0 (SFTP + file manager + compare pandas + UI PySide6).  
Se agrega una **nueva ruta funcional**: reconciliación manual EMR ↔ exports Snowflake, **100 % local**, sin conectores live.

La regla `.cursor/rules/scope-no-db.mdc` prohíbe Postgres/Snowflake connector y validación estilo validator TUI contra BD. Este módulo **no viola** esa intención si opera solo con:

- HTML capturado en browser (JS en consola F12)
- Archivos JSON/TXT en disco
- Scripts Python locales (pandas)

Requiere ADR explícito porque el **dominio** (golden dataset, cruce masivo) se parece al validator archivado, pero el **modo de operación** es distinto.

## Decisión

1. **Ubicación:** subcarpeta `emr-qa/` en la raíz de FTPQ + spec en `documentacion/emr-qa/`.
2. **PDE Desktop intacto:** no modificar flujos SFTP/UI existentes salvo wiring explícito futuro. EMR QA es funcionalidad **añadida**.
3. **Prohibido en este módulo (sin nuevo ADR):**
   - `psycopg2`, `asyncpg`, `snowflake-connector-python`
   - Consultas live a RDS / `extract_history` / CONFIG en BD
   - Distribución de bases locales a terceros
4. **Permitido:**
   - JavaScript vanilla en consola del navegador
   - Python + pandas (+ DuckDB opcional en fases posteriores)
   - Bases de conocimiento locales definidas por el usuario
   - TXT masivo Snowflake **como archivo** en disco
5. **Datos:** uso individual; acceso prod autorizado por el operador; bases locales no compartibles (ver `alcance-uso-individual.md`).

## Consecuencias

### Positivas
- Reutiliza entorno FTPQ (venv, scripts, documentación por módulo)
- Separación clara de dominios: `core/` SFTP no se contamina
- Agentes Cursor pueden trabajar EMR QA sin confundirlo con scope PDE fase 0–2

### Negativas
- Dos productos lógicos en un repo → índices y skills deben mantenerse
- Validación de fechas/timezone requiere reglas explícitas (no automáticas)

## Fuera de alcance (iteración 1)

- Consolidador Python (`consolidator.py`) — postergado
- Reconciliador masivo (`validator.py`) — incremental, spec aparte
- QA online, catálogos inmutables de alto nivel, schema_version rígido
- Lista fija de `clinic_id` QA — se define en primera iteración de extracción

## Alternativas consideradas

- **Repo hermano aparte** → descartado; usuario eligió dentro de FTPQ
- **Integrar en UI PySide6 desde día 1** → descartado; flujo manual browser + JS primero
- **Selenium / Playwright / navegador integrado** → descartado en v1; el operador **decide cuándo** sacar el snap; EMR QA es editor de memoria sobre instantáneas estáticas, no automatización del EMR (ver [`../README.md`](../README.md) § Qué es y qué no es)

## Referencias

- Spec módulo: [`../README.md`](../README.md)
- Iteración 1: [`../iteracion-01-extraccion.md`](../iteracion-01-extraccion.md)
- Alcance individual: [`../../alcance-uso-individual.md`](../../alcance-uso-individual.md)
