# EMR QA — ALPHA (archivo del enfoque anterior)

**Estado:** congelado · **Fecha de archivo:** 2026-07-29  
**Motivo:** el HTML que genera el EMR real (mezcla de `<select>`, checkboxes, radios, inputs vacíos y bloques JS embebidos) no es un snap amigable para marcar a mano. Se pivotará a un enfoque nuevo; este árbol queda como referencia **old**.

Nada se borró del repo activo. El código en `emr-qa/` (fuera de `ALPHA/`) sigue intacto hasta que definamos el nuevo acercamiento y retiremos piezas de forma incremental.

---

## Qué hay aquí

| Ruta | Contenido |
|------|-----------|
| [`snapshot/`](./snapshot/) | Copia completa del módulo EMR QA al momento del archivo (editor PySide6, core, capture JS, plantilla WebPT, tests, scripts) |
| [`documentacion/`](./documentacion/) | Spec iteración 1 tal como estaba en `documentacion/emr-qa/` |

---

## Enfoque anterior (iteración 1) — resumen

### Idea

Cuaderno de memoria local sobre **instantáneas discretas** que el operador elige guardar. Sin navegador integrado, sin Selenium, sin BD.

1. Navegar al EMR en Chrome/Edge (fuera de PDE).
2. Sacar snap cuando quieras: copiar HTML, `copy(JSON.stringify(wpt.page.vars.facility))`, etc.
3. Pegar URL + snap en el editor PySide6.
4. Seleccionar fragmentos de texto → **Marcar selección** → tag (nombre, clasificación, identificación).
5. Guardar captura JSON en `knowledge_bases/<id>/captures/`.
6. *(Opcional)* Plantilla de tags reutilizable + **Modo mapeo** para pantallas similares.
7. *(Opcional)* `browser_extractor.js` + `emrQaCapture()` en consola F12 si hay plantilla con `url_patterns`.

### Piezas principales

```text
snapshot/
  editor/           app PySide6 — panel texto, tabla tags, modo mapeo
  core/             modelos Tag/Capture/Template, storage JSON, ambientes dev/stage/prd
  capture/          runtime.js embebido en extractor exportado
  browser_extractor.js   captura automática vía wpt.page.vars (WebPT)
  knowledge_bases/default/templates/tpl_webpt_edit_clinic.json   61 tags Edit Clinic
```

Código legacy archivado (captura HTML / scraper de pantallas — **no usar**). Ver [`snapshot/README.md`](./snapshot/README.md) dentro de este árbol.

Spec histórica congelada en `ALPHA/documentacion/`. Flujo activo: [`../../documentacion/emr-qa/README.md`](../../documentacion/emr-qa/README.md).

Alcance repo: [`../../documentacion/alcance-validador-tabular.md`](../../documentacion/alcance-validador-tabular.md) · Handoff: [`../../HANDOFF.md`](../../HANDOFF.md)

---

## Por qué no escaló (lecciones)

| Problema | Detalle |
|----------|---------|
| **HTML del EMR poco usable** | Snap de “Guardar como” / View Source mezcla combos, checks, radios, labels duplicados e inputs vacíos; el valor real a menudo está en JS (`wpt.page.vars`), no en el DOM visible |
| **Doble fuente de verdad** | Operador debe saber si marcar HTML o JSON de consola; la plantilla WebPT (61 tags) documenta explícitamente “NO marcar input#name vacío” |
| **Mapeo manual pesado** | Modo mapeo + offsets de texto no escala a formularios grandes ni a controles que no serializan bien en texto plano |
| **Extractor acoplado a WebPT** | `webpt_page_vars` + `companies[companyId]` — útil como prueba, no como modelo genérico |
| **UX del editor** | Buscar en bloque monolítico de HTML/JSON; selección por offsets frágil ante cualquier cambio de layout |

Estas limitaciones motivan el **nuevo enfoque** (por definir contigo). ALPHA conserva el diseño y el código para consulta o rollback parcial.

---

## Cómo ejecutar el snapshot (referencia)

Desde la raíz del repo, apuntando al snapshot congelado:

```bash
# Editor (requiere .venv de ./scripts/setup.sh)
./.venv/bin/python3 emr-qa/ALPHA/snapshot/editor/app.py

# Regenerar browser_extractor.js desde plantillas del snapshot
./emr-qa/ALPHA/snapshot/scripts/export_emr_qa_capture.sh
# (ajustar ROOT en el script si hace falta — el snapshot asume repo raíz)

# Tests del snapshot (pytest desde raíz, paths relativos al snapshot)
./.venv/bin/python3 -m pytest emr-qa/ALPHA/snapshot/tests/ -q
```

Los scripts en `snapshot/scripts/` son copia fiel; el flujo **oficial** del repo sigue siendo `./scripts/run_emr_qa_editor.sh` sobre `emr-qa/` activo.

---

## Próximo paso

1. Operador define **funcionalidad EMR** sobre la base local (ver [`../documentacion/emr-qa/iteracion-02-enfoque-local.md`](../documentacion/emr-qa/iteracion-02-enfoque-local.md)).
2. Implementar en `emr-qa/` fuera de `ALPHA/`.
3. Ir eliminando piezas de iteración 1 del árbol activo; **ALPHA no se toca**.

---

## Relación con PDE Desktop

- ADR alcance local-only sigue vigente para el módulo EMR QA en general.
- SFTP / UI PySide6 baseline de PDE no dependen de este módulo.
- ALPHA no es el flujo activo; solo referencia histórica. Ver [`documentacion/alcance-validador-tabular.md`](../../documentacion/alcance-validador-tabular.md).
