/* EMR QA — generado desde knowledge_bases/ + config/environments.json
   Regenerar: ./scripts/export_emr_qa_capture.sh
   Uso en consola F12: emrQaCapture()
*/
(function () {
  "use strict";

  function registry() {
    return window.__EMR_QA_REGISTRY__ || { version: 0, templates: [], environments: [] };
  }

  function detectEnvironment(href, cfg) {
    var url = (href || "").toLowerCase();
    var rules = (cfg && cfg.environments) || [];
    for (var i = 0; i < rules.length; i++) {
      var rule = rules[i];
      var patterns = rule.url_patterns || [];
      for (var j = 0; j < patterns.length; j++) {
        if (url.indexOf(String(patterns[j]).toLowerCase()) >= 0) {
          return rule.id;
        }
      }
    }
    return (cfg && cfg.default_environment) || "unknown";
  }

  function findTemplate(href, title) {
    var haystack = ((href || "") + " " + (title || "")).toLowerCase();
    var templates = registry().templates || [];
    for (var i = 0; i < templates.length; i++) {
      var tpl = templates[i];
      var patterns = tpl.url_patterns || [];
      for (var j = 0; j < patterns.length; j++) {
        if (haystack.indexOf(String(patterns[j]).toLowerCase()) >= 0) {
          return tpl;
        }
      }
    }
    return null;
  }

  function webptRoot(extractor) {
    var vars = window.wpt && window.wpt.page && window.wpt.page.vars;
    if (!vars) {
      return null;
    }
    var rootKey = (extractor && extractor.root) || "facility";
    return { vars: vars, facility: vars[rootKey] || null };
  }

  function resolveIdentification(identification, ctx) {
    if (!identification) {
      return null;
    }
    if (identification === "companies[companyId]") {
      var companyId = ctx.facility && ctx.facility.companyId;
      if (companyId == null || !ctx.vars || !ctx.vars.companies) {
        return null;
      }
      return ctx.vars.companies[String(companyId)] ?? null;
    }
    if (ctx.facility && Object.prototype.hasOwnProperty.call(ctx.facility, identification)) {
      return ctx.facility[identification];
    }
    return null;
  }

  function formatValue(value) {
    if (value == null) {
      return "";
    }
    if (typeof value === "object") {
      return JSON.stringify(value);
    }
    return String(value);
  }

  function newCaptureId() {
    return "cap_" + Math.random().toString(16).slice(2, 14);
  }

  function extractFields(template, ctx) {
    var fields = {};
    var markers = [];
    var tags = template.tags || [];
    for (var i = 0; i < tags.length; i++) {
      var tag = tags[i];
      var raw = resolveIdentification(tag.identification, ctx);
      var text = formatValue(raw);
      fields[tag.name] = {
        tag_id: tag.tag_id,
        name: tag.name,
        identification: tag.identification,
        classification: tag.classification || "",
        subclassification: tag.subclassification || "",
        value: raw,
        text: text,
      };
      markers.push({
        marker_id: "mk_" + Math.random().toString(16).slice(2, 10),
        tag_id: tag.tag_id,
        name: tag.name,
        classification: tag.classification || "",
        subclassification: tag.subclassification || "",
        identification: tag.identification || "",
        start: -1,
        end: -1,
        text: text,
      });
    }
    return { fields: fields, markers: markers };
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      try {
        var area = document.createElement("textarea");
        area.value = text;
        area.style.position = "fixed";
        area.style.left = "-9999px";
        document.body.appendChild(area);
        area.select();
        document.execCommand("copy");
        document.body.removeChild(area);
        resolve();
      } catch (err) {
        reject(err);
      }
    });
  }

  function emrQaCapture(options) {
    options = options || {};
    var href = window.location.href;
    var title = document.title || "";
    var cfg = registry();
    var template = findTemplate(href, title);
    if (!template) {
      if (!options.silent) {
        console.info("[EMR QA] Sin plantilla para esta URL — no se captura.", href);
      }
      return null;
    }

    var extractor = template.extractor || { type: "webpt_page_vars", root: "facility" };
    if (extractor.type !== "webpt_page_vars") {
      console.warn("[EMR QA] Extractor no soportado:", extractor.type);
      return null;
    }

    var ctx = webptRoot(extractor);
    if (!ctx || !ctx.facility) {
      console.warn("[EMR QA] No hay wpt.page.vars.facility en esta página.");
      return null;
    }

    var extracted = extractFields(template, ctx);
    var capturedAt = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
    var capture = {
      _meta: {
        capture_id: newCaptureId(),
        knowledge_base_id: template.knowledge_base_id || "default",
        template_id: template.template_id,
        source_url: href,
        environment: detectEnvironment(href, cfg),
        captured_at: capturedAt,
        source: "browser_extractor",
        page_title: title,
      },
      source_text: JSON.stringify(ctx.facility, null, 2),
      fields: extracted.fields,
      markers: extracted.markers,
    };

    var json = JSON.stringify(capture, null, 2);
    if (options.copy !== false) {
      copyText(json).then(
        function () {
          console.info(
            "[EMR QA] Captura copiada al portapapeles:",
            template.name,
            "(" + Object.keys(extracted.fields).length + " campos)"
          );
        },
        function () {
          console.info("[EMR QA] Captura lista (no se pudo copiar al portapapeles):", capture);
        }
      );
    } else {
      console.info("[EMR QA] Captura:", capture);
    }
    return capture;
  }

  window.emrQaCapture = emrQaCapture;
})();

window.__EMR_QA_REGISTRY__ = {"version": 1, "environments": [{"id": "dev", "label": "Development", "url_patterns": [".dev.", "-dev.", "dev.", "localhost", "127.0.0.1"]}, {"id": "stage", "label": "Staging", "url_patterns": [".stage.", "-stage.", "staging.", ".stg.", "-stg."]}, {"id": "prd", "label": "Production", "url_patterns": [".prod.", "-prod.", "production.", ".prd.", "-prd."]}], "default_environment": "unknown", "templates": [{"template_id": "tpl_webpt_edit_clinic", "name": "WebPT — Edit Clinic", "description": "Admin Edit Clinic. Buscar \"facility\":{ en el snap. Valores reales en wpt.page.vars.facility; inputs HTML suelen ir vacíos.", "updated_at": "2026-07-27T22:08:20Z", "tags": [{"tag_id": "tag_clinic_id", "name": "clinic_id", "classification": "identificacion", "subclassification": "clinica", "identification": "id", "notes": "UI: Clinic ID | JSON: id | facility.id en wpt.page.vars"}, {"tag_id": "tag_status", "name": "status", "classification": "identificacion", "subclassification": "clinica", "identification": "status", "notes": "UI: Status | JSON: status | A = activo"}, {"tag_id": "tag_company_id", "name": "company_id", "classification": "identificacion", "subclassification": "empresa", "identification": "companyId", "notes": "UI: Company ID | JSON: companyId"}, {"tag_id": "tag_company_name", "name": "company_name", "classification": "identificacion", "subclassification": "empresa", "identification": "companies[companyId]", "notes": "UI: Company Name | JSON: companies[companyId] | mapa wpt.page.vars.companies"}, {"tag_id": "tag_clinic_name", "name": "clinic_name", "classification": "identificacion", "subclassification": "clinica", "identification": "name", "notes": "UI: Clinic Name | JSON: name | NO marcar input#name vacío"}, {"tag_id": "tag_clinic_name_2", "name": "clinic_name_2", "classification": "identificacion", "subclassification": "clinica", "identification": "nameOtherDesignation", "notes": "UI: Clinic Name 2 | JSON: nameOtherDesignation"}, {"tag_id": "tag_address_street", "name": "address_street", "classification": "direccion", "subclassification": "principal", "identification": "addressStreet", "notes": "UI: Address | JSON: addressStreet"}, {"tag_id": "tag_address_other", "name": "address_other", "classification": "direccion", "subclassification": "principal", "identification": "addressOtherDesignation", "notes": "UI: Address 2 | JSON: addressOtherDesignation"}, {"tag_id": "tag_address_city", "name": "address_city", "classification": "direccion", "subclassification": "principal", "identification": "addressCity", "notes": "UI: City | JSON: addressCity"}, {"tag_id": "tag_address_state", "name": "address_state", "classification": "direccion", "subclassification": "principal", "identification": "addressStateProvince", "notes": "UI: State | JSON: addressStateProvince"}, {"tag_id": "tag_address_zip", "name": "address_zip", "classification": "direccion", "subclassification": "principal", "identification": "addressPostalCode", "notes": "UI: Zip Code | JSON: addressPostalCode"}, {"tag_id": "tag_address_country", "name": "address_country", "classification": "direccion", "subclassification": "principal", "identification": "addressCountry", "notes": "UI: Country | JSON: addressCountry"}, {"tag_id": "tag_time_zone", "name": "time_zone", "classification": "configuracion", "subclassification": "clinica", "identification": "timeZone", "notes": "UI: Time Zone | JSON: timeZone"}, {"tag_id": "tag_phone_area_code", "name": "phone_area_code", "classification": "contacto", "subclassification": "principal", "identification": "phoneAreaCode", "notes": "UI: Phone area | JSON: phoneAreaCode"}, {"tag_id": "tag_phone_local_number", "name": "phone_local_number", "classification": "contacto", "subclassification": "principal", "identification": "phoneLocalNumber", "notes": "UI: Phone local | JSON: phoneLocalNumber"}, {"tag_id": "tag_fax_area_code", "name": "fax_area_code", "classification": "contacto", "subclassification": "principal", "identification": "faxAreaCode", "notes": "UI: Fax area | JSON: faxAreaCode"}, {"tag_id": "tag_fax_local_number", "name": "fax_local_number", "classification": "contacto", "subclassification": "principal", "identification": "faxLocalNumber", "notes": "UI: Fax local | JSON: faxLocalNumber"}, {"tag_id": "tag_website", "name": "website", "classification": "contacto", "subclassification": "principal", "identification": "webSiteAddress", "notes": "UI: Web Site | JSON: webSiteAddress"}, {"tag_id": "tag_contact", "name": "contact", "classification": "contacto", "subclassification": "principal", "identification": "contactName", "notes": "UI: Contact | JSON: contactName"}, {"tag_id": "tag_secondary_clinic_name", "name": "secondary_clinic_name", "classification": "direccion", "subclassification": "secundaria", "identification": "facilityName2", "notes": "UI: Secondary Clinic Name | JSON: facilityName2"}, {"tag_id": "tag_address2_street", "name": "address2_street", "classification": "direccion", "subclassification": "secundaria", "identification": "address2Street", "notes": "UI: Secondary Address | JSON: address2Street"}, {"tag_id": "tag_address2_other", "name": "address2_other", "classification": "direccion", "subclassification": "secundaria", "identification": "address2OtherDesignation", "notes": "UI: Secondary Address 2 | JSON: address2OtherDesignation"}, {"tag_id": "tag_address2_city", "name": "address2_city", "classification": "direccion", "subclassification": "secundaria", "identification": "address2City", "notes": "UI: Secondary City | JSON: address2City"}, {"tag_id": "tag_address2_state", "name": "address2_state", "classification": "direccion", "subclassification": "secundaria", "identification": "address2StateProvince", "notes": "UI: Secondary State | JSON: address2StateProvince"}, {"tag_id": "tag_address2_zip", "name": "address2_zip", "classification": "direccion", "subclassification": "secundaria", "identification": "address2PostalCode", "notes": "UI: Secondary Zip | JSON: address2PostalCode"}, {"tag_id": "tag_address2_country", "name": "address2_country", "classification": "direccion", "subclassification": "secundaria", "identification": "address2Country", "notes": "UI: Secondary Country | JSON: address2Country"}, {"tag_id": "tag_phone2", "name": "phone2", "classification": "contacto", "subclassification": "secundaria", "identification": "phone2", "notes": "UI: Secondary Phone | JSON: phone2"}, {"tag_id": "tag_fax2", "name": "fax2", "classification": "contacto", "subclassification": "secundaria", "identification": "fax2", "notes": "UI: Secondary Fax | JSON: fax2"}, {"tag_id": "tag_website2", "name": "website2", "classification": "contacto", "subclassification": "secundaria", "identification": "webSiteAddress2", "notes": "UI: Secondary Web Site | JSON: webSiteAddress2"}, {"tag_id": "tag_contact2", "name": "contact2", "classification": "contacto", "subclassification": "secundaria", "identification": "contactName2", "notes": "UI: Secondary Contact | JSON: contactName2"}, {"tag_id": "tag_pricing_id", "name": "pricing_id", "classification": "facturacion", "subclassification": "plan", "identification": "pricingId", "notes": "UI: Pricing | JSON: pricingId | ID numérico"}, {"tag_id": "tag_value_added_package_id", "name": "value_added_package_id", "classification": "facturacion", "subclassification": "plan", "identification": "valueAddedPackageId", "notes": "UI: Value Added Package | JSON: valueAddedPackageId"}, {"tag_id": "tag_therapist_licenses", "name": "therapist_licenses", "classification": "licencias", "subclassification": "conteo", "identification": "therapistLicenseCount", "notes": "UI: # Therapist | JSON: therapistLicenseCount"}, {"tag_id": "tag_therapist_assistant_licenses", "name": "therapist_assistant_licenses", "classification": "licencias", "subclassification": "conteo", "identification": "therapistAssistantLicenseCount", "notes": "UI: # Therapist Assistant | JSON: therapistAssistantLicenseCount"}, {"tag_id": "tag_clerical_licenses", "name": "clerical_licenses", "classification": "licencias", "subclassification": "conteo", "identification": "clericalLicenseCount", "notes": "UI: # Clerical | JSON: clericalLicenseCount"}, {"tag_id": "tag_student_licenses", "name": "student_licenses", "classification": "licencias", "subclassification": "conteo", "identification": "studentLicenseCount", "notes": "UI: # Student Therapist | JSON: studentLicenseCount"}, {"tag_id": "tag_ein", "name": "ein", "classification": "facturacion", "subclassification": "identificador", "identification": "employerId", "notes": "UI: EIN | JSON: employerId"}, {"tag_id": "tag_npi", "name": "npi", "classification": "facturacion", "subclassification": "identificador", "identification": "nationalProviderId", "notes": "UI: NPI | JSON: nationalProviderId"}, {"tag_id": "tag_start_date", "name": "start_date", "classification": "facturacion", "subclassification": "fechas", "identification": "startDate", "notes": "UI: Start Date | JSON: startDate | YYYY-MM-DD"}, {"tag_id": "tag_billing_type", "name": "billing_type", "classification": "facturacion", "subclassification": "config", "identification": "billingType", "notes": "UI: Billing Type | JSON: billingType"}, {"tag_id": "tag_billing_day", "name": "billing_day", "classification": "facturacion", "subclassification": "config", "identification": "billingDay", "notes": "UI: Billing Day | JSON: billingDay"}, {"tag_id": "tag_billing_address_street", "name": "billing_address_street", "classification": "direccion", "subclassification": "facturacion", "identification": "billingAddressStreet", "notes": "UI: Billing Address | JSON: billingAddressStreet"}, {"tag_id": "tag_billing_address_other", "name": "billing_address_other", "classification": "direccion", "subclassification": "facturacion", "identification": "billingAddressOtherDesignation", "notes": "UI: Billing Address 2 | JSON: billingAddressOtherDesignation"}, {"tag_id": "tag_billing_address_city", "name": "billing_address_city", "classification": "direccion", "subclassification": "facturacion", "identification": "billingAddressCity", "notes": "UI: Billing City | JSON: billingAddressCity"}, {"tag_id": "tag_billing_address_state", "name": "billing_address_state", "classification": "direccion", "subclassification": "facturacion", "identification": "billingAddressStateProvince", "notes": "UI: Billing State | JSON: billingAddressStateProvince"}, {"tag_id": "tag_billing_address_zip", "name": "billing_address_zip", "classification": "direccion", "subclassification": "facturacion", "identification": "billingAddressPostalCode", "notes": "UI: Billing Zip | JSON: billingAddressPostalCode"}, {"tag_id": "tag_billing_address_country", "name": "billing_address_country", "classification": "direccion", "subclassification": "facturacion", "identification": "billingAddressCountry", "notes": "UI: Billing Country | JSON: billingAddressCountry"}, {"tag_id": "tag_bfm_type", "name": "bfm_type", "classification": "integracion", "subclassification": "bfm", "identification": "bfmType", "notes": "UI: Billing Feeds Module | JSON: bfmType"}, {"tag_id": "tag_bfm_api_key", "name": "bfm_api_key", "classification": "integracion", "subclassification": "bfm", "identification": "bfmApiKey", "notes": "UI: Xmit API Key | JSON: bfmApiKey"}, {"tag_id": "tag_bfm_username", "name": "bfm_username", "classification": "integracion", "subclassification": "bfm", "identification": "bfmUserName", "notes": "UI: Xmit User Name | JSON: bfmUserName"}, {"tag_id": "tag_bfm_group_name", "name": "bfm_group_name", "classification": "integracion", "subclassification": "bfm", "identification": "bfmGroupName", "notes": "UI: Xmit Group Name | JSON: bfmGroupName"}, {"tag_id": "tag_bfm_external_id", "name": "bfm_external_id", "classification": "integracion", "subclassification": "bfm", "identification": "bfmExternalId", "notes": "UI: External ID | JSON: bfmExternalId"}, {"tag_id": "tag_bfm_ttl_seconds", "name": "bfm_ttl_seconds", "classification": "integracion", "subclassification": "bfm", "identification": "bfmTimeToLiveSeconds", "notes": "UI: Time To Live | JSON: bfmTimeToLiveSeconds"}, {"tag_id": "tag_bfm_effective_datetime", "name": "bfm_effective_datetime", "classification": "integracion", "subclassification": "bfm", "identification": "bfmEffectiveDateTime", "notes": "UI: Effective Datetime | JSON: bfmEffectiveDateTime"}, {"tag_id": "tag_bfm_terminate_datetime", "name": "bfm_terminate_datetime", "classification": "integracion", "subclassification": "bfm", "identification": "bfmTerminateDateTime", "notes": "UI: Terminate Datetime | JSON: bfmTerminateDateTime"}, {"tag_id": "tag_account_id", "name": "account_id", "classification": "integracion", "subclassification": "pagos", "identification": "accountId", "notes": "UI: Account ID | JSON: accountId"}, {"tag_id": "tag_account_token", "name": "account_token", "classification": "integracion", "subclassification": "pagos", "identification": "accountToken", "notes": "UI: Account Token | JSON: accountToken"}, {"tag_id": "tag_acceptor_id", "name": "acceptor_id", "classification": "integracion", "subclassification": "pagos", "identification": "acceptorId", "notes": "UI: Acceptor ID | JSON: acceptorId"}, {"tag_id": "tag_kno2_app_id", "name": "kno2_app_id", "classification": "integracion", "subclassification": "kno2", "identification": "kno2AppId", "notes": "UI: Kno2 Application ID | JSON: kno2AppId"}, {"tag_id": "tag_kno2_api_key", "name": "kno2_api_key", "classification": "integracion", "subclassification": "kno2", "identification": "kno2ApiKey", "notes": "UI: Kno2 Access Key | JSON: kno2ApiKey"}, {"tag_id": "tag_kno2_api_secret", "name": "kno2_api_secret", "classification": "integracion", "subclassification": "kno2", "identification": "kno2ApiSecret", "notes": "UI: Kno2 Secret Key | JSON: kno2ApiSecret"}], "url_patterns": ["edit clinic", "clinic-form", "/facility/edit", "/clinic/edit"], "extractor": {"type": "webpt_page_vars", "root": "facility"}, "knowledge_base_id": "default"}]};
