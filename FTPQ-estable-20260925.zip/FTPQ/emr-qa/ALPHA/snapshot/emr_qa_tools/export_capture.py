"""CLI — exportar browser_extractor.js desde plantillas locales."""
from __future__ import annotations

import sys
from pathlib import Path

EMR_ROOT = Path(__file__).resolve().parents[1]
if str(EMR_ROOT) not in sys.path:
    sys.path.insert(0, str(EMR_ROOT))

from core.capture_registry import export_browser_extractor, load_registry


def main() -> int:
    env, registered = load_registry()
    out = export_browser_extractor()
    print(f"OK: {out}")
    print(f"  plantillas con URL: {len(registered)}")
    print(f"  ambientes: {', '.join(rule.id for rule in env.environments)}")
    print("Uso en browser (F12): emrQaCapture()")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
