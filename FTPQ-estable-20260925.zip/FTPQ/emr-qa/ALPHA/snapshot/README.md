# EMR QA — editor de marcado manual

**Recordar pantallas**, no navegarlas. Tú decides **cuándo** sacar un snap del EMR; esta app **no es un browser** — solo recibe ese snap, te deja marcar qué fragmentos importan y guardarlos en tu base local. Si hace falta, creas una **plantilla** para reutilizar tags en pantallas similares.

Spec (incluye contraste vs Selenium): [`../documentacion/emr-qa/README.md`](../documentacion/emr-qa/README.md)

## Arrancar editor

```bash
./scripts/run_emr_qa_editor.sh
```

Requiere `./scripts/setup.sh` previo (PySide6 en `.venv`).

## Flujo

1. **En el EMR** (fuera de esta app): llega a la pantalla que quieres recordar.
2. **Snap cuando tú quieras** — copia HTML, exporta texto, consola F12, etc.
3. **Copia la URL** de la barra del browser (define dev / stage / prd automáticamente).
4. **Base de conocimiento** — carpeta bajo `knowledge_bases/<id>/`.
5. **Pegar URL + snap** en el editor (Archivo → Abrir texto… o pegar en el panel central).
6. **Buscar** dentro del snap (`Ctrl+F`, **Siguiente** / **Anterior**, `F3` / `Shift+F3`).
7. **Seleccionar fragmento** → **Marcar selección** → definir tag.
8. **Guardar captura** → incluye `source_url` y `environment` en `_meta`.
9. **(Opcional) Guardar plantilla** — hereda el ambiente actual del combo.
10. Otra pantalla similar → **Cargar plantilla** → **Modo mapeo** → mapear tags.

Patrones de URL: **Configuración → Ambientes (URLs dev / stage / prd)…** en el menú del editor, o editando [`config/environments.json`](config/environments.json) a mano.

## Captura en browser (un comando)

Tras editar plantillas:

```bash
./scripts/export_emr_qa_capture.sh
```

1. Copia **`emr-qa/browser_extractor.js`** en consola F12 (una vez por sesión).
2. En la página EMR: **`emrQaCapture()`** — reconoce URL → plantilla → extrae datos.

Sin plantilla para esa URL → no captura. Ver [`capture/README.md`](capture/README.md).

## Estructura

```text
emr-qa/
  core/           modelos JSON + storage
  editor/         app PySide6
  knowledge_bases/
    default/
      captures/
      templates/
  fixtures/       HTML de ejemplo (sin PHI)
  knowledge_bases/
    default/
      templates/
        tpl_webpt_edit_clinic.json   # 61 tags — WebPT Admin Edit Clinic
```

PDE Desktop (`./scripts/run_ui.sh`) no se modifica.
