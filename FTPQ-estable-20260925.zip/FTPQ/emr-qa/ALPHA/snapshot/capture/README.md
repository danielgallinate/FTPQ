# Captura en browser — un comando

## Flujo

1. **Editor** — defines plantilla + tags + `url_patterns` (qué páginas reconoce).
2. **Exportar** — `./scripts/export_emr_qa_capture.sh`  
   (o menú **Configuración → Exportar capturador JS…**)
3. **Browser** — pega `emr-qa/browser_extractor.js` en consola F12 **una vez por sesión**.
4. **Capturar** — en la página EMR:

```javascript
emrQaCapture()
```

- Si la **URL/título** coincide con alguna plantilla → extrae campos según tags → **copia JSON al portapapeles**.
- Si **no hay plantilla** → no hace nada (solo `console.info`).

## Plantilla WebPT Edit Clinic

Archivo: `knowledge_bases/default/templates/tpl_webpt_edit_clinic.json`

```json
"url_patterns": ["edit clinic", "clinic-form", "/facility/edit", "/clinic/edit"],
"extractor": { "type": "webpt_page_vars", "root": "facility" }
```

Datos desde `wpt.page.vars.facility` — no desde inputs HTML vacíos.

## Formato de captura

```json
{
  "_meta": {
    "source_url": "…",
    "environment": "dev",
    "template_id": "tpl_webpt_edit_clinic",
    "source": "browser_extractor"
  },
  "source_text": "{ … facility JSON … }",
  "fields": { "clinic_name": { "value": "…", "text": "…" } },
  "markers": [ … ]
}
```

Pegar en el editor EMR QA o guardar en `knowledge_bases/<kb>/captures/`.

## Nueva pantalla

1. Crear plantilla en el editor con tags (`identification` = clave JSON).
2. Añadir `url_patterns` al JSON (fragmentos de URL o título).
3. Definir `extractor` (`webpt_page_vars` + `root`).
4. Re-exportar JS.
