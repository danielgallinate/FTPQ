(function () {
  "use strict";

  function registry() {
    return window.__EMR_QA_REGISTRY__ || { version: 0, templates: [], environments: [] };
  }

  function detectEnvironment(href, cfg) {
    var url = (href || "").toLowerCase();
    var rules = (cfg && cfg.environments) || [];
    for (var i = 0; i < rules.length; i++) {
      var rule = rules[i];
      var patterns = rule.url_patterns || [];
      for (var j = 0; j < patterns.length; j++) {
        if (url.indexOf(String(patterns[j]).toLowerCase()) >= 0) {
          return rule.id;
        }
      }
    }
    return (cfg && cfg.default_environment) || "unknown";
  }

  function findTemplate(href, title) {
    var haystack = ((href || "") + " " + (title || "")).toLowerCase();
    var templates = registry().templates || [];
    for (var i = 0; i < templates.length; i++) {
      var tpl = templates[i];
      var patterns = tpl.url_patterns || [];
      for (var j = 0; j < patterns.length; j++) {
        if (haystack.indexOf(String(patterns[j]).toLowerCase()) >= 0) {
          return tpl;
        }
      }
    }
    return null;
  }

  function webptRoot(extractor) {
    var vars = window.wpt && window.wpt.page && window.wpt.page.vars;
    if (!vars) {
      return null;
    }
    var rootKey = (extractor && extractor.root) || "facility";
    return { vars: vars, facility: vars[rootKey] || null };
  }

  function resolveIdentification(identification, ctx) {
    if (!identification) {
      return null;
    }
    if (identification === "companies[companyId]") {
      var companyId = ctx.facility && ctx.facility.companyId;
      if (companyId == null || !ctx.vars || !ctx.vars.companies) {
        return null;
      }
      return ctx.vars.companies[String(companyId)] ?? null;
    }
    if (ctx.facility && Object.prototype.hasOwnProperty.call(ctx.facility, identification)) {
      return ctx.facility[identification];
    }
    return null;
  }

  function formatValue(value) {
    if (value == null) {
      return "";
    }
    if (typeof value === "object") {
      return JSON.stringify(value);
    }
    return String(value);
  }

  function newCaptureId() {
    return "cap_" + Math.random().toString(16).slice(2, 14);
  }

  function extractFields(template, ctx) {
    var fields = {};
    var markers = [];
    var tags = template.tags || [];
    for (var i = 0; i < tags.length; i++) {
      var tag = tags[i];
      var raw = resolveIdentification(tag.identification, ctx);
      var text = formatValue(raw);
      fields[tag.name] = {
        tag_id: tag.tag_id,
        name: tag.name,
        identification: tag.identification,
        classification: tag.classification || "",
        subclassification: tag.subclassification || "",
        value: raw,
        text: text,
      };
      markers.push({
        marker_id: "mk_" + Math.random().toString(16).slice(2, 10),
        tag_id: tag.tag_id,
        name: tag.name,
        classification: tag.classification || "",
        subclassification: tag.subclassification || "",
        identification: tag.identification || "",
        start: -1,
        end: -1,
        text: text,
      });
    }
    return { fields: fields, markers: markers };
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      try {
        var area = document.createElement("textarea");
        area.value = text;
        area.style.position = "fixed";
        area.style.left = "-9999px";
        document.body.appendChild(area);
        area.select();
        document.execCommand("copy");
        document.body.removeChild(area);
        resolve();
      } catch (err) {
        reject(err);
      }
    });
  }

  function emrQaCapture(options) {
    options = options || {};
    var href = window.location.href;
    var title = document.title || "";
    var cfg = registry();
    var template = findTemplate(href, title);
    if (!template) {
      if (!options.silent) {
        console.info("[EMR QA] Sin plantilla para esta URL — no se captura.", href);
      }
      return null;
    }

    var extractor = template.extractor || { type: "webpt_page_vars", root: "facility" };
    if (extractor.type !== "webpt_page_vars") {
      console.warn("[EMR QA] Extractor no soportado:", extractor.type);
      return null;
    }

    var ctx = webptRoot(extractor);
    if (!ctx || !ctx.facility) {
      console.warn("[EMR QA] No hay wpt.page.vars.facility en esta página.");
      return null;
    }

    var extracted = extractFields(template, ctx);
    var capturedAt = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
    var capture = {
      _meta: {
        capture_id: newCaptureId(),
        knowledge_base_id: template.knowledge_base_id || "default",
        template_id: template.template_id,
        source_url: href,
        environment: detectEnvironment(href, cfg),
        captured_at: capturedAt,
        source: "browser_extractor",
        page_title: title,
      },
      source_text: JSON.stringify(ctx.facility, null, 2),
      fields: extracted.fields,
      markers: extracted.markers,
    };

    var json = JSON.stringify(capture, null, 2);
    if (options.copy !== false) {
      copyText(json).then(
        function () {
          console.info(
            "[EMR QA] Captura copiada al portapapeles:",
            template.name,
            "(" + Object.keys(extracted.fields).length + " campos)"
          );
        },
        function () {
          console.info("[EMR QA] Captura lista (no se pudo copiar al portapapeles):", capture);
        }
      );
    } else {
      console.info("[EMR QA] Captura:", capture);
    }
    return capture;
  }

  window.emrQaCapture = emrQaCapture;
})();
