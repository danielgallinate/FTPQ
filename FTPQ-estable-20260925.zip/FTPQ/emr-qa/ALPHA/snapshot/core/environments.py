"""Reconocimiento de ambiente (dev / stage / prd) a partir de la URL del snap."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = ROOT / "config" / "environments.json"

ENV_DEV = "dev"
ENV_STAGE = "stage"
ENV_PRD = "prd"
ENV_UNKNOWN = "unknown"

KNOWN_ENVIRONMENTS = (ENV_DEV, ENV_STAGE, ENV_PRD, ENV_UNKNOWN)


@dataclass(frozen=True)
class EnvironmentRule:
    id: str
    label: str
    url_patterns: tuple[str, ...]


@dataclass(frozen=True)
class EnvironmentConfig:
    environments: tuple[EnvironmentRule, ...]
    default: str = ENV_UNKNOWN

    @classmethod
    def from_dict(cls, raw: dict) -> EnvironmentConfig:
        rules: list[EnvironmentRule] = []
        for item in raw.get("environments") or []:
            if not isinstance(item, dict):
                continue
            env_id = str(item.get("id") or "").strip().lower()
            if not env_id:
                continue
            patterns = item.get("url_patterns") or []
            cleaned = tuple(str(p).strip().lower() for p in patterns if str(p).strip())
            rules.append(
                EnvironmentRule(
                    id=env_id,
                    label=str(item.get("label") or env_id).strip(),
                    url_patterns=cleaned,
                )
            )
        default = str(raw.get("default") or ENV_UNKNOWN).strip().lower() or ENV_UNKNOWN
        return cls(environments=tuple(rules), default=default)


def default_config() -> EnvironmentConfig:
    return EnvironmentConfig(
        environments=(
            EnvironmentRule(
                id=ENV_DEV,
                label="Development",
                url_patterns=(".dev.", "-dev.", "dev.", "localhost", "127.0.0.1"),
            ),
            EnvironmentRule(
                id=ENV_STAGE,
                label="Staging",
                url_patterns=(".stage.", "-stage.", "staging.", ".stg.", "-stg."),
            ),
            EnvironmentRule(
                id=ENV_PRD,
                label="Production",
                url_patterns=(".prod.", "-prod.", "production.", ".prd.", "-prd."),
            ),
        ),
        default=ENV_UNKNOWN,
    )


def load_environment_config(path: Path | None = None) -> EnvironmentConfig:
    cfg_path = path or CONFIG_PATH
    if not cfg_path.is_file():
        return default_config()
    raw = json.loads(cfg_path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        return default_config()
    config = EnvironmentConfig.from_dict(raw)
    return config if config.environments else default_config()


def normalize_url(url: str) -> str:
    text = url.strip()
    if not text:
        return ""
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", text):
        text = f"https://{text}"
    return text


def detect_environment(url: str, config: EnvironmentConfig | None = None) -> str:
    """Devuelve dev | stage | prd | unknown según patrones configurados."""
    cfg = config or load_environment_config()
    normalized = normalize_url(url)
    if not normalized:
        return cfg.default

    parsed = urlparse(normalized)
    host = (parsed.hostname or "").lower()
    full = normalized.lower()

    for rule in cfg.environments:
        for pattern in rule.url_patterns:
            if pattern in host or pattern in full:
                return rule.id
    return cfg.default


def environment_label(env_id: str, config: EnvironmentConfig | None = None) -> str:
    cfg = config or load_environment_config()
    env = env_id.strip().lower()
    for rule in cfg.environments:
        if rule.id == env:
            return rule.label
    if env == ENV_UNKNOWN:
        return "Desconocido"
    return env


def config_to_dict(config: EnvironmentConfig) -> dict:
    return {
        "default": config.default,
        "environments": [
            {
                "id": rule.id,
                "label": rule.label,
                "url_patterns": list(rule.url_patterns),
            }
            for rule in config.environments
        ],
    }


def save_environment_config(config: EnvironmentConfig, path: Path | None = None) -> Path:
    cfg_path = path or CONFIG_PATH
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(config_to_dict(config), indent=2, ensure_ascii=False)
    cfg_path.write_text(f"{payload}\n", encoding="utf-8")
    return cfg_path


def pattern_from_user_url(text: str) -> str:
    """Host o fragmento usable como patrón a partir de URL/host pegado."""
    raw = text.strip().lower()
    if not raw:
        return ""
    normalized = normalize_url(raw)
    if "://" in normalized:
        host = urlparse(normalized).hostname
        return (host or raw).lower()
    return raw


def rule_patterns_for_form(rule: EnvironmentRule | None) -> tuple[str, list[str]]:
    if rule is None or not rule.url_patterns:
        return "", []
    primary = rule.url_patterns[0]
    extras = list(rule.url_patterns[1:])
    return primary, extras


def build_config_from_form(
    *,
    dev: str,
    stage: str,
    prd: str,
    dev_extra: list[str] | None = None,
    stage_extra: list[str] | None = None,
    prd_extra: list[str] | None = None,
) -> EnvironmentConfig:
    def patterns(primary: str, extras: list[str] | None) -> tuple[str, ...]:
        items: list[str] = []
        main = pattern_from_user_url(primary)
        if main:
            items.append(main)
        for line in extras or []:
            token = line.strip()
            if not token:
                continue
            pat = pattern_from_user_url(token)
            if pat and pat not in items:
                items.append(pat)
        return tuple(items)

    return EnvironmentConfig(
        environments=(
            EnvironmentRule(
                id=ENV_DEV,
                label="Development",
                url_patterns=patterns(dev, dev_extra),
            ),
            EnvironmentRule(
                id=ENV_STAGE,
                label="Staging",
                url_patterns=patterns(stage, stage_extra),
            ),
            EnvironmentRule(
                id=ENV_PRD,
                label="Production",
                url_patterns=patterns(prd, prd_extra),
            ),
        ),
        default=ENV_UNKNOWN,
    )


def find_rule(config: EnvironmentConfig, env_id: str) -> EnvironmentRule | None:
    for rule in config.environments:
        if rule.id == env_id:
            return rule
    return None
