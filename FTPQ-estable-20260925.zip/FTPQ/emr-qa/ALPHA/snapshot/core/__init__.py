"""Dominio EMR QA — modelos y persistencia local."""
