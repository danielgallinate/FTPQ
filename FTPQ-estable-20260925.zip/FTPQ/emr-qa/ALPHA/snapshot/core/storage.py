"""Rutas y persistencia JSON — bases de conocimiento locales."""
from __future__ import annotations

import json
from pathlib import Path

from .models import ScreenCapture, ScreenTemplate

ROOT = Path(__file__).resolve().parents[1]
KNOWLEDGE_BASES = ROOT / "knowledge_bases"


def knowledge_base_dir(kb_id: str) -> Path:
    path = KNOWLEDGE_BASES / kb_id
    path.mkdir(parents=True, exist_ok=True)
    (path / "captures").mkdir(exist_ok=True)
    (path / "templates").mkdir(exist_ok=True)
    return path


def list_knowledge_bases() -> list[str]:
    if not KNOWLEDGE_BASES.is_dir():
        KNOWLEDGE_BASES.mkdir(parents=True, exist_ok=True)
        return ["default"]
    names = sorted(p.name for p in KNOWLEDGE_BASES.iterdir() if p.is_dir())
    return names or ["default"]


def save_capture(capture: ScreenCapture) -> Path:
    base = knowledge_base_dir(capture.knowledge_base_id)
    path = base / "captures" / f"{capture.capture_id}.json"
    path.write_text(json.dumps(capture.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def load_capture(path: Path) -> ScreenCapture:
    raw = json.loads(path.read_text(encoding="utf-8"))
    return ScreenCapture.from_dict(raw)


def save_template(kb_id: str, template: ScreenTemplate) -> Path:
    base = knowledge_base_dir(kb_id)
    path = base / "templates" / f"{template.template_id}.json"
    path.write_text(json.dumps(template.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def load_template(path: Path) -> ScreenTemplate:
    raw = json.loads(path.read_text(encoding="utf-8"))
    return ScreenTemplate.from_dict(raw)


def list_templates(kb_id: str) -> list[Path]:
    folder = knowledge_base_dir(kb_id) / "templates"
    return sorted(folder.glob("*.json"))


def list_captures(kb_id: str) -> list[Path]:
    folder = knowledge_base_dir(kb_id) / "captures"
    return sorted(folder.glob("*.json"))
