"""Modelos JSON — tags, plantillas y capturas manuales."""
from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def new_id(prefix: str = "") -> str:
    token = uuid.uuid4().hex[:12]
    return f"{prefix}{token}" if prefix else token


@dataclass
class TagDefinition:
    tag_id: str
    name: str
    classification: str = ""
    subclassification: str = ""
    identification: str = ""
    notes: str = ""

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> TagDefinition:
        return cls(
            tag_id=str(raw.get("tag_id") or new_id("tag_")),
            name=str(raw.get("name") or "").strip(),
            classification=str(raw.get("classification") or "").strip(),
            subclassification=str(raw.get("subclassification") or "").strip(),
            identification=str(raw.get("identification") or "").strip(),
            notes=str(raw.get("notes") or "").strip(),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ScreenTemplate:
    template_id: str
    name: str
    description: str = ""
    tags: list[TagDefinition] = field(default_factory=list)
    updated_at: str = field(default_factory=_utc_now_iso)
    environment: str = ""
    url_patterns: list[str] = field(default_factory=list)
    extractor: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> ScreenTemplate:
        tags_raw = raw.get("tags") or []
        tags = [TagDefinition.from_dict(t) for t in tags_raw if isinstance(t, dict)]
        patterns_raw = raw.get("url_patterns") or []
        patterns = [str(p).strip() for p in patterns_raw if str(p).strip()]
        extractor_raw = raw.get("extractor") if isinstance(raw.get("extractor"), dict) else {}
        return cls(
            template_id=str(raw.get("template_id") or new_id("tpl_")),
            name=str(raw.get("name") or "Sin nombre").strip(),
            description=str(raw.get("description") or "").strip(),
            tags=tags,
            updated_at=str(raw.get("updated_at") or _utc_now_iso()),
            environment=str(raw.get("environment") or "").strip().lower(),
            url_patterns=patterns,
            extractor={str(k): str(v) for k, v in extractor_raw.items()},
        )

    def to_dict(self) -> dict[str, Any]:
        data = {
            "template_id": self.template_id,
            "name": self.name,
            "description": self.description,
            "updated_at": self.updated_at,
            "tags": [t.to_dict() for t in self.tags],
        }
        if self.environment:
            data["environment"] = self.environment
        if self.url_patterns:
            data["url_patterns"] = self.url_patterns
        if self.extractor:
            data["extractor"] = self.extractor
        return data

    def tag_by_id(self, tag_id: str) -> TagDefinition | None:
        for tag in self.tags:
            if tag.tag_id == tag_id:
                return tag
        return None


@dataclass
class TextMarker:
    marker_id: str
    tag_id: str
    start: int
    end: int
    text: str
    name: str = ""
    classification: str = ""
    subclassification: str = ""
    identification: str = ""

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> TextMarker:
        return cls(
            marker_id=str(raw.get("marker_id") or new_id("mk_")),
            tag_id=str(raw.get("tag_id") or ""),
            start=int(raw.get("start") or 0),
            end=int(raw.get("end") or 0),
            text=str(raw.get("text") or ""),
            name=str(raw.get("name") or "").strip(),
            classification=str(raw.get("classification") or "").strip(),
            subclassification=str(raw.get("subclassification") or "").strip(),
            identification=str(raw.get("identification") or "").strip(),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_tag(cls, tag: TagDefinition, start: int, end: int, text: str) -> TextMarker:
        return cls(
            marker_id=new_id("mk_"),
            tag_id=tag.tag_id,
            start=start,
            end=end,
            text=text,
            name=tag.name,
            classification=tag.classification,
            subclassification=tag.subclassification,
            identification=tag.identification,
        )


@dataclass
class ScreenCapture:
    capture_id: str
    knowledge_base_id: str
    source_text: str
    markers: list[TextMarker] = field(default_factory=list)
    template_id: str = ""
    record_pk: str = ""
    captured_at: str = field(default_factory=_utc_now_iso)
    source_url: str = ""
    environment: str = ""

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> ScreenCapture:
        meta = raw.get("_meta") if isinstance(raw.get("_meta"), dict) else {}
        markers_raw = raw.get("markers") or []
        markers = [TextMarker.from_dict(m) for m in markers_raw if isinstance(m, dict)]
        return cls(
            capture_id=str(meta.get("capture_id") or raw.get("capture_id") or new_id("cap_")),
            knowledge_base_id=str(meta.get("knowledge_base_id") or raw.get("knowledge_base_id") or "default"),
            source_text=str(raw.get("source_text") or ""),
            markers=markers,
            template_id=str(meta.get("template_id") or raw.get("template_id") or ""),
            record_pk=str(meta.get("record_pk") or raw.get("record_pk") or ""),
            captured_at=str(meta.get("captured_at") or raw.get("captured_at") or _utc_now_iso()),
            source_url=str(meta.get("source_url") or raw.get("source_url") or "").strip(),
            environment=str(meta.get("environment") or raw.get("environment") or "").strip().lower(),
        )

    def to_dict(self) -> dict[str, Any]:
        meta = {
            "capture_id": self.capture_id,
            "knowledge_base_id": self.knowledge_base_id,
            "template_id": self.template_id,
            "record_pk": self.record_pk,
            "captured_at": self.captured_at,
            "source": "manual_tag_editor",
        }
        if self.source_url:
            meta["source_url"] = self.source_url
        if self.environment:
            meta["environment"] = self.environment
        return {
            "_meta": meta,
            "source_text": self.source_text,
            "markers": [m.to_dict() for m in self.markers],
        }
