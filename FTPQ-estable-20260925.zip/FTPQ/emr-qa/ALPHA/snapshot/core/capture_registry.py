"""Registro local: plantillas + URLs → export para browser_extractor.js."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from .environments import EnvironmentConfig, detect_environment, load_environment_config
from .models import ScreenTemplate
from .storage import KNOWLEDGE_BASES, list_knowledge_bases, list_templates, load_template

RUNTIME_PATH = Path(__file__).resolve().parents[1] / "capture" / "runtime.js"
OUTPUT_PATH = Path(__file__).resolve().parents[1] / "browser_extractor.js"


@dataclass(frozen=True)
class RegisteredTemplate:
    knowledge_base_id: str
    template: ScreenTemplate
    url_patterns: tuple[str, ...]
    extractor: dict

    def to_export_dict(self) -> dict:
        data = self.template.to_dict()
        data["knowledge_base_id"] = self.knowledge_base_id
        data["url_patterns"] = list(self.url_patterns)
        data["extractor"] = self.extractor
        return data


def _extractor_from_raw(raw: dict) -> dict:
    ext = raw.get("extractor")
    if isinstance(ext, dict) and ext.get("type"):
        return ext
    return {"type": "webpt_page_vars", "root": "facility"}


def _url_patterns_from_raw(raw: dict) -> tuple[str, ...]:
    patterns = raw.get("url_patterns") or []
    return tuple(str(p).strip() for p in patterns if str(p).strip())


def load_registry() -> tuple[EnvironmentConfig, list[RegisteredTemplate]]:
    env = load_environment_config()
    registered: list[RegisteredTemplate] = []
    for kb_id in list_knowledge_bases():
        for path in list_templates(kb_id):
            raw = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                continue
            patterns = _url_patterns_from_raw(raw)
            if not patterns:
                continue
            tpl = load_template(path)
            registered.append(
                RegisteredTemplate(
                    knowledge_base_id=kb_id,
                    template=tpl,
                    url_patterns=patterns,
                    extractor=_extractor_from_raw(raw),
                )
            )
    return env, registered


def match_template(
    url: str,
    title: str,
    registered: list[RegisteredTemplate],
) -> RegisteredTemplate | None:
    haystack = f"{url.lower()} {title.lower()}"
    for item in registered:
        if any(pattern.lower() in haystack for pattern in item.url_patterns):
            return item
    return None


def match_template_for_export(url: str, title: str = "") -> RegisteredTemplate | None:
    _, registered = load_registry()
    return match_template(url, title, registered)


def build_export_payload() -> dict:
    env, registered = load_registry()
    return {
        "version": 1,
        "environments": [
            {
                "id": rule.id,
                "label": rule.label,
                "url_patterns": list(rule.url_patterns),
            }
            for rule in env.environments
        ],
        "default_environment": env.default,
        "templates": [item.to_export_dict() for item in registered],
    }


def export_browser_extractor(output: Path | None = None) -> Path:
    out = output or OUTPUT_PATH
    runtime = RUNTIME_PATH.read_text(encoding="utf-8")
    payload = json.dumps(build_export_payload(), ensure_ascii=False)
    banner = (
        "/* EMR QA — generado desde knowledge_bases/ + config/environments.json\n"
        "   Regenerar: ./scripts/export_emr_qa_capture.sh\n"
        "   Uso en consola F12: emrQaCapture()\n"
        "*/\n"
    )
    body = f"{banner}{runtime}\nwindow.__EMR_QA_REGISTRY__ = {payload};\n"
    out.write_text(body, encoding="utf-8")
    return out


def detect_env_for_url(url: str, config: EnvironmentConfig | None = None) -> str:
    return detect_environment(url, config or load_environment_config())


def normalized_page_url(url: str) -> str:
    return url.strip()
