"""Búsqueda in-text sobre snaps HTML/JSON."""
from __future__ import annotations

import re


def match_ranges(text: str, query: str, *, case_sensitive: bool) -> list[tuple[int, int]]:
    if not query:
        return []
    if case_sensitive:
        starts = [m.start() for m in re.finditer(re.escape(query), text)]
    else:
        starts = [m.start() for m in re.finditer(re.escape(query), text, flags=re.IGNORECASE)]
    return [(start, start + len(query)) for start in starts]
