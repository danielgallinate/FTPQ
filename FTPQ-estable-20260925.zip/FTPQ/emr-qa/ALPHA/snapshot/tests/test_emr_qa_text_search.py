"""Tests búsqueda in-text — EMR QA."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

EMR_ROOT = Path(__file__).resolve().parents[1]  # snapshot root (core/ aquí)


@pytest.fixture
def emr_match_ranges():
    saved_core = {
        key: sys.modules[key]
        for key in list(sys.modules)
        if key == "core" or key.startswith("core.")
    }
    for key in saved_core:
        del sys.modules[key]
    sys.path.insert(0, str(EMR_ROOT))
    from core.text_search import match_ranges

    yield match_ranges

    for key in list(sys.modules):
        if (key == "core" or key.startswith("core.")) and key not in saved_core:
            del sys.modules[key]
    sys.modules.update(saved_core)


def test_match_ranges_case_insensitive(emr_match_ranges):
    text = '"facility":{"name":"QA Release Clinic"}'
    matches = emr_match_ranges(text, "release clinic", case_sensitive=False)
    assert len(matches) == 1
    assert text[matches[0][0] : matches[0][1]].lower() == "release clinic"


def test_match_ranges_multiple(emr_match_ranges):
    text = "name name name"
    matches = emr_match_ranges(text, "name", case_sensitive=True)
    assert len(matches) == 3
