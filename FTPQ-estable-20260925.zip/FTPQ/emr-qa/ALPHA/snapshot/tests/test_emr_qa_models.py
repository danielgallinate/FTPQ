"""Tests EMR QA — modelos, ambientes y storage."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

EMR_ROOT = Path(__file__).resolve().parents[1]  # snapshot root (core/ aquí)


@pytest.fixture
def emr_qa_modules():
    """Importa emr-qa/core sin chocar con core/ del repo principal."""
    saved_core = {
        key: sys.modules[key]
        for key in list(sys.modules)
        if key == "core" or key.startswith("core.")
    }
    for key in saved_core:
        del sys.modules[key]

    inserted = str(EMR_ROOT)
    if inserted not in sys.path:
        sys.path.insert(0, inserted)

    from core.environments import (
        ENV_DEV,
        ENV_PRD,
        ENV_STAGE,
        ENV_UNKNOWN,
        EnvironmentConfig,
        EnvironmentRule,
        build_config_from_form,
        detect_environment,
        load_environment_config,
        save_environment_config,
    )
    from core.models import ScreenCapture, ScreenTemplate, TagDefinition, TextMarker
    import core.storage as storage

    yield {
        "ENV_DEV": ENV_DEV,
        "ENV_STAGE": ENV_STAGE,
        "ENV_PRD": ENV_PRD,
        "ENV_UNKNOWN": ENV_UNKNOWN,
        "EnvironmentConfig": EnvironmentConfig,
        "EnvironmentRule": EnvironmentRule,
        "ScreenCapture": ScreenCapture,
        "ScreenTemplate": ScreenTemplate,
        "TagDefinition": TagDefinition,
        "TextMarker": TextMarker,
        "build_config_from_form": build_config_from_form,
        "detect_environment": detect_environment,
        "load_environment_config": load_environment_config,
        "save_environment_config": save_environment_config,
        "storage": storage,
    }

    for key in list(sys.modules):
        if (key == "core" or key.startswith("core.")) and key not in saved_core:
            del sys.modules[key]
    sys.modules.update(saved_core)


def _sample_env_config(EnvironmentConfig, EnvironmentRule, ENV_DEV, ENV_STAGE, ENV_PRD, ENV_UNKNOWN):
    return EnvironmentConfig(
        environments=(
            EnvironmentRule(
                id=ENV_DEV,
                label="Development",
                url_patterns=("dev.emr.example.com", "localhost"),
            ),
            EnvironmentRule(
                id=ENV_STAGE,
                label="Staging",
                url_patterns=("stage.emr.example.com", "staging."),
            ),
            EnvironmentRule(
                id=ENV_PRD,
                label="Production",
                url_patterns=("app.emr.example.com", "prd."),
            ),
        ),
        default=ENV_UNKNOWN,
    )


def test_detect_environment_dev_stage_prd(emr_qa_modules):
    cfg = _sample_env_config(
        emr_qa_modules["EnvironmentConfig"],
        emr_qa_modules["EnvironmentRule"],
        emr_qa_modules["ENV_DEV"],
        emr_qa_modules["ENV_STAGE"],
        emr_qa_modules["ENV_PRD"],
        emr_qa_modules["ENV_UNKNOWN"],
    )
    detect = emr_qa_modules["detect_environment"]
    assert detect("https://dev.emr.example.com/patient/1", cfg) == emr_qa_modules["ENV_DEV"]
    assert detect("https://stage.emr.example.com/encounter", cfg) == emr_qa_modules["ENV_STAGE"]
    assert detect("https://app.emr.example.com/home", cfg) == emr_qa_modules["ENV_PRD"]
    assert detect("", cfg) == emr_qa_modules["ENV_UNKNOWN"]


def test_marker_roundtrip(emr_qa_modules, tmp_path, monkeypatch):
    storage = emr_qa_modules["storage"]
    monkeypatch.setattr(storage, "KNOWLEDGE_BASES", tmp_path / "kb")

    TagDefinition = emr_qa_modules["TagDefinition"]
    TextMarker = emr_qa_modules["TextMarker"]
    ScreenCapture = emr_qa_modules["ScreenCapture"]

    tag = TagDefinition(
        tag_id="tag_1",
        name="mrn",
        classification="identificacion",
        subclassification="paciente",
        identification="mrn",
    )
    marker = TextMarker.from_tag(tag, 10, 16, "001234")
    cap = ScreenCapture(
        capture_id="cap_test",
        knowledge_base_id="test_kb",
        source_text="MRN: 001234",
        markers=[marker],
        record_pk="pk-1",
        source_url="https://dev.emr.example.com/patient",
        environment=emr_qa_modules["ENV_DEV"],
    )
    path = storage.save_capture(cap)
    loaded = storage.load_capture(path)
    assert loaded.markers[0].text == "001234"
    assert loaded.record_pk == "pk-1"
    assert loaded.source_url == "https://dev.emr.example.com/patient"
    assert loaded.environment == emr_qa_modules["ENV_DEV"]


def test_template_roundtrip(emr_qa_modules, tmp_path, monkeypatch):
    storage = emr_qa_modules["storage"]
    monkeypatch.setattr(storage, "KNOWLEDGE_BASES", tmp_path / "kb")

    TagDefinition = emr_qa_modules["TagDefinition"]
    ScreenTemplate = emr_qa_modules["ScreenTemplate"]

    tpl = ScreenTemplate(
        template_id="tpl_1",
        name="Encuentro",
        tags=[
            TagDefinition(tag_id="t1", name="encounter_id", classification="encuentro"),
        ],
        environment=emr_qa_modules["ENV_STAGE"],
    )
    path = storage.save_template("test_kb", tpl)
    loaded = storage.load_template(path)
    assert loaded.name == "Encuentro"
    assert len(loaded.tags) == 1
    assert loaded.environment == emr_qa_modules["ENV_STAGE"]


def test_save_environment_config_roundtrip(emr_qa_modules, tmp_path):
    build_config_from_form = emr_qa_modules["build_config_from_form"]
    load_environment_config = emr_qa_modules["load_environment_config"]
    save_environment_config = emr_qa_modules["save_environment_config"]

    cfg_path = tmp_path / "environments.json"
    config = build_config_from_form(
        dev="https://dev.emr.example.com",
        stage="stage.emr.example.com",
        prd="https://app.emr.example.com",
        dev_extra=["localhost"],
    )
    save_environment_config(config, cfg_path)
    loaded = load_environment_config(cfg_path)
    dev_rule = next(r for r in loaded.environments if r.id == emr_qa_modules["ENV_DEV"])
    assert dev_rule.url_patterns[0] == "dev.emr.example.com"
    assert "localhost" in dev_rule.url_patterns
    assert emr_qa_modules["detect_environment"](
        "https://app.emr.example.com/x", loaded
    ) == emr_qa_modules["ENV_PRD"]
