"""Tests registro de captura EMR QA."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

EMR_ROOT = Path(__file__).resolve().parents[1]  # snapshot root (core/ aquí)


@pytest.fixture
def emr_capture_registry():
    saved_core = {
        key: sys.modules[key]
        for key in list(sys.modules)
        if key == "core" or key.startswith("core.")
    }
    for key in saved_core:
        del sys.modules[key]
    sys.path.insert(0, str(EMR_ROOT))
    from core.capture_registry import (
        build_export_payload,
        export_browser_extractor,
        load_registry,
        match_template,
    )

    yield {
        "build_export_payload": build_export_payload,
        "export_browser_extractor": export_browser_extractor,
        "load_registry": load_registry,
        "match_template": match_template,
    }

    for key in list(sys.modules):
        if (key == "core" or key.startswith("core.")) and key not in saved_core:
            del sys.modules[key]
    sys.modules.update(saved_core)


def test_load_registry_includes_webpt_template(emr_capture_registry):
    _env, registered = emr_capture_registry["load_registry"]()
    assert any(item.template.template_id == "tpl_webpt_edit_clinic" for item in registered)


def test_match_template_by_title(emr_capture_registry):
    _env, registered = emr_capture_registry["load_registry"]()
    matched = emr_capture_registry["match_template"](
        "https://app.webpt.com/facility/edit?clinicId=10354",
        "Edit Clinic - Admin - WebPT",
        registered,
    )
    assert matched is not None
    assert matched.template.template_id == "tpl_webpt_edit_clinic"


def test_match_template_miss(emr_capture_registry):
    _env, registered = emr_capture_registry["load_registry"]()
    matched = emr_capture_registry["match_template"](
        "https://example.com/dashboard",
        "Dashboard",
        registered,
    )
    assert matched is None


def test_export_browser_extractor(emr_capture_registry, tmp_path):
    out = tmp_path / "browser_extractor.js"
    emr_capture_registry["export_browser_extractor"](out)
    text = out.read_text(encoding="utf-8")
    assert "emrQaCapture" in text
    assert "__EMR_QA_REGISTRY__" in text
    payload = text.split("window.__EMR_QA_REGISTRY__ = ", 1)[1].rstrip(";\n")
    data = json.loads(payload)
    assert data["templates"]
