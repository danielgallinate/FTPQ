"""Ventana principal — editor de marcado manual EMR QA."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QToolBar,
    QVBoxLayout,
    QWidget,
)

from core.models import ScreenCapture, ScreenTemplate, TagDefinition, TextMarker, new_id
from core.environments import (
    ENV_UNKNOWN,
    EnvironmentConfig,
    detect_environment,
    environment_label,
    load_environment_config,
)
from core.storage import (
    knowledge_base_dir,
    list_captures,
    list_knowledge_bases,
    list_templates,
    load_capture,
    load_template,
    save_capture,
    save_template,
)
from core.capture_registry import export_browser_extractor
from editor.tag_dialog import TagDialog
from editor.environment_settings_dialog import EnvironmentSettingsDialog
from editor.text_panel import CaptureTextEditor


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("EMR QA — Editor de marcado")
        self.resize(1280, 820)

        self._template = ScreenTemplate(template_id="", name="")
        self._working_tags: list[TagDefinition] = []
        self._capture = ScreenCapture(
            capture_id=new_id("cap_"),
            knowledge_base_id="default",
            source_text="",
        )
        self._map_mode = False
        self._map_tag_id: str | None = None
        self._env_config = load_environment_config()
        self._env_manual = False

        self._build_ui()
        self._build_menu()
        self._refresh_kb_list()
        self._new_capture()

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        meta = QHBoxLayout()
        meta.addWidget(QLabel("Base de conocimiento"))
        self._kb = QComboBox()
        self._kb.setEditable(True)
        self._kb.currentTextChanged.connect(self._on_kb_changed)
        meta.addWidget(self._kb, 1)

        meta.addWidget(QLabel("Record PK"))
        self._record_pk = QLineEdit()
        self._record_pk.setPlaceholderText("opcional — iteración actual")
        meta.addWidget(self._record_pk, 1)
        layout.addLayout(meta)

        url_row = QHBoxLayout()
        url_row.addWidget(QLabel("URL del snap"))
        self._source_url = QLineEdit()
        self._source_url.setPlaceholderText("https://… — pega la URL de la barra del browser al sacar el snap")
        self._source_url.textChanged.connect(self._on_source_url_changed)
        url_row.addWidget(self._source_url, 3)

        url_row.addWidget(QLabel("Ambiente"))
        self._environment = QComboBox()
        for env_id in ("dev", "stage", "prd", ENV_UNKNOWN):
            self._environment.addItem(environment_label(env_id, self._env_config), env_id)
        self._environment.currentIndexChanged.connect(self._on_environment_changed)
        url_row.addWidget(self._environment, 1)
        layout.addLayout(url_row)

        toolbar = QToolBar()
        self.addToolBar(toolbar)
        for label, slot in (
            ("Nueva captura", self._new_capture),
            ("Abrir texto…", self._open_text_file),
            ("Marcar selección", self._mark_selection),
            ("Modo mapeo", self._toggle_map_mode),
            ("Guardar captura", self._save_capture),
            ("Guardar plantilla", self._save_template),
            ("Cargar plantilla…", self._load_template),
            ("Abrir captura…", self._open_capture),
        ):
            btn = QPushButton(label)
            btn.clicked.connect(slot)
            toolbar.addWidget(btn)

        split = QSplitter(Qt.Orientation.Horizontal)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(QLabel("Tags de la plantilla activa"))
        self._tag_table = QTableWidget(0, 4)
        self._tag_table.setHorizontalHeaderLabels(
            ["Nombre", "Clasificación", "Sub", "Identificación"]
        )
        self._tag_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._tag_table.itemSelectionChanged.connect(self._on_tag_row_selected)
        left_layout.addWidget(self._tag_table)

        btn_row = QHBoxLayout()
        add_tag = QPushButton("Nuevo tag")
        add_tag.clicked.connect(self._add_tag_manual)
        btn_row.addWidget(add_tag)
        left_layout.addLayout(btn_row)
        split.addWidget(left)

        self._text = CaptureTextEditor()
        split.addWidget(self._text)
        split.setStretchFactor(1, 3)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.addWidget(QLabel("Marcadores en esta captura"))
        self._marker_table = QTableWidget(0, 3)
        self._marker_table.setHorizontalHeaderLabels(["Tag", "Texto", "Rango"])
        right_layout.addWidget(self._marker_table)
        del_btn = QPushButton("Quitar marcador")
        del_btn.clicked.connect(self._delete_selected_marker)
        right_layout.addWidget(del_btn)
        split.addWidget(right)

        split.setStretchFactor(0, 1)
        split.setStretchFactor(2, 1)
        layout.addWidget(split, 1)

        self._status = QLabel("Listo — pega HTML/texto y marca fragmentos.")
        layout.addWidget(self._status)

    def _build_menu(self) -> None:
        edit_menu = self.menuBar().addMenu("Editar")
        find_action = edit_menu.addAction("Buscar en texto…")
        find_action.setShortcut("Ctrl+F")
        find_action.triggered.connect(self._text.focus_search)

        config_menu = self.menuBar().addMenu("Configuración")
        export_action = config_menu.addAction("Exportar capturador JS…")
        export_action.triggered.connect(self._export_browser_extractor)
        env_action = config_menu.addAction("Ambientes (URLs dev / stage / prd)…")
        env_action.triggered.connect(self._open_environment_settings)

    def _export_browser_extractor(self) -> None:
        try:
            path = export_browser_extractor()
        except OSError as exc:
            QMessageBox.warning(self, "Exportar JS", f"No se pudo exportar:\n{exc}")
            return
        QMessageBox.information(
            self,
            "Exportar JS",
            f"Capturador generado:\n{path}\n\n"
            "1. Copia todo el archivo en consola F12 (una vez por sesión).\n"
            "2. En la página EMR: emrQaCapture()",
        )
        self._status.setText(f"Capturador JS exportado: {path}")

    def _open_environment_settings(self) -> None:
        dlg = EnvironmentSettingsDialog(config=self._env_config, parent=self)
        if dlg.exec() != EnvironmentSettingsDialog.DialogCode.Accepted or not dlg.saved():
            return
        self._apply_environment_config(dlg.config())
        self._status.setText("Ambientes guardados — URLs dev / stage / prd actualizadas.")

    def _apply_environment_config(self, config: EnvironmentConfig) -> None:
        self._env_config = config
        current = self._current_environment()
        self._environment.blockSignals(True)
        self._environment.clear()
        for env_id in ("dev", "stage", "prd", ENV_UNKNOWN):
            self._environment.addItem(environment_label(env_id, self._env_config), env_id)
        self._environment.blockSignals(False)
        self._set_environment_combo(current)
        url = self._source_url.text().strip()
        if url:
            self._env_manual = False
            self._on_source_url_changed(url)

    def _refresh_kb_list(self) -> None:
        current = self._kb.currentText().strip() or self._capture.knowledge_base_id
        self._kb.blockSignals(True)
        self._kb.clear()
        for name in list_knowledge_bases():
            self._kb.addItem(name)
        idx = self._kb.findText(current)
        if idx >= 0:
            self._kb.setCurrentIndex(idx)
        else:
            self._kb.setEditText(current or "default")
        self._kb.blockSignals(False)
        knowledge_base_dir(self._kb.currentText().strip() or "default")

    def _on_kb_changed(self, value: str) -> None:
        kb = value.strip() or "default"
        self._capture.knowledge_base_id = kb
        knowledge_base_dir(kb)

    def _set_environment_combo(self, env_id: str) -> None:
        idx = self._environment.findData(env_id)
        if idx < 0:
            idx = self._environment.findData(ENV_UNKNOWN)
        self._environment.blockSignals(True)
        self._environment.setCurrentIndex(max(idx, 0))
        self._environment.blockSignals(False)

    def _current_environment(self) -> str:
        data = self._environment.currentData()
        return str(data or ENV_UNKNOWN)

    def _on_source_url_changed(self, value: str) -> None:
        url = value.strip()
        self._capture.source_url = url
        if self._env_manual and url:
            return
        detected = detect_environment(url, self._env_config)
        self._env_manual = False
        self._set_environment_combo(detected)
        self._capture.environment = detected
        if url:
            self._status.setText(
                f"URL reconocida → {environment_label(detected, self._env_config)} ({detected})"
            )

    def _on_environment_changed(self) -> None:
        self._env_manual = True
        self._capture.environment = self._current_environment()

    def _sync_capture_meta_fields(self) -> None:
        self._capture.record_pk = self._record_pk.text().strip()
        self._capture.source_url = self._source_url.text().strip()
        self._capture.environment = self._current_environment()

    def _load_capture_meta_fields(self, cap: ScreenCapture) -> None:
        self._record_pk.setText(cap.record_pk)
        self._env_manual = bool(cap.source_url and cap.environment)
        self._source_url.blockSignals(True)
        self._source_url.setText(cap.source_url)
        self._source_url.blockSignals(False)
        if cap.environment:
            self._set_environment_combo(cap.environment)
        elif cap.source_url:
            self._on_source_url_changed(cap.source_url)
        else:
            self._set_environment_combo(ENV_UNKNOWN)

    def _new_capture(self) -> None:
        kb = self._kb.currentText().strip() or "default"
        self._capture = ScreenCapture(
            capture_id=new_id("cap_"),
            knowledge_base_id=kb,
            source_text="",
            template_id=self._template.template_id,
            record_pk=self._record_pk.text().strip(),
            source_url=self._source_url.text().strip(),
            environment=self._current_environment(),
        )
        self._env_manual = False
        self._text.set_text("")
        self._text.clear_markers()
        self._refresh_marker_table()
        self._status.setText("Nueva captura — pega el contenido de la pantalla.")

    def _open_text_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Abrir HTML o texto",
            str(Path.home()),
            "Texto (*.txt *.html *.htm);;Todos (*)",
        )
        if not path:
            return
        text = Path(path).read_text(encoding="utf-8", errors="replace")
        self._capture.source_text = text
        self._text.set_text(text)
        self._text.clear_markers()
        self._refresh_marker_table()
        self._status.setText(f"Texto cargado: {path}")

    def _working_tag_list(self) -> list[TagDefinition]:
        seen: dict[str, TagDefinition] = {t.tag_id: t for t in self._template.tags}
        for t in self._working_tags:
            seen[t.tag_id] = t
        return list(seen.values())

    def _mark_selection(self) -> None:
        span = self._text.request_mark_selection()
        if span is None:
            QMessageBox.information(self, "Marcar", "Selecciona un fragmento de texto primero.")
            return
        start, end, selected = span

        if self._map_mode and self._map_tag_id:
            tag = self._find_tag(self._map_tag_id)
            if tag is None:
                QMessageBox.warning(self, "Mapeo", "Tag de mapeo no encontrado.")
                return
        else:
            dlg = TagDialog(existing_tags=self._working_tag_list(), parent=self)
            if dlg.exec() != TagDialog.DialogCode.Accepted or dlg.tag() is None:
                return
            tag = dlg.tag()
            assert tag is not None
            self._upsert_working_tag(tag)

        marker = TextMarker.from_tag(tag, start, end, selected)
        self._text.add_marker(marker)
        self._capture.markers = self._text.markers()
        self._capture.source_text = self._text.text()
        self._refresh_tag_table()
        self._refresh_marker_table()
        self._status.setText(f"Marcado: {tag.name} → «{selected[:40]}»")

    def _upsert_working_tag(self, tag: TagDefinition) -> None:
        for idx, existing in enumerate(self._working_tags):
            if existing.tag_id == tag.tag_id:
                self._working_tags[idx] = tag
                return
        if self._template.tag_by_id(tag.tag_id) is None:
            self._working_tags.append(tag)
        self._refresh_tag_table()

    def _find_tag(self, tag_id: str) -> TagDefinition | None:
        for tag in self._working_tag_list():
            if tag.tag_id == tag_id:
                return tag
        return None

    def _add_tag_manual(self) -> None:
        dlg = TagDialog(existing_tags=self._working_tag_list(), parent=self)
        if dlg.exec() != TagDialog.DialogCode.Accepted or dlg.tag() is None:
            return
        self._upsert_working_tag(dlg.tag())
        self._status.setText(f"Tag definido: {dlg.tag().name}")

    def _toggle_map_mode(self) -> None:
        self._map_mode = not self._map_mode
        if self._map_mode:
            row = self._tag_table.currentRow()
            if row >= 0:
                item = self._tag_table.item(row, 0)
                if item:
                    self._map_tag_id = item.data(Qt.ItemDataRole.UserRole)
            self._status.setText(
                "Modo mapeo ON — elige un tag a la izquierda, selecciona texto, «Marcar selección»."
            )
        else:
            self._map_tag_id = None
            self._status.setText("Modo mapeo OFF — puedes crear tags nuevos al marcar.")

    def _on_tag_row_selected(self) -> None:
        if not self._map_mode:
            return
        row = self._tag_table.currentRow()
        if row < 0:
            return
        item = self._tag_table.item(row, 0)
        if item:
            self._map_tag_id = item.data(Qt.ItemDataRole.UserRole)

    def _refresh_tag_table(self) -> None:
        tags = self._working_tag_list()
        self._tag_table.setRowCount(len(tags))
        for row, tag in enumerate(tags):
            for col, value in enumerate(
                (tag.name, tag.classification, tag.subclassification, tag.identification)
            ):
                item = QTableWidgetItem(value)
                if col == 0:
                    item.setData(Qt.ItemDataRole.UserRole, tag.tag_id)
                self._tag_table.setItem(row, col, item)

    def _refresh_marker_table(self) -> None:
        markers = self._text.markers()
        self._marker_table.setRowCount(len(markers))
        for row, marker in enumerate(markers):
            self._marker_table.setItem(row, 0, QTableWidgetItem(marker.name))
            text = marker.text.replace("\n", " ")
            self._marker_table.setItem(row, 1, QTableWidgetItem(text[:80]))
            self._marker_table.setItem(row, 2, QTableWidgetItem(f"{marker.start}:{marker.end}"))

    def _delete_selected_marker(self) -> None:
        row = self._marker_table.currentRow()
        if row < 0:
            return
        markers = self._text.markers()
        if row >= len(markers):
            return
        del markers[row]
        self._text.set_markers(markers)
        self._capture.markers = markers
        self._refresh_marker_table()

    def _save_capture(self) -> None:
        self._capture.source_text = self._text.text()
        self._capture.markers = self._text.markers()
        self._capture.template_id = self._template.template_id
        self._sync_capture_meta_fields()
        path = save_capture(self._capture)
        env = environment_label(self._capture.environment, self._env_config)
        self._status.setText(f"Captura guardada ({env}): {path}")

    def _save_template(self) -> None:
        name, ok = QInputDialog.getText(self, "Plantilla", "Nombre de la plantilla:")
        if not ok or not name.strip():
            return
        tags = self._working_tag_list()
        if not tags:
            QMessageBox.warning(self, "Plantilla", "Define al menos un tag antes de guardar.")
            return
        tpl = ScreenTemplate(
            template_id=self._template.template_id or new_id("tpl_"),
            name=name.strip(),
            description="",
            tags=tags,
            environment=self._current_environment(),
        )
        kb = self._kb.currentText().strip() or "default"
        path = save_template(kb, tpl)
        self._template = tpl
        self._working_tags = []
        self._refresh_tag_table()
        env = environment_label(tpl.environment, self._env_config)
        self._status.setText(f"Plantilla guardada ({env}): {path}")

    def _load_template(self) -> None:
        kb = self._kb.currentText().strip() or "default"
        templates = list_templates(kb)
        if not templates:
            QMessageBox.information(self, "Plantilla", "No hay plantillas en esta base.")
            return
        labels = [p.stem for p in templates]
        choice, ok = QInputDialog.getItem(
            self, "Cargar plantilla", "Plantilla:", labels, 0, False
        )
        if not ok:
            return
        path = templates[labels.index(choice)]
        self._template = load_template(path)
        self._working_tags = []
        self._capture.template_id = self._template.template_id
        self._refresh_tag_table()
        self._status.setText(
            f"Plantilla «{self._template.name}» — {len(self._template.tags)} tags. "
            "Pega otra pantalla y usa modo mapeo."
        )

    def _open_capture(self) -> None:
        kb = self._kb.currentText().strip() or "default"
        captures = list_captures(kb)
        if not captures:
            QMessageBox.information(self, "Captura", "No hay capturas guardadas.")
            return
        labels = [p.stem for p in captures]
        choice, ok = QInputDialog.getItem(
            self, "Abrir captura", "Captura:", labels, 0, False
        )
        if not ok:
            return
        cap = load_capture(captures[labels.index(choice)])
        self._capture = cap
        self._load_capture_meta_fields(cap)
        self._text.set_text(cap.source_text)
        self._text.set_markers(cap.markers)
        self._refresh_marker_table()
        if cap.template_id:
            for path in list_templates(kb):
                tpl = load_template(path)
                if tpl.template_id == cap.template_id:
                    self._template = tpl
                    break
        self._refresh_tag_table()
        self._status.setText(f"Captura abierta: {cap.capture_id}")
