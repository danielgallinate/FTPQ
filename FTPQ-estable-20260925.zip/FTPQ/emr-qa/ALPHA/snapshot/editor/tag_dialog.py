"""Diálogo — crear o editar definición de tag."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLineEdit,
    QTextEdit,
    QVBoxLayout,
)

from core.models import TagDefinition, new_id


class TagDialog(QDialog):
    def __init__(
        self,
        *,
        existing_tags: list[TagDefinition] | None = None,
        preset: TagDefinition | None = None,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Tag — clasificación")
        self._existing = existing_tags or []
        self._result: TagDefinition | None = None

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self._pick = QComboBox()
        self._pick.addItem("— Nuevo tag —", "")
        for tag in self._existing:
            label = f"{tag.name} ({tag.classification})"
            self._pick.addItem(label, tag.tag_id)
        self._pick.currentIndexChanged.connect(self._on_pick)
        form.addRow("Tag existente", self._pick)

        self._name = QLineEdit()
        self._classification = QLineEdit()
        self._subclassification = QLineEdit()
        self._identification = QLineEdit()
        self._notes = QTextEdit()
        self._notes.setMaximumHeight(72)

        form.addRow("Nombre", self._name)
        form.addRow("Clasificación", self._classification)
        form.addRow("Subclasificación", self._subclassification)
        form.addRow("Identificación", self._identification)
        form.addRow("Notas", self._notes)

        if preset is not None:
            self._fill(preset)
        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _on_pick(self) -> None:
        tag_id = self._pick.currentData()
        if not tag_id:
            return
        for tag in self._existing:
            if tag.tag_id == tag_id:
                self._fill(tag)
                break

    def _fill(self, tag: TagDefinition) -> None:
        self._name.setText(tag.name)
        self._classification.setText(tag.classification)
        self._subclassification.setText(tag.subclassification)
        self._identification.setText(tag.identification)
        self._notes.setPlainText(tag.notes)

    def accept(self) -> None:
        name = self._name.text().strip()
        if not name:
            self._name.setFocus()
            return
        picked = self._pick.currentData()
        tag_id = picked if picked else new_id("tag_")
        self._result = TagDefinition(
            tag_id=tag_id,
            name=name,
            classification=self._classification.text().strip(),
            subclassification=self._subclassification.text().strip(),
            identification=self._identification.text().strip(),
            notes=self._notes.toPlainText().strip(),
        )
        super().accept()

    def tag(self) -> TagDefinition | None:
        return self._result
