"""Entry point — editor EMR QA (marcado manual)."""
from __future__ import annotations

import sys
from pathlib import Path

EMR_ROOT = Path(__file__).resolve().parents[1]
if str(EMR_ROOT) not in sys.path:
    sys.path.insert(0, str(EMR_ROOT))

from PySide6.QtWidgets import QApplication

from editor.main_window import MainWindow


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("EMR QA Editor")
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
