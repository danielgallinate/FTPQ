"""Diálogo — configurar URLs/patrones dev, stage y prd."""
from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QLabel,
    QLineEdit,
    QMessageBox,
    QTextEdit,
    QVBoxLayout,
)

from core.environments import (
    ENV_DEV,
    ENV_PRD,
    ENV_STAGE,
    EnvironmentConfig,
    build_config_from_form,
    find_rule,
    load_environment_config,
    rule_patterns_for_form,
    save_environment_config,
)


class EnvironmentSettingsDialog(QDialog):
    def __init__(self, config: EnvironmentConfig | None = None, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Configuración — Ambientes")
        self.resize(640, 520)
        self._loaded = config or load_environment_config()
        self._saved = False

        layout = QVBoxLayout(self)
        layout.addWidget(
            QLabel(
                "Define la URL o el host de cada ambiente EMR. "
                "Al pegar un snap, el editor reconoce dev / stage / prd por estos patrones."
            )
        )

        self._dev_url = QLineEdit()
        self._stage_url = QLineEdit()
        self._prd_url = QLineEdit()
        self._dev_extra = QTextEdit()
        self._stage_extra = QTextEdit()
        self._prd_extra = QTextEdit()
        for field in (self._dev_url, self._stage_url, self._prd_url):
            field.setPlaceholderText("https://dev.emr.example.com o dev.emr.example.com")
        for area in (self._dev_extra, self._stage_extra, self._prd_extra):
            area.setPlaceholderText("Patrones extra opcionales, uno por línea")
            area.setMaximumHeight(72)

        layout.addWidget(self._env_group("Development (dev)", self._dev_url, self._dev_extra))
        layout.addWidget(self._env_group("Staging (stage)", self._stage_url, self._stage_extra))
        layout.addWidget(self._env_group("Production (prd)", self._prd_url, self._prd_extra))

        layout.addWidget(
            QLabel(
                "Tip: basta con el host principal por ambiente. "
                "Usa patrones extra solo si un mismo ambiente tiene más de una URL."
            )
        )

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Guardar")
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._fill_from_config(self._loaded)

    def _env_group(self, title: str, primary: QLineEdit, extra: QTextEdit) -> QGroupBox:
        box = QGroupBox(title)
        form = QFormLayout(box)
        form.addRow("URL / host", primary)
        form.addRow("Patrones extra", extra)
        return box

    def _fill_from_config(self, config: EnvironmentConfig) -> None:
        mapping = {
            ENV_DEV: (self._dev_url, self._dev_extra),
            ENV_STAGE: (self._stage_url, self._stage_extra),
            ENV_PRD: (self._prd_url, self._prd_extra),
        }
        for env_id, (primary_field, extra_field) in mapping.items():
            primary, extras = rule_patterns_for_form(find_rule(config, env_id))
            primary_field.setText(primary)
            extra_field.setPlainText("\n".join(extras))

    def _extra_lines(self, area: QTextEdit) -> list[str]:
        return [line.strip() for line in area.toPlainText().splitlines() if line.strip()]

    def _on_save(self) -> None:
        dev = self._dev_url.text().strip()
        stage = self._stage_url.text().strip()
        prd = self._prd_url.text().strip()
        if not dev and not stage and not prd:
            QMessageBox.warning(
                self,
                "Ambientes",
                "Indica al menos una URL o host (dev, stage o prd).",
            )
            self._dev_url.setFocus()
            return

        config = build_config_from_form(
            dev=dev,
            stage=stage,
            prd=prd,
            dev_extra=self._extra_lines(self._dev_extra),
            stage_extra=self._extra_lines(self._stage_extra),
            prd_extra=self._extra_lines(self._prd_extra),
        )
        save_environment_config(config)
        self._loaded = config
        self._saved = True
        self.accept()

    def saved(self) -> bool:
        return self._saved

    def config(self) -> EnvironmentConfig:
        return self._loaded
