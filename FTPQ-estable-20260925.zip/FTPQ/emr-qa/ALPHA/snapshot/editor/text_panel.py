"""Editor de texto con resaltado de marcadores y búsqueda in-text."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtGui import QColor, QFont, QKeySequence, QShortcut, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QWidget,
    QVBoxLayout,
)

from core.models import TextMarker
from core.text_search import match_ranges as _match_ranges


class CaptureTextEditor(QWidget):
    selection_mark_requested = Signal(int, int, str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self._hint = QLabel(
            "Pega el HTML/texto de la pantalla. Busca (Ctrl+F) → selecciona un fragmento → «Marcar selección»."
        )
        self._hint.setWordWrap(True)
        layout.addWidget(self._hint)

        search_row = QHBoxLayout()
        search_row.addWidget(QLabel("Buscar"))
        self._search = QLineEdit()
        self._search.setPlaceholderText("Texto a buscar en el snap…")
        self._search.returnPressed.connect(self.find_next)
        search_row.addWidget(self._search, 1)

        self._case_sensitive = QCheckBox("Aa")
        self._case_sensitive.setToolTip("Distinguir mayúsculas/minúsculas")
        self._case_sensitive.toggled.connect(self._refresh_search_status)
        search_row.addWidget(self._case_sensitive)

        prev_btn = QPushButton("Anterior")
        prev_btn.clicked.connect(self.find_previous)
        search_row.addWidget(prev_btn)

        next_btn = QPushButton("Siguiente")
        next_btn.clicked.connect(self.find_next)
        search_row.addWidget(next_btn)

        self._search_status = QLabel("")
        self._search_status.setMinimumWidth(88)
        search_row.addWidget(self._search_status)
        layout.addLayout(search_row)

        self._editor = QPlainTextEdit()
        self._editor.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self._editor.setFont(QFont("Menlo", 11))
        layout.addWidget(self._editor)

        self._markers: list[TextMarker] = []
        self._search_index = -1
        self._search.textChanged.connect(self._on_search_changed)

        self._shortcut_find = QShortcut(QKeySequence.StandardKey.Find, self)
        self._shortcut_find.activated.connect(self.focus_search)
        self._shortcut_find_next = QShortcut(QKeySequence("F3"), self)
        self._shortcut_find_next.activated.connect(self.find_next)
        self._shortcut_find_prev = QShortcut(QKeySequence("Shift+F3"), self)
        self._shortcut_find_prev.activated.connect(self.find_previous)

    def focus_search(self) -> None:
        self._search.setFocus()
        self._search.selectAll()

    def text(self) -> str:
        return self._editor.toPlainText()

    def set_text(self, text: str) -> None:
        self._editor.setPlainText(text)
        self._markers = []
        self._search_index = -1
        self._apply_highlights()

    def set_markers(self, markers: list[TextMarker]) -> None:
        self._markers = list(markers)
        self._apply_highlights()

    def markers(self) -> list[TextMarker]:
        return list(self._markers)

    def add_marker(self, marker: TextMarker) -> None:
        self._markers.append(marker)
        self._apply_highlights()

    def clear_markers(self) -> None:
        self._markers.clear()
        self._apply_highlights()

    def selected_span(self) -> tuple[int, int, str] | None:
        cursor = self._editor.textCursor()
        if not cursor.hasSelection():
            return None
        start = cursor.selectionStart()
        end = cursor.selectionEnd()
        if start >= end:
            return None
        return start, end, cursor.selectedText().replace("\u2029", "\n")

    def request_mark_selection(self) -> tuple[int, int, str] | None:
        span = self.selected_span()
        if span is None:
            return None
        return span

    def _query(self) -> str:
        return self._search.text()

    def _on_search_changed(self) -> None:
        self._search_index = -1
        self._refresh_search_status()
        self._apply_highlights()

    def _refresh_search_status(self) -> None:
        query = self._query()
        if not query:
            self._search_status.setText("")
            return
        total = len(_match_ranges(self.text(), query, case_sensitive=self._case_sensitive.isChecked()))
        if total == 0:
            self._search_status.setText("0/0")
            return
        current = self._search_index + 1 if self._search_index >= 0 else 0
        self._search_status.setText(f"{current}/{total}")

    def find_next(self) -> None:
        self._find(forward=True)

    def find_previous(self) -> None:
        self._find(forward=False)

    def _find(self, *, forward: bool) -> None:
        query = self._query()
        if not query:
            self.focus_search()
            return

        matches = _match_ranges(self.text(), query, case_sensitive=self._case_sensitive.isChecked())
        if not matches:
            self._search_index = -1
            self._refresh_search_status()
            self._apply_highlights()
            return

        cursor = self._editor.textCursor()
        pos = cursor.selectionStart() if cursor.hasSelection() else cursor.position()

        if forward:
            idx = next((i for i, (start, _end) in enumerate(matches) if start > pos), None)
            if idx is None:
                idx = 0
        else:
            idx = next((i for i in range(len(matches) - 1, -1, -1) if matches[i][0] < pos), None)
            if idx is None:
                idx = len(matches) - 1

        self._search_index = idx
        start, end = matches[idx]
        cursor = QTextCursor(self._editor.document())
        cursor.setPosition(start)
        cursor.setPosition(end, QTextCursor.MoveMode.KeepAnchor)
        self._editor.setTextCursor(cursor)
        self._editor.centerCursor()
        self._refresh_search_status()
        self._apply_highlights(active_match=(start, end))

    def _apply_highlights(self, active_match: tuple[int, int] | None = None) -> None:
        doc = self._editor.document()
        selections: list = []
        palette = [
            QColor("#fff3bf"),
            QColor("#ffc9c9"),
            QColor("#b2f2bb"),
            QColor("#a5d8ff"),
            QColor("#eebefa"),
        ]
        for idx, marker in enumerate(self._markers):
            if marker.start < 0 or marker.end > len(self.text()):
                continue
            fmt = QTextCharFormat()
            fmt.setBackground(palette[idx % len(palette)])
            cursor = QTextCursor(doc)
            cursor.setPosition(marker.start)
            cursor.setPosition(marker.end, QTextCursor.MoveMode.KeepAnchor)
            sel = QPlainTextEdit.ExtraSelection()
            sel.cursor = cursor
            sel.format = fmt
            selections.append(sel)

        query = self._query()
        if query:
            for start, end in _match_ranges(self.text(), query, case_sensitive=self._case_sensitive.isChecked()):
                if active_match and (start, end) == active_match:
                    continue
                fmt = QTextCharFormat()
                fmt.setBackground(QColor("#ffe066"))
                cursor = QTextCursor(doc)
                cursor.setPosition(start)
                cursor.setPosition(end, QTextCursor.MoveMode.KeepAnchor)
                sel = QPlainTextEdit.ExtraSelection()
                sel.cursor = cursor
                sel.format = fmt
                selections.append(sel)

        if active_match:
            start, end = active_match
            fmt = QTextCharFormat()
            fmt.setBackground(QColor("#ff922b"))
            fmt.setForeground(QColor("#000000"))
            cursor = QTextCursor(doc)
            cursor.setPosition(start)
            cursor.setPosition(end, QTextCursor.MoveMode.KeepAnchor)
            sel = QPlainTextEdit.ExtraSelection()
            sel.cursor = cursor
            sel.format = fmt
            selections.append(sel)
        elif self._search_index >= 0 and query:
            matches = _match_ranges(self.text(), query, case_sensitive=self._case_sensitive.isChecked())
            if 0 <= self._search_index < len(matches):
                start, end = matches[self._search_index]
                fmt = QTextCharFormat()
                fmt.setBackground(QColor("#ff922b"))
                fmt.setForeground(QColor("#000000"))
                cursor = QTextCursor(doc)
                cursor.setPosition(start)
                cursor.setPosition(end, QTextCursor.MoveMode.KeepAnchor)
                sel = QPlainTextEdit.ExtraSelection()
                sel.cursor = cursor
                sel.format = fmt
                selections.append(sel)

        self._editor.setExtraSelections(selections)
