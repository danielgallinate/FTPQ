# WebPT Edit Clinic — plantilla predefinida

Plantilla: `knowledge_bases/default/templates/tpl_webpt_edit_clinic.json` (**61 tags**).

## Cargar en el editor

1. `./scripts/run_emr_qa_editor.sh`
2. Base de conocimiento: `default`
3. **Cargar plantilla…** → `tpl_webpt_edit_clinic`
4. Pegar snap (HTML o JSON de `facility`)
5. **Modo mapeo** ON → recorrer tags de la tabla izquierda

## Dónde marcar valores (no el formulario vacío)

| Buscar (`Ctrl+F`) | Tag |
|-------------------|-----|
| `"facility":{` | bloque completo |
| `"name":"` | `clinic_name` |
| `"companyId":` | `company_id` |
| `"7272":"` (o tu id) | `company_name` en mapa companies |
| `"addressStreet":` | `address_street` |

Snap compacto (consola F12):

```javascript
copy(JSON.stringify(wpt.page.vars.facility, null, 2))
```

Pegar en el editor → mapear cada clave JSON al tag con el mismo `identification`.
