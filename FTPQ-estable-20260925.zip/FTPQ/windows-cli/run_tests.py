#!/usr/bin/env python3
"""Valida archivos tabulares contra reglas JSON — solo consola (CMD/PowerShell)."""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from engine.messages import LANGUAGES, Messages, default_language
from engine.reader import collect_tabular_files, load_row_dicts
from engine.store import (
    BUILTIN_RULES_DIR,
    USER_RULES_DIR,
    SchemaJob,
    filename_matches,
    find_job,
    list_schema_jobs,
    rules_dirs,
)
from engine.validation import validate_schema_catalog

SAMPLE_DIR = "ejemplo"

# Ni éxito ni fallo: el archivo no traía filas que evaluar.
EXIT_NO_DATA = 3


@dataclass
class RunOutcome:
    ok: bool
    job: SchemaJob
    file_path: Path
    rows: int
    cells_ok: int
    cells_nok: int
    quality_pct: float
    structural_errors: list[str]
    alerts: list[str]
    no_data: bool = False

    @property
    def verdict(self) -> str:
        """PASS, FAIL o SIN DATOS. Cero filas (incremental) nunca es FAIL."""
        if self.no_data:
            return "NO DATA"
        if not self.ok:
            return "FAIL"
        return "PASS"


def _preparse_language(argv: list[str]) -> str:
    for index, token in enumerate(argv):
        if token == "--lang" and index + 1 < len(argv):
            candidate = argv[index + 1].strip().casefold()
            if candidate in LANGUAGES:
                return candidate
        if token.startswith("--lang="):
            candidate = token.split("=", 1)[1].strip().casefold()
            if candidate in LANGUAGES:
                return candidate
    return default_language()


def _build_parser(tr: Messages) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=tr("cli.description"))
    parser.add_argument("data_dir", nargs="?", type=Path, help=tr("cli.data_dir"))
    parser.add_argument("--file", "-f", type=Path, help=tr("cli.file"))
    parser.add_argument("--job", "-j", help=tr("cli.job"))
    parser.add_argument("--rules-dir", type=Path, help=tr("cli.rules_dir"))
    parser.add_argument("--recursive", action="store_true", help=tr("cli.recursive"))
    parser.add_argument("--dry-run", action="store_true", help=tr("cli.dry_run"))
    parser.add_argument("--short", "-s", action="store_true", help=tr("cli.short"))
    parser.add_argument("--fail-fast", action="store_true", help=tr("cli.fail_fast"))
    parser.add_argument("--json-out", type=Path, help=tr("cli.json_out"))
    parser.add_argument("--list-jobs", action="store_true", help=tr("cli.list_jobs"))
    parser.add_argument("--self-test", action="store_true", help=tr("cli.self_test"))
    parser.add_argument("--lang", choices=LANGUAGES, help=tr("cli.lang"))
    return parser


def _run_one(job: SchemaJob, file_path: Path) -> RunOutcome:
    columns, rows = load_row_dicts(file_path)
    name_to_index = {name: index for index, name in enumerate(columns)}
    result = validate_schema_catalog(
        job.catalog,
        rows,
        file_columns=columns,
        name_to_index=name_to_index,
    )
    no_data = len(rows) == 0
    ok = True if no_data else (
        len(result.failed_cells) == 0 and not result.structural_errors
    )
    quality = result.percent if result.total_count else 0.0
    return RunOutcome(
        ok=ok,
        job=job,
        file_path=file_path,
        rows=len(rows),
        cells_ok=len(result.passed_cells),
        cells_nok=len(result.failed_cells),
        quality_pct=quality,
        structural_errors=list(result.structural_errors),
        alerts=list(result.alerts[:12]),
        # Sin filas no hay tipos ni patrones que juzgar: se alerta, no se aprueba.
        no_data=no_data,
    )


def _print_outcome(outcome: RunOutcome, tr: Messages, *, short: bool) -> None:
    status = outcome.verdict
    if short:
        print(
            f"{status}  {outcome.job.schema_id}  {outcome.file_path.name}  "
            f"rows={outcome.rows}  ok={outcome.cells_ok}  nok={outcome.cells_nok}  "
            f"quality={outcome.quality_pct:.2f}%"
        )
        return
    print(f"{tr('out.job')}    {outcome.job.job_path.name} ({outcome.job.name})")
    print(f"{tr('out.schema')}    {outcome.job.schema_path.name}")
    print(f"{tr('out.file')}  {outcome.file_path}")
    print(f"{tr('out.rows')}   {outcome.rows:,}")
    print(
        f"{tr('out.cells')}  OK {outcome.cells_ok:,} · NOK {outcome.cells_nok:,} "
        f"({outcome.quality_pct:.2f}%)"
    )
    if outcome.no_data:
        print(tr("out.no_data"))
    for error in outcome.structural_errors:
        print(f"{tr('out.struct')} {error}")
    for alert in outcome.alerts:
        print(f"{tr('out.alert')} {alert}")
    print(status)


def _print_list(jobs: list[SchemaJob], tr: Messages) -> None:
    print(tr("list.title"))
    for job in jobs:
        origin = (
            tr("header.user") if job.source == USER_RULES_DIR else tr("header.builtin")
        )
        patterns = (
            list(job.catalog.batch_match.filename_patterns)
            if job.catalog.batch_match
            else []
        )
        print(f"  {job.schema_id}")
        print(f"    {tr('list.source')}  {job.source} ({origin})")
        print(f"    {tr('list.job')}  {job.job_path.name}")
        print(f"    {tr('list.schema')}  {job.schema_path.name}")
        print(f"    {tr('list.columns')} {len(job.catalog.columns)}")
        if patterns:
            print(f"    {tr('list.match')} {patterns[0]}")


def _print_header(root: Path, extra_dir: Path | None, tr: Messages) -> None:
    print(tr("header"))
    for folder in rules_dirs(root, extra=extra_dir):
        origin = tr("header.user") if folder.name == USER_RULES_DIR else tr("header.builtin")
        print(f"{tr('header.rules')} {folder}  ({origin})")
    print()


def _self_test(tr: Messages, *, short: bool) -> int:
    sample = ROOT / SAMPLE_DIR
    print(tr("selftest.title"))
    if not sample.is_dir():
        print(tr("err.rules_dir") % sample, file=sys.stderr)
        return 2
    code = main(
        [
            str(sample),
            "--rules-dir",
            str(sample),
            "--lang",
            tr.language,
            *(["--short"] if short else []),
        ]
    )
    print(tr("selftest.ok") if code == 0 else tr("selftest.fail"))
    return code


def main(argv: list[str] | None = None) -> int:
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    tr = Messages(_preparse_language(raw_argv))
    parser = _build_parser(tr)
    args = parser.parse_args(raw_argv)

    if args.self_test:
        return _self_test(tr, short=args.short)

    extra_dir: Path | None = None
    if args.rules_dir is not None:
        extra_dir = args.rules_dir.expanduser().resolve()
        if not extra_dir.is_dir():
            print(tr("err.rules_dir") % extra_dir, file=sys.stderr)
            return 2

    try:
        jobs = list_schema_jobs(ROOT, extra_dir=extra_dir)
    except FileNotFoundError as exc:
        print(tr("err.no_rules") % exc, file=sys.stderr)
        return 2
    if not jobs:
        print(tr("err.no_rules") % (extra_dir or ROOT / BUILTIN_RULES_DIR), file=sys.stderr)
        return 2

    if args.list_jobs:
        _print_header(ROOT, extra_dir, tr)
        _print_list(jobs, tr)
        return 0

    pairs: list[tuple[SchemaJob, Path]] = []
    pending_skips: list[str] = []
    rules_without_file: list[str] = []

    if args.file is not None:
        file_path = args.file.expanduser().resolve()
        if not file_path.is_file():
            print(tr("err.no_file") % file_path, file=sys.stderr)
            return 2
        if args.job:
            try:
                job = find_job(ROOT, args.job, extra_dir=extra_dir)
            except FileNotFoundError as exc:
                print(tr("err.job_missing") % exc, file=sys.stderr)
                return 2
        else:
            matches = [item for item in jobs if filename_matches(item.catalog, file_path.name)]
            if len(matches) != 1:
                print(tr("err.need_job"), file=sys.stderr)
                return 2
            job = matches[0]
        pairs.append((job, file_path))
    elif args.data_dir is not None:
        data_dir = args.data_dir.expanduser().resolve()
        if not data_dir.is_dir():
            print(tr("err.no_dir") % data_dir, file=sys.stderr)
            return 2
        files = collect_tabular_files(data_dir, recursive=args.recursive)
        if not files:
            print(tr("err.no_tabular") % data_dir, file=sys.stderr)
            return 2
        selected = jobs
        if args.job:
            try:
                selected = [find_job(ROOT, args.job, extra_dir=extra_dir)]
            except FileNotFoundError as exc:
                print(tr("err.job_missing") % exc, file=sys.stderr)
                return 2
        matched_files: set[Path] = set()
        for job in selected:
            if job.catalog.batch_match is None or not job.catalog.batch_match.is_configured():
                pending_skips.append(f"{tr('skip.no_regex')} {job.job_path.name}")
                continue
            hits = [path for path in files if filename_matches(job.catalog, path.name)]
            if not hits:
                rules_without_file.append(job.job_path.name)
                continue
            for path in hits:
                matched_files.add(path.resolve())
                pairs.append((job, path))
        if len(rules_without_file) <= 3:
            pending_skips.extend(
                f"{tr('skip.no_file')} {name}" for name in rules_without_file
            )
        else:
            pending_skips.append(tr("skip.no_file_many") % len(rules_without_file))
        for path in files:
            if path.resolve() not in matched_files:
                pending_skips.append(f"{tr('skip.no_job')} {path.name}")
    else:
        parser.print_help()
        print()
        print(tr("usage.examples"))
        print(f"  run.cmd .                                    :: {tr('usage.here')}")
        print(f"  run.cmd extracts                             :: {tr('usage.other')}")
        print(f"  run.cmd --file archivo.csv                   :: {tr('usage.one_file')}")
        print("  run.cmd --job clinic_extract_col --file archivo.csv")
        print("  run.cmd --list-jobs")
        print(f"  run.cmd --self-test                          :: {tr('usage.check')}")
        return 2

    _print_header(ROOT, extra_dir, tr)
    for line in pending_skips:
        print(line)
    if pending_skips:
        print()

    summaries: list[dict] = []
    ran = 0
    passed = 0
    failed = 0
    no_data = 0
    exit_early = False

    for job, file_path in pairs:
        print("-" * 20)
        ran += 1
        if args.dry_run:
            print(f"{tr('out.job')}    {job.job_path.name}")
            print(f"{tr('out.file')}  {file_path}")
            continue
        try:
            outcome = _run_one(job, file_path)
        except Exception as exc:  # noqa: BLE001 — errores de archivo/regla en consola
            print(f"{tr('out.job')}    {job.job_path.name}")
            print(f"{tr('out.file')}  {file_path}")
            print(f"ERROR: {exc}")
            print("FAIL")
            failed += 1
            summaries.append(
                {
                    "ok": False,
                    "error": str(exc),
                    "job": job.schema_id,
                    "file": str(file_path),
                }
            )
            if args.fail_fast:
                exit_early = True
                break
            continue
        _print_outcome(outcome, tr, short=args.short)
        if outcome.no_data:
            no_data += 1
        elif not outcome.ok:
            failed += 1
        else:
            passed += 1
        summaries.append(
            {
                "ok": outcome.ok,
                "verdict": outcome.verdict,
                "no_data": outcome.no_data,
                "job": outcome.job.schema_id,
                "file": str(outcome.file_path),
                "rows": outcome.rows,
                "cells_ok": outcome.cells_ok,
                "cells_nok": outcome.cells_nok,
                "quality_pct": outcome.quality_pct,
                "structural_errors": outcome.structural_errors,
            }
        )
        if args.fail_fast and not outcome.ok and not outcome.no_data:
            exit_early = True
            break

    print()
    print(tr("summary.title"))
    if args.dry_run:
        print(tr("summary.dry_run") % ran)
    else:
        print(tr("summary.run") % (ran, passed, failed, no_data))

    if args.json_out is not None:
        payload = {
            "generated_at": datetime.now(timezone.utc)
            .replace(microsecond=0)
            .isoformat()
            .replace("+00:00", "Z"),
            "ran": ran,
            "passed": passed,
            "failed": failed,
            "no_data": no_data,
            "results": summaries,
        }
        json_path = args.json_out.expanduser()
        json_path.parent.mkdir(parents=True, exist_ok=True)
        json_path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        print(f"{tr('summary.json')} {json_path}")

    if exit_early:
        return 1
    if args.dry_run:
        return 0
    if ran == 0:
        return 2
    if failed > 0:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
