@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem Zip de esta carpeta sin .venv ni caches / zip without .venv or caches
set "STAGE=%TEMP%\ftpq-windows-cli-pack"
set "OUT=%USERPROFILE%\Downloads\FTPQ-windows-cli.zip"

if exist "%STAGE%" rmdir /s /q "%STAGE%"

robocopy "." "%STAGE%\windows-cli" /E /XD .venv __pycache__ .git /XF *.zip /NFL /NDL /NJH /NJS >nul
if %ERRORLEVEL% GEQ 8 goto :fail_copy

if exist "%OUT%" del /f /q "%OUT%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '%STAGE%\windows-cli' -DestinationPath '%OUT%' -Force"
if errorlevel 1 goto :fail_zip

rmdir /s /q "%STAGE%"
echo Creado / created: %OUT%
exit /b 0

:fail_copy
echo ERROR: robocopy fallo / robocopy failed.
exit /b 1

:fail_zip
echo ERROR: no se pudo crear el zip / could not create the zip.
exit /b 1
