#Requires -Version 5.1
Push-Location -LiteralPath $PSScriptRoot
trap { Pop-Location; break }

function Get-PythonCmd {
    $candidates = @(
        @{ File = "py"; Args = @("-3.12") },
        @{ File = "py"; Args = @("-3") },
        @{ File = "python"; Args = @() }
    )
    foreach ($item in $candidates) {
        $exe = Get-Command $item.File -ErrorAction SilentlyContinue
        if (-not $exe) { continue }
        & $item.File @($item.Args) -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 12) else 1)" 2>$null
        if ($LASTEXITCODE -eq 0) {
            return @{ File = $item.File; Args = $item.Args }
        }
    }
    return $null
}

$py = Get-PythonCmd
if ($null -eq $py) {
    Write-Error "Se necesita Python 3.12 o superior / Python 3.12+ required (python.org, tick 'Add python.exe to PATH')."
    Pop-Location
    exit 1
}

Write-Host "Usando / using: $($py.File) $($py.Args -join ' ')"
& $py.File @($py.Args) -m venv .venv
if ($LASTEXITCODE -ne 0) { Pop-Location; exit $LASTEXITCODE }
& ".\.venv\Scripts\python.exe" -m pip install -U pip
if ($LASTEXITCODE -ne 0) { Pop-Location; exit $LASTEXITCODE }
& ".\.venv\Scripts\python.exe" -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { Pop-Location; exit $LASTEXITCODE }
Pop-Location
Write-Host ""
Write-Host "OK / done. Siguiente / next:"
Write-Host "  .\run.ps1 --self-test"
Write-Host "  .\run.ps1 --list-jobs"
Write-Host '  .\run.ps1 "C:\ruta\a\carpeta\csv"'
Write-Host ""
Write-Host "Manual: MANUAL-ES.md  ·  MANUAL-EN.md"
