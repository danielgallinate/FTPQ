# Manual — usage and installation (Windows)

Command-line validator for tabular files. It checks CSV/TSV/PSV/Excel against **JSON rules**: expected columns, data types, nulls, duplicates and strict structure.

Everything runs from **scripts in CMD or PowerShell**. There is no graphical interface, and it needs neither WSL2 nor internet access (except the first preparation, which downloads pandas).

> Provided **as is, without warranties**. Whoever runs it chooses which files to analyse and owns their environment. This is not an official product and does not replace compliance controls.

**Versión en español:** [`MANUAL-ES.md`](MANUAL-ES.md)

---

## 1. Requirements

| Requirement | Detail |
|-------------|--------|
| Windows | 10 or 11 |
| Python | **3.12 or newer**, native Windows build |
| Disk | ~150 MB (pandas stays inside this folder) |
| Privileges | None beyond installing Python |

The folder can live anywhere you have **write permission**, since it needs to create its own `.venv\` subfolder. That is why `C:\Program Files` is a poor choice.

---

## 2. Install Python (once per machine)

1. Download from [python.org/downloads/windows](https://www.python.org/downloads/windows/) — *Windows installer (64-bit)*.
2. On the installer's first screen, tick **Add python.exe to PATH**.
3. Install with the default options.
4. Check in a **new** CMD window:

```bat
python --version
```

It must print `Python 3.12.x` or newer. If the command is not found, close and reopen the console; if it still fails, reinstall Python with the PATH checkbox ticked.

---

## 3. Run it

There is no preparation step. The **first** time you run `run.cmd` it sets itself up: it creates `.venv\`, installs pandas inside the folder, and then carries on with whatever you asked for. From the second run onwards it starts straight away.

Paths you pass are resolved **from your current folder**, not from wherever the script lives. Both styles work.

Standing in your data folder, calling the script by its path:

```bat
cd <where your CSVs are>
C:\path\to\windows-cli\run.cmd . --lang en
```

Or standing in the script folder, pointing at the data:

```bat
cd <where windows-cli is>
run.cmd --lang en "<folder with your CSVs>"
```

Confirm the install using the bundled sample data:

```bat
run.cmd --self-test --lang en
```

It should end with `PASS` and `OK: engine, pandas and rule loading work.`

In **PowerShell** use `.\run.ps1` with the same arguments. If the execution policy blocks it:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
```

`setup.cmd` and `setup.ps1` exist in case you want to prepare the environment separately, for example to get a machine ready before the data arrives. Calling them is optional.

Add `--lang en` for English messages, or set it once per session with `set FTPQ_LANG=en` (CMD) / `$env:FTPQ_LANG="en"` (PowerShell). The examples below assume that variable is set.

---

## 4. Commands

### List the available rules

```bat
run.cmd --list-jobs
```

For each rule this shows its identifier, which folder it came from, how many columns it defines and which file names it claims.

### Validate a folder

Every rule carries its own file-name pattern, so pointing at the folder is enough and matching is automatic:

```bat
run.cmd .
run.cmd extracts
run.cmd "D:\yesterday's extracts"
```

Variants:

```bat
run.cmd --short .          :: one line per test
run.cmd --recursive .      :: include subfolders
run.cmd --dry-run .        :: preview what would run, validate nothing
run.cmd --fail-fast .      :: stop at the first failure
```

### Validate a single file

```bat
run.cmd --file file.csv
run.cmd --job clinic_extract_col --file file.csv
```

You can drop `--job` when the file name matches exactly one rule.

### Save the result

```bat
run.cmd --json-out result.json .
run.cmd . > report.txt 2>&1
```

---

## 5. Reading the output

```text
RULE:    clinic_extract_col.job.json (CLINIC EXTRACT COL)
MAPPING:    clinic_extract_col.schema.json
FILE:  D:\extracts\something_PDE_Clinic_1.csv
ROWS:   1,204
CELLS:  OK 27,588 · NOK 4 (99.99%)
STRUCTURE: missing column: GPMS_CODE
ALERT: duplicate value in unique column CLINIC_ID: 2 rows
FAIL
```

| Line | Meaning |
|------|---------|
| `ROWS` | rows read from the file |
| `CELLS` | cells matching the expected type vs. those that do not, plus the percentage |
| `STRUCTURE` | column problem: a missing column, or extra/missing ones in strict mode |
| `ALERT` | duplicates, file columns the rule does not cover, disabled columns |
| `NO DATA` | the file has a header but no rows |
| `PASS` / `FAIL` / `NO DATA` | `FAIL` when there are NOK cells **or** any structural problem; `NO DATA` when there are no rows to evaluate |

`NO DATA` is neither passed nor failed: with no rows there is no type or pattern to check, so
the tool raises an alert instead of a `PASS` that would mean nothing. If the header itself has
column problems, that *is* judged and the result is `FAIL`.

Exit codes, handy for chaining inside a `.bat`:

| Code | Meaning |
|------|---------|
| `0` | every test passed |
| `1` | data or structural failures |
| `2` | usage error: missing path, no rules, broken Python install |
| `3` | no failures, but some file had no rows (`NO DATA`) |

---

## 6. Your own JSON rules

The **`mis-reglas\`** folder ("my rules") is yours. Its rules load together with the ones in `jobs\`, and if you reuse a `schema_id` yours wins, so you can override a bundled rule without editing it.

A rule is **two files** sharing a base name:

```text
mis-reglas\
  my_extract.job.json      ← which test to run
  my_extract.schema.json   ← the column mapping
```

Copy `_plantilla.job.json` and `_plantilla.schema.json`, rename them, and set `schema_id` to match the base name. Files starting with `_` are ignored.

The mapping looks like this:

```json
{
  "schema_version": 1,
  "schema_id": "my_extract",
  "name": "MY EXTRACT",
  "strict": false,
  "columns": [
    { "name": "ID", "data_type": "integer", "allows_null": false, "unique": true, "enabled": true },
    { "name": "CREATED", "data_type": "datetime", "allows_null": true, "enabled": true }
  ],
  "batch_match": {
    "filename_patterns": ["(?i).*_MY_Extract_.*\\.(?:csv|tsv|psv|xlsx|xlsm|xls)$"]
  }
}
```

| Field | Effect |
|-------|--------|
| `data_type` | `string`, `integer`, `decimal`, `boolean`, `date`, `datetime` |
| `allows_null` | `false` = an empty cell is NOK |
| `unique` | `true` = repeated values are NOK |
| `enabled` | `false` = the column is not evaluated |
| `date_format` | Python format such as `%d/%m/%Y`; omit it to accept ISO |
| `strict` | `true` = the file must have **exactly** those columns |
| `batch_match.filename_patterns` | regular expressions on the file name deciding which files use this rule |

After editing, confirm it loaded with `run.cmd --list-jobs`. If it does not show up, it is almost always one of three things: `schema_id` does not match the base name, one of the two files is missing, or the JSON has a syntax error such as a trailing comma.

If you would rather keep your rules elsewhere — a shared folder, say — point at it and those are used **instead of** the local ones:

```bat
run.cmd --rules-dir "D:\rules" .
```

---

## 7. Troubleshooting

| Symptom | What to do |
|---------|-----------|
| `python is not recognized` | reinstall Python with *Add python.exe to PATH*, then open a new console |
| `dependency install failed` | no internet route, or a corporate proxy blocking pip |
| `run.ps1 cannot be loaded` | run `Set-ExecutionPolicy -Scope Process Bypass`, or use `run.cmd` |
| `could not create .venv` | the folder sits in a path without write permission; move it under your user profile |
| `SKIPPED file (no rule matches)` | the file name matches no `filename_patterns` — check with `--list-jobs` |
| `SKIPPED N rules with no matching file` | expected: those rules do not apply to that folder |
| `ERROR: pass --job` | the file name matches several rules or none; add `--job <schema_id>` |
| Garbled accents on screen | use `run.cmd` (it sets UTF-8) instead of calling `python run_tests.py` directly |
| File too large | the limit is 200 MB per file |

---

## 8. What is in the folder

```text
run.cmd / run.ps1        run it (sets itself up on first use)
setup.cmd / setup.ps1    prepare the environment separately (optional)
run_tests.py             command-line logic
engine\                  validation engine (types, nulls, strict mode)
jobs\                    bundled rules (*_extract_col)
mis-reglas\              your own rules
ejemplo\                 synthetic data for --self-test
package.cmd              build a zip of this folder
sync_jobs.py             author only: re-copy jobs\ from the FTPQ repo
MANUAL-ES.md             Spanish manual
MANUAL-EN.md             this manual
```

It ships no graphical interface, no SFTP, no PDF export and no patient data.

To hand it over, copy the folder **without** `.venv\`, or run `package.cmd` to drop a zip in Downloads. The recipient only needs Python (step 2) and `run.cmd`.
