# Mis reglas / My rules

**ES** — Poné acá tus reglas JSON propias. Se cargan automáticamente junto con las de `jobs\`.
Si un `schema_id` se repite, gana el de esta carpeta (así podés sobrescribir una regla incluida sin editarla).

Cada regla son **dos archivos** con el mismo nombre base:

| Archivo | Contenido |
|---------|-----------|
| `mi_extract.job.json` | qué prueba correr (`mode: schema`) y a qué `schema_id` apunta |
| `mi_extract.schema.json` | el mapeo: columnas, tipos, nulos, `strict`, patrón de nombre de archivo |

Copiá `_plantilla.job.json` y `_plantilla.schema.json` y renombralos (el `schema_id` debe coincidir con el nombre base).

Verificá que la regla cargó:

```bat
run.cmd --list-jobs
```

Tipos válidos en `data_type`: `string`, `integer`, `decimal`, `boolean`, `date`, `datetime`.

| Campo de columna | Efecto |
|------------------|--------|
| `allows_null` | `false` = celda vacía es FAIL |
| `unique` | `true` = valores repetidos son FAIL |
| `enabled` | `false` = columna no se evalúa |
| `date_format` | formato Python, ej. `%d/%m/%Y` (si se omite, acepta ISO) |

`strict: true` exige que el archivo tenga **exactamente** esas columnas.
`batch_match.filename_patterns` son expresiones regulares sobre el **nombre del archivo**; deciden qué CSV usa esta regla al validar una carpeta.

---

**EN** — Put your own JSON rules here. They load together with the ones in `jobs\`.
If a `schema_id` repeats, this folder wins, so you can override a bundled rule without editing it.

Each rule is **two files** sharing a base name: `my_extract.job.json` (which test to run) and `my_extract.schema.json` (the column mapping). Copy `_plantilla.job.json` and `_plantilla.schema.json`, rename them, and keep `schema_id` equal to the base name.

Valid `data_type` values: `string`, `integer`, `decimal`, `boolean`, `date`, `datetime`.
`allows_null: false` fails empty cells, `unique: true` fails duplicates, `enabled: false` skips the column, and `date_format` takes a Python format such as `%d/%m/%Y`.
`strict: true` requires the file to have exactly those columns, and `batch_match.filename_patterns` are regular expressions on the file name that decide which files this rule validates.

Check that your rule loaded with `run.cmd --list-jobs --lang en`.
