@echo off
setlocal EnableExtensions
cd /d "%~dp0"

chcp 65001 >nul 2>&1
set "PYTHONUTF8=1"

set "PY="
call :try_py "py -3.12"
call :try_py "py -3"
call :try_py "python"
if not defined PY goto :no_python

echo Usando / using: %PY%
%PY% -m venv .venv
if errorlevel 1 goto :fail_venv

".venv\Scripts\python.exe" -m pip install -U pip
if errorlevel 1 goto :fail_pip

".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail_pip

echo.
echo OK / done. Siguiente / next:
echo   run.cmd --self-test
echo   run.cmd --list-jobs
echo   run.cmd "C:\ruta\a\carpeta\csv"
echo.
echo Manual: MANUAL-ES.md  -  MANUAL-EN.md
exit /b 0

:try_py
if defined PY goto :eof
%~1 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if errorlevel 1 goto :eof
set "PY=%~1"
goto :eof

:no_python
echo ERROR: se necesita Python 3.12 o superior.
echo ERROR: Python 3.12 or newer is required.
echo.
echo Descargar / download: https://www.python.org/downloads/windows/
echo Marcar durante la instalacion / tick during install: "Add python.exe to PATH"
exit /b 1

:fail_venv
echo ERROR: no se pudo crear .venv / could not create .venv
exit /b 1

:fail_pip
echo ERROR: fallo la instalacion de dependencias / dependency install failed
echo Revise su conexion o proxy / check your connection or proxy.
exit /b 1
