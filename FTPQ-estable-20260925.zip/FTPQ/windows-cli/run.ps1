#Requires -Version 5.1

# No se cambia de directorio: las rutas relativas se resuelven contra el
# directorio de quien ejecuta / relative paths resolve against the caller's directory.

$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$python = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"

if (-not (Test-Path -LiteralPath $python)) {
    Write-Host "Primera ejecucion: preparando entorno / first run: preparing environment..."
    Write-Host ""
    & (Join-Path $PSScriptRoot "setup.ps1")
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $python)) {
        Write-Error "No se pudo preparar el entorno / environment setup failed."
        exit 1
    }
    Write-Host ""
}

& $python (Join-Path $PSScriptRoot "run_tests.py") @args
exit $LASTEXITCODE
