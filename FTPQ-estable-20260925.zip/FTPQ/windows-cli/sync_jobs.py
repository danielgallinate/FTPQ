"""Copia jobs *_extract_col y mapeos .schema.json desde el repo FTPQ."""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "emr-qa" / "knowledge_bases" / "default" / "jobs"
DEST = ROOT / "jobs"


def main() -> int:
    if not SOURCE.is_dir():
        print(f"ERROR: no está el repo fuente: {SOURCE}", file=sys.stderr)
        print("Esta carpeta ya incluye jobs/; no hace falta sync en el zip de Windows.", file=sys.stderr)
        return 2
    DEST.mkdir(parents=True, exist_ok=True)
    copied = 0
    for path in sorted(SOURCE.glob("*_extract_col.job.json")):
        shutil.copy2(path, DEST / path.name)
        copied += 1
        schema = SOURCE / f"{path.name[: -len('.job.json')]}.schema.json"
        if schema.is_file():
            shutil.copy2(schema, DEST / schema.name)
            copied += 1
    print(f"OK: {copied} archivos copiados → {DEST}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
