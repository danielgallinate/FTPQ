@echo off
setlocal EnableExtensions

rem No se cambia de directorio: las rutas relativas que reciba se resuelven
rem contra el directorio donde esta parado quien ejecuta.
rem No directory change: relative paths resolve against the caller's directory.

chcp 65001 >nul 2>&1
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

set "HERE=%~dp0"
set "VENV_PY=%HERE%.venv\Scripts\python.exe"

if exist "%VENV_PY%" goto :run
call :bootstrap
if errorlevel 1 exit /b 1

:run
"%VENV_PY%" "%HERE%run_tests.py" %*
exit /b %ERRORLEVEL%

:bootstrap
echo Primera ejecucion: preparando entorno / first run: preparing environment...
echo.
pushd "%HERE%"
call setup.cmd
if errorlevel 1 goto :boot_fail
popd
echo.
exit /b 0

:boot_fail
popd
exit /b 1
