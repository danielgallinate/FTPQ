# Manual — uso e instalación (Windows)

Validador de archivos tabulares por consola. Compara CSV/TSV/PSV/Excel contra **reglas JSON**: columnas esperadas, tipos de dato, nulos, duplicados y estructura estricta.

Todo se ejecuta con **scripts en CMD o PowerShell**. No hay interfaz gráfica, no necesita WSL2 ni internet (salvo la primera preparación, que descarga pandas).

> Se entrega **tal cual, sin garantías**. Quien lo ejecuta elige qué archivos analiza y asume su entorno. No es un producto oficial ni sustituye controles de compliance.

**English version:** [`MANUAL-EN.md`](MANUAL-EN.md)

---

## 1. Requisitos

| Requisito | Detalle |
|-----------|---------|
| Windows | 10 u 11 |
| Python | **3.12 o superior**, nativo de Windows |
| Espacio | ~150 MB (pandas queda dentro de esta carpeta) |
| Permisos | Ninguno de administrador, salvo instalar Python |

La carpeta puede vivir donde quieras, siempre que tengas **permiso de escritura** ahí (necesita crear su subcarpeta `.venv\`). Por eso conviene evitar `C:\Program Files`.

---

## 2. Instalar Python (una sola vez por máquina)

1. Descargar desde [python.org/downloads/windows](https://www.python.org/downloads/windows/) — *Windows installer (64-bit)*.
2. En la primera pantalla del instalador, marcar **Add python.exe to PATH**.
3. Instalar con las opciones por defecto.
4. Comprobar en una ventana **nueva** de CMD:

```bat
python --version
```

Debe responder `Python 3.12.x` o superior. Si dice que el comando no existe, cerrá y volvé a abrir la consola; si sigue igual, reinstalá Python marcando la casilla del PATH.

---

## 3. Ejecutar

No hay paso previo. La **primera** vez que corras `run.cmd` se prepara solo: crea `.venv\` e instala pandas dentro de la carpeta, y sigue con lo que le pediste. Desde la segunda vez arranca directo.

Las rutas que le pases se resuelven **desde tu carpeta actual**, no desde donde está el script. Podés trabajar de las dos maneras:

Parado en la carpeta de tus datos, invocando el script por su ruta:

```bat
cd <donde están tus CSV>
C:\ruta\a\windows-cli\run.cmd .
```

O parado en la carpeta del script, apuntando a los datos:

```bat
cd <donde está windows-cli>
run.cmd "<carpeta con tus CSV>"
```

Comprobar que quedó bien instalado, con los datos de ejemplo que trae:

```bat
run.cmd --self-test
```

Debe terminar en `PASS` y `OK: motor, pandas y lectura de reglas funcionan.`

En **PowerShell** es `.\run.ps1` con los mismos argumentos. Si la política de ejecución lo bloquea:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
```

`setup.cmd` y `setup.ps1` existen por si querés preparar el entorno por separado, por ejemplo para dejar la máquina lista antes de tener los datos. No es obligatorio llamarlos.

---

## 4. Comandos

### Ver las reglas disponibles

```bat
run.cmd --list-jobs
```

Muestra, por cada regla, su identificador, de qué carpeta salió, cuántas columnas define y qué nombres de archivo le corresponden.

### Validar una carpeta

Cada regla trae su patrón de nombre de archivo, así que basta apuntar a la carpeta y el emparejamiento es automático:

```bat
run.cmd .
run.cmd extracts
run.cmd "D:\extracts de ayer"
```

Variantes:

```bat
run.cmd --short .          :: una línea por prueba
run.cmd --recursive .      :: incluir subcarpetas
run.cmd --dry-run .        :: ver qué se ejecutaría, sin validar
run.cmd --fail-fast .      :: detenerse en el primer fallo
```

### Validar un archivo puntual

```bat
run.cmd --file archivo.csv
run.cmd --job clinic_extract_col --file archivo.csv
```

`--job` se puede omitir cuando el nombre del archivo coincide con una sola regla.

### Guardar el resultado

```bat
run.cmd --json-out resultado.json .
run.cmd . > reporte.txt 2>&1
```

### Idioma

Los mensajes salen en español por defecto. Para inglés, `--lang en`; para fijarlo en la sesión, `set FTPQ_LANG=en` (CMD) o `$env:FTPQ_LANG="en"` (PowerShell).

---

## 5. Leer el resultado

```text
REGLA:    clinic_extract_col.job.json (CLINIC EXTRACT COL)
MAPEO:    clinic_extract_col.schema.json
ARCHIVO:  D:\extracts\algo_PDE_Clinic_1.csv
FILAS:   1,204
CELDAS:  OK 27,588 · NOK 4 (99.99%)
ESTRUCTURA: missing column: GPMS_CODE
AVISO: duplicate value in unique column CLINIC_ID: 2 rows
FAIL
```

| Línea | Significado |
|-------|-------------|
| `FILAS` | filas leídas del archivo |
| `CELDAS` | celdas que cumplen el tipo esperado vs. las que no, y el porcentaje |
| `ESTRUCTURA` | problema de columnas: falta una, o en modo estricto sobra/falta alguna |
| `AVISO` | duplicados, columnas del archivo que la regla no cubre, columnas desactivadas |
| `SIN DATOS` | el archivo trae encabezado pero ninguna fila |
| `PASS` / `FAIL` / `NO DATA` | `FAIL` si hay celdas NOK **o** algún problema de estructura; `NO DATA` si no hay filas que evaluar |

`NO DATA` no es aprobado ni reprobado: sin filas no hay tipo ni patrón que comprobar, así que
la herramienta avisa en lugar de dar un `PASS` que no significaría nada. Si además el
encabezado tiene problemas de columnas, eso sí se juzga y el resultado es `FAIL`.

Códigos de salida, útiles para encadenar en un `.bat`:

| Código | Significado |
|--------|-------------|
| `0` | todas las pruebas pasaron |
| `1` | hubo fallos de datos o de estructura |
| `2` | error de uso: ruta inexistente, sin reglas, Python mal instalado |
| `3` | sin fallos, pero algún archivo venía sin filas (`NO DATA`) |

---

## 6. Tus propias reglas JSON

La carpeta **`mis-reglas\`** es para tus reglas. Se cargan automáticamente junto con las de `jobs\`, y si repetís un `schema_id` la tuya tiene prioridad, así podés sobrescribir una regla incluida sin editarla.

Una regla son **dos archivos** con el mismo nombre base:

```text
mis-reglas\
  mi_extract.job.json      ← qué prueba correr
  mi_extract.schema.json   ← el mapeo de columnas
```

Copiá `_plantilla.job.json` y `_plantilla.schema.json`, renombralos y ajustá `schema_id` para que coincida con el nombre base. Los archivos que empiezan con `_` se ignoran.

El mapeo se ve así:

```json
{
  "schema_version": 1,
  "schema_id": "mi_extract",
  "name": "MI EXTRACT",
  "strict": false,
  "columns": [
    { "name": "ID", "data_type": "integer", "allows_null": false, "unique": true, "enabled": true },
    { "name": "FECHA", "data_type": "datetime", "allows_null": true, "enabled": true }
  ],
  "batch_match": {
    "filename_patterns": ["(?i).*_MI_Extract_.*\\.(?:csv|tsv|psv|xlsx|xlsm|xls)$"]
  }
}
```

| Campo | Efecto |
|-------|--------|
| `data_type` | `string`, `integer`, `decimal`, `boolean`, `date`, `datetime` |
| `allows_null` | `false` = celda vacía es NOK |
| `unique` | `true` = valores repetidos son NOK |
| `enabled` | `false` = la columna no se evalúa |
| `date_format` | formato Python, ej. `%d/%m/%Y`; si se omite, acepta ISO |
| `strict` | `true` = el archivo debe tener **exactamente** esas columnas |
| `batch_match.filename_patterns` | expresiones regulares sobre el nombre del archivo; deciden qué archivos usan esta regla |

Tras editar, confirmá que cargó con `run.cmd --list-jobs`. Si no aparece, casi siempre es una de tres cosas: el `schema_id` no coincide con el nombre base, falta uno de los dos archivos, o el JSON tiene un error de sintaxis (una coma sobrante).

Si preferís tener tus reglas en otro lado —una carpeta compartida, por ejemplo— apuntá ahí y se usan **en lugar** de las locales:

```bat
run.cmd --rules-dir "D:\reglas" .
```

---

## 7. Problemas frecuentes

| Síntoma | Qué hacer |
|---------|-----------|
| `python no se reconoce` | reinstalar Python marcando *Add python.exe to PATH*, y abrir una consola nueva |
| `fallo la instalacion de dependencias` | sin salida a internet o proxy corporativo bloqueando pip |
| `run.ps1 no se puede cargar` | `Set-ExecutionPolicy -Scope Process Bypass`, o usar `run.cmd` |
| `no se pudo crear .venv` | la carpeta está en una ruta sin permiso de escritura; moverla al perfil del usuario |
| `OMITIDO archivo (ninguna regla coincide)` | el nombre del archivo no cuadra con ningún `filename_patterns` — revisar con `--list-jobs` |
| `OMITIDAS N reglas sin archivo que coincida` | normal: son las reglas que no aplican a esa carpeta |
| `ERROR: indique --job` | el nombre del archivo coincide con varias reglas o con ninguna; pasar `--job <schema_id>` |
| Acentos raros en pantalla | usar `run.cmd` (fija UTF-8), no llamar a `python run_tests.py` directamente |
| Archivo muy grande | el límite es 200 MB por archivo |

---

## 8. Qué contiene la carpeta

```text
run.cmd / run.ps1        ejecutar (se prepara solo la primera vez)
setup.cmd / setup.ps1    preparar el entorno por separado (opcional)
run_tests.py             lógica de línea de comandos
engine\                  motor de validación (tipos, nulos, estricto)
jobs\                    reglas incluidas (*_extract_col)
mis-reglas\              tus reglas propias
ejemplo\                 datos sintéticos para --self-test
package.cmd              generar un zip de esta carpeta
sync_jobs.py             solo para el autor: recopiar jobs\ desde el repo FTPQ
MANUAL-ES.md             este manual
MANUAL-EN.md             manual en inglés
```

No incluye interfaz gráfica, SFTP, exportación a PDF ni datos de pacientes.

Para compartirla, copiá la carpeta **sin** `.venv\`, o ejecutá `package.cmd`, que deja un zip en Descargas. Quien la recibe solo necesita Python (paso 2) y correr `run.cmd`.
