# Ejemplo / Sample

**ES** — Datos y regla sintéticos para verificar la instalación. No contiene datos reales.

```bat
run.cmd --self-test
```

Para ver cómo se reporta un fallo (fila duplicada, tipos inválidos, columna vacía):

```bat
run.cmd --rules-dir ejemplo "ejemplo\con-errores"
```

**EN** — Synthetic rule and data used by the installation check. No real data included.

```bat
run.cmd --self-test --lang en
run.cmd --lang en --rules-dir ejemplo "ejemplo\con-errores"
```
