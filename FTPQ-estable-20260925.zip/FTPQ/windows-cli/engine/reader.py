"""Lectura tabular con pandas — CSV/TSV/PSV/Excel, todas las filas."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from engine.types import BATCH_TABULAR_GLOB_SUFFIXES, TABULAR_EXTENSIONS

DEFAULT_MAX_BYTES = 209_715_200  # 200 MiB


def collect_tabular_files(data_dir: Path, *, recursive: bool = False) -> list[Path]:
    files: list[Path] = []
    seen: set[Path] = set()
    for suffix in BATCH_TABULAR_GLOB_SUFFIXES:
        pattern = f"**/{suffix}" if recursive else suffix
        for path in data_dir.glob(pattern):
            resolved = path.resolve()
            if resolved not in seen:
                seen.add(resolved)
                files.append(path)
    return sorted(files, key=lambda item: str(item).casefold())


def is_tabular_file(path: Path) -> bool:
    return path.suffix.lower() in TABULAR_EXTENSIONS


def _read_dataframe(pd, path: Path):
    ext = path.suffix.lower()
    nullable = {"dtype_backend": "numpy_nullable"}
    if ext in {".xlsx", ".xlsm"}:
        return pd.read_excel(path, engine="openpyxl")
    if ext == ".xls":
        return pd.read_excel(path)
    if ext == ".tsv":
        return pd.read_csv(path, sep="\t", engine="c", encoding="utf-8-sig", **nullable)
    if ext == ".psv":
        return pd.read_csv(path, sep="|", engine="c", encoding="utf-8-sig", **nullable)
    try:
        return pd.read_csv(path, sep=",", engine="c", encoding="utf-8-sig", **nullable)
    except Exception:
        return pd.read_csv(path, sep=None, engine="python", encoding="utf-8-sig", **nullable)


def load_row_dicts(path: Path) -> tuple[list[str], list[dict[str, Any]]]:
    if not path.is_file():
        raise FileNotFoundError(f"Archivo no encontrado: {path}")
    file_size = path.stat().st_size
    if file_size > DEFAULT_MAX_BYTES:
        raise ValueError(
            f"Archivo demasiado grande ({file_size} bytes). Límite: {DEFAULT_MAX_BYTES}."
        )
    try:
        import pandas as pd
    except ImportError as exc:
        raise RuntimeError("pandas no está instalado. Ejecute setup.cmd") from exc

    dataframe = _read_dataframe(pd, path)
    if dataframe.empty and len(dataframe.columns) == 0:
        raise ValueError("Archivo tabular vacío o sin columnas.")

    columns = [str(name) for name in dataframe.columns]
    rows: list[dict[str, Any]] = []
    for record in dataframe.itertuples(index=False, name=None):
        row: dict[str, Any] = {}
        for index, name in enumerate(columns):
            value = record[index] if index < len(record) else ""
            if value is None:
                row[name] = ""
            else:
                row[name] = str(value)
        rows.append(row)
    return columns, rows
