"""CLI Windows — validación estructural con jobs JSON y mapeos schema."""
