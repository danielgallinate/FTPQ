"""Tipos — catálogos de esquema y emparejamiento batch (copia mínima, sin UI)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

SchemaDataType = Literal["string", "integer", "decimal", "boolean", "date", "datetime"]
SCHEMA_CATALOG_VERSION = 1
DATA_TYPES: tuple[SchemaDataType, ...] = (
    "string",
    "integer",
    "decimal",
    "boolean",
    "date",
    "datetime",
)
TABULAR_EXTENSIONS = frozenset({".csv", ".tsv", ".psv", ".xlsx", ".xlsm", ".xls"})
BATCH_TABULAR_GLOB_SUFFIXES = ("*.csv", "*.tsv", "*.psv", "*.xlsx", "*.xlsm", "*.xls")


@dataclass(frozen=True)
class BatchMatchSpec:
    filename_patterns: tuple[str, ...] = ()
    filename_excludes: tuple[str, ...] = ()

    def is_configured(self) -> bool:
        return bool(self.filename_patterns)

    @classmethod
    def from_dict(cls, raw: Any) -> BatchMatchSpec | None:
        if not isinstance(raw, dict):
            return None
        patterns = tuple(
            str(item).strip()
            for item in (raw.get("filename_patterns") or [])
            if str(item).strip()
        )
        excludes = tuple(
            str(item).strip()
            for item in (raw.get("filename_excludes") or [])
            if str(item).strip()
        )
        if not patterns and not excludes:
            return None
        return cls(filename_patterns=patterns, filename_excludes=excludes)


@dataclass
class SchemaColumnSpec:
    name: str
    data_type: SchemaDataType = "string"
    allows_null: bool = True
    unique: bool = False
    date_format: str = ""
    enabled: bool = True

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> SchemaColumnSpec:
        data_type = str(raw.get("data_type") or "string").strip().casefold()
        if data_type not in DATA_TYPES:
            data_type = "string"
        return cls(
            name=str(raw.get("name") or "").strip(),
            data_type=data_type,  # type: ignore[assignment]
            allows_null=bool(raw.get("allows_null", True)),
            unique=bool(raw.get("unique", False)),
            date_format=str(raw.get("date_format") or "").strip(),
            enabled=bool(raw.get("enabled", True)),
        )


@dataclass
class SchemaCatalog:
    schema_id: str
    name: str
    strict: bool = False
    columns: list[SchemaColumnSpec] = field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""
    schema_version: int = SCHEMA_CATALOG_VERSION
    batch_match: BatchMatchSpec | None = None

    def enabled_columns(self) -> list[SchemaColumnSpec]:
        return [column for column in self.columns if column.enabled and column.name.strip()]

    def expected_column_names(self) -> set[str]:
        return {column.name.strip() for column in self.columns if column.name.strip()}

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> SchemaCatalog:
        columns_raw = raw.get("columns") or []
        columns = [
            SchemaColumnSpec.from_dict(item)
            for item in columns_raw
            if isinstance(item, dict)
        ]
        return cls(
            schema_version=int(raw.get("schema_version") or SCHEMA_CATALOG_VERSION),
            schema_id=str(raw.get("schema_id") or "").strip(),
            name=str(raw.get("name") or "").strip(),
            strict=bool(raw.get("strict", False)),
            columns=columns,
            created_at=str(raw.get("created_at") or ""),
            updated_at=str(raw.get("updated_at") or ""),
            batch_match=BatchMatchSpec.from_dict(raw.get("batch_match")),
        )


class SchemaCatalogValidationError(Exception):
    pass
