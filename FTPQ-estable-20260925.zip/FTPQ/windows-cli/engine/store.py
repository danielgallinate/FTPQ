"""Carga jobs y mapeos schema JSON desde las carpetas de reglas locales."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

from engine.types import SchemaCatalog, SchemaCatalogValidationError


JOB_SUFFIX = ".job.json"
SCHEMA_SUFFIX = ".schema.json"

# jobs/ = reglas que vienen en el paquete · mis-reglas/ = reglas propias del usuario
BUILTIN_RULES_DIR = "jobs"
USER_RULES_DIR = "mis-reglas"


@dataclass(frozen=True)
class SchemaJob:
    job_path: Path
    schema_path: Path
    name: str
    schema_id: str
    catalog: SchemaCatalog

    @property
    def source(self) -> str:
        return self.job_path.parent.name


def rules_dirs(root: Path, *, extra: Path | None = None) -> list[Path]:
    """Carpetas donde buscar reglas, en orden de prioridad creciente."""
    if extra is not None:
        return [extra]
    folders = [root / BUILTIN_RULES_DIR, root / USER_RULES_DIR]
    return [folder for folder in folders if folder.is_dir()]


def _schema_id_from_job(raw: dict) -> str:
    schema = raw.get("schema") if isinstance(raw.get("schema"), dict) else {}
    return str(schema.get("schema_id") or "").strip()


def _compile_patterns(patterns: tuple[str, ...]) -> tuple[re.Pattern[str], ...]:
    return tuple(re.compile(pattern) for pattern in patterns)


def filename_matches(catalog: SchemaCatalog, basename: str) -> bool:
    spec = catalog.batch_match
    if spec is None or not spec.is_configured():
        return False
    includes = _compile_patterns(spec.filename_patterns)
    excludes = _compile_patterns(spec.filename_excludes)
    if not any(pattern.search(basename) for pattern in includes):
        return False
    if any(pattern.search(basename) for pattern in excludes):
        return False
    return True


def load_catalog(schema_path: Path) -> SchemaCatalog:
    raw = json.loads(schema_path.read_text(encoding="utf-8"))
    catalog = SchemaCatalog.from_dict(raw)
    if not catalog.schema_id:
        raise SchemaCatalogValidationError(f"schema_id: {schema_path.name}")
    return catalog


def _jobs_in_dir(folder: Path) -> list[SchemaJob]:
    items: list[SchemaJob] = []
    for job_path in sorted(folder.glob(f"*{JOB_SUFFIX}")):
        if job_path.name.startswith("_"):  # plantillas
            continue
        try:
            raw = json.loads(job_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        mode = str(raw.get("mode") or "").strip()
        if mode and mode != "schema":
            continue
        schema_id = _schema_id_from_job(raw)
        if not schema_id:
            schema_id = job_path.name[: -len(JOB_SUFFIX)]
        schema_path = folder / f"{schema_id}{SCHEMA_SUFFIX}"
        if not schema_path.is_file():
            continue
        try:
            catalog = load_catalog(schema_path)
        except (OSError, json.JSONDecodeError, SchemaCatalogValidationError):
            continue
        items.append(
            SchemaJob(
                job_path=job_path,
                schema_path=schema_path,
                name=str(raw.get("name") or catalog.name or schema_id),
                schema_id=catalog.schema_id or schema_id,
                catalog=catalog,
            )
        )
    return items


def list_schema_jobs(root: Path, *, extra_dir: Path | None = None) -> list[SchemaJob]:
    """Reglas de todas las carpetas; mis-reglas/ gana ante mismo schema_id."""
    folders = rules_dirs(root, extra=extra_dir)
    if not folders:
        raise FileNotFoundError(f"{root / BUILTIN_RULES_DIR}")
    by_id: dict[str, SchemaJob] = {}
    for folder in folders:
        for job in _jobs_in_dir(folder):
            by_id[job.schema_id] = job
    return sorted(by_id.values(), key=lambda item: item.schema_id.casefold())


def find_job(root: Path, token: str, *, extra_dir: Path | None = None) -> SchemaJob:
    needle = token.strip()
    for job in list_schema_jobs(root, extra_dir=extra_dir):
        if (
            job.schema_id == needle
            or job.job_path.name == needle
            or job.job_path.stem == needle
            or job.job_path.name == f"{needle}{JOB_SUFFIX}"
        ):
            return job
    raise FileNotFoundError(needle)
