"""Mensajes del CLI en español e inglés."""
from __future__ import annotations

import os

LANGUAGES = ("es", "en")

_MESSAGES: dict[str, dict[str, str]] = {
    "es": {
        "cli.description": "Validar CSV/TSV/PSV/Excel contra reglas JSON (jobs + mapeos de columnas).",
        "cli.data_dir": "Carpeta con archivos a validar (empareja por el regex de cada regla).",
        "cli.file": "Un archivo tabular concreto (combinable con --job).",
        "cli.job": "schema_id o nombre de la regla (ej. clinic_extract_col).",
        "cli.rules_dir": "Usar otra carpeta de reglas en lugar de jobs/ y mis-reglas/.",
        "cli.recursive": "Buscar también en subcarpetas.",
        "cli.dry_run": "Listar pares regla ↔ archivo sin validar.",
        "cli.short": "Una línea por prueba.",
        "cli.fail_fast": "Detener en el primer FAIL.",
        "cli.json_out": "Escribir resumen en JSON.",
        "cli.list_jobs": "Listar reglas disponibles y salir.",
        "cli.self_test": "Verificar la instalación con datos de ejemplo.",
        "cli.lang": "Idioma de los mensajes (es o en).",
        "header": "=== Validador tabular — reglas JSON ===",
        "header.rules": "Reglas:",
        "header.builtin": "incluidas",
        "header.user": "propias",
        "list.title": "Reglas disponibles:",
        "list.job": "regla:",
        "list.schema": "mapeo:",
        "list.match": "archivos:",
        "list.source": "origen:",
        "list.columns": "columnas:",
        "err.no_rules": "ERROR: no hay reglas. Carpeta esperada: %s",
        "err.no_file": "ERROR: archivo no encontrado: %s",
        "err.no_dir": "ERROR: carpeta no encontrada: %s",
        "err.no_tabular": "ERROR: no hay archivos tabulares en %s",
        "err.job_missing": "ERROR: regla no encontrada: %s",
        "err.need_job": "ERROR: indique --job (ninguna regla única coincidió con el nombre del archivo).",
        "err.rules_dir": "ERROR: carpeta de reglas no encontrada: %s",
        "skip.no_regex": "OMITIDA regla (sin patrón de archivos):",
        "skip.no_file": "OMITIDA regla (sin archivo que coincida):",
        "skip.no_file_many": "OMITIDAS %s reglas sin archivo que coincida en esta carpeta.",
        "skip.no_job": "OMITIDO archivo (ninguna regla coincide):",
        "out.job": "REGLA:",
        "out.schema": "MAPEO:",
        "out.file": "ARCHIVO:",
        "out.rows": "FILAS:",
        "out.cells": "CELDAS:",
        "out.struct": "ESTRUCTURA:",
        "out.alert": "AVISO:",
        "out.no_data": "SIN DATOS: el archivo no trae filas; no se puede evaluar tipo ni patrón.",
        "summary.title": "=== Resumen ===",
        "summary.dry_run": "Simulación: %s par(es) regla ↔ archivo",
        "summary.run": "Ejecutadas: %s | PASS: %s | FAIL/ERROR: %s | SIN DATOS: %s",
        "summary.json": "JSON:",
        "usage.examples": "Ejemplos (las rutas se resuelven desde su carpeta actual):",
        "usage.here": "carpeta actual",
        "usage.one_file": "un archivo",
        "usage.other": "otra carpeta",
        "usage.check": "verificar la instalación",
        "selftest.title": "=== Verificación de instalación ===",
        "selftest.ok": "OK: motor, pandas y lectura de reglas funcionan.",
        "selftest.fail": "ERROR: la verificación no pasó.",
    },
    "en": {
        "cli.description": "Validate CSV/TSV/PSV/Excel against JSON rules (jobs + column mappings).",
        "cli.data_dir": "Folder with files to validate (matched by each rule's regex).",
        "cli.file": "A single tabular file (can be combined with --job).",
        "cli.job": "schema_id or rule name (e.g. clinic_extract_col).",
        "cli.rules_dir": "Use another rules folder instead of jobs/ and mis-reglas/.",
        "cli.recursive": "Search subfolders too.",
        "cli.dry_run": "List rule ↔ file pairs without validating.",
        "cli.short": "One line per test.",
        "cli.fail_fast": "Stop at the first FAIL.",
        "cli.json_out": "Write a JSON summary.",
        "cli.list_jobs": "List available rules and exit.",
        "cli.self_test": "Check the installation with sample data.",
        "cli.lang": "Message language (es or en).",
        "header": "=== Tabular validator — JSON rules ===",
        "header.rules": "Rules:",
        "header.builtin": "bundled",
        "header.user": "your own",
        "list.title": "Available rules:",
        "list.job": "rule:",
        "list.schema": "mapping:",
        "list.match": "files:",
        "list.source": "source:",
        "list.columns": "columns:",
        "err.no_rules": "ERROR: no rules found. Expected folder: %s",
        "err.no_file": "ERROR: file not found: %s",
        "err.no_dir": "ERROR: folder not found: %s",
        "err.no_tabular": "ERROR: no tabular files in %s",
        "err.job_missing": "ERROR: rule not found: %s",
        "err.need_job": "ERROR: pass --job (no single rule matched the file name).",
        "err.rules_dir": "ERROR: rules folder not found: %s",
        "skip.no_regex": "SKIPPED rule (no file pattern):",
        "skip.no_file": "SKIPPED rule (no matching file):",
        "skip.no_file_many": "SKIPPED %s rules with no matching file in this folder.",
        "skip.no_job": "SKIPPED file (no rule matches):",
        "out.job": "RULE:",
        "out.schema": "MAPPING:",
        "out.file": "FILE:",
        "out.rows": "ROWS:",
        "out.cells": "CELLS:",
        "out.struct": "STRUCTURE:",
        "out.alert": "ALERT:",
        "out.no_data": "NO DATA: file has no rows; type and pattern cannot be evaluated.",
        "summary.title": "=== Summary ===",
        "summary.dry_run": "Dry run: %s rule ↔ file pair(s)",
        "summary.run": "Executed: %s | PASS: %s | FAIL/ERROR: %s | NO DATA: %s",
        "summary.json": "JSON:",
        "usage.examples": "Examples (paths resolve from your current folder):",
        "usage.here": "current folder",
        "usage.one_file": "a single file",
        "usage.other": "another folder",
        "usage.check": "check the installation",
        "selftest.title": "=== Installation check ===",
        "selftest.ok": "OK: engine, pandas and rule loading work.",
        "selftest.fail": "ERROR: the check did not pass.",
    },
}


def default_language() -> str:
    raw = str(os.environ.get("FTPQ_LANG") or "").strip().casefold()
    if raw.startswith("en"):
        return "en"
    return "es"


class Messages:
    def __init__(self, language: str) -> None:
        self.language = language if language in LANGUAGES else default_language()

    def __call__(self, key: str) -> str:
        table = _MESSAGES[self.language]
        return table.get(key, _MESSAGES["es"].get(key, key))
