# Validador tabular — Windows CLI / Tabular validator — Windows CLI

Carpeta **autónoma**: se comparte tal cual a una máquina Windows y se ejecuta por consola (CMD o PowerShell). Sin interfaz gráfica, sin WSL2, sin el resto del repositorio.

Self-contained folder: hand it to a Windows machine as is and run it from the console (CMD or PowerShell). No GUI, no WSL2, no rest of the repository.

## Inicio rápido / Quick start

Sin paso previo: la primera ejecución prepara el entorno sola.
No setup step: the first run prepares the environment by itself.

```bat
run.cmd --self-test          :: verificar / check
run.cmd --list-jobs          :: reglas disponibles / available rules
run.cmd .                    :: validar la carpeta actual / validate current folder
run.cmd --file archivo.csv   :: un archivo / a single file
```

Las rutas se resuelven desde **tu carpeta actual**, no desde la del script.
Paths resolve from **your current folder**, not the script's.

PowerShell: `.\run.ps1` con los mismos argumentos / with the same arguments.
Inglés / English messages: `--lang en`.

## Manuales / Manuals

- **Español:** [`MANUAL-ES.md`](MANUAL-ES.md)
- **English:** [`MANUAL-EN.md`](MANUAL-EN.md)

## Reglas / Rules

| Carpeta | Contenido |
|---------|-----------|
| `jobs\` | reglas incluidas / bundled rules (`*_extract_col`) |
| `mis-reglas\` | tus reglas JSON propias / your own JSON rules — ver [`mis-reglas/README.md`](mis-reglas/README.md) |
| `ejemplo\` | datos sintéticos para `--self-test` / synthetic data for `--self-test` |

Requisito / requirement: Python **3.12+** nativo de Windows ([python.org](https://www.python.org/downloads/windows/), marcar *Add python.exe to PATH*).

Se entrega **tal cual, sin garantías** · Provided **as is, without warranties**.
