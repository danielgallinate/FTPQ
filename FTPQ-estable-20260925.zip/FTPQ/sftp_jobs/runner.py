"""Runner headless — job sftp_fetch (existencia + descarga en secuencia)."""
from __future__ import annotations

import fnmatch
import json
import re
from dataclasses import dataclass, field, replace
from datetime import date, datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from adapters.sftp_browser_factory import create_sftp_browser
from core.sftp_browser import ISftpBrowser
from core.sftp_errors import SftpError
from core.sftp_job import SftpExpect, SftpFetchJob
from core.sftp_paths import join_remote_path
from core.sftp_types import SftpProfile


@dataclass
class SftpJobRunResult:
    ok: bool
    name: str
    remote_dir: str
    local_dir: Path | None
    sftp_user: str = ""
    messages: list[str] = field(default_factory=list)
    expects: list[dict[str, Any]] = field(default_factory=list)

    @property
    def verdict(self) -> str:
        return "PASS" if self.ok else "FAIL"

    def to_report_text(self) -> str:
        lines = [
            f"job: {self.name}",
            f"remote: {self.remote_dir}",
            f"local: {self.local_dir if self.local_dir is not None else '(not used)'}",
            f"verdict: {self.verdict}",
        ]
        for item in self.expects:
            matched = ", ".join(item.get("matched") or []) or "(none)"
            lines.append(
                f"{item['status']}: {item['pattern']} → {matched}"
            )
        lines.extend(self.messages)
        return "\n".join(lines)

    def to_json(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "verdict": self.verdict,
            "name": self.name,
            "remote_dir": self.remote_dir,
            "local_dir": str(self.local_dir) if self.local_dir is not None else None,
            "sftp_user": self.sftp_user,
            "messages": self.messages,
            "expects": self.expects,
        }


@dataclass(frozen=True)
class _RemoteFile:
    name: str
    remote_path: str
    relative_path: PurePosixPath
    size: int


def _safe_remote_name(name: str) -> bool:
    return bool(name) and name not in (".", "..") and "/" not in name and "\\" not in name


def _collect_remote_files(
    browser: ISftpBrowser,
    remote_dir: str,
    *,
    recursive: bool,
) -> list[_RemoteFile]:
    files: list[_RemoteFile] = []

    def visit(current: str, relative_parent: PurePosixPath) -> None:
        entries = browser.list_dir(current)
        for entry in entries:
            if entry.name == "..":
                continue
            if not _safe_remote_name(entry.name):
                raise ValueError(f"unsafe remote entry name: {entry.name!r}")
            remote_path = join_remote_path(current, entry.name)
            relative_path = relative_parent / entry.name
            if entry.entry_type == "dir":
                if recursive:
                    visit(remote_path, relative_path)
                continue
            files.append(
                _RemoteFile(
                    name=entry.name,
                    remote_path=remote_path,
                    relative_path=relative_path,
                    size=entry.size,
                )
            )

    visit(remote_dir, PurePosixPath())
    files.sort(key=lambda item: str(item.relative_path))
    return files


def _match(
    files: list[_RemoteFile],
    pattern: str,
    *,
    match_type: str,
) -> list[_RemoteFile]:
    if match_type == "regex":
        try:
            expression = re.compile(pattern)
        except re.error as exc:
            raise ValueError(f"invalid expect regex {pattern!r}: {exc}") from exc
        return [
            item
            for item in files
            if expression.search(item.name)
            or expression.search(str(item.relative_path))
        ]
    return [
        item
        for item in files
        if fnmatch.fnmatch(item.name, pattern)
        or fnmatch.fnmatch(str(item.relative_path), pattern)
    ]


def _expect_record(
    spec: SftpExpect,
    *,
    status: str,
    resolved_pattern: str | None = None,
    matched: list[str] | None = None,
    local_paths: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "pattern": spec.pattern,
        "resolved_pattern": resolved_pattern or spec.pattern,
        "match_type": spec.match_type,
        "min_count": spec.min_count,
        "matched": matched or [],
        "local_paths": local_paths or [],
        "status": status,
    }


def run_sftp_job(
    job: SftpFetchJob,
    *,
    browser: ISftpBrowser | None = None,
    keep_going: bool = False,
    local_dir: Path | None = None,
    sftp_user: str | None = None,
    private_key: Path | None = None,
    as_of: date | None = None,
) -> SftpJobRunResult:
    profile = SftpProfile.load_json_file(job.resolved_profile_path())
    if sftp_user is not None:
        user = sftp_user.strip()
        if not user:
            raise ValueError("sftp_user cannot be empty")
        profile = replace(profile, user=user)
    if private_key is not None:
        profile = replace(profile, private_key_path=private_key.expanduser().resolve())
    destination: Path | None = None
    if job.download:
        base_dir = job.resolved_local_dir(local_dir)
        destination = job.resolve_destination(base_dir, sftp_user=profile.user)
    result = SftpJobRunResult(
        ok=True,
        name=job.name,
        remote_dir=job.remote_dir,
        local_dir=destination,
        sftp_user=profile.user,
    )
    if (
        job.download
        and job.destination_name
        and destination is not None
        and destination.exists()
        and job.on_collision == "fail"
    ):
        result.ok = False
        for index, spec in enumerate(job.expect):
            result.expects.append(
                _expect_record(
                    spec,
                    status="COLLISION" if index == 0 else "SKIPPED",
                )
            )
        result.messages.append(f"COLLISION: destination folder exists: {destination}")
        return result
    owned = browser is None
    client = browser or create_sftp_browser()
    downloaded_manifest: dict[str, dict[str, Any]] = {}
    try:
        client.connect(profile)
        remote_files = _collect_remote_files(
            client,
            job.remote_dir,
            recursive=job.recursive,
        )
        skip_rest = False
        for spec in job.expect:
            resolved_pattern = spec.pattern.replace(
                "{date}", (as_of or date.today()).strftime("%Y%m%d")
            )
            if skip_rest:
                result.expects.append(
                    _expect_record(
                        spec,
                        status="SKIPPED",
                        resolved_pattern=resolved_pattern,
                    )
                )
                continue
            matched_files = _match(
                remote_files,
                resolved_pattern,
                match_type=spec.match_type,
            )
            matched = [str(item.relative_path) for item in matched_files]
            if len(matched) < spec.min_count:
                result.ok = False
                result.expects.append(
                    _expect_record(
                        spec,
                        status="MISSING",
                        resolved_pattern=resolved_pattern,
                        matched=matched,
                    )
                )
                result.messages.append(
                    f"MISSING: {resolved_pattern} matched {len(matched)}, "
                    f"need {spec.min_count}"
                )
                if not keep_going:
                    skip_rest = True
                continue
            local_paths: list[str] = []
            expect_ok = True
            status = "PASS"
            if not job.download:
                result.expects.append(
                    _expect_record(
                        spec,
                        status=status,
                        resolved_pattern=resolved_pattern,
                        matched=matched,
                    )
                )
                continue
            for remote_file in matched_files:
                relative = Path(*remote_file.relative_path.parts)
                assert destination is not None
                dest = destination / relative
                if dest.is_file() and job.on_collision == "fail":
                    result.ok = False
                    expect_ok = False
                    status = "COLLISION"
                    result.messages.append(f"COLLISION: {dest}")
                    break
                dest.parent.mkdir(parents=True, exist_ok=True)
                client.download(
                    remote_file.remote_path,
                    dest,
                    force=job.on_collision == "overwrite",
                )
                if not dest.is_file() or dest.stat().st_size <= 0:
                    result.ok = False
                    expect_ok = False
                    status = "EMPTY"
                    result.messages.append(f"EMPTY: {dest}")
                    break
                local_paths.append(str(dest))
                downloaded_manifest[str(remote_file.relative_path)] = {
                    "remote": remote_file.remote_path,
                    "relative_path": str(remote_file.relative_path),
                    "size": dest.stat().st_size,
                }
            if not expect_ok and status == "PASS":
                status = "FAIL"
            result.expects.append(
                _expect_record(
                    spec,
                    status=status,
                    resolved_pattern=resolved_pattern,
                    matched=matched,
                    local_paths=local_paths,
                )
            )
            if not expect_ok and not keep_going:
                skip_rest = True
        if result.ok and job.download and job.recursive:
            assert destination is not None
            destination.mkdir(parents=True, exist_ok=True)
            files = [
                downloaded_manifest[key]
                for key in sorted(downloaded_manifest)
            ]
            manifest = {
                "schema_version": 1,
                "job": job.name,
                "sftp_user": profile.user,
                "remote_dir": job.remote_dir,
                "downloaded_at_utc": datetime.now(timezone.utc).isoformat(),
                "file_count": len(files),
                "total_bytes": sum(int(item["size"]) for item in files),
                "files": files,
            }
            (destination / "_download_manifest.json").write_text(
                json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
    except SftpError as exc:
        result.ok = False
        result.messages.append(str(exc))
        raise
    finally:
        if owned:
            client.disconnect()
    return result
