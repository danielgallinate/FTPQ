#!/usr/bin/env python3
"""CLI — ejecutar job sftp_fetch (conectar, existencia, descarga en secuencia)."""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from core.sftp_errors import SftpError  # noqa: E402
from core.sftp_job import load_job  # noqa: E402
from sftp_jobs.runner import run_sftp_job  # noqa: E402


def _parse_as_of(value: str):
    try:
        return datetime.strptime(value, "%Y%m%d").date()
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "--as-of must use YYYYMMDD, for example 20260916"
        ) from exc


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run an SFTP fetch job JSON (connect, exist, download sequence).",
    )
    parser.add_argument("job", type=Path, help="Path to sftp_fetch job.json")
    parser.add_argument(
        "--json-out",
        type=Path,
        help="Write machine summary JSON to this path",
    )
    parser.add_argument(
        "--error-out",
        type=Path,
        help="Write machine-readable error JSON on exit 1 or 2",
    )
    parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Automation: stdout only PASS or FAIL",
    )
    parser.add_argument(
        "--short",
        "-s",
        action="store_true",
        help="Automation: one-line summary",
    )
    parser.add_argument(
        "--keep-going",
        action="store_true",
        help="Continue remaining expect[] after a FAIL",
    )
    parser.add_argument(
        "--local-dir",
        "-d",
        type=Path,
        help="Download directory (overrides job JSON; use when the path is not browsable)",
    )
    parser.add_argument(
        "--sftp-user",
        help="SFTP user (overrides profile JSON)",
    )
    parser.add_argument(
        "--private-key",
        type=Path,
        help="Private key path (overrides profile JSON)",
    )
    parser.add_argument(
        "--as-of",
        type=_parse_as_of,
        help="Date for {date} placeholders, formatted as YYYYMMDD (default: today)",
    )
    return parser


def _short_line(result) -> str:
    failed = sum(1 for item in result.expects if item["status"] not in ("PASS", "SKIPPED"))
    return f"{result.verdict} job={result.name} expects={len(result.expects)} failed={failed}"


def _write_error(
    path: Path | None,
    *,
    error: str,
    exit_code: int,
    job: str = "",
) -> None:
    if path is None:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "ok": False,
                "exit_code": exit_code,
                "job": job,
                "error": error,
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    job_path = args.job.resolve()
    try:
        job = load_job(job_path)
        result = run_sftp_job(
            job,
            keep_going=args.keep_going,
            local_dir=args.local_dir.resolve() if args.local_dir else None,
            sftp_user=args.sftp_user,
            private_key=args.private_key,
            as_of=args.as_of,
        )
    except FileNotFoundError as exc:
        _write_error(args.error_out, error=str(exc), exit_code=2)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except ValueError as exc:
        _write_error(args.error_out, error=str(exc), exit_code=2)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except SftpError as exc:
        _write_error(args.error_out, error=str(exc), exit_code=2)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except OSError as exc:
        _write_error(args.error_out, error=str(exc), exit_code=2)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    report_text = result.to_report_text()
    if args.json_out is not None:
        args.json_out.parent.mkdir(parents=True, exist_ok=True)
        args.json_out.write_text(
            json.dumps(result.to_json(), indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    if args.quiet:
        print(result.verdict)
    elif args.short:
        print(_short_line(result))
    else:
        print(report_text)
    if not result.ok:
        _write_error(
            args.error_out,
            error="; ".join(result.messages) or "SFTP job failed",
            exit_code=1,
            job=result.name,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
