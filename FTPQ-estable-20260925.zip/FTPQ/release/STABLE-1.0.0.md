# PDE Desktop 1.0.0 — congelado estable

**Fecha:** 2026-07-17

## Qué incluye esta versión

- SFTP + file manager dual (Local A/B)
- Compare multiset (pandas)
- Visualización tabular y texto (modo foco + Cerrar)
- i18n ES/EN
- Perfil local JSON (`profiles/default.json`)

## Cómo ejecutar (solo dos vías)

| Plataforma | Requisito | Comandos |
|------------|-----------|----------|
| **macOS nativo** | Python **3.12+** | `./scripts/setup.sh` → `./scripts/run_ui.sh` |
| **Windows** | **WSL2** + Python **3.12+** en la distro | Mismo repo montado en WSL → mismos scripts `.sh` |

Guías detalladas: [`../instalacion/`](../instalacion/README.md) · Plantilla IT: [`../instalacion/plantilla-ticket-it.md`](../instalacion/plantilla-ticket-it.md)

No hay instalador MSI, portable PyInstaller, Python embed ni build-kit Windows nativo en esta línea estable.

## Eliminado en 1.0.0 (archivado)

Ver [`../scripts/ARCHIVADO-INSTALADORES.md`](../scripts/ARCHIVADO-INSTALADORES.md).

## Uso

Solo individual / entorno autorizado. No compartir binarios ni bundles con terceros.  
Ver [`../documentacion/alcance-uso-individual.md`](../documentacion/alcance-uso-individual.md).

## Tag git (opcional)

```bash
./scripts/create_release_tag.sh
# → v1.0.0
```
