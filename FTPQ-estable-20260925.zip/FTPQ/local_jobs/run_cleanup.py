#!/usr/bin/env python3
"""CLI — job local_cleanup. El CI decide cuándo invocarlo."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from core.local_cleanup_job import load_job  # noqa: E402
from local_jobs.cleanup_runner import run_local_cleanup  # noqa: E402


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Delete local files matching globs. Never touches SFTP.",
    )
    parser.add_argument("job", type=Path, help="Path to local_cleanup job.json")
    parser.add_argument("--json-out", type=Path, help="Write summary JSON")
    parser.add_argument(
        "--error-out",
        type=Path,
        help="Write error JSON when the job does not PASS",
    )
    parser.add_argument("--quiet", "-q", action="store_true")
    parser.add_argument("--short", "-s", action="store_true")
    parser.add_argument(
        "--local-dir",
        "-d",
        type=Path,
        help="Directory to clean (overrides job JSON)",
    )
    return parser


def _write_error(path: Path | None, *, error: str, exit_code: int, name: str = "") -> None:
    if path is None:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "ok": False,
                "exit_code": exit_code,
                "name": name,
                "error": error,
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    job_path = args.job.resolve()
    try:
        job = load_job(job_path)
        result = run_local_cleanup(
            job,
            local_dir=args.local_dir.resolve() if args.local_dir else None,
        )
    except FileNotFoundError as exc:
        _write_error(args.error_out, error=str(exc), exit_code=2)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except ValueError as exc:
        _write_error(args.error_out, error=str(exc), exit_code=2)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    if args.json_out is not None:
        args.json_out.parent.mkdir(parents=True, exist_ok=True)
        args.json_out.write_text(
            json.dumps(result.to_json(), indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    if args.quiet:
        print(result.verdict)
    elif args.short:
        print(
            f"{result.verdict} job={result.name} deleted={len(result.deleted)}"
        )
    else:
        print(result.to_report_text())
    if not result.ok:
        _write_error(
            args.error_out,
            error="; ".join(result.messages) or "cleanup FAIL",
            exit_code=1,
            name=result.name,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
