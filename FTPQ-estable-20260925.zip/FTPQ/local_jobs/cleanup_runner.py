"""Runner — borra archivos locales que coincidan con globs. Nunca toca SFTP."""
from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.local_cleanup_job import LocalCleanupJob, pattern_is_unsafe


@dataclass
class LocalCleanupResult:
    ok: bool
    name: str
    local_dir: Path
    deleted: list[str] = field(default_factory=list)
    expects: list[dict[str, Any]] = field(default_factory=list)
    messages: list[str] = field(default_factory=list)

    @property
    def verdict(self) -> str:
        return "PASS" if self.ok else "FAIL"

    def to_report_text(self) -> str:
        lines = [
            f"job: {self.name}",
            f"local: {self.local_dir}",
            f"verdict: {self.verdict}",
            f"deleted: {len(self.deleted)}",
        ]
        for item in self.expects:
            lines.append(f"{item['status']}: {item['pattern']}")
        lines.extend(self.messages)
        return "\n".join(lines)

    def to_json(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "verdict": self.verdict,
            "name": self.name,
            "local_dir": str(self.local_dir),
            "deleted": list(self.deleted),
            "expects": self.expects,
            "messages": self.messages,
        }


def run_local_cleanup(
    job: LocalCleanupJob,
    *,
    local_dir: Path | None = None,
) -> LocalCleanupResult:
    target = job.resolved_local_dir(local_dir)
    result = LocalCleanupResult(ok=True, name=job.name, local_dir=target)
    if not target.exists():
        raise FileNotFoundError(f"local_dir not found: {target}")
    if not target.is_dir():
        raise ValueError(f"local_dir is not a directory: {target}")

    names = sorted(p.name for p in target.iterdir() if p.is_file())
    for pattern in job.patterns:
        if pattern_is_unsafe(pattern):
            result.ok = False
            result.expects.append(
                {
                    "pattern": pattern,
                    "matched": [],
                    "deleted": [],
                    "status": "REFUSED",
                }
            )
            result.messages.append(f"REFUSED: unsafe pattern {pattern!r}")
            continue
        matched = [name for name in names if fnmatch.fnmatch(name, pattern)]
        deleted: list[str] = []
        for name in matched:
            path = (target / name).resolve()
            try:
                path.relative_to(target)
            except ValueError:
                result.ok = False
                result.messages.append(f"REFUSED: {path} is outside {target}")
                continue
            if not path.is_file():
                continue
            path.unlink(missing_ok=True)
            if not path.exists():
                deleted.append(name)
                result.deleted.append(name)
        result.expects.append(
            {
                "pattern": pattern,
                "matched": matched,
                "deleted": deleted,
                "status": "PASS",
            }
        )
    return result
