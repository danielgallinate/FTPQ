# Skills — PDE Desktop

Skills **afinados por módulo y rol** para generar contexto de proyecto en Cursor.

## Contexto (repo-wide)

| Rol | Skill | Referencia |
|-----|-------|------------|
| Mantener contexto | [context/SKILL.md](./context/SKILL.md) | [context/reference.md](./context/reference.md) |

**Invocación:** `@context-maintainer` — auditar, actualizar docs/skills, promover draft, sync.

```bash
python scripts/context-audit.py
./scripts/sync-skills.sh
```

## SFTP (completo)

| Rol | Skill | Contexto compartido |
|-----|-------|-------------------|
| Dev | [sftp/dev/SKILL.md](./sftp/dev/SKILL.md) | [sftp/reference.md](./sftp/reference.md) |
| QA | [sftp/qa/SKILL.md](./sftp/qa/SKILL.md) | ↑ |
| Peer review | [sftp/peer-review/SKILL.md](./sftp/peer-review/SKILL.md) | ↑ |

**Invocación:** `@sftp-dev` · `@sftp-qa` · `@sftp-peer-review`

## UI (QA prototipo)

| Rol | Skill |
|-----|-------|
| QA | [ui/qa/SKILL.md](./ui/qa/SKILL.md) |

**Invocación:** `@ui-qa` — checklist + `tests/test_ui_smoke.py`

### Orden recomendado al iniciar sesión SFTP

```text
1. Leer skills/sftp/reference.md     ← contexto del proyecto
2. Invocar skill del rol             ← dev / qa / peer-review
3. Spec viva en documentacion/sftp/  ← fuente de verdad funcional
```

## Espejo Cursor

Copia en [`.cursor/skills/`](../.cursor/skills/). Tras editar `skills/`:

```bash
cp skills/sftp/dev/SKILL.md .cursor/skills/sftp-dev/SKILL.md
cp skills/sftp/qa/SKILL.md .cursor/skills/sftp-qa/SKILL.md
cp skills/sftp/peer-review/SKILL.md .cursor/skills/sftp-peer-review/SKILL.md
cp skills/sftp/reference.md .cursor/skills/sftp-reference.md
cp skills/context/SKILL.md .cursor/skills/context-maintainer/SKILL.md
cp skills/context/reference.md .cursor/skills/context-reference.md
cp skills/ui/qa/SKILL.md .cursor/skills/ui-qa/SKILL.md
```

O ejecutar: `./scripts/sync-skills.sh`

## Rules complementarias

`.cursor/rules/`: `scope-no-db`, `architecture`, `cross-platform`, `sftp-real-test`, `memory-limits`

## Pendiente

- `skills/pandas/{dev,qa,peer-review}/`
- `skills/ui/dev/` · `skills/ui/reference.md`
