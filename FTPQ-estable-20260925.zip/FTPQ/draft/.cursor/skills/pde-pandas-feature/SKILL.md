---
name: pde-pandas-feature
description: Use when implementing CSV analysis F11-F16, pandas rules from JSON profiles, or batch validation queue in PDE Desktop.
---

# PDE Pandas Feature Workflow

## Requirements reference

`documentacion/paso-02-funcionalidades/README.md` — section 2.2

## Implementation order

1. `IFileAnalyzer` in `core/` with `AnalysisReport` / `BatchReport` dataclasses
2. `adapters/pandas_analyzer.py` — lazy import pandas inside methods
3. Load rules from profile `pandas_rules` section
4. UI tab "Análisis": pick file → run → show stats, duplicates, column validation (F11–F15)
5. Batch: queue paths, one at a time, table of results (F16)

## Rules engine (F15)

From profile JSON:

- delimiter
- required_columns / optional_columns
- metadata checks (clinic, datasource) vs column values or constants

**Not from Postgres.**

## Fixtures

Use `mocks/fixtures/csv/sample_*.csv` for unit tests.

## Memory

Follow `memory-limits.mdc`: warn >50MB, sequential batch.
