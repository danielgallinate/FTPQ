---
name: pde-sftp-feature
description: Use when implementing SFTP features F01-F10, key selector, explorer, preview, download, or SSH key generation in PDE Desktop.
---

# PDE SFTP Feature Workflow

## Requirements reference

`documentacion/paso-02-funcionalidades/README.md` — section 2.1

## Implementation order

1. Define/use `ISftpBrowser` and `IKeyStore` in `core/`
2. Implement `adapters/paramiko_sftp.py`
3. Implement `MockSftpBrowser` with `mocks/fixtures/sftp/*.json`
4. Wire UI: profile form, key dropdown (F03), test button (F05), explorer (F06–F07)
5. Preview with size limits (rule `memory-limits.mdc`)
6. Download with native file picker (F09)
7. Key generation (F10) via paramiko/cryptography in adapter

## Critical fix vs legacy TUI

Key selector must **apply** the key to the active SFTP session and reconnect.

## Tests

- Mock: list_dir returns fixture JSON
- Integration (VPN): test_auth against real Transfer — manual QA checklist

## Cross-platform

Update both `run.sh` and `run.ps1` if adding CLI flags.
