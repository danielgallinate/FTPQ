---
name: pde-mock-mode
description: Use when creating MockSftpBrowser, SFTP/CSV fixtures, or running PDE Desktop without VPN via PDE_DESKTOP_MOCK=1.
---

# PDE Mock Mode

## Enable

```bash
PDE_DESKTOP_MOCK=1 ./run.sh
```

```powershell
$env:PDE_DESKTOP_MOCK = "1"; .\run.ps1
```

## Fixture layout

```
mocks/fixtures/
  sftp/listing_*.json
  csv/sample_*.csv
  profiles/example_profile.json
```

## MockSftpBrowser behavior

- `test_auth()` → success
- `list_dir(path)` → read matching fixture or empty list
- `download()` → copy fixture CSV to target path
- `preview()` → truncate per profile limits

## Recording real listings (VPN once)

Script placeholder: `scripts/record_sftp_listing.py` — serialize paramiko list to JSON.

Sanitize hostnames and client names before commit.

## Tests

All core tests should run with mocks only (no network in CI).
