---
name: pde-cross-platform
description: Use when adding or changing setup/run/build scripts, PyInstaller packaging, or ensuring macOS and Windows PowerShell parity in PDE Desktop.
---

# PDE Cross-Platform Workflow

## Parity rule

Every `*.sh` at repo root or in `scripts/` needs a matching `*.ps1`.

## Script matrix

| sh | ps1 |
|----|-----|
| setup.sh | setup.ps1 |
| run.sh | run.ps1 |
| scripts/build.sh | scripts/build.ps1 |

## Windows specifics

- `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` if blocked
- Detect Python: `py -3`, then `python`, then `python3`
- App restart: subprocess, not os.execv alone

## macOS specifics

- chmod +x on shell scripts
- ~/.ssh permissions 700 dir, 600 keys

## Docs to update

- `documentacion/plataformas/macos.md`
- `documentacion/plataformas/windows.md`

## Packaging (F20)

PyInstaller one-folder; exclude .venv, .env, keys from zip.
