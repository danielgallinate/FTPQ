---
name: pde-handoff
description: Use when starting work on PDE Desktop to load handoff context, scope limits, and the 5-step documentation map before coding.
---

# PDE Desktop Handoff

## Before any implementation

1. Read `documentacion/README.md`
2. Confirm phase: Fase 0 (SFTP), Fase 1 (pandas file), Fase 2 (batch + exe)
3. Check `.cursor/rules/scope-no-db.mdc` — no Postgres/Snowflake

## Documentation map

| Step | Path |
|------|------|
| Understand | `documentacion/paso-01-entender/` |
| Features F01–F22 | `documentacion/paso-02-funcionalidades/` |
| Infrastructure | `documentacion/paso-03-infraestructura/` |
| Mocks | `documentacion/paso-04-mocks/` |
| Decisions ADR | `documentacion/paso-05-decisiones/` |

## Quick scope reminder

- GUI app, not TUI
- JSON profiles, not .env+DB for main config
- Windows: native `.ps1`, WSL not required
- Real SFTP test when not in mock mode

## If VPN unavailable

Set `PDE_DESKTOP_MOCK=1` and use `MockSftpBrowser` + fixtures.
