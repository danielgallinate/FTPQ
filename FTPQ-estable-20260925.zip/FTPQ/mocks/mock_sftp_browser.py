"""Mock SFTP browser — no network; used when PDE_DESKTOP_MOCK=1."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from core.result import Ok
from core.sftp_browser import ISftpBrowser
from core.sftp_errors import SftpPathError
from core.sftp_paths import SFTP_ROOT, resolve_list_path
from core.sftp_types import PreviewResult, RemoteEntry, SessionState, SftpProfile

_FIXTURES = Path(__file__).resolve().parent / "fixtures" / "sftp"


class MockSftpBrowser(ISftpBrowser):
    """In-memory SFTP for dev/QA without VPN. test_auth always succeeds."""

    def __init__(self, fixtures_dir: Path | None = None) -> None:
        self._fixtures_dir = fixtures_dir or _FIXTURES
        self._state = SessionState.DISCONNECTED
        self._profile: SftpProfile | None = None
        self._current_path: str | None = None
        self._listing_map = {
            SFTP_ROOT: "listing_root.json",
            ".": "listing_root.json",
            "scheduled": "listing_scheduled.json",
            "config/example_config/scheduled": "listing_scheduled.json",
            "requested": "listing_requested.json",
            "config/example_config/requested": "listing_requested.json",
            "archived": "listing_archived.json",
            "config/example_config/archived": "listing_archived.json",
        }

    @property
    def state(self) -> SessionState:
        return self._state

    @property
    def current_remote_path(self) -> str | None:
        return self._current_path

    def connect(self, profile: SftpProfile) -> None:
        self.disconnect()
        self._profile = profile
        self._state = SessionState.CONNECTED
        self._current_path = SFTP_ROOT

    def disconnect(self) -> None:
        self._profile = None
        self._current_path = None
        self._state = SessionState.DISCONNECTED

    def test_auth(self) -> Ok[None]:
        if self._profile is None:
            self._state = SessionState.DISCONNECTED
        return Ok(None)

    def list_dir(self, remote_path: str) -> list[RemoteEntry]:
        if self._state != SessionState.CONNECTED:
            raise RuntimeError("Not connected")
        logical = resolve_list_path(self._current_path, remote_path)
        lookup = SFTP_ROOT if logical == "." else logical
        fixture_name = self._listing_map.get(lookup)
        if fixture_name is None:
            raise SftpPathError(f"Path not found in mock fixtures", path=remote_path)
        data = json.loads((self._fixtures_dir / fixture_name).read_text(encoding="utf-8"))
        self._current_path = logical
        return [_entry_from_dict(e) for e in data["entries"]]

    def download(
        self,
        remote_path: str,
        local_path: Path,
        *,
        on_progress=None,
        force: bool = False,
    ) -> None:
        local_path.parent.mkdir(parents=True, exist_ok=True)
        name = Path(remote_path).name.lower()
        if name.endswith(".csv") or name.endswith(".tsv") or name.endswith(".psv"):
            if name.endswith(".psv"):
                content = (
                    "id|name|amount|status\n"
                    "1|alpha|10.5|ok\n"
                    "2|beta|20.0|ok\n"
                    "3|gamma|15.25|pending\n"
                    "4|alpha|10.5|ok\n"
                )
            else:
                content = (
                    "id,name,amount,status\n"
                    "1,alpha,10.5,ok\n"
                    "2,beta,20.0,ok\n"
                    "3,gamma,15.25,pending\n"
                    "4,alpha,10.5,ok\n"
                )
        else:
            content = f"mock content for {remote_path}\n"
        payload = content.encode("utf-8")
        if on_progress is not None:
            on_progress(0, len(payload))
            on_progress(len(payload), len(payload))
        local_path.write_text(content, encoding="utf-8")

    def preview(self, remote_path: str, max_bytes: int) -> PreviewResult:
        content = f"mock preview: {remote_path}\nline2\n"
        encoded = content.encode("utf-8")
        truncated = len(encoded) > max_bytes
        if truncated:
            content = encoded[:max_bytes].decode("utf-8", errors="replace")
        return PreviewResult(
            content=content,
            truncated=truncated,
            bytes_read=min(len(encoded), max_bytes),
            line_count=content.count("\n") + (1 if content and not content.endswith("\n") else 0),
        )


def _entry_from_dict(raw: dict) -> RemoteEntry:
    modified = None
    if raw.get("modified"):
        modified = datetime.fromisoformat(raw["modified"])
    return RemoteEntry(
        name=raw["name"],
        entry_type=raw["type"],
        size=int(raw.get("size", 0)),
        modified=modified,
    )
