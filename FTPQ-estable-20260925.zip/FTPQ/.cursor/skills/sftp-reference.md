# SFTP — Referencia de contexto (PDE Desktop)

Documento compartido por skills `sftp-dev`, `sftp-qa`, `sftp-peer-review`.  
Spec detallada: `documentacion/sftp/`. **No mezclar** con `pandas/` ni `ui/`.

---

## 1. Identidad del producto

| | |
|---|---|
| **Producto** | PDE Desktop — app escritorio portable (Mac + Windows nativo) |
| **Este módulo** | SFTP: conexión, llaves, exploración, preview, descarga |
| **No es** | PDE SFTP Validator TUI; no Postgres; no F7 SFTP↔BD |
| **Stack SFTP** | Python 3.11+, paramiko ≥3.4 |
| **Entorno real** | AWS Transfer Family + VPN + IP whitelist |
| **Sin VPN** | `PDE_DESKTOP_MOCK=1` + fixtures JSON |

---

## 2. Límites de módulo (inviolables)

```text
core/       ← contratos, tipos, errores (sin paramiko, sin UI)
adapters/   ← paramiko_sftp, key_store
mocks/      ← MockSftpBrowser, fixtures/sftp/
ui/         ← SOLO consume ISftpBrowser / IKeyStore (otro skill)
```

**Prohibido en cambios SFTP:** `pandas`, `psycopg2`, `snowflake`, `textual`, `flet`, `PySide6`.

**Fuera de alcance SFTP:** upload, delete remoto, multi-sesión, túnel SSH, validación vs `extract_history`.

---

## 3. Catálogo S01–S17

| ID | Funcionalidad | Aceptación |
|----|---------------|------------|
| S01 | Conector por llave privada | SSH + SFTP paramiko |
| S02 | host, port, user | Perfil JSON |
| S03 | Selector llave | Cambio → disconnect + reconnect |
| S04 | ssh_keys_dir | Default `~/.ssh` |
| S05 | test_auth | Handshake real R6 |
| S06 | list_dir | name, type, size, mtime? |
| S07 | navegar | enter, .., refresh |
| S08 | preview | texto/CSV; R11–R15 |
| S09 | download | stream → local_path |
| S10 | path actual | POSIX para breadcrumb |
| S11 | discover keys | sin .pub |
| S12 | fingerprint | SHA256 |
| S13 | validate key | existe, parseable, permisos |
| S14 | generate key | RSA/ECDSA |
| S17 | perfil JSON | load/save multi |

**Grafo:** S17→S02,S03,S04 → S05 → S06 → S07,S08,S09 | S04→S11→S03 | S14→S11

---

## 4. Restricciones R01–R27

| ID | Regla |
|----|-------|
| R1 | Una sesión SFTP activa |
| R2 | disconnect al cambiar perfil/host/user/key |
| R3 | SFTP en worker thread |
| R4 | timeout 30s default |
| R5 | VPN para PDE real |
| R6 | test_auth real; no flags BD |
| R7 | pathlib.Path + expanduser |
| R8 | remoto POSIX |
| R9 | local Win ~ y C:\Users |
| R10 | default_remote_path normalizado |
| R11–R15 | preview solo texto/CSV; 512KB/500 líneas; configurable |
| R13 | binarios → PreviewNotSupported |
| R16–R19 | download: local_path resuelto; downloads/ vs tmp/preview/ |
| R20–R24 | llaves privadas; permisos; fingerprint antes de guardar |
| R25–R27 | no secrets en git/logs; tmp/preview limpiar |

---

## 5. Mapa S → R (trazabilidad)

| S | R obligatorias |
|---|----------------|
| S01,S05 | R1,R4,R5,R6,R20 |
| S03 | R1,R2,R6,R20,L-01 |
| S06–S07 | R3,R8,R10 |
| S08 | R3,R11–R15,R27 |
| S09 | R3,R16–R19,R17 |
| S11–S14 | R7,R9,R20–R24 |
| S17 | R2,R7,R25 |

---

## 6. Lecciones validator

| ID | Lección | Acción |
|----|---------|--------|
| **L-01** | TUI tecla K no aplicaba llave | S03 + R2: siempre reconnect |
| **L-02** | Transfer ≠ BD; config10 OK con llave config3 | S05 real; no confiar provisioning |
| **L-03** | Win restart subprocess | scripts .ps1 paridad |

---

## 7. Contexto PDE (rutas)

```text
config/<profile_id>/scheduled/
config/<profile_id>/requested/
```

| JSON | Validator legacy |
|------|------------------|
| profile_id | CONFIG_NAME |
| sftp.user | SFTP_USER (= profile_id nonprod) |
| sftp.host | SFTP_HOST |
| sftp.private_key_path | SFTP_KEY_PATH |
| sftp.default_remote_path | DEFAULT_FOLDER (prefijo config/...) |

Schema: `documentacion/sftp/schema-perfil.draft.json`

---

## 8. Contrato core

```python
# ISftpBrowser — core/sftp_browser.py
connect(profile: SftpProfile) -> None
disconnect() -> None
test_auth() -> Result[None, SftpError]
list_dir(remote_path: str) -> list[RemoteEntry]
download(remote_path: str, local_path: Path) -> None
preview(remote_path: str, max_bytes: int) -> PreviewResult

# IKeyStore — core/key_store.py
discover(keys_dir: Path) -> list[KeyCandidate]
fingerprint(private_key_path: Path) -> str
generate(path: Path, key_type: Literal["rsa","ecdsa"], bits: int | None) -> KeyPairInfo
validate(private_key_path: Path) -> list[KeyWarning]

# SessionState
disconnected | connecting | connected | error
```

---

## 9. Errores tipados (core)

| Tipo | Cuándo |
|------|--------|
| SftpAuthError | publickey, auth failed |
| SftpConnectionError | banner, timeout, network |
| SftpPathError | path not found |
| KeyNotFoundError | private key missing |
| KeyFormatError | parse fail |
| PreviewNotSupported | binario R13 |
| PreviewTooLarge | > R12 |

Sin secretos en `str(error)`.

---

## 10. Mock mode

| Env | Efecto |
|-----|--------|
| `PDE_DESKTOP_MOCK=1` | MockSftpBrowser |

Fixtures: `mocks/fixtures/sftp/listing_scheduled.json`, `listing_requested.json`  
Perfil ejemplo: ver `draft/mocks/fixtures/profiles/example_profile.json`

---

## 11. Archivos repo esperados

```text
core/sftp_profile.py      # SftpProfile dataclass
core/sftp_browser.py      # Protocol ISftpBrowser
core/key_store.py         # Protocol IKeyStore
core/sftp_errors.py       # excepciones §9
adapters/paramiko_sftp.py
adapters/paramiko_keys.py
mocks/mock_sftp_browser.py
mocks/mock_key_store.py
tests/test_sftp_*.py
```

---

## 12. Criterios cierre módulo

Ver `documentacion/sftp/criterios-exito.md` — Mac + Windows + mock + sin Postgres en adapters.

---

## 13. Comandos útiles

```bash
# Dev/QA Mac
PDE_DESKTOP_MOCK=1 ./run.sh
pytest tests/test_sftp_* -q

# QA real (VPN)
./run.sh   # cuando exista --sftp-check

# Win
$env:PDE_DESKTOP_MOCK="1"; .\run.ps1
```

Legacy: `draft/.../test-sftp-login.sh` → equivalente S05.
