---
name: sftp-peer-review
description: Peer review of PDE Desktop SFTP PRs against S01-S17, R1-R27, ISftpBrowser contract, and project boundaries. Use when reviewing paramiko code, core SFTP types, mocks, SFTP tests, or SFTP docs — reject UI/pandas/Postgres mixed PRs.
---

# SFTP — Peer review

<MANDATORY-READ>
1. **`skills/sftp/reference.md`** — contexto completo S/R/contrato/PDE
2. Diff del PR + `documentacion/sftp/` afectada
</MANDATORY-READ>

## Rol de este skill

Actuar como **guardián de dominio**: el módulo SFTP permanece aislado, trazable y alineado al validator corregido (L-01, L-02).

---

## Flujo de review (obligatorio)

```text
1. Clasificar PR: SFTP-puro | mixto | otro dominio
   → mixto sin split: BLOCK
2. Listar Sxx declarados en PR (si faltan: MAJOR)
3. Por cada archivo: mapa reference.md §11
4. Verificar Rxx §5 reference.md
5. Tests: mock sin VPN + cobertura Sxx
6. Seguridad R25-R26
7. Emitir review estructurada + veredicto
```

---

## Clasificación PR (primera línea del review)

| Tipo | Criterio | Veredicto default |
|------|----------|-------------------|
| **A — SFTP puro** | Solo core/adapters/mocks/tests SFTP | Continuar checklist |
| **B — Mixto** | SFTP + ui/pandas en mismo PR | **Block** — pedir split |
| **C — Fuera alcance** | upload, psycopg2, F7 BD | **Block** — ADR o fuera |

---

## Checklist BLOCKER (1 fallo = Request changes)

### Dominio y arquitectura

- [ ] **B1** Cero `flet`/`PySide6` en core/adapters SFTP
- [ ] **B2** Cero `pandas`/`psycopg2`/`snowflake`/`textual`
- [ ] **B3** Cero lógica paramiko/list_dir/preview en `ui/`
- [ ] **B4** Contrato `ISftpBrowser`/`IKeyStore` intacto o versionado con doc

### Comportamiento L-01 / L-02 / R6

- [ ] **B5** Cambio llave (S03) → disconnect + connect (grep `apply_key`, `disconnect`)
- [ ] **B6** `test_auth` no retorna OK sin handshake (excepto class Mock*)
- [ ] **B7** Una sesión (R1): no segundo SFTPClient sin cerrar primero

### Preview / download

- [ ] **B8** Preview acotado R14; binarios R13
- [ ] **B9** download no lee archivo entero a RAM en archivos grandes

### Seguridad

- [ ] **B10** Sin llaves/.env/perfiles secretos en diff
- [ ] **B11** Sin log de contenido remoto o passphrase R26

### Tests

- [ ] **B12** Test nuevo/actualizado por Sxx del PR
- [ ] **B13** `pytest tests/test_sftp_*` pasa sin VPN

---

## Checklist MAJOR

- [ ] **M1** PR menciona IDs Sxx y Rxx en descripción
- [ ] **M2** Doc `documentacion/sftp/` actualizada si cambia comportamiento
- [ ] **M3** Errores usan tipos §9 reference.md
- [ ] **M4** Paths pathlib R7; remoto POSIX R8
- [ ] **M5** Timeout configurable R4 (default 30)
- [ ] **M6** Script `.sh` → par `.ps1` si aplica

---

## Checklist MINOR

- Naming, docstrings públicos, typing en core, fixtures organizados.

---

## Anti-patterns → BLOCKER automático

| Código / pattern | Regla |
|------------------|-------|
| `connection_verified` de BD | R6 |
| Tecla/lista llaves sin reconnect | L-01 |
| `sftp.open().read()` sin límite preview | R14 |
| `os.path.join` para path remoto | R8 |
| Upload/delete remoto | fuera alcance |
| `CONFIG_ID` query SQL | dominio BD |

---

## Mapa archivo → qué revisar

| Path pattern | S | R |
|--------------|---|---|
| `core/sftp*.py` | contrato | R7 |
| `core/*error*` | §9 reference | R26 |
| `adapters/paramiko_sftp*` | S01-S10 | R1-R6,R11-R19 |
| `adapters/*key*` | S11-S14 | R20-R24 |
| `mocks/mock_sftp*` | paridad contrato | — |
| `tests/test_sftp*` | cobertura Sxx PR | — |
| `documentacion/sftp/*` | coherencia S/R | — |

---

## Plantilla review (usar verbatim)

```markdown
# Peer review — SFTP

**PR:** | **Clasificación:** A/B/C | **Revisor:**

## Sxx en scope
- [ ] S__

## Rxx verificadas
- [ ] R__

## BLOCKERS
| ID | Archivo:Línea | Issue |
|----|---------------|-------|

## MAJOR
| ID | Issue |

## MINOR
| Issue |

## Trazabilidad tests
| Sxx | Test file | ¿Cubre edge error? |

## Veredicto
- [ ] **Approve**
- [ ] **Request changes** (N blockers, M major)
- [ ] **Block** (mixto dominio / fuera alcance)

## Notas L-01 / L-02
```

---

## Criterios veredicto

| Veredicto | Condición |
|-----------|-----------|
| **Approve** | 0 BLOCKER; MAJOR resueltos o waiver explícito del autor |
| **Request changes** | ≥1 BLOCKER o ≥2 MAJOR sin plan |
| **Block** | PR tipo B/C; o intento reintroducir bug TUI K sin reconnect |

---

## Post-review

| Acción | Skill |
|--------|-------|
| Autor corrige | `@sftp-dev` |
| Re-test manual | `@sftp-qa` casos QA-Sxx afectados |
| Solo doc SFTP | Approve si S/R coherentes |

---

## Qué NO comentar en este review

- Estética, Lottie, spacing → UI
- Reglas pandas JSON → pandas
- Empaquetado global PyInstaller (salvo scripts SFTP mock/run)

---

## Salida esperada del agente

Review completa usando plantilla § arriba. Cada issue con **Sxx/Rxx** citado. Sin opinión vaga sin spec.
