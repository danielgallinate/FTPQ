---
name: ui-qa
description: Verifies PDE Desktop UI prototype against checklist-prototipo.md — layout 2:1:1, Color button, menu-only chrome, four flat panels. Use after UI changes; run test_ui_smoke.py and report PASS/FAIL per checklist ID before claiming done.
---

# UI — QA prototipo

<MANDATORY-READ>
1. `documentacion/ui/checklist-prototipo.md`
2. `documentacion/ui/layout-principal.md`
3. `documentacion/ui/menu.md`
</MANDATORY-READ>

## Al recibir "verificar" o tras cambios UI

```bash
cd <repo>
QT_QPA_PLATFORM=offscreen pytest tests/test_ui_smoke.py -q -v
```

## Reporte obligatorio

```markdown
## UI QA — prototipo

**pytest:** pass/fail (pegar salida)
**GUI manual:** sí/no (usuario o agente con pantalla)

| ID | Resultado | Notas |
|----|-----------|-------|
| L-01 | PASS/FAIL | |
| C-01 | PASS/FAIL | |
| C-03 | PASS/FAIL | |
| ... | | |

**Bloqueantes:** ...
**No declarar completo si:** C-01, C-03, L-03, P-04 fallan.
```

## Si pytest pasa pero usuario reporta FAIL visual

Priorizar reporte humano; corregir y re-ejecutar.

## Prohibido

- Decir "listo" solo porque importa sin pytest
- Omitir checklist tras rediseño de paneles
