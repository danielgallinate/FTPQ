# Skills Cursor (espejo)

**Fuente canonical:** [`../skills/`](../skills/)

| Archivo | Origen |
|---------|--------|
| `context-maintainer/SKILL.md` | `skills/context/SKILL.md` |
| `context-reference.md` | `skills/context/reference.md` |
| `sftp-dev/SKILL.md` | `skills/sftp/dev/SKILL.md` |
| `sftp-qa/SKILL.md` | `skills/sftp/qa/SKILL.md` |
| `sftp-peer-review/SKILL.md` | `skills/sftp/peer-review/SKILL.md` |
| `sftp-reference.md` | `skills/sftp/reference.md` |
| `ui-qa/SKILL.md` | `skills/ui/qa/SKILL.md` |

Sync:

```bash
./scripts/sync-skills.sh
```
