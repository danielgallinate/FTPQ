---
name: sftp-dev
description: Implements PDE Desktop SFTP module only — ISftpBrowser, IKeyStore, paramiko adapters, mocks, tests for S01-S17 and R1-R27. Use when building SFTP connection, SSH keys, remote listing, preview, download in core/adapters; never UI, pandas, or Postgres.
---

# SFTP — Desarrollo

<MANDATORY-READ>
Antes de escribir código, cargar contexto completo:
1. **`skills/sftp/reference.md`** — contexto del proyecto (S, R, contrato, PDE)
2. `documentacion/sftp/funcionalidades.md` + `restricciones.md` + `contrato.md`
</MANDATORY-READ>

## Rol de este skill

Generar implementación **correcta por dominio**: solo `core/`, `adapters/`, `mocks/`, `tests/` SFTP.  
El agente debe razonar en IDs **Sxx** y **Rxx** en commits, PRs y tests.

---

## Contexto express (no sustituye reference.md)

**PDE Desktop** ≠ Validator TUI. Módulo SFTP = paramiko + perfiles JSON + una sesión.  
**L-01:** S03 cambia llave → `disconnect()` → `connect()`.  
**L-02:** S05 siempre handshake real (MockSftpBrowser es la única excepción explícita).

---

## Árbol de decisión al recibir una tarea

```text
¿Es SFTP puro (S01-S17)?
  NO → detener; usar skill pandas/ui o pedir split PR
  SÍ → ¿Toca ui/?
    SÍ → solo wiring mínimo si usuario lo exige; lógica en adapters
    NO → identificar Sxx → leer Rxx en reference.md §5 → implementar
```

---

## Orden de implementación (greenfield)

| Fase | Entregable | Sxx |
|------|------------|-----|
| 1 | `core/sftp_errors.py`, `SftpProfile`, Protocols | contrato |
| 2 | `MockSftpBrowser`, fixtures JSON | S05–S10 mock |
| 3 | `tests/test_sftp_contract.py` | todos mock |
| 4 | `ParamikoSftpBrowser` | S01–S10 real |
| 5 | `ParamikoKeyStore` | S11–S14 |
| 6 | Profile load/save (sin UI) | S17 |
| 7 | Factory `create_sftp_browser()` mock vs real | PDE_DESKTOP_MOCK |

---

## Patrones de implementación

### Sesión (R1, R2)

```python
def connect(self, profile: SftpProfile) -> None:
    self.disconnect()  # R2: idempotente
    # ... paramiko SSHClient + SFTPClient
    self._state = SessionState.connected

def apply_key_change(self, new_key_path: Path) -> None:
    """S03 / L-01: obligatorio en API pública si expuesto."""
    self.disconnect()
    self._profile.private_key_path = new_key_path
    self.connect(self._profile)
```

### test_auth (R6, S05)

```python
def test_auth(self) -> Result[None, SftpError]:
    # Handshake real: connect SSH + open sftp channel + close
    # NO retornar Ok sin socket
    # MockSftpBrowser: Ok siempre (documentado en clase)
```

### list_dir (S06, R8)

- Remoto siempre string POSIX: `config/foo/scheduled`
- Normalizar: sin `//`, strip según R10
- Entrada `..` resuelta por servidor o normalizada antes

### preview (S08, R11–R15)

```python
def preview(self, remote_path: str, max_bytes: int) -> PreviewResult:
    # 1. stat tamaño; si binario por ext → PreviewNotSupported
    # 2. Leer como máximo max_bytes (y contar líneas ≤ preview_max_lines)
    # 3. truncated=True si hay más datos
    # 4. Temp en tmp/preview/ si se usa disco (R27)
```

### download (S09, R16–R19)

- Recibe `local_path: Path` ya resuelto
- Stream con `sftp.getfo` o equivalente; no cargar RAM completa en archivos grandes
- Propagar `OSError` sin tragar

### paths (R7, R9)

```python
from pathlib import Path
key = Path(profile.private_key_path).expanduser()
# NUNCA: base + "/" + name para remoto
```

---

## Tests obligatorios por Sxx

| Sxx | Test mínimo |
|-----|-------------|
| S05 | mock auth ok; paramiko mock auth fail |
| S03 | cambio key invoca disconnect+connect (spy) |
| S06 | fixture listing_scheduled.json |
| S08 | csv ok; .zip → PreviewNotSupported; truncado |
| S09 | escribe bytes correctos a tmp_path |
| S11 | discover excluye .pub |
| S14 | generate crea par (tmp dir) |

Marcar tests: `@pytest.mark.parametrize("spec_id", ["S06"])`

---

## Dependencias permitidas

```text
paramiko>=3.4.0
# cryptography — solo si generate key lo requiere
```

---

## Checklist pre-commit (dev)

- [ ] Cada función pública mapea a Sxx documentado
- [ ] Rxx aplicables verificadas (reference.md §5)
- [ ] Cero imports prohibidos (reference.md §2)
- [ ] Tests pasan sin VPN (`pytest -q`)
- [ ] Errores son tipos de `core/sftp_errors.py`
- [ ] `.sh` nuevo → `.ps1` par si afecta run/mock

---

## Anti-patterns (rechazar en self-review)

| ❌ | ✅ |
|----|-----|
| `connected=True` antes de handshake | state=connected solo post OK |
| Lista llaves sin reconnect | S03 + L-01 |
| `open().read()` preview sin límite | R14 streaming acotado |
| SFTP en main thread UI | R3 executor |
| psycopg2 “para CONFIG_NAME” | profile_id en JSON |

---

## Handoff a otros roles

| Cuándo | Skill |
|--------|-------|
| PR listo | `@sftp-peer-review` |
| Feature lista para probar | `@sftp-qa` |
| Pantalla/botón | skill UI (futuro) |

---

## Salida esperada del agente

Al terminar una tarea, reportar:

```markdown
## Implementación SFTP
**Sxx:** ...
**Rxx:** ...
**Archivos:** ...
**Tests:** ...
**Mock:** sí/no
**Pendiente QA:** ...
```
