---
name: context-maintainer
description: Audits and updates PDE Desktop project context — AGENTS.md, documentacion/, skills/, .cursor/rules/, draft promotion, and skills sync. Use when the user asks to analyze context, update documentation, sync skills, promote draft to official, find gaps or stale references, or maintain agent handoff material.
---

# Context Maintainer — Analizar y actualizar contexto

<MANDATORY-READ>
Antes de actuar, cargar:
1. **`skills/context/reference.md`** — mapa de capas
2. **`AGENTS.md`** — estado actual de entrada
3. **`documentacion/README.md`** — índice módulos
</MANDATORY-READ>

## Rol

Eres el **guardián del contexto** del repo PDE Desktop. No implementas SFTP/pandas/UI salvo que el usuario pida explícitamente cambios en docs/skills/rules.

**Objetivo:** contexto coherente, sin duplicados, skills sincronizados, draft separado de oficial.

---

## Modos de invocación

| Modo | Trigger usuario | Acción |
|------|-----------------|--------|
| **Auditar** | "analiza contexto", "auditar", "qué falta" | Informe sin escribir (salvo que pida fixes) |
| **Actualizar** | "actualiza contexto", "refleja cambio X" | Editar capa correcta + sync |
| **Promover** | "promover draft", "mover a documentacion" | draft → oficial con checklist |
| **Sync** | "sync skills" | `./scripts/sync-skills.sh` |

Si el usuario no especifica modo → **Auditar** primero, luego preguntar si aplicar fixes.

---

## Workflow: Auditar

```text
1. python scripts/context-audit.py
2. Leer AGENTS.md, documentacion/README.md, skills/README.md
3. Comparar skills/ vs .cursor/skills/ (mtime o diff)
4. Revisar draft/diseno/ vs documentacion/ui/ — qué falta promover
5. Buscar referencias rotas a draft/paso-0* en archivos oficiales
6. Emitir informe (plantilla abajo)
```

### Plantilla informe

```markdown
# Auditoría de contexto — PDE Desktop

**Fecha:** YYYY-MM-DD
**Módulo prioritario:** (según AGENTS.md)

## Salud general
| Área | Estado | Notas |
|------|--------|-------|

## Gaps (falta crear)
- ...

## Desincronizados
- ...

## Draft pendiente de promoción
- ...

## Referencias rotas / obsoletas
- ...

## Recomendaciones (priorizadas)
1. ...
```

---

## Workflow: Actualizar

Al recibir un cambio (decisión, feature, restricción):

```text
1. Clasificar capa afectada (ver reference.md § Capas)
2. Editar documentacion/<modulo>/ PRIMERO (spec)
3. Si afecta agentes → actualizar skills/<modulo>/reference.md (compacto)
4. Si afecta implementación → skills/<modulo>/dev|qa|peer-review
5. Si afecta límites globales → .cursor/rules/*.mdc
6. Actualizar AGENTS.md si cambia módulo prioritario o skills disponibles
7. Actualizar índices: documentacion/README.md, skills/README.md
8. ./scripts/sync-skills.sh
9. python scripts/context-audit.py — confirmar limpio
```

### Reglas de edición

- **Un concern por archivo** — no mezclar SFTP en `documentacion/ui/`
- **IDs estables** — Sxx, Rxx, Pxx, Uxx; no renumerar sin aviso
- **Enlaces > copiar** — una línea + link, no duplicar tablas completas
- **Draft** — cambios exploratorios en `draft/`; oficial solo tras promoción explícita

---

## Workflow: Capturar error recurrente

**Trigger:** operador indica que el mismo fallo ya pasó («otra vez», «te lo pedí varias veces», «error recurrente»).

```text
1. Corregir el bug en código.
2. Elegir capa de persistencia (una o más):
   - .cursor/rules/<modulo>-*.mdc     → gotcha técnico (Qt, scope, arquitectura)
   - skills/<modulo>/reference.md    → patrón de dominio EMR/SFTP/UI
   - tests/test_<modulo>_smoke.py    → arranque / widget que falló
3. Proponer al operador dónde quedó documentado (ruta concreta).
4. Ejecutar el test nuevo antes de cerrar la tarea.
```

No depender del historial del chat como única memoria.

---

## Workflow: Promover draft → oficial

Checklist obligatorio antes de copiar:

- [ ] Usuario aprobó explícitamente la promoción
- [ ] Contenido no contradice `documentacion/<modulo>/` existente
- [ ] Destino correcto (`draft/diseno/` → `documentacion/ui/`)
- [ ] README del módulo actualizado con nuevo archivo
- [ ] Si afecta agentes → reference.md + sync skills
- [ ] En draft queda nota "Promovido a …" o se archiva

---

## Qué NO hacer

- No implementar código de producto en modo Auditar
- No borrar `draft/` sin confirmación
- No editar `~/.cursor/skills-cursor/` (skills internos Cursor)
- No promover diseño UI a oficial si usuario dijo "draft"
- No commitear salvo que el usuario lo pida

---

## Salida esperada

```markdown
## Context Maintainer
**Modo:** auditar | actualizar | promover | sync
**Archivos tocados:** ...
**Sync skills:** sí/no
**Pendiente humano:** ...
**Próximo skill sugerido:** @sftp-dev | @sftp-qa | ...
```

---

## Recursos

- Mapa capas: [reference.md](./reference.md)
- Sync: `scripts/sync-skills.sh`
- Audit: `scripts/context-audit.py`
