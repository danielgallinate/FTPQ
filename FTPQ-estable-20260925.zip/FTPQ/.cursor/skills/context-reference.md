# Contexto del proyecto — Mapa de capas (PDE Desktop / FTPQ)

Referencia compartida del skill `@context-maintainer`.  
**Línea activa:** `FTPQ/` — ver [`../../documentacion/linea-desarrollo.md`](../../documentacion/linea-desarrollo.md)  
**Fuente de verdad funcional:** `documentacion/<modulo>/`  
**Contexto compacto para agentes:** `skills/<modulo>/reference.md` + skills de rol  
**Entrada rápida:** `AGENTS.md`

---

## Capas (de arriba abajo)

| Capa | Ruta | Qué contiene | Quién edita |
|------|------|--------------|-------------|
| **Entrada** | `AGENTS.md` | Índice vivo: módulo activo, skills, reglas | context-maintainer |
| **Spec dominio** | `documentacion/sftp\|pandas\|ui/` | Sxx/Pxx/Uxx, restricciones, contratos | Tras aprobación; no mezclar módulos |
| **Skills rol** | `skills/<modulo>/{dev,qa,peer-review}/` | Cómo implementar/probar/revisar | Tras cambio de spec o patrón |
| **Referencia skill** | `skills/<modulo>/reference.md` | Contexto compacto S/R/contrato | Cuando spec cambia |
| **Espejo Cursor** | `.cursor/skills/` | Copia de skills para `@` | `scripts/sync-skills.sh` |
| **Rules** | `.cursor/rules/*.mdc` | Límites inviolables en sesión | Cambios arquitectura/scope |
| **Draft** | `draft/` | Borrador, legacy, diseño sin aprobar | Exploración; promover a oficial |
| **Código** | `core/`, `adapters/`, `ui/`, `mocks/` | Implementación | Skills de dominio (sftp-dev, etc.) |

---

## Flujo draft → oficial

```text
draft/diseno/          ──aprobación──► documentacion/ui/
draft/documentacion/   ──archivado───► (queda en draft; no duplicar)
skills/                ──sync───────► .cursor/skills/
documentacion/         ──resumen────► skills/*/reference.md (compacto)
```

**Regla:** no copiar párrafos largos entre capas — enlazar.

---

## Módulos y estado esperado

| Módulo | Doc oficial | Skill dev | Skill qa | reference.md |
|--------|-------------|-----------|----------|--------------|
| SFTP | `documentacion/sftp/` ✅ | `sftp-dev` ✅ | `sftp-qa` ✅ | `skills/sftp/reference.md` ✅ |
| Pandas | `documentacion/pandas/` esqueleto | pendiente | pendiente | pendiente |
| UI | `documentacion/ui/` ✅ prototipo | pendiente | `ui-qa` ✅ | pendiente |
| **Contexto** | `documentacion/README.md` + `linea-desarrollo.md` | **`context-maintainer`** ✅ | — | este archivo |

---

## Archivos índice (mantener al día)

| Archivo | Debe listar |
|---------|-------------|
| `documentacion/README.md` | Módulos + estado |
| `skills/README.md` | Skills + sync |
| `.cursor/skills/README.md` | Espejo + comando sync |
| `AGENTS.md` | Módulo prioritario + `@skills` |
| `draft/diseno/README.md` | Diseño UI en borrador |

---

## Anti-patterns de contexto

| ❌ | ✅ |
|----|-----|
| Spec SFTP dentro de `documentacion/ui/` | Enlace a `sftp/` |
| Editar solo `.cursor/skills/` | Editar `skills/` → sync |
| Duplicar S01–S17 en skill y doc | Skill resume; doc detalla |
| Promover draft sin checklist | Modo `promover` del skill |
| AGENTS.md con rutas a `draft/paso-01` | Rutas a `documentacion/` |

---

## Comandos útiles

```bash
# Auditoría rápida
python scripts/context-audit.py

# Sync skills → .cursor/skills
./scripts/sync-skills.sh
```
