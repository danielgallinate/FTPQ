---
name: sftp-qa
description: QA verification and test planning for PDE Desktop SFTP module S01-S17 against R1-R27. Use when writing test cases, manual QA checklists, VPN/Transfer validation, mock-mode smoke tests, or SFTP bug reports — not for implementing code or testing pandas/UI layout.
---

# SFTP — QA

<MANDATORY-READ>
1. **`skills/sftp/reference.md`** — S, R, PDE paths, errores, mock
2. `documentacion/sftp/criterios-exito.md`
3. `documentacion/sftp/funcionalidades.md` + `restricciones.md`
</MANDATORY-READ>

## Rol de este skill

Validar que el **comportamiento SFTP** cumple spec. No implementar fixes.  
Trazabilidad: cada caso de prueba cita **Sxx** + **Rxx** + resultado medible.

---

## Niveles de prueba

| Nivel | Entorno | Objetivo | Bloquea release |
|-------|---------|----------|-----------------|
| **L0 Smoke mock** | `PDE_DESKTOP_MOCK=1` | Contrato + fixtures | Sí (CI) |
| **L1 Smoke real** | VPN + 1 perfil | S05, S06, S09 | Sí |
| **L2 Completo** | VPN + 2 perfiles | S01–S17, Mac+Win | Sí módulo |
| **L3 Regresión validator** | Comparar TUI legacy | Paridad comportamiento SFTP | Recomendado |

---

## Matriz trazable S → R → Caso

### Conexión

| Caso ID | S | R | Precondición | Pasos | Resultado esperado |
|---------|---|---|--------------|-------|-------------------|
| QA-S05-01 | S05 | R5,R6 | VPN on, perfil válido | Test conexión | OK; state=connected |
| QA-S05-02 | S05 | R4,R5 | VPN off | Test conexión | SftpConnectionError/banner; mensaje accionable |
| QA-S05-03 | S05 | R6 | user incorrecto | Test | SftpAuthError publickey |
| QA-S05-04 | S05 | R4 | host invalido | Test | timeout ≤30s + error |
| QA-S03-01 | S03 | R2,L-01 | sesión activa | Cambiar llave | disconnect previo; nuevo list_dir |
| QA-S02-01 | S02 | R2 | connected | Cambiar host | sesión cerrada; re-test |

### Exploración

| Caso ID | S | R | Pasos | Resultado |
|---------|---|---|-------|-----------|
| QA-S06-01 | S06 | R8,R10 | list `config/<id>/scheduled` | ≥0 entries; campos name,type,size |
| QA-S07-01 | S07 | R8 | enter subdir → .. → refresh | path S10 coherente |
| QA-S08-01 | S08 | R11,R12 | preview CSV <512KB | content; truncated=false |
| QA-S08-02 | S08 | R12,R13 | preview CSV >512KB | truncated=true o PreviewTooLarge |
| QA-S08-03 | S08 | R13 | preview .zip | PreviewNotSupported |
| QA-S09-01 | S09 | R16,R17 | download a picker path | bytes==remote size; en downloads/ o elegido |
| QA-S09-02 | S09 | R18 | download mismo nombre | UI confirma overwrite (bug UI si no) |

### Llaves

| Caso ID | S | R | Pasos | Resultado |
|---------|---|---|-------|-----------|
| QA-S11-01 | S11 | R20 | discover ~/.ssh | sin .pub en lista seleccionable |
| QA-S12-01 | S12 | R24 | select key | SHA256 visible |
| QA-S13-01 | S13 | R21 | key chmod 644 Mac | warning; intento conexión documentado |
| QA-S14-01 | S14 | R23 | generate RSA nueva | .pub+priv; fingerprint; usable S03 |

### Perfiles

| Caso ID | S | R | Pasos | Resultado |
|---------|---|---|-------|-----------|
| QA-S17-01 | S17 | R25 | save/load reinicio | valores iguales |
| QA-S17-02 | S17 | R2 | switch perfil A→B | sesión A cerrada |

---

## L0 — Script smoke mock (ejecutar siempre)

```bash
pytest tests/test_sftp_* -q
PDE_DESKTOP_MOCK=1 ./run.sh   # cuando exista
```

Checklist L0:

- [ ] test_auth → OK
- [ ] list_dir fixture scheduled → nombres esperados JSON
- [ ] preview sample csv fixture
- [ ] sin acceso red en CI

---

## L1 — Smoke real (VPN)

Pre-flight (bloquear si falla):

- [ ] VPN conectada
- [ ] IP whitelist (infra)
- [ ] Llave privada path válido R7
- [ ] `chmod 600` llave (Mac/Linux)
- [ ] Perfil: host, user=profile_id, default_remote_path

Ejecutar mínimo: **QA-S05-01**, **QA-S06-01**, **QA-S09-01**

---

## L2 — Paridad plataforma

Ejecutar **misma matriz** en:

| | Mac | Windows |
|---|-----|---------|
| Setup | `./setup.sh` | `.\setup.ps1` |
| Run | `./run.sh` | `.\run.ps1` |
| Keys | `~/.ssh/` | `%USERPROFILE%\.ssh\` y `~/.ssh` |
| Mock | `PDE_DESKTOP_MOCK=1` | `$env:PDE_DESKTOP_MOCK="1"` |

---

## Comparación validator legacy

| Validator (TUI) | PDE Desktop | Caso QA |
|-----------------|-------------|---------|
| `./scripts/test-sftp-login.sh` | S05 UI/botón | QA-S05-01 |
| Browser F-keys | S06–S07 GUI | QA-S06-01 |
| F3 download | S09 + picker | QA-S09-01 |
| F4 SFTP_KEY_PATH | S03 selector | QA-S03-01 (**debe** reconectar) |
| `--check` BD+SFTP | solo S05 | no exigir BD |

Legacy docs: `draft/documentacion/legacy/QA_HANDOFF.md`

---

## Errores — árbol de diagnóstico QA

```text
Permission denied (publickey)
  → user == profile_id? → llave correcta S03? → L-02 escalar infra

Error reading SSH protocol banner
  → VPN? → whitelist? → esperar 30s R4 → no debugger pausado en connect

Private key not found
  → expanduser R7? → path Win R9?

Listado vacío
  → default_remote_path R10? → navegar manual config/<id>/

Preview vacío/garbage
  → encoding? → R12 truncado?
```

---

## Fuera de scope — no abrir bug SFTP

- Postgres, F7, ORPHAN/GHOST
- Duplicados CSV / pandas P01+
- Color, Lottie, layout (bug módulo UI)
- Upload/delete remoto (fuera de alcance)

---

## Plantilla bug

```markdown
## [SFTP-BUG-XXX] título

| Campo | Valor |
|-------|-------|
| Caso QA | QA-S__-__ |
| Sxx | |
| Rxx violada | |
| Plataforma | Mac / Win |
| VPN | on / off |
| Mock | on / off |
| profile_id | (sin secretos) |

### Pasos
1.

### Esperado (doc)
### Actual
### Evidencia
log / screenshot / tamaño archivo

### Severidad
Blocker / Major / Minor
```

---

## Plantilla reporte QA sprint

```markdown
# Reporte QA — Módulo SFTP

**Fecha:** | **Build:** | **Tester:**

## Resumen
- L0 mock: PASS/FAIL
- L1 real: PASS/FAIL/SKIPPED (motivo)
- L2 paridad Win: PASS/FAIL/SKIPPED

## Matriz
| Caso ID | Resultado | Notas |

## Bloqueantes abiertos
## Criterios-exito.md
(copiar checklist con [x]/[ ])
```

---

## Gate de release SFTP

Todos en `documentacion/sftp/criterios-exito.md` ✅ en **L0 + L1** mínimo; **L2** antes de demo cliente.

Escalar fixes: `@sftp-dev`. Validar fix: re-ejecutar caso ID afectado.

---

## Salida esperada del agente

Al planificar o ejecutar QA, entregar matriz con IDs **QA-Sxx-xx** y mapeo **S/R** explícito.
