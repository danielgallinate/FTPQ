# Perfiles JSON

Los schemas viven en documentación por módulo:

- SFTP: [`../documentacion/sftp/schema-perfil.draft.json`](../documentacion/sftp/schema-perfil.draft.json)
- Pandas: (pendiente) `documentacion/pandas/schema-reglas.draft.json`

Instancias de ejemplo (sin secretos) irán aquí cuando existan.
