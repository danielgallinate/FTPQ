#!/usr/bin/env bash
# Entorno local — macOS nativo o Windows WSL2
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

python3 - <<'PY'
import sys
if sys.version_info < (3, 12):
    raise SystemExit(
        f"Se requiere Python 3.12 o superior (actual: {sys.version.split()[0]})"
    )
PY

python3 -m venv .venv
.venv/bin/pip install -U pip
.venv/bin/pip install -r requirements.txt
echo "OK."
echo "  EMR QA (validador):  ./scripts/run_emr_qa_editor.sh"
echo "  Job CLI:             ./scripts/run_emr_qa_job.sh <job.json> --file <csv>"
echo "  SFTP job CLI:        ./scripts/run_sftp_job.sh <sftp_fetch.job.json>"
echo "  Cleanup local:       ./scripts/run_local_cleanup.sh <cleanup.job.json> -d <dir>"
echo "  PDE Desktop SFTP:    ./scripts/run_ui.sh"
