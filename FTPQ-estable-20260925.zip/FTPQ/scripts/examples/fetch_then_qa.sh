#!/usr/bin/env bash
# Ejemplo: fetch SFTP (job) y después validación EMR QA sobre un CSV local.
# Con mock no hace falta VPN. El CSV mock no coincide con extracts PDE reales:
# sustituye el job *_col y el --file por tus archivos.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"

export PDE_DESKTOP_MOCK=1

JOB_SFTP="$ROOT/mocks/fixtures/sftp/fetch-scheduled.job.json"
JOB_QA="$ROOT/emr-qa/knowledge_bases/default/jobs/sample_encounters.job.json"

./scripts/run_sftp_job.sh "$JOB_SFTP" --short

CSV="$(ls -1 "$ROOT/downloads/sftp-fetch-example/"*.csv 2>/dev/null | head -n 1 || true)"
if [[ -z "$CSV" ]]; then
  echo "ERROR: no se descargó ningún CSV." >&2
  exit 1
fi

echo "CSV local: $CSV"
echo "Siguiente paso (formato/calidad): ajusta el job *_col a tu extract."
set +e
./scripts/run_emr_qa_job.sh "$JOB_QA" --file "$CSV" --short
qa_rc=$?
set -e
echo "EMR QA exit=$qa_rc (el CSV mock no coincide con sample_encounters; en operación real usa tu job *_col)."
exit 0
