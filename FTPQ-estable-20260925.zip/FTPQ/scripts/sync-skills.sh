#!/usr/bin/env bash
# Sync skills/ (canonical) → .cursor/skills/ (Cursor @ mentions)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

mkdir -p .cursor/skills/sftp-dev .cursor/skills/sftp-qa .cursor/skills/sftp-peer-review .cursor/skills/context-maintainer .cursor/skills/ui-qa

cp skills/sftp/dev/SKILL.md           .cursor/skills/sftp-dev/SKILL.md
cp skills/sftp/qa/SKILL.md            .cursor/skills/sftp-qa/SKILL.md
cp skills/sftp/peer-review/SKILL.md   .cursor/skills/sftp-peer-review/SKILL.md
cp skills/sftp/reference.md             .cursor/skills/sftp-reference.md
cp skills/context/SKILL.md              .cursor/skills/context-maintainer/SKILL.md
cp skills/context/reference.md          .cursor/skills/context-reference.md
cp skills/ui/qa/SKILL.md                .cursor/skills/ui-qa/SKILL.md

echo "OK: skills synced to .cursor/skills/"
