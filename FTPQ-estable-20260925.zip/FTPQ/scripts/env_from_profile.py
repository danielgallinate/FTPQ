#!/usr/bin/env python3
"""Genera pde.env (SFTP only) desde profiles/default.json."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def profile_to_env(profile_path: Path) -> str:
    raw = json.loads(profile_path.read_text(encoding="utf-8"))
    sftp = raw.get("sftp", {})
    vis = raw.get("visualization", {})
    lines = [
        "# PDE Desktop — SFTP settings (no database credentials)",
        f"CONFIG_NAME={raw.get('profile_id', 'default')}",
        "",
        f"SFTP_HOST={sftp.get('host', '')}",
        f"SFTP_USER={sftp.get('user', '')}",
        f"SFTP_KEY_PATH={sftp.get('private_key_path', '~/.ssh/id_rsa')}",
        f"DOWNLOAD_DIR={sftp.get('download_dir', '~/PDE-Desktop/downloads')}",
        "",
        f"PDE_MAX_DISPLAY_ROWS={vis.get('max_display_rows', 50000)}",
        f"PDE_PANDAS_MAX_BYTES={vis.get('pandas_max_bytes', 52428800)}",
    ]
    return "\n".join(lines) + "\n"


def handoff_profile(profile_path: Path, *, platform: str) -> dict:
    raw = json.loads(profile_path.read_text(encoding="utf-8"))
    sftp = dict(raw.get("sftp", {}))
    key_name = Path(sftp.get("private_key_path", "~/.ssh/id_rsa")).name
    if platform == "portable":
        sftp["download_dir"] = "data/downloads"
        sftp["ssh_keys_dir"] = "data/ssh"
        sftp["private_key_path"] = f"data/ssh/{key_name}"
    elif platform == "mac":
        sftp["download_dir"] = "~/PDE-Desktop/downloads"
        sftp["ssh_keys_dir"] = "~/.ssh"
        sftp["private_key_path"] = f"~/.ssh/{key_name}"
    else:
        sftp["download_dir"] = "%USERPROFILE%\\PDE-Desktop\\downloads"
        sftp["ssh_keys_dir"] = "%USERPROFILE%\\.ssh"
        sftp["private_key_path"] = f"%USERPROFILE%\\.ssh\\{key_name}"
    return {
        "profile_id": raw.get("profile_id", "default"),
        "sftp": sftp,
        "visualization": raw.get("visualization", {}),
        "ui": raw.get("ui", {}),
    }


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    profile = root / "profiles" / "default.json"
    if len(sys.argv) > 1:
        profile = Path(sys.argv[1])
    if not profile.is_file():
        print(f"No existe {profile}", file=sys.stderr)
        return 1
    out_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else root / "dist" / "handoff-tmp"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "pde.env").write_text(profile_to_env(profile), encoding="utf-8")
    profiles = out_dir / "profiles"
    profiles.mkdir(exist_ok=True)
    import json as json_mod

    (profiles / "default.mac.json").write_text(
        json_mod.dumps(handoff_profile(profile, platform="mac"), indent=2, ensure_ascii=False)
        + "\n",
        encoding="utf-8",
    )
    (profiles / "default.windows.json").write_text(
        json_mod.dumps(handoff_profile(profile, platform="windows"), indent=2, ensure_ascii=False)
        + "\n",
        encoding="utf-8",
    )
    (profiles / "default.portable.json").write_text(
        json_mod.dumps(handoff_profile(profile, platform="portable"), indent=2, ensure_ascii=False)
        + "\n",
        encoding="utf-8",
    )
    portable_raw = handoff_profile(profile, platform="portable")
    ps = portable_raw["sftp"]
    vis = portable_raw.get("visualization", {})
    portable_env = "\n".join(
        [
            "# PDE Desktop — portable SFTP settings",
            f"CONFIG_NAME={portable_raw.get('profile_id', 'default')}",
            "",
            f"SFTP_HOST={ps.get('host', '')}",
            f"SFTP_USER={ps.get('user', '')}",
            f"SFTP_KEY_PATH={ps.get('private_key_path', 'data/ssh/id_rsa')}",
            f"DOWNLOAD_DIR={ps.get('download_dir', 'data/downloads')}",
            "",
            f"PDE_MAX_DISPLAY_ROWS={vis.get('max_display_rows', 50000)}",
            f"PDE_PANDAS_MAX_BYTES={vis.get('pandas_max_bytes', 52428800)}",
            "",
        ]
    )
    (out_dir / "pde.portable.env").write_text(portable_env, encoding="utf-8")
    print(out_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
