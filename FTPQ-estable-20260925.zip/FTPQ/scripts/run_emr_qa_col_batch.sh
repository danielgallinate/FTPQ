#!/usr/bin/env bash
# Ejecuta jobs EMR QA contra CSVs PDE emparejados por regex en schema/catalog del job.
#
# Uso:
#   ./scripts/run_emr_qa_col_batch.sh "/Users/.../PDE TEST"
#   ./scripts/run_emr_qa_col_batch.sh --lang en --recursive "/Users/.../PDE TEST"
#   ./scripts/run_emr_qa_col_batch.sh --dry-run "/Users/.../PDE TEST"
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python3"

if [[ ! -x "$PY" ]]; then
  echo "ERROR: no hay entorno virtual (.venv)." >&2
  echo "Ejecuta: ./scripts/setup.sh" >&2
  exit 1
fi

ARGS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --lang)
      case "$(echo "$2" | tr '[:upper:]' '[:lower:]')" in
        en|eng|english) ARGS+=(--lang en) ;;
        es|esp|spanish) ARGS+=(--lang es) ;;
        *)
          echo "ERROR: --lang debe ser es o en (recibido: $2)" >&2
          exit 2
          ;;
      esac
      shift 2
      ;;
    *)
      ARGS+=("$1")
      shift
      ;;
  esac
done

exec "$PY" emr-qa/batch_col.py "${ARGS[@]}"
