#!/usr/bin/env python3
"""Auditoría rápida de contexto PDE Desktop — sin dependencias externas."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Pares canonical → espejo Cursor
SKILL_SYNC = [
    ("skills/sftp/dev/SKILL.md", ".cursor/skills/sftp-dev/SKILL.md"),
    ("skills/sftp/qa/SKILL.md", ".cursor/skills/sftp-qa/SKILL.md"),
    ("skills/sftp/peer-review/SKILL.md", ".cursor/skills/sftp-peer-review/SKILL.md"),
    ("skills/sftp/reference.md", ".cursor/skills/sftp-reference.md"),
    ("skills/context/SKILL.md", ".cursor/skills/context-maintainer/SKILL.md"),
    ("skills/context/reference.md", ".cursor/skills/context-reference.md"),
]

REQUIRED_DOCS = {
    "sftp": [
        "README.md",
        "funcionalidades.md",
        "restricciones.md",
        "contrato.md",
        "errores.md",
        "criterios-exito.md",
    ],
    "pandas": ["README.md", "funcionalidades.md", "restricciones.md"],
    "ui": ["README.md", "funcionalidades.md", "restricciones.md"],
}

STALE_PATTERNS = [
    "documentacion/paso-01",
    "documentacion/paso-02",
    "paso-01-entender",
    "paso-02-funcionalidades",
]

INDEX_FILES = [
    "AGENTS.md",
    "documentacion/README.md",
    "skills/README.md",
    ".cursor/skills/README.md",
]


def file_hash(path: Path) -> str | None:
    if not path.is_file():
        return None
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_sync() -> list[str]:
    issues: list[str] = []
    for src, dst in SKILL_SYNC:
        sp, dp = ROOT / src, ROOT / dst
        if not sp.is_file():
            issues.append(f"MISSING canonical: {src}")
            continue
        if not dp.is_file():
            issues.append(f"MISSING mirror: {dst} (run scripts/sync-skills.sh)")
            continue
        if file_hash(sp) != file_hash(dp):
            issues.append(f"OUT OF SYNC: {src} ≠ {dst}")
    return issues


def check_module_docs() -> list[str]:
    issues: list[str] = []
    for module, files in REQUIRED_DOCS.items():
        base = ROOT / "documentacion" / module
        if not base.is_dir():
            issues.append(f"MISSING module dir: documentacion/{module}/")
            continue
        for name in files:
            if not (base / name).is_file():
                issues.append(f"MISSING doc: documentacion/{module}/{name}")
    return issues


def check_stale_refs() -> list[str]:
    issues: list[str] = []
    scan_roots = [ROOT / "AGENTS.md", ROOT / "documentacion", ROOT / "skills"]
    for base in scan_roots:
        paths = [base] if base.is_file() else base.rglob("*.md")
        for path in paths:
            if "draft" in path.parts and base != ROOT / "AGENTS.md":
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for pat in STALE_PATTERNS:
                if pat in text:
                    rel = path.relative_to(ROOT)
                    issues.append(f"STALE REF '{pat}' in {rel}")
    return issues


def check_indexes() -> list[str]:
    issues: list[str] = []
    for rel in INDEX_FILES:
        if not (ROOT / rel).is_file():
            issues.append(f"MISSING index: {rel}")
    return issues


def check_skills_gaps() -> list[str]:
    issues: list[str] = []
    for module in ("pandas", "ui"):
        ref = ROOT / "skills" / module / "reference.md"
        dev = ROOT / "skills" / module / "dev" / "SKILL.md"
        if not ref.is_file():
            issues.append(f"PENDING skill ref: skills/{module}/reference.md")
        if not dev.is_file():
            issues.append(f"PENDING skill dev: skills/{module}/dev/SKILL.md")
    return issues


def main() -> int:
    sections = {
        "sync": check_sync(),
        "indexes": check_indexes(),
        "module_docs": check_module_docs(),
        "stale_refs": check_stale_refs(),
        "skills_gaps": check_skills_gaps(),
    }
    total = sum(len(v) for v in sections.values())

    print("# Context audit — PDE Desktop\n")
    for name, items in sections.items():
        status = "OK" if not items else f"{len(items)} issue(s)"
        print(f"## {name}: {status}")
        for item in items:
            print(f"  - {item}")
        print()

    summary = {
        "root": str(ROOT),
        "total_issues": total,
        "sections": {k: len(v) for k, v in sections.items()},
        "issues": sections,
    }
    if "--json" in sys.argv:
        print(json.dumps(summary, indent=2))

    return 0 if total == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
