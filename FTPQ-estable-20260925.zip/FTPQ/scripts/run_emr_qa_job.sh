#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python3"

if [[ ! -x "$PY" ]]; then
  echo "ERROR: no hay entorno virtual (.venv)." >&2
  echo "Ejecuta: ./scripts/setup.sh" >&2
  exit 1
fi

exec "$PY" emr-qa/run_job.py "$@"
