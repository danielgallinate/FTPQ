# Scripts PDE Desktop 1.0.0

Solo **dos formas** de ejecutar la app:

| Entorno | Scripts |
|---------|---------|
| macOS nativo | `setup.sh` → `run_ui.sh` |
| Windows (WSL2) | Los mismos `.sh` dentro de la distro Linux |

Requisito: **Python 3.12+** (venv creado por `setup.sh`).

## Utilidades

| Script | Uso |
|--------|-----|
| `create_release_tag.sh` | Tag git `v1.0.0` si hay repo |
| `sync-skills.sh` | Sync skills → `.cursor/skills/` |
| `context-audit.py` | Auditoría de contexto del repo |
| `env_from_profile.py` | Genera `.env` desde perfil JSON (dev) |

Instaladores portable, embed, handoff y build-kit Windows nativo: **eliminados** — ver [`ARCHIVADO-INSTALADORES.md`](./ARCHIVADO-INSTALADORES.md).
