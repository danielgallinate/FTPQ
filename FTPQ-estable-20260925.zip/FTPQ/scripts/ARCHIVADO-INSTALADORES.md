# Instaladores cross-platform — archivado (1.0.0)

**2026-07-17** — Versión estable **1.0.0** congela el producto como **código fuente + venv**.

## Eliminado del repo

- `dist/releases/*` (build-kits, portable zip, copias embebidas)
- `installer/` (Inno Setup)
- `windows-native/`
- `scripts/handoff/`, `scripts/portable/`
- `scripts/build_*`, `setup.cmd`, `setup.ps1`, `setup_embed.cmd`, `run_ui.ps1`
- `requirements-build.txt` (PyInstaller)
- Raíz: `CHECK-WINDOWS.bat`, `BUILD-*.cmd`, `BUILD-WINDOWS*.txt`, `CURSOR-WINDOWS.md`

## Sustituido por

| Antes | Ahora |
|-------|-------|
| Portable Mac/Win | `./scripts/setup.sh` + `./scripts/run_ui.sh` |
| Windows nativo CMD/embed | **WSL2** + mismos scripts `.sh` |
| Handoff zip a colega (código fuente) | Permitido — [`documentacion/alcance-validador-tabular.md`](../documentacion/alcance-validador-tabular.md) |

## Recuperar algo del historial

Si necesitás un script borrado, buscá en commits/tags anteriores a `v1.0.0` (p. ej. `v1.0.0-beta.3`). No se mantiene en la rama estable.
