#!/usr/bin/env bash
# Crea tag anotado si el directorio es un repo git
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
TAG="$("$ROOT/.venv/bin/python3" -c "from ui.version import release_tag; print(release_tag())" 2>/dev/null || echo "v1.0.0-beta.1")"
MSG="PDE Desktop $(cat release/VERSION 2>/dev/null || echo 1.0.0) — estable"
if git rev-parse --git-dir >/dev/null 2>&1; then
  git tag -a "$TAG" -m "$MSG"
  echo "Tag creado: $TAG"
  echo "Push: git push origin $TAG"
else
  echo "No hay repo git. Tag documentado en release/TAG-${TAG#v}.txt"
fi
