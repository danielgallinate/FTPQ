#!/usr/bin/env bash
# Empaqueta código fuente para handoff (sin venv, secretos, datos locales ni archivos pesados).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

STAMP="$(date +%Y%m%d)"
BUNDLE_NAME="FTPQ-handoff-${STAMP}"
OUT_DIR="${1:-$HOME/Downloads}"
OUT_ZIP="$OUT_DIR/${BUNDLE_NAME}.zip"
STAGE="$(mktemp -d "${TMPDIR:-/tmp}/ftpq-handoff.XXXXXX")"

cleanup() {
  rm -rf "$STAGE"
}
trap cleanup EXIT

mkdir -p "$OUT_DIR" "$STAGE/$BUNDLE_NAME"

rsync -a --delete \
  --exclude '.git/' \
  --exclude '.venv/' \
  --exclude '__pycache__/' \
  --exclude '*.pyc' \
  --exclude '.env' \
  --exclude '.env.*' \
  --exclude 'emr-qa/config/template_encryption.key' \
  --exclude 'SFTP TOOL/' \
  --exclude 'draft/' \
  --exclude 'emr-qa/ALPHA/' \
  --exclude 'downloads/' \
  --exclude 'ui/assets/wallpapers/' \
  --exclude 'emr-qa/knowledge_bases/default/templates/case_patient.json' \
  --exclude '.cursor/' \
  --exclude '*.zip' \
  --exclude 'dist/' \
  --exclude 'profiles/default.json' \
  "$ROOT/" "$STAGE/$BUNDLE_NAME/"

cp "$ROOT/profiles/default.handoff.json" "$STAGE/$BUNDLE_NAME/profiles/default.json"

(
  cd "$STAGE"
  rm -f "$OUT_ZIP"
  zip -r "$OUT_ZIP" "$BUNDLE_NAME" > /dev/null
)

echo "Creado: $OUT_ZIP"
echo "Tamaño: $(du -h "$OUT_ZIP" | cut -f1)"
echo ""
echo "Instrucciones para quien recibe (WSL):"
echo "  unzip ${BUNDLE_NAME}.zip"
echo "  cd ${BUNDLE_NAME}"
echo "  chmod +x scripts/*.sh && ./scripts/setup.sh"
echo "  ./scripts/run_emr_qa_editor.sh"
echo ""
echo "Guía: HANDOFF.md · instalacion/windows-wsl2.md"
