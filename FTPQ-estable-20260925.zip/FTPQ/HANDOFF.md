# Handoff — validador tabular FTPQ

Herramienta local para **revisar archivos CSV/TSV** con pandas: el núcleo es **repetir el contrato de entrega** (columnas/tipos), no certificar calidad de contenido. UI opcional; jobs headless para el veredicto.

**Tal cual — sin garantías.** Quien instala decide qué archivos analiza y asume su entorno.

## Requisitos

- macOS nativo **o** Windows con **WSL2** (Ubuntu recomendado) para la app completa
- Python **3.12+** dentro del entorno donde ejecutes los scripts
- **Solo tests estructurales en Windows nativo (CMD/PowerShell, sin WSL2 ni UI):** carpeta [`windows-cli/`](windows-cli/README.md)

---

## Instalación rápida (WSL — tu compañero)

1. Descomprimir el zip en WSL (mejor rendimiento en `~/FTPQ`, no solo en `/mnt/c/...`):

```bash
cd ~
unzip ~/Downloads/FTPQ-handoff-*.zip
cd FTPQ-handoff-*
chmod +x scripts/*.sh
./scripts/setup.sh
```

2. Si falta Python 3.12:

```bash
sudo apt update
sudo apt install -y python3.12 python3.12-venv
python3.12 --version
```

3. Arrancar la UI (EMR QA):

```bash
./scripts/run_emr_qa_editor.sh
```

En **Windows 11 + WSLg** la ventana PySide6 suele abrir sola. Si no: `wsl --update` en PowerShell y reiniciar WSL (`wsl --shutdown`).

Guía WSL completa: [`instalacion/windows-wsl2.md`](instalacion/windows-wsl2.md)

---

## Instalación (macOS)

```bash
unzip FTPQ-handoff-*.zip
cd FTPQ-handoff-*
chmod +x scripts/*.sh
./scripts/setup.sh
./scripts/run_emr_qa_editor.sh
```

---

## Qué arrancar

| Script | Uso |
|--------|-----|
| `./scripts/run_emr_qa_editor.sh` | **Validador tabular** (UI principal) |
| `./scripts/run_emr_qa_job.sh` | Un job JSON headless (CI / terminal) |
| `./scripts/run_sftp_job.sh` | Job SFTP: conectar, existencia, descarga en secuencia |
| `./scripts/run_local_cleanup.sh` | Borra CSV locales por glob (el CI decide cuándo) |
| `./scripts/run_emr_qa_col_batch.sh` | Varios jobs `*_col` sobre una carpeta de CSV |
| `./scripts/run_ui.sh` | PDE Desktop SFTP (legacy, opcional) |

### Ejemplo CLI (estructura / esquema)

```bash
./scripts/run_emr_qa_job.sh \
  emr-qa/knowledge_bases/default/jobs/clinic_extract_col.job.json \
  --file "/ruta/al/extract.csv" \
  --lang es \
  --json-out /tmp/clinic-result.json
```

Exit code: `0` = PASS, `1` = FAIL de datos, `2` = error (archivo/job). El CLI admite hasta **1 GiB** por archivo (`CLI_PANDAS_MAX_BYTES`) y valida el archivo completo.

La UI mantiene su tope de 200 MiB para carga completa: por encima de eso abre una **muestra** de hasta `UI_SAMPLE_MAX_ROWS` (100 000) filas en vez de fallar. El dataset queda marcado `sampled=True` con `estimated_total_rows` aproximado por bytes/línea, y el visor y los mensajes lo indican. Las métricas y validaciones de la UI en ese caso describen solo la muestra; para el veredicto sobre el archivo completo use el CLI.

### Job SFTP (existencia o descarga)

El JSON `kind: sftp_fetch` no lleva secretos: solo la **ruta** a un perfil SFTP. El destino de descarga puede ir en el JSON o por parámetro (`--local-dir`), útil cuando la carpeta no es navegable en UI:

```bash
PDE_DESKTOP_MOCK=1 ./scripts/run_sftp_job.sh \
  mocks/fixtures/sftp/fetch-scheduled.job.json \
  --local-dir ./downloads/run-001 \
  --json-out /tmp/sftp-fetch.json
```

Composición fetch → QA: [`scripts/examples/fetch_then_qa.sh`](scripts/examples/fetch_then_qa.sh). El CSV mock no es un extract PDE; en operación real apunta `--file` a lo descargado y un job `*_col`.

Exit code SFTP: `0` = PASS, `1` = FAIL (faltantes/colisión), `2` = perfil o conexión.

Chequeo remoto sin descargar ni abrir archivos:

```bash
./scripts/run_sftp_job.sh \
  sftp_jobs/examples/exist-files-by-date.job.json \
  --as-of 20260916 \
  --json-out /tmp/sftp-exist.json
```

`download: false` solo ejecuta `list_dir`. `{date}` usa `YYYYMMDD`: toma la
fecha local o el valor reproducible de `--as-of`. Cada `expect` admite
`match_type: "glob"` (predeterminado) o `"regex"`.

Descarga completa de una configuración, sin editar el JSON:

```bash
./scripts/run_sftp_job.sh \
  sftp_jobs/examples/fetch-config-tree.job.json \
  --sftp-user Daniel_test_config11 \
  --private-key "~/.ssh/pde_daniel_test_config11_rsa" \
  --local-dir "/ruta/base/test auto" \
  --json-out "/ruta/resultados/sftp.json" \
  --error-out "/ruta/resultados/sftp-error.json"
```

Con `destination_name: "{sftp_user}"`, el destino efectivo es
`<local-dir>/Daniel_test_config11/`. `on_collision: fail` evita mezclarlo con
una descarga anterior. `recursive: true` conserva las carpetas remotas y crea
`_download_manifest.json`.

### Limpieza local (job tonto)

No mira el resultado de QA ni el SFTP. El **CI** decide si lo llama. Solo borra archivos cuyo **nombre** coincida con el glob (p. ej. `*.csv`); deja `*.json` y `*.log` si no están en `patterns`.

```bash
./scripts/run_local_cleanup.sh \
  mocks/fixtures/sftp/cleanup-extracts.job.json \
  --local-dir ./downloads/run-001 \
  --json-out /tmp/cleanup.json \
  --error-out /tmp/cleanup-error.json
```

Ejemplo de pipeline en CI (el job de borrado no tiene `on_success`):

```bash
WORK="./downloads/${RUN_ID}"
./scripts/run_sftp_job.sh fetch.job.json --local-dir "$WORK" --json-out "$WORK/sftp.json"
./scripts/run_emr_qa_job.sh charges_extract_col.job.json --file "$WORK/Charges_x.csv" --json-out "$WORK/qa.json"
# el CI elige: siempre, nunca, o solo si QA pasó
./scripts/run_local_cleanup.sh cleanup.job.json -d "$WORK" --json-out "$WORK/cleanup.json"
```

### Batch sobre carpeta de CSV PDE

```bash
./scripts/run_emr_qa_col_batch.sh --lang es --short "/ruta/carpeta/csv"
```

---

## Flujo UI rápido

1. Navegador local → elegir CSV (p. ej. en `~/Downloads`).
2. **Abrir** — visor tabular.
3. Tabs **Esquema** / **Estructura** — catálogos columnar.
4. **Probar** / **Run job** — validación con plantilla o job.
5. Export PDF / CSV desde métricas.

Fixture: `emr-qa/fixtures/sample_encounters.csv`  
Jobs y catálogos: `emr-qa/knowledge_bases/default/jobs/*.job.json` y `*.schema.json`

---

## No incluido en el zip

- `.venv/` — se crea con `./scripts/setup.sh`
- Secretos (`.env`, llaves SSH, `template_encryption.key`)
- Datos locales (`downloads/`, PHI real)
- Código archivado (`emr-qa/ALPHA/`, `draft/`)

## Problemas frecuentes

| Síntoma | Acción |
|---------|--------|
| `no hay entorno virtual` | `./scripts/setup.sh` |
| Windows CMD no funciona | Usar **WSL2** y bash |
| UI no abre en WSL | WSLg / `wsl --update` |
| SFTP no conecta tras importar `.env` | **Settings → Paths → Import .env → Save** (vuelve a importar con zip reciente). Borrar perfil viejo: `rm profiles/default.json` y copiar `profiles/default.handoff.json` → `profiles/default.json` |
| Sigue con user/host de otra persona | El zip antiguo traía credenciales embebidas; regenerar con `./scripts/package_handoff.sh` |
| SFTP (solo `run_ui.sh`) | VPN en **Windows** + llave en `~/.ssh` WSL + `SFTP_HOST` en `.env` |

Spec: [`documentacion/alcance-validador-tabular.md`](documentacion/alcance-validador-tabular.md)
